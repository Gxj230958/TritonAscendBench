"""Task L2_22_fused_dual_residual_rmsnorm -- Triton-Ascend candidate (round 3).

Operation (per row of the 2-D activation), unchanged across all three rounds:

    normed1 = (x / sqrt(mean(x*x) + eps)) * weight1          # fp32 math
    mid     = residual + bf16(normed1)                       # add AFTER a bf16 round
    rms2    = sqrt(mean(mid*mid) + eps)                      # fp32, over the bf16 mid
    output  = bf16((mid / rms2) * weight2)

Diagnosis of rounds 1-2
-----------------------
Rounds 1 and 2 reported byte-for-byte identical errors on all 49 shapes, and in
both rounds ONLY `output` failed; `mid` matched the eager reference everywhere.
That pairing pins the defect unusually tightly.

1. The first stage is exonerated end to end, including the fp32 -> bfloat16 store
   path: the stored `mid` register is an fp32-domain sum that the store lowering
   narrows, and it lands bit-exactly on 49/49 shapes.  The sum of squares, the
   divide, the multiply, the sqrt and the eps placement are all shared with `mid`
   and are therefore right too.
2. Round 2 changed only the rounding applied to the final store and moved not one
   reported error.  So the value handed to that store was already wrong before
   any cast could touch it: the defect is in stage 2's INPUT, not in its output
   conversion.
3. The numbers describe that defect specifically:
     * max_abs lands in the 2**-7..2**-3 band -- about half a bfloat16 ULP of
       `mid` -- and scales with the largest |mid| in the shape (0.0312 at D=64,
       0.0625 around D~1-4k, 0.125 at the biggest shapes).  That is what skipping
       a narrowing before the second normalisation costs; no summation order or
       rounding mode produces it.
     * max_rel is modest (0.0067-0.4) on the shapes with few elements (P16 16x2,
       P17 16x4, P19 16x8, P20 16x16, H5 1x2) and absurd, 1e7-1e10, on every
       shape with many elements.  A stratospheric relative error means the
       reference value is EXACTLY zero while the candidate is small but nonzero.
       `output` is exactly zero only when bfloat16 `mid` is exactly zero, i.e.
       where `residual` cancels `bf16(normed1)` -- and a kernel that normalises
       the UNROUNDED sum has no such zero.  Whether a shape contains such a
       cancellation is a pure element-count lottery, and the receipt splits
       exactly that way, shape by shape.

So stage 2 consumes `residual + normed1` before stage 1's result was narrowed,
even though the source spells that narrowing as `(...).to(r.dtype)` and asks for
the value back with `a2r.to(tl.float32)`.  It is the only place in the kernel
where a precision requirement rides on a TYPE rather than on an operation: a
narrow-then-widen pair never separated by storage is a no-op in value, so the
backend may fold it, and folding it leaves `mid` byte-identical (the add is
bf16 + bf16 either way and the store rounds on its own) while quietly feeding
stage 2 the unrounded sum.  Every symptom above follows from that single fold.

Fix for round 3 (one variable: how the bfloat16 narrowings are performed)
-------------------------------------------------------------------------
All three narrowings the eager reference performs are now forced by integer bit
manipulation on the fp32 pattern -- canonical RTNE: bias by half an ULP plus the
LSB of the kept mantissa, then clear the low 16 bits.  The value that comes out is
an fp32 register with zero bits below bit 16, i.e. exactly a bfloat16 value.
Consequences:

  * the rounding cannot be folded away; integer add/shift/and are load-bearing
    operations, not conversions;
  * one derived `m` now feeds BOTH the `mid` store and stage 2, so the two cannot
    disagree and the kernel does less work than rounds 1-2 (no duplicated divide
    and multiply).  Between two bfloat16-quantised operands, an fp32 add followed
    by one RTNE is exactly how a bfloat16 add is evaluated in hardware and in
    torch's bf16 `+` (upcast, one fp32 add, one round), so `mid` keeps matching
    the reference bit for bit -- it just now matches by construction instead of by
    a promise;
  * both reductions square exactly-bf16-representable fp32 values, and such a
    product needs only 16 mantissa bits, so it is EXACT in fp32.  This kernel and
    the eager reference now sum the same set of fp32 numbers and only summation order
    can differ.  Rounds 1-2 lost that property in the second reduction;
  * `output` reaches memory the same way `mid` demonstrably did in rounds 1-2: as
    a bfloat16 register holding a value the conversion cannot alter.

Nothing relies on store-to-load visibility inside a program: stage 2 keeps its
operand in registers, so this remains one kernel launch with one program per row.

Geometry is untouched: single tile up to SINGLE_BLOCK_LIMIT = 4096 with
BLOCK_SIZE = next_power_of_2(hidden_dim), otherwise three chunked passes with
BLOCK_SIZE = 2048; same grid, same deterministic num_warps rule, same
{"output", "mid"} dict.

Off-device validation (no NPU touched; see notes.md): Triton interpret mode over
the shape grid, plus an fp32 bit-level emulation showing this integer RTNE is
identical to torch's bfloat16 cast and that the full three-narrowing chain
reproduces the reference `output` and `mid` bit-for-bit.  Interpret mode itself
confirmed the failure mode being fixed here: emulated bfloat16 register arithmetic
returns junk unless the value is forced through a representation the host can
represent at all.

"""

import torch
import triton
import triton.language as tl

# Rows at or below this width are handled by the single-tile path.
SINGLE_BLOCK_LIMIT = 4096
# Tile width used by the chunked path.
CHUNK_BLOCK_SIZE = 2048


@triton.jit
def fused_dual_residual_rmsnorm_kernel(
    output_ptr,
    mid_ptr,
    activ_ptr,
    residual_ptr,
    weight1_ptr,
    weight2_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    input_start = pid * hidden_dim
    offsets = tl.arange(0, BLOCK_SIZE)

    if BLOCK_SIZE >= hidden_dim:
        # ---- single-tile path -------------------------------------------
        mask = offsets < hidden_dim
        a_ = tl.load(activ_ptr + input_start + offsets, mask=mask, other=0.0)
        a = a_.to(tl.float32)
        rms = tl.sqrt(tl.sum(a * a, axis=0) / hidden_dim + eps)
        r_ = tl.load(residual_ptr + input_start + offsets, mask=mask, other=0.0)
        r = r_.to(tl.float32)
        w1_ = tl.load(weight1_ptr + offsets, mask=mask, other=0.0)
        w1 = w1_.to(tl.float32)

        # bf16(RMSNorm1(x)): RTNE on the fp32 bits, kept as an exact-bf16 fp32.
        u = (a / rms * w1).to(tl.int32, bitcast=True)
        u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
        n = u.to(tl.float32, bitcast=True)
        # mid = residual + normed1, rounded once, the same way.
        u = (r + n).to(tl.int32, bitcast=True)
        u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
        m = u.to(tl.float32, bitcast=True)
        tl.store(mid_ptr + input_start + offsets, m.to(tl.bfloat16), mask=mask)

        # Second reduction consumes the ROUNDED mid, as the reference does.
        rms2 = tl.sqrt(tl.sum(m * m, axis=0) / hidden_dim + eps)
        w2_ = tl.load(weight2_ptr + offsets, mask=mask, other=0.0)
        w2 = w2_.to(tl.float32)
        u = (m / rms2 * w2).to(tl.int32, bitcast=True)
        u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
        tl.store(output_ptr + input_start + offsets,
                 u.to(tl.float32, bitcast=True).to(tl.bfloat16), mask=mask)
    else:
        # ---- chunked path (long rows) ------------------------------------
        # pass 1: sum of squares of the raw activation
        acc = tl.zeros([BLOCK_SIZE], dtype=tl.float32)
        for start in range(0, hidden_dim, BLOCK_SIZE):
            offs = start + offsets
            msk = offs < hidden_dim
            a = tl.load(activ_ptr + input_start + offs, mask=msk,
                        other=0.0).to(tl.float32)
            acc += a * a
        rms = tl.sqrt(tl.sum(acc, axis=0) / hidden_dim + eps)

        # pass 2: rounded mid + its sum of squares
        acc2 = tl.zeros([BLOCK_SIZE], dtype=tl.float32)
        for start in range(0, hidden_dim, BLOCK_SIZE):
            offs = start + offsets
            msk = offs < hidden_dim
            a = tl.load(activ_ptr + input_start + offs, mask=msk,
                        other=0.0).to(tl.float32)
            r = tl.load(residual_ptr + input_start + offs, mask=msk,
                        other=0.0).to(tl.float32)
            w1 = tl.load(weight1_ptr + offs, mask=msk,
                         other=0.0).to(tl.float32)
            u = (a / rms * w1).to(tl.int32, bitcast=True)
            u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
            n = u.to(tl.float32, bitcast=True)
            u = (r + n).to(tl.int32, bitcast=True)
            u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
            m = u.to(tl.float32, bitcast=True)
            tl.store(mid_ptr + input_start + offs, m.to(tl.bfloat16), mask=msk)
            acc2 += m * m
        rms2 = tl.sqrt(tl.sum(acc2, axis=0) / hidden_dim + eps)

        # pass 3: second normalisation, mid re-derived with the same forced
        # rounding (bit-identical to what pass 2 stored, so no load-after-store
        # visibility is relied upon)
        for start in range(0, hidden_dim, BLOCK_SIZE):
            offs = start + offsets
            msk = offs < hidden_dim
            a = tl.load(activ_ptr + input_start + offs, mask=msk,
                        other=0.0).to(tl.float32)
            r = tl.load(residual_ptr + input_start + offs, mask=msk,
                        other=0.0).to(tl.float32)
            w1 = tl.load(weight1_ptr + offs, mask=msk,
                         other=0.0).to(tl.float32)
            u = (a / rms * w1).to(tl.int32, bitcast=True)
            u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
            n = u.to(tl.float32, bitcast=True)
            u = (r + n).to(tl.int32, bitcast=True)
            u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
            m = u.to(tl.float32, bitcast=True)
            w2 = tl.load(weight2_ptr + offs, mask=msk,
                         other=0.0).to(tl.float32)
            u = (m / rms2 * w2).to(tl.int32, bitcast=True)
            u = (u + 0x7FFF + ((u >> 16) & 1)) & -65536
            tl.store(output_ptr + input_start + offs,
                     u.to(tl.float32, bitcast=True).to(tl.bfloat16), mask=msk)


def _pick(inputs, names, required=True):
    for name in names:
        if name in inputs:
            return inputs[name]
    if required:
        raise KeyError("missing input, tried " + repr(tuple(names)))
    return None


def npu_triton_impl(inputs: dict) -> dict:
    x = _pick(inputs, ("x", "activ", "activation"))
    residual = _pick(inputs, ("residual", "residual_a"))
    weight1 = _pick(inputs, ("weight1", "w1", "weight"))
    weight2 = _pick(inputs, ("weight2", "w2"))
    eps_val = _pick(inputs, ("eps",), required=False)
    eps = 1e-6 if eps_val is None else float(eps_val)

    hidden_dim = int(x.shape[-1])
    x_flat = x.contiguous().view(-1, hidden_dim)
    res_flat = residual.contiguous().view(-1, hidden_dim)
    w1 = weight1.contiguous()
    w2 = weight2.contiguous()

    output = torch.empty_like(x)
    mid = torch.empty_like(x)

    rows = int(x_flat.shape[0])
    if rows == 0:
        return {"output": output, "mid": mid}

    if hidden_dim <= SINGLE_BLOCK_LIMIT:
        block_size = triton.next_power_of_2(hidden_dim)
    else:
        block_size = CHUNK_BLOCK_SIZE
    num_warps = min(max(triton.next_power_of_2((block_size + 1023) // 1024), 4), 8)

    fused_dual_residual_rmsnorm_kernel[(rows,)](
        output,
        mid,
        x_flat,
        res_flat,
        w1,
        w2,
        eps=eps,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=block_size,
        num_warps=num_warps,
    )

    return {"output": output, "mid": mid}


# Alias kept so the file can also be driven through the generic dict entrypoint.
run = npu_triton_impl
