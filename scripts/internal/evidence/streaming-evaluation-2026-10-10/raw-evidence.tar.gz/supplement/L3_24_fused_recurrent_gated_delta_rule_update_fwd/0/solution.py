"""
L3_24 fused recurrent gated-delta rule update forward — NPU triton solution (round 2).

Recurrence (per (batch, head) pair, token-by-token):

    S = exp(g_t) * S                    # decay carried state
    kS = S @ k_t^T                      # contraction over K
    delta = (v_t - kS) * beta_t         # gated delta
    S = S + delta[:, None] * k_t        # rank-1 state update
    o_t = scale * (S @ q_t^T)           # output from updated state

State S has shape [V, K].  Parallelisation: one program per
(V-tile, batch*head), sequential loop over T.

Round-2 fix: removed host-side float(inputs["scale"]) which triggered
the static-check blocker ("host-side float(...) — forces Tensor →
Python; use a triton kernel").  The scale value is a Python float
derived from shapes.yaml, so we pass it through directly.
"""

import torch
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["T"])
def _update_kernel(
    q_ptr, k_ptr, v_ptr, g_ptr, beta_ptr, o_ptr,
    h0_source_ptr, h0_indices_ptr,
    scale,
    T,
    B: tl.constexpr, H: tl.constexpr, K: tl.constexpr, V: tl.constexpr,
    BK: tl.constexpr, BV: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    DISABLE_STATE_UPDATE: tl.constexpr,
):
    """Each program owns (i_v, i_n, i_h).

    i_v  – V-tile index
    i_n  – batch index
    i_h  – head index

    State b_h is [BV, BK] float32 carried through the T-loop.
    """
    i_v = tl.program_id(0)
    i_nh = tl.program_id(1)
    i_n = i_nh // H
    i_h = i_nh % H

    # Tile coordinate vectors
    off_v = i_v * BV + tl.arange(0, BV)
    off_k = tl.arange(0, BK)

    mask_v = off_v < V
    mask_k = off_k < K
    mask_h = mask_v[:, None] & mask_k[None, :]

    # Starting time offset for this batch element
    bos = i_n * T

    # Flat pointer bases (contiguous tensors)
    # q, k: [B, T, H, K]  — stride H*K per time-step
    p_q = q_ptr + (bos * H + i_h) * K
    p_k = k_ptr + (bos * H + i_h) * K
    # v: [B, T, H, V]     — stride H*V per time-step
    p_v = v_ptr + (bos * H + i_h) * V
    # g, beta: [B, T, H]  — stride H per time-step
    p_g = g_ptr + bos * H + i_h
    p_beta = beta_ptr + bos * H + i_h
    # o: [B, T, H, V]     — stride H*V per time-step
    p_o = o_ptr + (bos * H + i_h) * V

    # Accumulate state in float32
    b_h = tl.zeros([BV, BK], dtype=tl.float32)

    if USE_INITIAL_STATE:
        idx = tl.load(h0_indices_ptr + i_n)
        if idx >= 0:
            # h0_source layout: [B, H, V, K]
            p_h0 = h0_source_ptr + idx * H * V * K + i_h * V * K
            p_h0_tile = p_h0 + off_v[:, None] * K + off_k[None, :]
            b_h = b_h + tl.load(p_h0_tile, mask=mask_h, other=0.0).to(tl.float32)

    scale_f32 = scale.to(tl.float32)

    # ====== sequential token loop ======
    for _ in range(0, T):
        # --- load current-token data --------------------------------
        b_q  = tl.load(p_q  + off_k, mask=mask_k, other=0.0).to(tl.float32)
        b_k  = tl.load(p_k  + off_k, mask=mask_k, other=0.0).to(tl.float32)
        b_v  = tl.load(p_v  + off_v, mask=mask_v, other=0.0).to(tl.float32)
        b_g  = tl.load(p_g).to(tl.float32)
        b_beta = tl.load(p_beta).to(tl.float32)

        # --- gated-delta recurrence (matches original kernel order) -
        # 1. scale query
        b_q = b_q * scale_f32
        # 2. decay state
        b_h *= tl.exp(b_g)
        # 3. kS contraction and subtract from v
        b_v -= tl.sum(b_h * b_k[None, :], 1)
        # 4. apply beta gate
        b_v *= b_beta
        # 5. rank-1 state update
        b_h += b_v[:, None] * b_k[None, :]
        # 6. output = S @ (scale*q)
        b_o = tl.sum(b_h * b_q[None, :], 1)

        # --- store output -------------------------------------------
        tl.store(p_o + off_v, b_o.to(tl.bfloat16), mask=mask_v)

        # --- advance pointers to next time step ---------------------
        p_q  += H * K
        p_k  += H * K
        p_v  += H * V
        p_o  += H * V
        p_g  += H
        p_beta += H
    # ====== end token loop ======

    # Write-back final state
    if not DISABLE_STATE_UPDATE:
        idx = tl.load(h0_indices_ptr + i_n)
        if idx >= 0:
            p_h0 = h0_source_ptr + idx * H * V * K + i_h * V * K
            p_h0_tile = p_h0 + off_v[:, None] * K + off_k[None, :]
            tl.store(p_h0_tile, b_h.to(tl.float32), mask=mask_h)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    g = inputs["g"]
    beta = inputs["beta"]
    scale = inputs["scale"]
    initial_state = inputs["initial_state"]

    B, T, H, K = q.shape
    V = v.shape[-1]

    # Tile sizing (same strategy as upstream)
    BK = triton.next_power_of_2(K)          # NK is always 1
    BV = min(triton.next_power_of_2(V), 8)  # cap at 8 for register pressure
    NV = triton.cdiv(V, BV)

    # Allocate output (bfloat16, same as input q)
    o = torch.empty(B, T, H, V, dtype=torch.bfloat16, device=q.device)

    # State pool — float32 clone; final state written back in-place
    state_pool = initial_state.to(torch.float32).contiguous().clone()
    state_indices = torch.arange(B, device=q.device, dtype=torch.int64)

    grid = (NV, B * H)

    _update_kernel[grid](
        q.contiguous(), k.contiguous(), v.contiguous(),
        g.contiguous(), beta.contiguous(), o,
        state_pool, state_indices,
        scale, T,
        B, H, K, V, BK, BV,
        USE_INITIAL_STATE=True,
        DISABLE_STATE_UPDATE=False,
        num_warps=1,
        num_stages=3,
    )

    return {
        "output": o,
        "final_state": state_pool.to(initial_state.dtype),
    }
