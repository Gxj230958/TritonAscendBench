"""Round 2 — L1_36_gemma_qkv_rmsnorm.

Fix: Round 1 crashed on all 48 shapes because `tl.static_range(NUM_Q_HEADS)`
statically unrolls the per-head loop at compile time. With up to 256 heads
(shape P40) this produces an enormous kernel that triton-ascend cannot compile.

This round eliminates all `tl.static_range` usage. Instead, the grid is
`(M, num_heads)` — one program per (token, head) pair — so there are zero
loop unrolls inside the kernel body. Three separate kernel launches handle
Q, K, and V respectively.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

EPS = 1e-6


@triton.jit
def _rmsnorm_kernel(
    X_ptr,
    W_ptr,
    stride_x_m,
    head_dim: tl.constexpr,
    eps,
    has_weight: tl.constexpr,
    BLOCK: tl.constexpr,
):
    """One program = one (token, head).  No static loops."""
    m = tl.program_id(0)
    h = tl.program_id(1)

    cols = tl.arange(0, BLOCK)
    mask = cols < head_dim

    off = m * stride_x_m + h * head_dim + cols
    x = tl.load(X_ptr + off, mask=mask, other=0.0).to(tl.float32)

    rrms = tl.rsqrt(tl.sum(x * x, axis=0) / head_dim + eps)
    out = x * rrms

    if has_weight:
        w = tl.load(W_ptr + cols, mask=mask, other=0.0).to(tl.float32)
        out = out * w

    tl.store(X_ptr + off, out.to(tl.bfloat16), mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    q_weight = inputs["q_weight"]
    k_weight = inputs["k_weight"]

    M = q.shape[0]
    head_dim = q_weight.shape[-1]
    num_q_heads = q.shape[1] // head_dim
    num_kv_heads = k.shape[1] // head_dim
    BLOCK = triton.next_power_of_2(head_dim)

    # --- Q (with weight) ---
    _rmsnorm_kernel[(M, num_q_heads)](
        q,
        q_weight,
        q.stride(0),
        head_dim=head_dim,
        eps=EPS,
        has_weight=True,
        BLOCK=BLOCK,
    )

    # --- K (with weight) ---
    _rmsnorm_kernel[(M, num_kv_heads)](
        k,
        k_weight,
        k.stride(0),
        head_dim=head_dim,
        eps=EPS,
        has_weight=True,
        BLOCK=BLOCK,
    )

    # --- V (no weight) ---
    _rmsnorm_kernel[(M, num_kv_heads)](
        v,
        q_weight,  # dummy ptr, never read when has_weight=False
        v.stride(0),
        head_dim=head_dim,
        eps=EPS,
        has_weight=False,
        BLOCK=BLOCK,
    )

    return {"q": q, "k": k, "v": v}
