"""L2_05_gelu_and_mul — Ascend triton solution (Round 4).

GeGLU: split last dimension in half, apply GELU to the gate (first half),
then multiply element-wise by the up (second half).

Round 4 fix: Round 3 used tl.abs (not on Layer C allowlist).
Replaced tl.abs(x) with tl.where(x >= 0.0, x, -x) which uses only
Layer C allowed ops. Still uses the Abramowitz & Stegun 7.1.26
polynomial erf approximation (max abs error ~1.5e-7).

Only Layer C allowed ops used: tl.exp, tl.where, tl.arange, tl.load,
tl.store, tl.program_id, tl.float32, plus basic arithmetic.

    erf(x) approx sign * (1 - t * (a1 + t*(a2 + t*(a3 + t*(a4 + t*a5)))))
    where t = 1 / (1 + p*|x|)^n,   sign = 1 if x >= 0 else -1
    n = 1, p = 0.3275911, and Horner coefficients a1..a5.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _erf_approx(x):
    """Abramowitz & Stegun 7.1.26 polynomial erf approximation.

    Only uses tl.exp, tl.where, and basic arithmetic -- all on the
    Layer C allowlist.  Max absolute error about 1.5e-7.
    """
    p: tl.constexpr = 0.3275911
    a1: tl.constexpr = 0.254829592
    a2: tl.constexpr = -0.284496736
    a3: tl.constexpr = 1.421413741
    a4: tl.constexpr = -1.453152027
    a5: tl.constexpr = 1.061405429

    ax = tl.where(x >= 0.0, x, -x)
    sign = tl.where(x >= 0.0, 1.0, -1.0)

    t = 1.0 / (1.0 + p * ax)
    poly = a1 + t * (a2 + t * (a3 + t * (a4 + t * a5)))
    erfc = t * poly * tl.exp(-x * x)
    return sign * (1.0 - erfc)


@triton.jit
def _gelu_and_mul_kernel(
    out_ptr,
    hidden_states_ptr,
    hidden_dim: tl.constexpr,
    stride: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """One program per row. Each program processes one batch element."""
    pid = tl.program_id(axis=0)

    input_start = pid * stride
    output_start = pid * hidden_dim

    offsets = tl.arange(0, BLOCK_SIZE)
    mask = offsets < hidden_dim

    gate_offsets = input_start + offsets
    up_offsets = input_start + hidden_dim + offsets

    x1 = tl.load(hidden_states_ptr + gate_offsets, mask=mask, other=0.0).to(tl.float32)
    x3 = tl.load(hidden_states_ptr + up_offsets, mask=mask, other=0.0).to(tl.float32)

    gelu_x1 = 0.5 * x1 * (1.0 + _erf_approx(x1 * 0.7071067811865475))

    out = x3 * gelu_x1.to(hidden_states_ptr.dtype.element_ty)

    tl.store(out_ptr + output_start + offsets, out, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    hidden_states = inputs["hidden_states"]
    batch_size, total_dim = hidden_states.shape
    half_dim = total_dim // 2

    out = torch.empty(
        (batch_size, half_dim),
        dtype=hidden_states.dtype,
        device=hidden_states.device,
    )

    grid = (batch_size,)
    BLOCK_SIZE = triton.next_power_of_2(half_dim)

    _gelu_and_mul_kernel[grid](
        out,
        hidden_states,
        hidden_dim=half_dim,
        stride=total_dim,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=min(
            max(triton.next_power_of_2(triton.cdiv(half_dim, 8 * 32)), 4), 32
        ),
    )

    return {"output": out}
