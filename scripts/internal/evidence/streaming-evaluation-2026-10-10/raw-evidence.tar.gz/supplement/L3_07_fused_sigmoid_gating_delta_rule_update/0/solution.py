"""Triton-Ascend implementation of the gated DeltaNet single-step update.

For each (batch, head) the kernel computes, with all vector math in fp32:

    g      = exp(-exp(A_log) * softplus(a + dt_bias, beta, threshold))
    Sg     = g * state
    delta  = beta * (v - k @ Sg)
    state' = Sg + outer(k, delta)
    out    = q @ state'

Each program owns the FULL k dimension (BLOCK_K = next_power_of_2(D)) and a
BLOCK_V-wide block of the v dimension, exactly like the upstream decode
kernel. That keeps both delta-rule contractions (k@Sg and q@state') program-
local, so state is read once and written once in a single fused pass.
"""

from typing import Dict

import torch
import triton
import triton.language as tl


@triton.jit
def _gated_delta_rule_update_kernel(
    A_log_ptr,
    a_ptr,
    dt_bias_ptr,
    beta_ptr,
    q_ptr,
    k_ptr,
    v_ptr,
    state_ptr,
    state_new_ptr,
    out_ptr,
    H,
    D,
    DV,
    softplus_beta,
    softplus_threshold,
    BLOCK_K: tl.constexpr,
    BLOCK_V: tl.constexpr,
    BLOCK_NV: tl.constexpr,
):
    pid = tl.program_id(0)
    i_v = pid % BLOCK_NV
    i_bh = pid // BLOCK_NV
    i_h = i_bh % H

    o_k = tl.arange(0, BLOCK_K)
    o_v = i_v * BLOCK_V + tl.arange(0, BLOCK_V)
    mask_k = o_k < D
    mask_v = o_v < DV
    mask_tile = mask_k[:, None] & mask_v[None, :]

    # ---- Scalar gating for this (batch, head) ----
    b_A = tl.load(A_log_ptr + i_bh).to(tl.float32)
    b_a = tl.load(a_ptr + i_bh).to(tl.float32)
    b_dt = tl.load(dt_bias_ptr + i_h).to(tl.float32)
    b_beta = tl.load(beta_ptr + i_bh).to(tl.float32)

    # softplus(x; beta, threshold) with the same stability form as the kernel
    # under test: log(1 + exp(beta*x))/beta, switching to the linear branch
    # once beta*x > threshold. Scalar coercion happens here, inside the
    # kernel, whether the harness passed Python scalars or scalar tensors.
    x = b_a + b_dt
    beta_x = softplus_beta * x
    sp = tl.where(
        beta_x <= softplus_threshold,
        (1.0 / softplus_beta) * tl.log(1.0 + tl.exp(beta_x)),
        x,
    )
    decay = tl.exp(-tl.exp(b_A) * sp)

    # ---- State tile [BLOCK_K, BLOCK_V]; contiguous along v ----
    base = i_bh.to(tl.int64) * (D * DV)
    s_ptrs = state_ptr + base + o_k[:, None] * DV + o_v[None, :]
    b_s = tl.load(s_ptrs, mask=mask_tile, other=0.0)

    # bf16 vectors upcast once, then stay in fp32 for the whole recurrence
    b_q = tl.load(q_ptr + i_bh * D + o_k, mask=mask_k, other=0.0).to(tl.float32)
    b_k = tl.load(k_ptr + i_bh * D + o_k, mask=mask_k, other=0.0).to(tl.float32)
    b_v = tl.load(v_ptr + i_bh * DV + o_v, mask=mask_v, other=0.0).to(tl.float32)

    # 1) decay the state: Sg = g * state
    b_s = b_s * decay

    # 2) delta-rule correction against the DECAYED state:
    #    delta = beta * (v - k @ Sg)
    b_v = b_v - tl.sum(b_s * b_k[:, None], axis=0)
    b_v = b_v * b_beta
    b_s = b_s + b_k[:, None] * b_v[None, :]

    # 3) out = q @ state'
    b_o = tl.sum(b_s * b_q[:, None], axis=0)

    tl.store(out_ptr + i_bh * DV + o_v, b_o.to(out_ptr.dtype.element_ty), mask=mask_v)
    tl.store(
        state_new_ptr + base + o_k[:, None] * DV + o_v[None, :],
        b_s.to(state_new_ptr.dtype.element_ty),
        mask=mask_tile,
    )


def npu_triton_impl(inputs: Dict) -> Dict:
    A_log = inputs["A_log"].contiguous()
    a = inputs["a"].contiguous()
    dt_bias = inputs["dt_bias"].contiguous()
    beta = inputs["beta"].contiguous()
    q = inputs["q"].contiguous()
    k = inputs["k"].contiguous()
    v = inputs["v"].contiguous()
    state = inputs["state"].contiguous()
    softplus_beta = inputs["softplus_beta"]
    softplus_threshold = inputs["softplus_threshold"]

    B, H, D = q.shape
    DV = v.shape[-1]

    out = torch.empty(B, H, DV, dtype=q.dtype, device=q.device)
    new_state = torch.empty(B, H, D, DV, dtype=state.dtype, device=state.device)

    BLOCK_K = triton.next_power_of_2(D)
    BLOCK_V = 32 if BLOCK_K <= 512 else 16
    NV = triton.cdiv(DV, BLOCK_V)
    grid = (B * H * NV,)

    _gated_delta_rule_update_kernel[grid](
        A_log, a, dt_bias, beta, q, k, v, state, new_state, out,
        H, D, DV, softplus_beta, softplus_threshold,
        BLOCK_K=BLOCK_K, BLOCK_V=BLOCK_V, BLOCK_NV=NV,
    )
    return {"output": out, "state": new_state}
