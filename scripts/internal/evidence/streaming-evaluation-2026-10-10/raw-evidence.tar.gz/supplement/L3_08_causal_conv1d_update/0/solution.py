"""Triton-Ascend candidate for L3_08_causal_conv1d_update (round 3).

Single-token decode causal depthwise conv1d state update over a gathered
rolling history cache:

    x                   [B, D]         bf16   fresh token per batch row
    conv_state          [N, D, KW-1]   bf16   rolling history cache
    weight              [D, KW]        bf16   depthwise taps
    bias                [D]            bf16   optional additive term
    conv_state_indices  [B]            int32  cache line picked per row

For batch row i that selects cache line c = conv_state_indices[i], with
state_len = KW - 1 history columns:

    window = concat(conv_state[c, :, :], x[i, :])         # [D, KW]
    y[i]   = sum_k window[:, k] * weight[:, k] (+ bias)   # then optional SiLU
    conv_state[c, 0:state_len - 1] <- conv_state[c, 1:state_len]
    conv_state[c, state_len - 1]   <- x[i, :]

Cache lines that no index names are passed through untouched. The cache is
rolled in place and handed back beside the per-row output, which is what the
task interface asks for (returned `output` plus in-place `conv_state`).

What this round changes, and why
--------------------------------
Both earlier rounds lost whole families of shapes to the runtime audit's
blocked-operation rule, and the families line up exactly with the value of the
tap count: in round 1 every `KW == 3` shape never executed, in round 2 every
`KW in {4, 6}` shape never executed. A constexpr tap count is part of a built
artifact's identity, so each width asks the backend for its own build, and `4`
and `6` together cover 31 of the 46 shapes: leaving the width in the artifact
key concentrates most of the grid behind builds that get denied. Here
`kernel_width` and `state_len` arrive as runtime scalars in
`do_not_specialize`, and the window walks a fixed five-slot history sequence
whose per-slot activity is decided at run time by the load mask. With a fixed
tile and every shape number held out of specialization, the whole grid resolves
to a single build.

The other half is geometry. Round 2 moved to a 2-D 8 x 256 tile, which
multiplies a [BLOCK_B, BLOCK_N] history tile against a rank-1 [BLOCK_N] tap
tile. What did execute came back split cleanly: every `KW == 2` shape was bit
exact while every `KW >= 3` shape that ran was wrong in `output` only, with
`conv_state` correct, and the wrongness reached magnitudes near 1e38. That is
far outside any rounding story and consistent with a broadcast feature tile
reading past the weight rows rather than with bad addressing or a bad roll.
This round goes back to the rank-1 tile that round 1 executed correctly at
every width, so each multiply is [BLOCK_N] against [BLOCK_N] with no broadcast
in the accumulator at all, and keeps round 2's numerics, which the device
confirmed bit exact on the `KW == 2` shapes.

Numerics that carry weight
--------------------------
The reference forms each tap product on the bf16 operands, rounds that product
back to bf16, and only then folds it into an fp32 accumulator. That per-tap
rounding is load bearing: without it the output sits one or two bf16 ulps off,
which is past the graded relative tolerance once the window is summed. Spelling
the rounding as `.to(bf16).to(f32)` does not express it on this backend -- the
multiply happens in fp32 (exactly, since a bf16 x bf16 product needs only 16
mantissa bits) and the cast pair cancels in the folder, so nothing reaches the
accumulator rounded. `_rne_bf16_f32` states the invariant as integer work on
the fp32 bit pattern instead: bias the payload by half an ulp plus the
round-to-nearest-even tie bit, then clear the low 16 mantissa bits. Integer
shifts and adds of that shape are not something a cast folder erases, the
arriving product is already the exact value so there is no double rounding, and
the primitive is idempotent on values already on the bf16 grid, so it costs
nothing on a device that rounds the product by itself. The same primitive is
applied once more to the accumulator before the store, which takes the final
rounding out of the hands of whatever mode a fp32 -> bf16 store conversion
happens to use.

"""

import torch
import triton
import triton.language as tl

# Fixed rank-1 feature tile, the same for every shape in the grid. Keeping the
# size out of the shape data is what stops the artifact identity from forking
# per shape; the launch-bound tiny shapes are launch bound either way.
BLOCK_N = 256

# History columns are at most KW - 1 = 5 by the knob constraint, so five slots
# cover every shape and the sequence needs no run-time trip count.


def _peek(source: dict, key: str, default):
    try:
        return source[key]
    except KeyError:
        return default


@triton.jit
def _rne_bf16_f32(v):
    """Nearest-even round of an fp32 value to the bf16 grid, result still fp32."""
    bits = v.to(tl.int32, bitcast=True)
    bits = bits + 32767 + ((bits >> 16) & 1)
    bits = (bits >> 16) << 16
    return bits.to(tl.float32, bitcast=True)


# Every shape number is held out of the built-artifact identity. None of them
# needs a divisibility proof here: the axis that gets vectorized is the
# `arange` feature tile, whose contiguity is structural rather than something
# inferred from a scalar.
@triton.jit(
    do_not_specialize=[
        "batch",
        "dim",
        "num_cache_lines",
        "kernel_width",
        "state_len",
    ]
)
def _causal_conv1d_update_kernel(
    x_ptr,
    w_ptr,
    bias_ptr,
    conv_state_ptr,
    conv_state_indices_ptr,
    o_ptr,
    batch,
    dim,
    num_cache_lines,
    kernel_width,
    state_len,
    HAS_BIAS: tl.constexpr,
    SILU_ACTIVATION: tl.constexpr,
    USE_STATE_INDICES: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    row = tl.program_id(0)
    feats = tl.program_id(1) * BLOCK_N + tl.arange(0, BLOCK_N)
    feat_ok = feats < dim

    # Cache line this row gathers its history from and rolls back into.
    # Without indices a row owns its own line.
    if USE_STATE_INDICES:
        line = tl.load(conv_state_indices_ptr + row).to(tl.int64)
    else:
        line = row.to(tl.int64)
    line_ok = (line >= 0) & (line < num_cache_lines)
    mask_cs = feat_ok & line_ok

    state_span = dim * state_len
    cs_base = conv_state_ptr + line * state_span + feats * state_len
    w_base = w_ptr + feats * kernel_width

    # The decode step brings one new token: the newest window column, and the
    # newest state column after the roll.
    new_token = tl.load(x_ptr + row * dim + feats, mask=feat_ok, other=0.0)

    # History columns are read once and held in registers: the accumulator
    # consumes them oldest to newest and the roll below shifts those same
    # registers, so the line is never read a second time and no observer can
    # see a half shifted cache line. A slot past the live span loads zeros,
    # which contribute exactly nothing, so the fixed five-slot walk matches a
    # walk of the real history length term for term.
    col0 = tl.load(cs_base, mask=mask_cs & (state_len > 0), other=0.0)
    tap0 = tl.load(w_base, mask=mask_cs & (kernel_width > 0), other=0.0)
    acc = _rne_bf16_f32(col0.to(tl.float32) * tap0.to(tl.float32))

    col1 = tl.load(cs_base + 1, mask=mask_cs & (state_len > 1), other=0.0)
    tap1 = tl.load(w_base + 1, mask=mask_cs & (kernel_width > 1), other=0.0)
    acc += _rne_bf16_f32(col1.to(tl.float32) * tap1.to(tl.float32))

    col2 = tl.load(cs_base + 2, mask=mask_cs & (state_len > 2), other=0.0)
    tap2 = tl.load(w_base + 2, mask=mask_cs & (kernel_width > 2), other=0.0)
    acc += _rne_bf16_f32(col2.to(tl.float32) * tap2.to(tl.float32))

    col3 = tl.load(cs_base + 3, mask=mask_cs & (state_len > 3), other=0.0)
    tap3 = tl.load(w_base + 3, mask=mask_cs & (kernel_width > 3), other=0.0)
    acc += _rne_bf16_f32(col3.to(tl.float32) * tap3.to(tl.float32))

    col4 = tl.load(cs_base + 4, mask=mask_cs & (state_len > 4), other=0.0)
    tap4 = tl.load(w_base + 4, mask=mask_cs & (kernel_width > 4), other=0.0)
    acc += _rne_bf16_f32(col4.to(tl.float32) * tap4.to(tl.float32))

    tap_last = tl.load(w_base + (kernel_width - 1), mask=feat_ok, other=0.0)
    acc += _rne_bf16_f32(new_token.to(tl.float32) * tap_last.to(tl.float32))

    if HAS_BIAS:
        acc += tl.load(bias_ptr + feats, mask=feat_ok, other=0.0).to(tl.float32)

    if SILU_ACTIVATION:
        acc = acc / (1 + tl.exp(-acc))

    # Exactly representable in bf16 by construction, so the store conversion
    # cannot round a second time.
    out_val = _rne_bf16_f32(acc).to(o_ptr.dtype.element_ty)
    tl.store(o_ptr + row * dim + feats, out_val, mask=feat_ok)

    # Roll, out of registers only: history slot j + 1 lands in slot j and the
    # last slot takes the fresh token. Stores run oldest to newest, each one
    # writing a slot whose old value has already been read above, so there is
    # no read-after-write hazard and no barrier is needed.
    tl.store(cs_base, col1, mask=mask_cs & (state_len > 1))
    tl.store(cs_base + 1, col2, mask=mask_cs & (state_len > 2))
    tl.store(cs_base + 2, col3, mask=mask_cs & (state_len > 3))
    tl.store(cs_base + 3, col4, mask=mask_cs & (state_len > 4))
    tl.store(cs_base + (state_len - 1), new_token, mask=mask_cs & (state_len > 0))


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    conv_state = inputs["conv_state"]
    weight = inputs["weight"]
    bias = _peek(inputs, "bias", None)
    activation = _peek(inputs, "activation", None)
    conv_state_indices = _peek(inputs, "conv_state_indices", None)

    # The graded path is single-token decode with rank-2 x; a trailing unit
    # token axis is folded away if the runner hands one over.
    if x.dim() == 3:
        x = x.reshape(x.shape[0], x.shape[1])
    if x.dtype != conv_state.dtype:
        x = x.to(conv_state.dtype)

    # The address math below assumes a dense layout; the fixture builds dense
    # tensors, so these are guards rather than work.
    if not x.is_contiguous():
        x = x.contiguous()
    if not conv_state.is_contiguous():
        conv_state = conv_state.contiguous()
    if not weight.is_contiguous():
        weight = weight.contiguous()
    if bias is not None and not bias.is_contiguous():
        bias = bias.contiguous()
    if conv_state_indices is not None and not conv_state_indices.is_contiguous():
        conv_state_indices = conv_state_indices.contiguous()

    if isinstance(activation, bool):
        activation = "silu" if activation else None

    batch, dim = int(x.shape[0]), int(x.shape[1])
    kernel_width = int(weight.shape[-1])
    # The rolled span follows the cache's own history length, which the fixture
    # always sets to KW - 1; reading it from the tensor rather than deriving it
    # keeps the stride arithmetic honest if the two ever disagree.
    state_len = int(conv_state.shape[-1])
    num_cache_lines = int(conv_state.shape[0])

    out = torch.empty((batch, dim), dtype=x.dtype, device=x.device)
    grid = (batch, triton.cdiv(dim, BLOCK_N))

    _causal_conv1d_update_kernel[grid](
        x,
        weight,
        bias if bias is not None else x,
        conv_state,
        conv_state_indices if conv_state_indices is not None else x,
        out,
        batch,
        dim,
        num_cache_lines,
        kernel_width,
        state_len,
        HAS_BIAS=bias is not None,
        SILU_ACTIVATION=activation in ("silu", "swish"),
        USE_STATE_INDICES=conv_state_indices is not None,
        BLOCK_N=BLOCK_N,
    )

    return {"output": out, "conv_state": conv_state}
