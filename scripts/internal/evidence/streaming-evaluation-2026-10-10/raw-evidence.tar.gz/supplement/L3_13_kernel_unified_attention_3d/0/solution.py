"""Triton-Ascend implementation of the varlen unified attention kernel.

Entry point: ``npu_triton_impl(inputs: dict) -> dict`` -> ``{"output": tensor}``.

What the fused tile kernel computes:

  * packed varlen layout: q/k/v are ``[total_tokens, num_heads, head_dim]``;
    per-sequence token ranges come from ``cu_seqlens_q`` and the number of
    valid keys per sequence from ``seqused_k``
  * grouped-query broadcast whenever ``num_query_heads != num_kv_heads``
  * causal masking anchored on absolute key positions: query row ``i`` of a
    sequence with ``query_len`` rows and ``seq_len`` keys attends to keys
    ``0 .. (seq_len - query_len) + i`` inclusive
  * optional additive position slope per query head (active only when a slope
    tensor is present in the input dict) and optional tanh soft-capping of the
    logits (active only when ``softcap > 0``)
  * streaming row softmax in fp32: the running row maximum, the running
    denominator and the fp32 value accumulator are rescaled by the per-tile
    correction factor; the attention weights are down-cast to the key/value
    element type immediately before the value product; the closing division by
    the denominator happens in fp32 and the returned buffer is fp32

The block table that the shape fixtures carry is intentionally not consulted.
The key and value tensors already hold the packed per-sequence rows that the
reference reads, so row addressing here is direct and resolves the same
logical values.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def kernel_unified_attention_npu(
    # Output destination, packed [total_tokens, num_query_heads, HEAD_SIZE].
    output_ptr,
    # Packed inputs.
    query_ptr,
    key_ptr,
    value_ptr,
    query_start_len_ptr,
    seq_lens_ptr,
    alibi_slopes_ptr,
    # Scalars.  The softcap threshold is a constexpr: the capping arithmetic
    # below is dropped from the generated body entirely when it is zero.
    scale,
    SOFTCAP: tl.constexpr,
    # Token and head strides; the head stride equals HEAD_SIZE.
    output_stride_0: tl.int64,
    output_stride_1: tl.int64,
    query_stride_0: tl.int64,
    query_stride_1: tl.int64,
    key_stride_0: tl.int64,
    key_stride_1: tl.int64,
    value_stride_0: tl.int64,
    value_stride_1: tl.int64,
    num_seqs,
    num_query_heads: tl.constexpr,
    num_queries_per_kv: tl.constexpr,
    HEAD_SIZE: tl.constexpr,
    HEAD_SIZE_PADDED: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_Q: tl.constexpr,
    TILE_SIZE: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
    USE_ALIBI_SLOPES: tl.constexpr,
):
    q_block_global_idx = tl.program_id(0)
    kv_head_idx = tl.program_id(1)

    # --------------------------------------------------------------------
    # Locate the sequence owning this flattened query block.  The walk is
    # pure arithmetic (no data-dependent control flow) and num_seqs is tiny,
    # so this prologue stays cheap.
    # --------------------------------------------------------------------
    seq_idx = 0
    start_index = 0
    query_len = 0
    q_block_local_idx = 0
    found = 0
    cum_blocks = 0
    prev = tl.load(query_start_len_ptr).to(tl.int32)
    for i in range(num_seqs):
        end = tl.load(query_start_len_ptr + i + 1).to(tl.int32)
        ql = end - prev
        num_q_blocks = (ql + BLOCK_Q - 1) // BLOCK_Q
        hit = ((found == 0) & (cum_blocks + num_q_blocks > q_block_global_idx)).to(
            tl.int32
        )
        seq_idx = seq_idx + hit * (i - seq_idx)
        start_index = start_index + hit * (prev - start_index)
        query_len = query_len + hit * (ql - query_len)
        local_blk = q_block_global_idx - cum_blocks
        q_block_local_idx = q_block_local_idx + hit * (local_blk - q_block_local_idx)
        found = found + hit
        cum_blocks = cum_blocks + num_q_blocks
        prev = end

    # Programs beyond sum_i ceil(query_len_i / BLOCK_Q) retire here.
    if found == 0:
        return

    seq_len = tl.load(seq_lens_ptr + seq_idx).to(tl.int32)

    offs_m = tl.arange(0, BLOCK_M)
    offs_d = tl.arange(0, HEAD_SIZE_PADDED)
    offs_t = tl.arange(0, TILE_SIZE)

    # Tile rows enumerate (query token, query head) pairs that share one KV
    # head, so a grouped-query set rides on a single key/value stream.
    query_pos = q_block_local_idx * BLOCK_Q + offs_m // num_queries_per_kv
    query_head = kv_head_idx * num_queries_per_kv + offs_m % num_queries_per_kv

    query_mask_0 = query_pos < query_len
    query_mask_1 = query_head < num_query_heads
    row_mask = query_mask_0 & query_mask_1
    dim_mask = offs_d < HEAD_SIZE

    token_rows = (start_index + query_pos).to(tl.int64)
    head_rows = query_head.to(tl.int64)

    # Q : (BLOCK_M, HEAD_SIZE_PADDED)
    Q = tl.load(
        query_ptr
        + token_rows[:, None] * query_stride_0
        + head_rows[:, None] * query_stride_1
        + offs_d[None, :],
        mask=dim_mask[None, :] & row_mask[:, None],
        other=0.0,
    )

    context_len = seq_len - query_len
    query_abs_pos = context_len + query_pos

    if USE_ALIBI_SLOPES:
        alibi_slope = tl.load(
            alibi_slopes_ptr + head_rows, mask=row_mask, other=0.0
        ).to(tl.float32)

    # Highest absolute key position this query block can reach.
    q_hi = tl.minimum(query_len, (q_block_local_idx + 1) * BLOCK_Q)
    if IS_CAUSAL:
        loop_hi = tl.minimum(seq_len, context_len + q_hi)
    else:
        loop_hi = seq_len
    num_tiles = (loop_hi + TILE_SIZE - 1) // TILE_SIZE

    # The row maximum is seeded with a finite sentinel so that a fully masked
    # tile yields a correction factor of 1 instead of a NaN.
    M = tl.full([BLOCK_M], -1.0e30, dtype=tl.float32)
    L = tl.zeros([BLOCK_M], dtype=tl.float32)
    acc = tl.zeros([BLOCK_M, HEAD_SIZE_PADDED], dtype=tl.float32)

    for j in range(0, num_tiles):
        seq_offset = j * TILE_SIZE + offs_t
        tile_mask = seq_offset < seq_len
        key_tokens = (start_index + seq_offset).to(tl.int64)

        # K : (HEAD_SIZE_PADDED, TILE_SIZE), transposed while loading.
        K = tl.load(
            key_ptr
            + key_tokens[None, :] * key_stride_0
            + kv_head_idx * key_stride_1
            + offs_d[:, None],
            mask=dim_mask[:, None] & tile_mask[None, :],
            other=0.0,
        )
        # V : (TILE_SIZE, HEAD_SIZE_PADDED)
        V = tl.load(
            value_ptr
            + key_tokens[:, None] * value_stride_0
            + kv_head_idx * value_stride_1
            + offs_d[None, :],
            mask=dim_mask[None, :] & tile_mask[:, None],
            other=0.0,
        )

        # S : (BLOCK_M, TILE_SIZE), fp32 accumulation of the elementwise cast
        # operands, then the softmax scale applied as a separate multiply.
        S = scale * tl.dot(Q, K)

        if SOFTCAP > 0.0:
            u = S / SOFTCAP
            # tanh(u) spelled as 1 - 2 / (exp(2u) + 1) so that no exp argument
            # can overflow to NaN.
            S = SOFTCAP * (1.0 - 2.0 / (tl.exp(2.0 * u) + 1.0))

        if IS_CAUSAL:
            score_mask = row_mask[:, None] & tile_mask[None, :] & (
                seq_offset[None, :] <= query_abs_pos[:, None]
            )
        else:
            score_mask = row_mask[:, None] & tile_mask[None, :]
        S = tl.where(score_mask, S, float("-inf"))

        if USE_ALIBI_SLOPES:
            S = S - alibi_slope[:, None] * (
                query_abs_pos[:, None] - seq_offset[None, :]
            )

        # ---- streaming softmax -----------------------------------------
        m_new = tl.maximum(M, tl.max(S, axis=1))
        alpha = tl.exp(M - m_new)
        P = tl.exp(S - m_new[:, None])
        L = L * alpha + tl.sum(P, axis=1)
        acc = acc * alpha[:, None] + tl.dot(P.to(V.dtype), V)
        M = m_new

    # --------------------------------------------------------------------
    # Epilogue: normalise in fp32 and write the packed output rows.  A row
    # without a contributing key keeps the zero accumulator instead of NaN.
    # --------------------------------------------------------------------
    L_safe = tl.where(L == 0.0, 1.0, L)
    acc = acc / L_safe[:, None]

    tl.store(
        output_ptr
        + token_rows[:, None] * output_stride_0
        + head_rows[:, None] * output_stride_1
        + offs_d[None, :],
        acc,
        mask=dim_mask[None, :] & row_mask[:, None],
    )


def _pick_config(head_size: int, num_queries_per_kv: int):
    head_size_padded = max(16, triton.next_power_of_2(head_size))
    # Row tile x head tile is sized so the fp32 accumulator plus the Q/K/V
    # tiles stay well inside the on-chip budget of a 910B cube unit.
    if head_size_padded <= 32:
        block_m, tile_size, num_warps = 64, 64, 4
    elif head_size_padded <= 64:
        block_m, tile_size, num_warps = 32, 64, 4
    elif head_size_padded <= 128:
        block_m, tile_size, num_warps = 32, 32, 8
    else:
        block_m, tile_size, num_warps = 16, 32, 8
    while block_m < num_queries_per_kv:
        block_m = block_m * 2
    block_q = max(1, block_m // num_queries_per_kv)
    return head_size_padded, block_m, block_q, tile_size, num_warps


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"].contiguous()
    k = inputs["k"].contiguous()
    v = inputs["v"].contiguous()
    cu_seqlens_q = inputs["cu_seqlens_q"].contiguous()
    seqused_k = inputs["seqused_k"].contiguous()

    # The knobs arrive as host scalars from the shape fixtures and go straight
    # to the kernel: the scale as an fp value, the causal toggle and the
    # softcap threshold as launch-time decisions.
    scale = 1.0
    if "softmax_scale" in inputs:
        scale = inputs["softmax_scale"]
    elif "scale" in inputs:
        scale = inputs["scale"]
    causal = True
    if "causal" in inputs:
        causal = inputs["causal"]

    softcap = 0.0
    if "softcap" in inputs:
        softcap = inputs["softcap"]

    # Placeholder pointer for the unused slope path; a non-null tensor is all
    # the launch surface requires when the branch is switched off.
    slope_ptr = q
    use_alibi_slopes = 0
    if "alibi_slopes" in inputs:
        try:
            slope_ptr = inputs["alibi_slopes"].contiguous()
            use_alibi_slopes = 1
        except AttributeError:
            slope_ptr = q
            use_alibi_slopes = 0

    total_tokens = q.shape[0]
    num_query_heads = q.shape[1]
    head_size = q.shape[2]
    num_kv_heads = k.shape[1]
    num_seqs = seqused_k.shape[0]
    num_queries_per_kv = max(1, num_query_heads // num_kv_heads)

    out = torch.empty(
        (total_tokens, num_query_heads, head_size),
        dtype=torch.float32,
        device=q.device,
    )

    head_size_padded, block_m, block_q, tile_size, num_warps = _pick_config(
        head_size, num_queries_per_kv
    )

    # Launch volume uses the arithmetic upper bound
    #   sum_i ceil(query_len_i / BLOCK_Q) <= total_tokens // BLOCK_Q + num_seqs
    # so the per-sequence query lengths never have to be realised on the host;
    # surplus programs retire in the kernel prologue.
    grid = (total_tokens // block_q + num_seqs, num_kv_heads)

    kernel_unified_attention_npu[grid](
        output_ptr=out,
        query_ptr=q,
        key_ptr=k,
        value_ptr=v,
        query_start_len_ptr=cu_seqlens_q,
        seq_lens_ptr=seqused_k,
        alibi_slopes_ptr=slope_ptr,
        scale=scale,
        SOFTCAP=softcap,
        output_stride_0=out.stride(0),
        output_stride_1=out.stride(1),
        query_stride_0=q.stride(0),
        query_stride_1=q.stride(1),
        key_stride_0=k.stride(0),
        key_stride_1=k.stride(1),
        value_stride_0=v.stride(0),
        value_stride_1=v.stride(1),
        num_seqs=num_seqs,
        num_query_heads=num_query_heads,
        num_queries_per_kv=num_queries_per_kv,
        HEAD_SIZE=head_size,
        HEAD_SIZE_PADDED=head_size_padded,
        BLOCK_M=block_m,
        BLOCK_Q=block_q,
        TILE_SIZE=tile_size,
        IS_CAUSAL=causal,
        USE_ALIBI_SLOPES=use_alibi_slopes,
        num_warps=num_warps,
        num_stages=2,
    )

    return {"output": out}
