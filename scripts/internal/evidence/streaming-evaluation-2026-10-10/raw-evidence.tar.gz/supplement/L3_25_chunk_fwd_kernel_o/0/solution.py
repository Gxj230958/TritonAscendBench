"""L3_25_chunk_fwd_kernel_o - Triton-Ascend port of chunk_fwd_kernel_o.

Ports the upstream vLLM FLA chunk_fwd_kernel_o (kernel.py) to Triton-Ascend
for the local 910B NPU. Entry: npu_triton_impl(inputs) -> dict.

Per chunk i_t (BT=64), value head h reads key/query head h // (H // Hg):
  o = scale * ((q @ h_state^T) * exp(g) + tril(exp(g_i - g_j) * (q @ k^T)) @ v)
where h_state = h[:, i_t] is the per-chunk [V, K] snapshot.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _chunk_fwd_kernel_o(
    q, k, v, h, g, o, scale,
    T,
    H: tl.constexpr, Hg: tl.constexpr, K: tl.constexpr, V: tl.constexpr,
    BT: tl.constexpr, BK: tl.constexpr, BV: tl.constexpr,
):
    i_v, i_t, i_bh = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    i_b = i_bh // H
    i_h = i_bh % H
    NT = tl.cdiv(T, BT)
    i_tg = i_b * NT + i_t
    bos = i_b * T
    hq = i_h // (H // Hg)

    rows = i_t * BT + tl.arange(0, BT)
    row_mask = rows < T
    vv = i_v * BV + tl.arange(0, BV)
    vv_mask = vv < V

    b_o = tl.zeros([BT, BV], dtype=tl.float32)
    b_A = tl.zeros([BT, BT], dtype=tl.float32)

    for i_k in range(0, tl.cdiv(K, BK)):
        kk = i_k * BK + tl.arange(0, BK)
        kk_mask = kk < K
        # b_q [BT, BK]
        q_off = (bos * Hg + hq) * K + rows[:, None] * K + kk[None, :]
        b_q = tl.load(q + q_off, mask=row_mask[:, None] & kk_mask[None, :], other=0.0)
        # b_k [BK, BT]
        k_off = (bos * Hg + hq) * K + kk[:, None] * K + rows[None, :]
        b_k = tl.load(k + k_off, mask=kk_mask[:, None] & row_mask[None, :], other=0.0)
        # b_h [BK, BV]
        h_off = (i_tg * H + i_h).to(tl.int64) * V * K + kk[:, None] * K + vv[None, :]
        b_h = tl.load(h + h_off, mask=kk_mask[:, None] & vv_mask[None, :], other=0.0)
        b_o += tl.dot(b_q, b_h)
        b_A += tl.dot(b_q, b_k)

    b_g = tl.load(g + (bos * H + i_h) + rows, mask=row_mask, other=0.0)
    b_o = b_o * tl.exp(b_g)[:, None]
    b_A = b_A * tl.exp(b_g[:, None] - b_g[None, :])

    m_A = (rows[:, None] >= rows[None, :]) & (row_mask[:, None] & row_mask)
    b_A = tl.where(m_A, b_A, 0)

    v_off = (bos * H + i_h) * V + rows[:, None] * V + vv[None, :]
    b_v = tl.load(v + v_off, mask=row_mask[:, None] & vv_mask[None, :], other=0.0)

    b_o = b_o * scale + tl.dot(b_A.to(b_v.dtype), b_v) * scale
    o_off = (bos * H + i_h) * V + rows[:, None] * V + vv[None, :]
    tl.store(o + o_off, b_o.to(o.dtype.element_ty), mask=row_mask[:, None] & vv_mask[None, :])


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    h = inputs["h"]
    g = inputs["g"]
    scale = inputs["scale"]
    B, T, Hg, K = q.shape
    H = v.shape[-2]
    V = v.shape[-1]
    BT = 64
    BK = 64
    BV = 64
    NT = (T + BT - 1) // BT
    o = torch.empty_like(v)
    grid = (triton.cdiv(V, BV), NT, B * H)
    _chunk_fwd_kernel_o[grid](
        q, k, v, h, g, o, scale, T=T,
        H=H, Hg=Hg, K=K, V=V, BT=BT, BK=BK, BV=BV,
        num_warps=4, num_stages=3,
    )
    return {"output": o}
