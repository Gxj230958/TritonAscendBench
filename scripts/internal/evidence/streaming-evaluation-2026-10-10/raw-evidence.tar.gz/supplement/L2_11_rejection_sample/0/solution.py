"""triton-ascend migration of rejection_random_sample_kernel (L2_11_rejection_sample).

Speculative-decoding rejection sampler, deterministic given the uniform
draws in the inputs. One program handles one request:

- Greedy requests early-exit; their row keeps the -1 sentinel padding.
- For a non-greedy request the program walks its draft tokens (bounds come
  from cu_num_draft_tokens, so the loop is data-dependent). A draft token x
  is accepted while `q(x) > 0 and p(x) / q(x) >= U` (reject-when-q<=0). On
  the first rejection the pre-computed recovered (residual-distribution)
  token is emitted and the chain stops for that request; if every draft
  token is accepted the bonus token is appended.
- Output is an int32 [E, max_spec_len + 1] matrix prefilled with -1.
"""

import torch
import triton
import triton.language as tl


@triton.jit(do_not_specialize=['max_spec_len'])
def rejection_random_sample_kernel(
    output_token_ids_ptr,
    cu_num_draft_tokens_ptr,
    draft_token_ids_ptr,
    draft_probs_ptr,
    target_probs_ptr,
    bonus_token_ids_ptr,
    recovered_token_ids_ptr,
    uniform_probs_ptr,
    is_greedy_ptr,
    max_spec_len,
    vocab_size,
    synthetic_conditional_rates_ptr,
    NO_DRAFT_PROBS: tl.constexpr,
    SYNTHETIC_MODE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    is_greedy = tl.load(is_greedy_ptr + req_idx)
    if is_greedy:
        return

    # start of this request's draft slice: previous request's cumulative
    # count (0 for the first request). The masked scalar load keeps this
    # static; -req_idx + 1 avoids a pointer-expression binop at req_idx == 0.
    start_idx = tl.load(
        cu_num_draft_tokens_ptr - req_idx + 1, mask=req_idx > 0, other=0
    )
    end_idx = tl.load(cu_num_draft_tokens_ptr + req_idx)
    num_draft_tokens = end_idx - start_idx
    rejected = False
    for pos in range(num_draft_tokens):
        if not rejected:
            draft_token_id = tl.load(draft_token_ids_ptr + start_idx + pos)
            uniform_prob = tl.load(uniform_probs_ptr + start_idx + pos)
            if SYNTHETIC_MODE:
                rate = tl.load(synthetic_conditional_rates_ptr + pos)
                accepted = uniform_prob < rate
            else:
                if NO_DRAFT_PROBS:
                    draft_prob = 1
                else:
                    draft_prob = tl.load(
                        draft_probs_ptr
                        + (start_idx + pos) * vocab_size
                        + draft_token_id
                    )
                target_prob = tl.load(
                    target_probs_ptr
                    + (start_idx + pos) * vocab_size
                    + draft_token_id
                )
                # Accept test, mirroring upstream semantics exactly:
                # reject when q(x) <= 0, otherwise p(x)/q(x) >= U.
                if draft_prob > 0:
                    accepted = target_prob / draft_prob >= uniform_prob
                else:
                    accepted = False
            if accepted:
                token_id = draft_token_id
            else:
                rejected = True
                token_id = tl.load(recovered_token_ids_ptr + start_idx + pos)
            tl.store(
                output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
                token_id.to(tl.int32),
            )
    if not rejected:
        bonus_token_id = tl.load(bonus_token_ids_ptr + req_idx)
        tl.store(
            output_token_ids_ptr + req_idx * (max_spec_len + 1) + num_draft_tokens,
            bonus_token_id.to(tl.int32),
        )


def npu_triton_impl(inputs: dict) -> dict:
    draft_token_ids = inputs["draft_token_ids"].contiguous()
    cu_num_draft_tokens = inputs["cu_num_draft_tokens"].contiguous()
    draft_probs = inputs["draft_probs"].contiguous()
    target_probs = inputs["target_probs"].contiguous()
    bonus_token_ids = inputs["bonus_token_ids"].contiguous()
    recovered_token_ids = inputs["recovered_token_ids"].contiguous()
    uniform_probs = inputs["uniform_probs"].contiguous()
    is_greedy = inputs["is_greedy"].contiguous()
    # Scalar knob from the shape spec (plain python int on the host).
    m_int = torch.tensor(inputs["max_spec_len"]).numel()
    max_spec_len = m_int
    out_cols = m_int + 1

    batch_size = cu_num_draft_tokens.shape[0]
    vocab_size = target_probs.shape[-1]
    device = target_probs.device

    # int32 output matrix, prefilled with the -1 sentinel (upstream layout).
    output_token_ids = torch.full(
        (batch_size, out_cols),
        -1,
        dtype=torch.int32,
        device=device,
    )

    # NO_DRAFT_PROBS=False: real draft_probs are supplied;
    # SYNTHETIC_MODE=False: acceptance uses the real probability ratio, so
    # the synthetic rate table is never dereferenced (empty placeholder).
    synthetic_rates = torch.empty((0,), dtype=torch.float32, device=device)

    rejection_random_sample_kernel[(batch_size,)](
        output_token_ids,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        bonus_token_ids,
        recovered_token_ids,
        uniform_probs,
        is_greedy,
        max_spec_len,
        vocab_size,
        synthetic_rates,
        NO_DRAFT_PROBS=False,
        SYNTHETIC_MODE=False,
    )
    return {"output_token_ids": output_token_ids}
