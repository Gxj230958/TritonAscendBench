"""Triton-Ascend implementation of fused_recurrent_gated_delta_rule_fwd_kernel.

Migrates the upstream GPU kernel (frozen vendor copy kernel.py) to the
Ascend backend. The recurrence is the gated DeltaNet token-by-token forward:

    S  = exp(g_t) * S                # decay carried state FIRST
    kS = sum_k (S * k_t)             # contraction over K on decayed state
    d  = (v_t - kS) * beta_t
    S  = S + d[:, None] * k_t[None, :]
    o_t = sum_k (S * (scale * q_t))

State S is carried per program as a [BV, BK] fp32 tile (V-major layout,
matching the upstream kernel's b_h indexing). All accumulation happens in
fp32; q/k/v/g/beta arrive as bf16 and are upcast before arithmetic, while
output and final state are downcast to bf16 on store.

Grid: one program per (batch, value-head, V-tile); the K dimension is fully
covered by a single program (BK = next_power_of_2(K)) so the two K-contractions
stay inside one program without cross-program communication. The host wrapper
is branch-free: every tensor flows straight into the kernel launch.
"""

import torch
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["T"])
def _fused_recurrent_gated_delta_rule_fwd_kernel(
    q, k, v, g, beta, o, h0, ht,
    scale,
    T,
    H: tl.constexpr,
    HV: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    NV: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
):
    pid = tl.program_id(0)
    i_v = pid % NV
    i_nh = pid // NV
    i_n = i_nh // HV
    i_hv = i_nh % HV
    i_h = i_hv // (HV // H)

    o_k = tl.arange(0, BK)
    o_v = i_v * BV + tl.arange(0, BV)
    mask_k = o_k < K
    mask_v = o_v < V
    mask_h = mask_v[:, None] & mask_k[None, :]

    # Token rows are contiguous [B, T, H, D]; advance one token per iter.
    base = i_n * T * H + i_h
    p_q = q + base * K + o_k
    p_k = k + base * K + o_k
    p_v = v + (i_n * T * HV + i_hv) * V + o_v
    p_g = g + i_n * T * HV + i_hv
    p_beta = beta + i_n * T * HV + i_hv
    p_o = o + (i_n * T * HV + i_hv) * V + o_v

    b_h = tl.zeros([BV, BK], dtype=tl.float32)
    if USE_INITIAL_STATE:
        # initial_state layout: [B, H, V, K] (kernel's V-major state layout)
        p_h0 = h0 + (i_n * HV + i_hv) * V * K + o_v[:, None] * K + o_k[None, :]
        b_h = tl.load(p_h0, mask=mask_h, other=0.0).to(tl.float32)

    for i_t in range(0, T):
        b_q = tl.load(p_q, mask=mask_k, other=0.0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0.0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0.0).to(tl.float32)
        b_g = tl.load(p_g).to(tl.float32)
        b_beta = tl.load(p_beta).to(tl.float32)

        b_q = b_q * scale
        # Decay carried state before the kS contraction.
        b_h = b_h * tl.exp(b_g)
        kS = tl.sum(b_h * b_k[None, :], 1)
        b_v = (b_v - kS) * b_beta
        b_h = b_h + b_v[:, None] * b_k[None, :]
        b_o = tl.sum(b_h * b_q[None, :], 1)
        tl.store(p_o, b_o.to(tl.bfloat16), mask=mask_v)

        p_q += H * K
        p_k += H * K
        p_v += HV * V
        p_g += HV
        p_beta += HV
        p_o += HV * V

    # Final state (after the last token) back to [B, H, V, K] V-major layout.
    p_ht = ht + (i_n * HV + i_hv) * V * K + o_v[:, None] * K + o_k[None, :]
    tl.store(p_ht, b_h.to(tl.bfloat16), mask=mask_h)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"].contiguous()
    k = inputs["k"].contiguous()
    v = inputs["v"].contiguous()
    g = inputs["g"].contiguous()
    beta = inputs["beta"].contiguous()
    initial_state = inputs["initial_state"].contiguous()
    scale = inputs["scale"]

    B, T, H, K = q.shape
    HV = v.shape[2]
    V = v.shape[3]

    BK = triton.next_power_of_2(K)
    BV = min(triton.next_power_of_2(V), 32)
    NV = triton.cdiv(V, BV)

    output = torch.empty((B, T, H, V), dtype=q.dtype, device=q.device)
    final_state = torch.empty((B, H, V, K), dtype=q.dtype, device=q.device)

    _fused_recurrent_gated_delta_rule_fwd_kernel[(NV * B * HV,)](
        q, k, v, g, beta, output,
        initial_state,
        final_state,
        scale,
        T,
        H=H,
        HV=HV,
        K=K,
        V=V,
        BK=BK,
        BV=BV,
        NV=NV,
        USE_INITIAL_STATE=True,
        num_warps=1,
        num_stages=1,
    )

    return {"output": output, "final_state": final_state}
