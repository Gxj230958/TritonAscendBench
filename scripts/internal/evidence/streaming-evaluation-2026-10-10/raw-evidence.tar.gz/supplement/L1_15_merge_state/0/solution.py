"""Triton-Ascend merge_state_kernel.

FlashAttention split-KV merge of two partial attention states. Per
(token, head) pair the kernel recombinates the two log-sum-exp values
with the online-softmax formula and rescales the two partial outputs by
the merged normalization, producing (merged_output, merged_lse).

Mirrors the frozen upstream semantics: an empty split arrives as +inf LSE
and is collapsed to -inf so it is dropped (zero weight). When both splits
are empty every term collapses to NaN and the merged output/LSE are NaN.
All arithmetic runs in fp32; the output is cast to the input dtype once
at the store boundary. The per-element arithmetic sequence follows the
upstream kernel line-for-line (scalar sentinel select, max/shift, exp,
sum, log, reciprocal scales, bf16->fp32 promote, fused multiply-add,
single final rounding) so results reproduce the reference elementwise.

The grid is a (token-blocks, heads) 2D launch whose total size stays
below the 65536 block cap, with a grid-stride loop over tokens so
arbitrarily large token counts stay valid. Each program processes one
(token, head) row at a time: a scalar LSE recombination followed by a
masked chunked copy of the row, which keeps the per-program on-chip
footprint bounded for arbitrarily large head sizes. The entry point
returns the outputs under the same _out{i} keys that the frozen upstream
tuple entrypoint (kernel.py run()) produces.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _merge_state_kernel(
    output,
    output_lse,
    prefix_output,
    prefix_lse,
    suffix_output,
    suffix_lse,
    NUM_TOKENS,
    HEAD_SIZE: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    pid_t = tl.program_id(0)
    num_t_blocks = tl.num_programs(0)
    pid_h = tl.program_id(1)
    num_heads = tl.num_programs(1)

    # Grid-stride over tokens: block pid_t covers
    # pid_t, pid_t + num_t_blocks, pid_t + 2*num_t_blocks, ...
    for t in range(pid_t, NUM_TOKENS, num_t_blocks):
        # Contiguous [num_tokens, num_heads, HEAD_SIZE] rows map
        # t * num_heads + pid_h -> row (t, pid_h) directly.
        row = t * num_heads + pid_h

        p_lse = tl.load(prefix_lse + row)
        s_lse = tl.load(suffix_lse + row)

        # Empty-split sentinel: +inf -> -inf so that split is dropped.
        p_lse = tl.where(p_lse == float("inf"), float("-inf"), p_lse)
        s_lse = tl.where(s_lse == float("inf"), float("-inf"), s_lse)

        max_lse = tl.maximum(p_lse, s_lse)
        p_lse = p_lse - max_lse
        s_lse = s_lse - max_lse
        p_e = tl.exp(p_lse)
        s_e = tl.exp(s_lse)
        out_se = p_e + s_e

        out_lse = tl.log(out_se) + max_lse
        tl.store(output_lse + row, out_lse)

        p_scale = p_e / out_se
        s_scale = s_e / out_se

        # Row base for pid in contiguous [B, H, D] layout; chunk the row so
        # arbitrarily large head sizes stay within on-chip capacity.
        base = row.to(tl.int64) * HEAD_SIZE
        for start in range(0, HEAD_SIZE, BLOCK_SIZE):
            offs = start + tl.arange(0, BLOCK_SIZE)
            mask = offs < HEAD_SIZE
            p = tl.load(prefix_output + base + offs, mask=mask)
            s = tl.load(suffix_output + base + offs, mask=mask)
            o = p.to(tl.float32) * p_scale + s.to(tl.float32) * s_scale
            tl.store(output + base + offs, o.to(tl.bfloat16), mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    prefix_output = inputs["prefix_output"]
    prefix_lse = inputs["prefix_lse"]
    suffix_output = inputs["suffix_output"]
    suffix_lse = inputs["suffix_lse"]

    output = torch.empty_like(prefix_output)
    output_lse = torch.empty_like(prefix_lse)

    num_tokens, num_heads, head_size = prefix_output.shape

    # Chunk size mirrors the upstream next_power_of_2 head tile; capped so
    # large heads stream in bounded tiles instead of one giant allocation.
    block_size = max(min(triton.next_power_of_2(head_size), 4096), 32)

    # Keep the 2D grid product strictly below the 65536 block cap while
    # staying as parallel as possible; the stride loop absorbs the rest.
    max_blocks_per_head = max(65535 // max(num_heads, 1), 1)
    token_blocks = min(num_tokens, max_blocks_per_head)

    _merge_state_kernel[(token_blocks, num_heads)](
        output,
        output_lse,
        prefix_output,
        prefix_lse,
        suffix_output,
        suffix_lse,
        num_tokens,
        HEAD_SIZE=head_size,
        BLOCK_SIZE=block_size,
    )
    return {"_out0": output, "_out1": output_lse}
