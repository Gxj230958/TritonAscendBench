"""L3_09_causal_conv1d_fwd -- Triton-Ascend implementation (round 3).

Depthwise causal 1-D convolution over a [D, L] channel-major bf16 fixture
(Mamba-style prefill projection). With W = weight.shape[1] taps and a left zero
pad of W-1:

    out[d, t] = fp32 sum_j bf16_round(x[d, t-(W-1)+j] * w[d, j])
                + bias[d]            # fp32, added after the tap sum
                -> SiLU when asked   # fp32, acc / (1 + exp(-acc))
                -> bf16 at the store

Round 2's value pipeline is carried over untouched: per-tap narrowing by integer
bit surgery (no float-level fold can delete it), fp32 accumulator, ascending tap
order, bias last, fp32 SiLU, and the same rounding once more before the store.
That is deliberate. Round 2 passed 30/40 shapes and its 10 failures are the same
10 the task's shipped equivalence record marks CEILING_ACCEPTED at
max_abs=0.0078125 / max_rel=0.0055555557 -- the identical pair this round's
receipt reports for those shapes -- while the 30 records listed as VERIFIED are
the 30 that passed. The arithmetic is at the ceiling this task tolerates, so this
round moves the geometry, which is where the remaining score is: the harness
efficiency is baseline_ns / measured_ns per shape and the aggregate is a geometric
mean over all 40, so every microsecond off any shape counts.

One variable: how the lanes of a program are shaped.

Round 2 gave each program 2048 lanes as 32 channels x 64 tokens. Each tap load
then walked a 64-element row (128 bytes) at a 64-element-lane stride, under a
2-D predicate `idx_c < D & col < L & col >= 0`. The Ascend vector pipe consumes
4096 bits per instruction, 256 bf16 lanes, so a 64-lane row is one quarter of an
instruction's width and the row count multiplies the issue overhead; a 2-D
predicate is what keeps a masked load from lowering to a wide vector copy. This
version gives the same 2048 lanes to 2 channels x 1024 tokens (4 x 512 where the
row is shorter), so every load is 1024 contiguous bf16 -- 2 KB, four full vector
instructions -- and the predicate collapses onto the token axis alone.

That is a shape-only change on the shapes that matter, which is what makes it
worth a round: program counts are identical on every large fixture, so the timing
delta is attributable to contiguity and predicate rank rather than to how much
work each program holds or how many programs the scheduler must place.

    shape          round 2 tile   round 2 progs   this tile   this progs
    P8  384 x 8192    32 x 64          1536         2 x 1024       1536
    P7  384 x 6144    32 x 64          1152         2 x 1024       1152
    P4 1024 x 2048    32 x 64          1024         2 x 1024       1024
    P5 2048 x  256    32 x 64           256         8 x 256         256
    P11 3072 x 384    32 x 64           576        16 x 128         576
    P3   512 x  512    32 x 64           128        4 x 512         128
    P21  128 x  512    16 x 64            32        4 x 512          32

and the corresponding contiguous run per load goes 128 bytes -> 2048 bytes.

Two further pieces come along for free, both value-preserving by construction:

* FULL_C / FULL_T are decided on the host (D % BLOCK_C, L % BLOCK_T) and passed as
  constexpr, so a tile that cannot straddle a boundary issues no predicate for it:
  the `col < L` upper bound disappears from all KW tap masks, and a full tile
  stores unmasked. Live-lane values are unchanged -- FULL_T means
  idx_t <= L - 1, hence col < L for every tap -- and an unmasked full-tile store
  writes exactly the bytes the masked one would have. The left-pad predicate is
  never dropped: columns below zero are the reference's zero pad, and a masked-off
  lane still contributes 0.0.
* The grid axes swap so program_id(0) advances along tokens. Neighbouring
  programs then read neighbouring 2 KB runs of the same rows, which is the
  direction that streams; axis order cannot affect any element's value.
* `tl.max_contiguous` / `tl.multiple_of` name the token run's contiguity instead
  of leaving the pass to rediscover it through a constant shift. Hints only: they
  constrain codegen, never values.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

# activation scalar -> SiLU flag; anything unmapped runs the linear path.
_ACT_MODE = {
    "silu": 1,
    "swish": 1,
    "SiLU": 1,
    "Swish": 1,
    "SILU": 1,
    "SWISH": 1,
    "none": 0,
    "None": 0,
    "": 0,
}

# Lane budget per program, kept at round 2's value so the only variable is how
# those lanes are shaped. The token axis is filled first because it is the axis
# that is contiguous in memory and the axis the vector pipe consumes.
_BLOCK_LANES = 2048
_MIN_BLOCK_T = 16
_MAX_BLOCK_T = 1024
_MIN_BLOCK_C = 2


@triton.jit
def _causal_conv1d_fwd_ascend(
    x_ptr,
    w_ptr,
    b_ptr,
    o_ptr,
    D,
    L,
    stride_xc,
    stride_xt,
    stride_wc,
    stride_ww,
    stride_bc,
    stride_oc,
    stride_ot,
    BLOCK_C: tl.constexpr,
    BLOCK_T: tl.constexpr,
    KW: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    SILU: tl.constexpr,
    FULL_C: tl.constexpr,
    FULL_T: tl.constexpr,
):
    # Axis 0 is the token axis: neighbouring programs cover neighbouring token
    # blocks of the same channel block.
    pid_t = tl.program_id(0)
    pid_c = tl.program_id(1)

    idx_c = pid_c * BLOCK_C + tl.arange(0, BLOCK_C)
    idx_t = pid_t * BLOCK_T + tl.arange(0, BLOCK_T)
    mask_c = idx_c < D

    acc = tl.zeros((BLOCK_C, BLOCK_T), dtype=tl.float32)

    x_rows = x_ptr + idx_c[:, None] * stride_xc
    w_row = w_ptr + idx_c * stride_wc

    # Tap j reads the window shifted by -(KW-1)+j. Adjacent taps touch the same
    # cache lines, so reloading beats a rolling register window: every lane stays
    # busy and the taps form independent FMA chains. Columns left of the sequence
    # are the reference's zero pad -- the masked load returns 0.0 and the tap
    # contributes nothing. The right-hand bound only matters when a tile
    # straddles the end of a row, which FULL_T rules out at compile time, and the
    # channel bound only matters on a partial channel block, which FULL_C does.
    # The token index is an arange shifted by a compile-time constant, so the
    # run is contiguous by construction; say so explicitly, because this load is
    # the whole point of the tile shape and it should not have to be re-derived
    # from the address expression after the shift.
    idx_t = tl.max_contiguous(tl.multiple_of(idx_t, BLOCK_T), BLOCK_T)
    for j in tl.static_range(KW):
        col = idx_t - (KW - 1) + j
        if FULL_T:
            in_x = col >= 0
        else:
            in_x = (col >= 0) & (col < L)
        if FULL_C:
            mask_x = in_x[None, :]
        else:
            mask_x = mask_c[:, None] & in_x[None, :]
        x_tile = tl.load(x_rows + col[None, :] * stride_xt, mask=mask_x, other=0.0)
        if FULL_C:
            w_col = tl.load(w_row + j * stride_ww)
        else:
            w_col = tl.load(w_row + j * stride_ww, mask=mask_c, other=0.0)
        # Widen deliberately: a bf16 x bf16 product is exact in fp32 (the result
        # needs 16 mantissa bits at most), so the only rounding on the tap is the
        # one below, independent of whether this backend widens or narrows a
        # bf16 x bf16 product.
        prod = x_tile.to(tl.float32) * w_col.to(tl.float32)[:, None]
        # Round the product onto the bf16 grid by bit surgery: integer-only, so
        # no optimiser can fold it away as a redundant widen/narrow cast pair.
        u = prod.to(tl.int32, bitcast=True)
        u = u + 32767 + ((u >> 16) & 1)
        acc += (u - (u & 65535)).to(tl.float32, bitcast=True)

    if HAS_BIAS:
        if FULL_C:
            b_tile = tl.load(b_ptr + idx_c * stride_bc)
        else:
            b_tile = tl.load(b_ptr + idx_c * stride_bc, mask=mask_c, other=0.0)
        acc += b_tile.to(tl.float32)[:, None]

    if SILU:
        acc = acc / (1.0 + tl.exp(-acc))

    # Land on the bf16 grid before the store cast, so the final narrowing is
    # exact and does not depend on the backend's float-cast rounding mode.
    u = acc.to(tl.int32, bitcast=True)
    u = u + 32767 + ((u >> 16) & 1)
    out_tile = (u - (u & 65535)).to(tl.float32, bitcast=True).to(o_ptr.dtype.element_ty)

    o_ptrs = o_ptr + idx_c[:, None] * stride_oc + idx_t[None, :] * stride_ot
    if FULL_C and FULL_T:
        tl.store(o_ptrs, out_tile)
    elif FULL_C:
        in_o = idx_t < L
        tl.store(o_ptrs, out_tile, mask=in_o[None, :])
    else:
        in_o = idx_t < L
        tl.store(o_ptrs, out_tile, mask=mask_c[:, None] & in_o[None, :])


def _act_mode(inputs, key):
    """Map the activation scalar to a flag without touching tensor values."""
    if key in inputs:
        try:
            return _ACT_MODE[inputs[key]]
        except KeyError:
            return 0
    return 0


def _bias_flag(inputs):
    """1 when inputs carries a real bias tensor, 0 when it is absent or None."""
    if "bias" not in inputs:
        return 0
    try:
        inputs["bias"].contiguous()
    except AttributeError:
        return 0
    return 1


def _bias_or_weight(inputs, weight):
    """Bias tensor when present, else the weight; the kernel never reads this
    pointer unless the HAS_BIAS branch is live."""
    if "bias" not in inputs:
        return weight.contiguous()
    try:
        return inputs["bias"].contiguous()
    except AttributeError:
        return weight.contiguous()


def _pick_blocks(D: int, L: int) -> tuple[int, int]:
    """Power-of-two tile of <= _BLOCK_LANES lanes, token axis filled first.

    The token block is the widest power of two that divides L and still leaves
    the lane budget to a channel block of at least _MIN_BLOCK_C: run length is
    what the vector pipe pays for, and a block that divides L wastes no lane on
    a padded tail. If nothing divides above the 16-lane floor the least-padded
    candidate wins instead, tie-broken toward the longer run. Channels then take
    the rest of the budget -- that axis adds rows at stride L and buys no
    contiguity, so it must not compete with the axis the pipe consumes. Every
    candidate is capped at _MAX_BLOCK_T, so a program's live footprint stays
    within _MAX_BLOCK_T * _MAX_FOOTPRINT_ROWS rows of x whatever L is.
    """
    np2_c = triton.next_power_of_2(max(D, 1))
    np2_t = triton.next_power_of_2(max(L, 1))
    cap_t = min(np2_t, _MAX_BLOCK_T)
    if cap_t < _MIN_BLOCK_T:
        # Degenerate row: keep the 16-lane vector floor and buy channels instead.
        return max(min(np2_c, _BLOCK_LANES // _MIN_BLOCK_T), _MIN_BLOCK_C), _MIN_BLOCK_T

    # Widest divisor of L that leaves the budget's remainder to channels.
    block_t = 0
    b = cap_t
    while b >= _MIN_BLOCK_T:
        if L % b == 0 and _BLOCK_LANES // b >= _MIN_BLOCK_C:
            block_t = b
            break
        b //= 2

    if block_t == 0:
        # No divisor above the floor: minimise the padded tail.
        best_span = 0
        b = _MIN_BLOCK_T
        while b <= cap_t:
            span = triton.cdiv(L, b) * b
            if block_t == 0 or span <= best_span:
                best_span = span
                block_t = b
            b *= 2

    block_c = max(min(np2_c, _BLOCK_LANES // block_t), _MIN_BLOCK_C)
    return block_c, block_t


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weight = inputs["weight"]
    silu_mode = _act_mode(inputs, "activation")

    x_c = x.contiguous()
    w_c = weight.contiguous()
    bias_flag = _bias_flag(inputs)
    b_c = _bias_or_weight(inputs, w_c)

    dim = int(x_c.shape[0])
    seqlen = int(x_c.shape[1])
    kw = int(w_c.shape[-1])

    out = torch.empty((dim, seqlen), dtype=x_c.dtype, device=x_c.device)
    if dim == 0 or seqlen == 0 or kw == 0:
        return {"output": out}

    block_c, block_t = _pick_blocks(dim, seqlen)
    # Token axis first: neighbouring programs read neighbouring token blocks.
    grid = (triton.cdiv(seqlen, block_t), triton.cdiv(dim, block_c))

    # b_ptr is only read inside the HAS_BIAS branch, so a missing or None bias
    # still gets a real tensor and the constexpr drops the dead code.
    _causal_conv1d_fwd_ascend[grid](
        x_c,
        w_c,
        b_c,
        out,
        dim,
        seqlen,
        x_c.stride(0),
        x_c.stride(1),
        w_c.stride(0),
        w_c.stride(1),
        b_c.stride(0),
        out.stride(0),
        out.stride(1),
        BLOCK_C=block_c,
        BLOCK_T=block_t,
        KW=kw,
        HAS_BIAS=bias_flag,
        SILU=silu_mode,
        FULL_C=1 if dim % block_c == 0 else 0,
        FULL_T=1 if seqlen % block_t == 0 else 0,
    )

    return {"output": out}
