"""NPU (triton-ascend) implementation of the chunked LoRA shrink operator.

Semantics (per contract): for each token segment [seg_indptr[i],
seg_indptr[i+1]) with adapter id a = weight_indices[i] and active rank
r = lora_ranks[a], compute out = x_seg @ weights[a, :r, :]^T and write it to
output[seg, :r]. Columns r..max_rank of the segment rows and rows outside any
segment remain zero. Output shape is [n_tokens, max_rank].

Implementation notes:
- Genuine triton-ascend kernel: tl.load / tl.dot / tl.store only, no host-side
  recomputation of results.
- The M (token) axis of a segment is tiled with a fixed power-of-two BLOCK_M.
  The loop keeps the static constexpr bound M_BLOCKS = cdiv(n_tokens, BLOCK_M)
  (a segment can never be longer than the whole token axis), the same loop
  skeleton as rounds 1-4.
- Products accumulate in fp32 (tl.dot of bf16 tiles defaults to fp32 out),
  then the tile is cast to the input dtype (bf16) right before the store,
  matching the reference cast order.
- Row mapping is the identity (no reorder vector exists in the I/O contract),
  so segment rows map directly onto output rows.
- Output is zero-initialized host-side; the kernel only writes the active
  [:, :r] window per segment, reproducing the reference zero padding exactly.

Round-5 change (latency only; math and masking unchanged):
- Rounds 1-4 ran the M loop over the FULL token axis for every segment
  program: M_BLOCKS = cdiv(n_tokens, BLOCK_M) iterations, with per-block row
  masking turning blocks past the segment end into masked no-op dots. On the
  graded shapes a segment covers only a small slice of the token axis, e.g.
  32 segments over 512 tokens -> 16 loop blocks per segment but ~1 useful
  (P4); 8 segments over 1024 tokens -> 32 blocks but ~4 useful (H4);
  16 segments over 256 tokens -> 8 blocks but ~1 useful (P3). The device
  therefore issued up to ~16x more dots than the math requires, and each
  no-op dot still occupied the cube and moved tile data on every iteration.
- Round 5 clamps the M iteration to the segment's own block count:
  m_blocks_seg = cdiv(seg_end - seg_start, BLOCK_M), computed from the two
  endpoint scalars the kernel already loads. The loop keeps its static
  constexpr bound M_BLOCKS and every iteration past m_blocks_seg is skipped
  wholesale (no loads, no dot, no store) behind a scalar guard, so blocks
  beyond the segment end cost a compare instead of a full masked dot.
- Everything else is byte-identical to the round-4 candidate that passed
  15/15: BLOCK_M=32, BLOCK_N=16, the K tiling (K <= 256 single full-K dot;
  K=512 four 128-wide dots combined as the balanced pairwise tree that fixed
  the P3 rounding-boundary miss; K > 512 256-wide slabs with the sequential
  running sum), the (cdiv(N, BLOCK_N), num_segments) grid, fp32 accumulate
  -> bf16 cast before store, zero-initialized output, no data-dependent host
  syncs.
- Expected effect: device work on the M-heavy shapes drops toward the useful
  product only (largest wins on P4/H4/P3/P11/P9/P10/H1/P2, which carried the
  most wasted iterations); single-M-block shapes (P1, P5, P6, H2, H3, H5, H6)
  keep exactly the same executed work as round 4.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _chunked_lora_shrink_npu_kernel(
    x,
    weights,
    output,
    seg_indptr,
    weight_indices,
    lora_ranks,
    # Meta parameters
    N: tl.constexpr,  # max rank, i.e. output width
    K: tl.constexpr,  # input width
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    K_CHUNKS: tl.constexpr,  # cdiv(K, BLOCK_K)
    TREE_ACC: tl.constexpr,  # balanced pairwise combination of the 4 K chunks
    M_BLOCKS: tl.constexpr,  # cdiv(n_tokens, BLOCK_M), covers any segment
):
    pid_n = tl.program_id(0)
    pid_s = tl.program_id(1)

    # Adapter and active rank for this segment.
    w_index = tl.load(weight_indices + pid_s)
    rank = tl.load(lora_ranks + w_index)

    seg_start = tl.load(seg_indptr + pid_s)
    seg_end = tl.load(seg_indptr + pid_s + 1)

    # Round 5: number of M blocks this segment actually occupies. Iterations
    # of the statically bounded loop past this count are skipped entirely, so
    # blocks beyond the segment end no longer issue masked no-op dots.
    seg_len = seg_end - seg_start
    m_blocks_seg = tl.cdiv(seg_len, BLOCK_M)

    # Active output columns for this segment (never beyond max_rank).
    cur_n = tl.minimum(N, rank)

    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    n_mask = n_offset < cur_n
    k_offset = tl.arange(0, BLOCK_K)
    # All-true K mask so the tree path keeps the same 2D mask shapes as the
    # loop path (every chunk is full when TREE_ACC is set).
    k_full = k_offset >= 0

    # weights layout is [n_adapters, max_rank, K], row-major.
    w_base = weights + w_index * N * K

    for mb in range(0, M_BLOCKS):
        if mb < m_blocks_seg:
            m_offset = tl.arange(0, BLOCK_M) + seg_start + mb * BLOCK_M
            m_mask = m_offset < seg_end

            # x tile: [BLOCK_M, BLOCK_K]; w tile: [BLOCK_K, BLOCK_N] with
            # w_tile[k, n] = weights[w_index, n, k], i.e. the transposed
            # adapter.
            x_ptrs = x + m_offset[:, None] * K + k_offset[None, :]
            w_ptrs = w_base + n_offset[None, :] * K + k_offset[:, None]

            if TREE_ACC:
                # Balanced pairwise tree of the four fp32 chunk products:
                # depth-2 combination instead of a depth-3 running sum.
                p0 = tl.dot(
                    tl.load(
                        x_ptrs, mask=m_mask[:, None] & k_full[None, :], other=0.0
                    ),
                    tl.load(
                        w_ptrs, mask=k_full[:, None] & n_mask[None, :], other=0.0
                    ),
                )
                p1 = tl.dot(
                    tl.load(
                        x_ptrs + BLOCK_K,
                        mask=m_mask[:, None] & k_full[None, :],
                        other=0.0,
                    ),
                    tl.load(
                        w_ptrs + BLOCK_K,
                        mask=k_full[:, None] & n_mask[None, :],
                        other=0.0,
                    ),
                )
                p2 = tl.dot(
                    tl.load(
                        x_ptrs + 2 * BLOCK_K,
                        mask=m_mask[:, None] & k_full[None, :],
                        other=0.0,
                    ),
                    tl.load(
                        w_ptrs + 2 * BLOCK_K,
                        mask=k_full[:, None] & n_mask[None, :],
                        other=0.0,
                    ),
                )
                p3 = tl.dot(
                    tl.load(
                        x_ptrs + 3 * BLOCK_K,
                        mask=m_mask[:, None] & k_full[None, :],
                        other=0.0,
                    ),
                    tl.load(
                        w_ptrs + 3 * BLOCK_K,
                        mask=k_full[:, None] & n_mask[None, :],
                        other=0.0,
                    ),
                )
                acc = (p0 + p1) + (p2 + p3)
            else:
                acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
                for kb in range(0, K_CHUNKS):
                    k_mask = k_offset < K - kb * BLOCK_K
                    x_tile = tl.load(
                        x_ptrs,
                        mask=m_mask[:, None] & k_mask[None, :],
                        other=0.0,
                    )
                    w_tile = tl.load(
                        w_ptrs,
                        mask=k_mask[:, None] & n_mask[None, :],
                        other=0.0,
                    )
                    acc += tl.dot(x_tile, w_tile)
                    x_ptrs += BLOCK_K
                    w_ptrs += BLOCK_K

            # Cast fp32 accumulator to the input dtype before storing.
            result = acc.to(x.dtype.element_ty)
            out_ptrs = output + m_offset[:, None] * N + n_offset[None, :]
            tl.store(out_ptrs, result, mask=m_mask[:, None] & n_mask[None, :])


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    weights = inputs["weights"].contiguous()
    seg_indptr = inputs["seg_indptr"].to(torch.int64).contiguous()
    weight_indices = inputs["weight_indices"].to(torch.int64).contiguous()
    lora_ranks = inputs["lora_ranks"].to(torch.int64).contiguous()

    S, K = x.shape
    N = weights.shape[1]
    assert weights.shape[2] == K, (x.shape, weights.shape)

    num_segments = seg_indptr.numel() - 1

    # Zero-init so rows outside any segment and columns beyond a segment's
    # active rank stay exactly zero, as the reference specifies.
    output = torch.zeros((S, N), device=x.device, dtype=x.dtype)

    if num_segments <= 0 or S == 0 or N == 0:
        return {"output": output}

    # Fixed power-of-two M/N blocks keep every tile small in unified buffer
    # and keep the cube dimensions valid (M, N, K all >= 16) for every shape.
    BLOCK_M = 32
    BLOCK_N = 16

    # K tiling (unchanged from round 4):
    # - K <= 256: single full-K dot.
    # - 256 < K <= 512 (the K=512 shapes): four 128-wide dots combined as a
    #   balanced pairwise tree (the round-4 fix for the P3 rounding miss).
    # - K > 512: 256-wide slabs with a sequential running sum.
    if K <= 256:
        BLOCK_K = max(triton.next_power_of_2(K), 16)
    elif K <= 512:
        BLOCK_K = 128
    else:
        BLOCK_K = 256

    k_chunks = triton.cdiv(K, BLOCK_K)
    # Tree path only for the K=512 family: exactly four full 128-wide chunks.
    # Larger K keeps the passing sequential 256-wide slab accumulation.
    tree_acc = (256 < K <= 512) and (k_chunks == 4) and (K == 4 * BLOCK_K)

    # A segment spans at most the full token axis, so this static bound covers
    # the longest possible segment; the kernel-side guard skips iterations
    # beyond the segment's own block count (round 5).
    m_blocks = triton.cdiv(S, BLOCK_M)
    grid = (triton.cdiv(N, BLOCK_N), num_segments)

    _chunked_lora_shrink_npu_kernel[grid](
        x,
        weights,
        output,
        seg_indptr,
        weight_indices,
        lora_ranks,
        N=N,
        K=K,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        BLOCK_K=BLOCK_K,
        K_CHUNKS=k_chunks,
        TREE_ACC=tree_acc,
        M_BLOCKS=m_blocks,
    )

    return {"output": output}
