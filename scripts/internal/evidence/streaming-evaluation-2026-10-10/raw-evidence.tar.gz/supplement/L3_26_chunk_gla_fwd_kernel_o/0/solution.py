"""Triton-Ascend port of the chunked-GLA output kernel (L3_26).

Ports the frozen upstream `chunk_gla_fwd_kernel_o` (dense, non-varlen
path) to triton-ascend for the 910B. Per (batch, head, chunk) the kernel
produces one BT-row output tile:

    o[b, r, h, :] = sum_k (q*scale*exp(g))[b,r,h,k] * h_state[b,c,h,:,k]
                  + sum_{j<=i} A[b,r,h,j] * v[b,c*BT+j,h,:]

Layouts (dense, head-structured, block-diagonal per chunk):
    q, g : [B, T, H, K]
    v    : [B, T, H, V]
    A    : [B, T, H, BT]    last axis is the LOCAL within-chunk column
    h    : [B, NT, H, V, K] per-chunk state, read as a [V, K] tile
    o    : [B, T, H, V]

Port decisions:
- Both tl.dot calls run on fp32 inputs with input_precision="ieee" and an
  fp32 accumulator, keeping the task's fp32 end-to-end contract.
- Tiling uses explicit pointer arithmetic; the state tile is loaded
  already-oriented as [BK, BV] (swapped strides) so no tensor transpose
  op is needed before the dot.
- BK/BV are clamped to at least 16 lanes (cube-friendly tile sizes) and
  masked loads zero-pad out-of-range lanes, so degenerate K/V extents
  (e.g. 1..8) stay correct without a special path.
- The varlen branch is dropped: the contract only exercises the dense
  path, so T is the per-batch sequence length and bos = i_b * T.
"""

import torch
import triton
import triton.language as tl


def _next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


@triton.jit(do_not_specialize=["T"])
def _chunk_gla_fwd_kernel_o(
    q, v, g, h, o, A,
    scale,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
):
    i_v, i_t, i_bh = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    i_b, i_h = i_bh // H, i_bh % H
    NT = tl.cdiv(T, BT)
    i_tg = i_b * NT + i_t
    bos = i_b * T

    # Global rows of this chunk tile and the local column axis.
    offs_i = i_t * BT + tl.arange(0, BT)
    mask_i = offs_i < T
    offs_c = tl.arange(0, BT)
    offs_v = i_v * BV + tl.arange(0, BV)
    mask_v = offs_v < V

    # Lower-triangular (diagonal kept) mask over the local chunk columns.
    m_s = offs_c[:, None] >= offs_c[None, :]

    # Inter-chunk term: gated-query read of the per-chunk [V, K] state.
    # The state tile is loaded directly as [BK, BV] (strides swapped) so
    # the dot consumes it without a separate transpose step.
    b_o = tl.zeros([BT, BV], dtype=tl.float32)
    qg_base = (q + (bos * H + i_h) * K)
    gg_base = (g + (bos * H + i_h) * K)
    h_base = h + (i_tg * H + i_h) * K * V
    for i_k in range(tl.cdiv(K, BK)):
        offs_k = i_k * BK + tl.arange(0, BK)
        mask_k = offs_k < K
        mk = mask_i[:, None] & mask_k[None, :]
        b_q = tl.load(qg_base + offs_i[:, None] * (H * K) + offs_k[None, :],
                      mask=mk, other=0.0)
        b_q = (b_q * scale).to(b_q.dtype)
        b_g = tl.load(gg_base + offs_i[:, None] * (H * K) + offs_k[None, :],
                      mask=mk, other=0.0)
        b_qg = (b_q * tl.exp(b_g)).to(b_q.dtype)
        b_ht = tl.load(h_base + offs_k[:, None] + offs_v[None, :] * K,
                       mask=mask_k[:, None] & mask_v[None, :], other=0.0)
        b_o += tl.dot(b_qg, b_ht, input_precision="ieee", out_dtype=tl.float32)

    # Intra-chunk term: causal-masked score x value within the chunk.
    v_base = v + (bos * H + i_h) * V
    a_base = A + (bos * H + i_h) * BT
    b_A = tl.load(a_base + offs_i[:, None] * (H * BT) + offs_c[None, :],
                  mask=mask_i[:, None], other=0.0)
    b_A = tl.where(m_s, b_A, 0.0)
    b_v = tl.load(v_base + (i_t * BT + offs_c)[:, None] * (H * V) + offs_v[None, :],
                  mask=((i_t * BT + offs_c) < T)[:, None] & mask_v[None, :],
                  other=0.0)
    b_o += tl.dot(b_A, b_v, input_precision="ieee", out_dtype=tl.float32)

    o_base = o + (bos * H + i_h) * V
    p_o = o_base + offs_i[:, None] * (H * V) + offs_v[None, :]
    tl.store(p_o, b_o.to(p_o.dtype.element_ty),
             mask=mask_i[:, None] & mask_v[None, :])


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    v = inputs["v"]
    g = inputs["g"]
    A = inputs["A"]
    h = inputs["h"]
    scale = inputs["scale"]

    B, T, H, K = q.shape
    V = v.shape[-1]
    BT = A.shape[-1]
    NT = (T + BT - 1) // BT

    # Cube tiles want >= 16 lanes; masked loads absorb the zero padding.
    BK = min(32, max(16, _next_pow2(K)))
    BV = min(64, max(16, _next_pow2(V)))

    o = torch.empty_like(v)
    grid = ((V + BV - 1) // BV, NT, B * H)
    _chunk_gla_fwd_kernel_o[grid](
        q, v, g, h, o, A,
        scale, T,
        H=H, K=K, V=V, BT=BT, BK=BK, BV=BV,
    )
    return {"output": o}


# Alias so either entry name resolves to the same implementation.
run = npu_triton_impl
