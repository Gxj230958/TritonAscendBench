import torch
import triton
import triton.language as tl


@triton.jit(do_not_specialize=["T"])
def _chunk_delta_fwd_kernel(
    k_ptr, w_ptr, u_ptr, g_ptr, gk_ptr, h_ptr,
    T,
    B: tl.constexpr,
    H: tl.constexpr,
    Hg: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BV: tl.constexpr,
    BT: tl.constexpr,
):
    """Chunk-level gated delta rule forward kernel.

    Each program handles one (V-block, batch, head) tile.
    State S is carried in [64, BV] register tiles (K-first layout)
    across the K dimension, iteratively updated across NT chunks.

    The K-first layout avoids tl.trans: both tl.dot calls in the
    inner loop already have their inner dimensions aligned.

    Per chunk the recurrence is:
        1. h[i_t] = S                       (snapshot before update)
        2. b_v = w_chunk @ S_tile            (predict V from state)  [BT,64]@[64,BV]=[BT,BV]
        3. dv = u_chunk - b_v               (residual value)
        4. dv *= exp(g_last - g_row)        (gate by cumulative log-decay)
        5. S *= exp(g_last)                 (scalar state decay)
        6. S *= exp(gk_last) per-K-channel  (per-channel state decay)
        7. S += k_tile^T @ dv               (accumulate)              [64,BT]@[BT,BV]=[64,BV]
    """
    i_v = tl.program_id(0)
    i_bh = tl.program_id(1)
    i_b = i_bh // H
    i_h = i_bh % H

    # Key-head grouping: each value head maps to a (possibly shared) key head.
    group = H // Hg
    i_hg = i_h // group
    NT = tl.cdiv(T, BT)

    # Strides (contiguous layout)
    stride_h_nt = H * V * K
    stride_h_v  = K
    stride_w_t  = H * K
    stride_u_t  = H * V
    stride_k_t  = Hg * K
    stride_g_t  = H

    # Base offsets for this (i_b, i_h) / (i_b, i_hg) pair
    off_h  = (i_b * NT * stride_h_nt + i_h * V * K).to(tl.int64)
    off_w  = (i_b * T * stride_w_t + i_h * K).to(tl.int64)
    off_u  = (i_b * T * stride_u_t + i_h * V).to(tl.int64)
    off_k  = (i_b * T * stride_k_t + i_hg * K).to(tl.int64)
    off_g  = (i_b * T * stride_g_t + i_h).to(tl.int64)
    off_gk = (i_b * T * stride_w_t + i_h * K).to(tl.int64)

    # Register tiles: state S stored as [64, BV] (K-first, not V-first).
    # This eliminates the need for tl.trans in both tl.dot calls.
    b_h1 = tl.zeros([64, BV], dtype=tl.float32)
    if K > 64:
        b_h2 = tl.zeros([64, BV], dtype=tl.float32)
    if K > 128:
        b_h3 = tl.zeros([64, BV], dtype=tl.float32)
    if K > 192:
        b_h4 = tl.zeros([64, BV], dtype=tl.float32)

    # Precompute index ranges (compile-time constants)
    o_v  = tl.arange(0, BV)           # V tile indices [0..BV-1]
    o_bt = tl.arange(0, BT)           # Time chunk indices [0..BT-1]
    o_k1 = tl.arange(0, 64)           # K tile indices [0..63]
    # masks
    mask_v = o_v < V                  # [BV]
    mask_v_row = mask_v[None, :]      # [1, BV] for broadcasting with [64, BV] tiles

    # Main loop over time chunks
    for i_t in range(NT):
        t_start = i_t * BT
        t_end = t_start + BT
        last_t = min(t_end, T) - 1

        # time mask: which BT slots are valid
        abs_t = t_start + o_bt        # [BT] absolute time indices
        mask_t = abs_t < T            # [BT]
        mask_t_col = mask_t[:, None]  # [BT, 1]

        # ── 1. STORE: snapshot state S -> h output ────────────────────
        # h layout: [B, NT, H, V, K], element (v,k) offset = v*K + k
        # b_h1 is [64, BV] = [K_seg, V_seg]
        h_base = h_ptr + off_h + i_t.to(tl.int64) * stride_h_nt
        # offset[i,j] = h_base + o_k1[i] + o_v[j] * stride_h_v   -> [64, BV]
        off_hk1 = h_base + (o_k1[:, None] + o_v[None, :] * stride_h_v).to(tl.int64)
        tl.store(off_hk1, b_h1, mask=mask_v_row)
        if K > 64:
            off_hk2 = h_base + (64 + o_k1[:, None] + o_v[None, :] * stride_h_v).to(tl.int64)
            tl.store(off_hk2, b_h2, mask=mask_v_row)
        if K > 128:
            off_hk3 = h_base + (128 + o_k1[:, None] + o_v[None, :] * stride_h_v).to(tl.int64)
            tl.store(off_hk3, b_h3, mask=mask_v_row)
        if K > 192:
            off_hk4 = h_base + (192 + o_k1[:, None] + o_v[None, :] * stride_h_v).to(tl.int64)
            tl.store(off_hk4, b_h4, mask=mask_v_row)

        # ── 2. LOAD w chunk [BT, 64] and compute b_v += w @ S  [BT,BV] ─
        # b_w1 is [BT, 64], b_h1 is [64, BV] -> tl.dot -> [BT, BV]. No trans needed.
        w_off = w_ptr + off_w + (t_start + o_bt[:, None]) * stride_w_t + o_k1[None, :]
        b_w1 = tl.load(w_off, mask=mask_t_col, other=0.0).to(tl.float32)
        b_v = tl.dot(b_w1, b_h1)
        if K > 64:
            b_w2 = tl.load(w_off + 64, mask=mask_t_col, other=0.0).to(tl.float32)
            b_v = b_v + tl.dot(b_w2, b_h2)
        if K > 128:
            b_w3 = tl.load(w_off + 128, mask=mask_t_col, other=0.0).to(tl.float32)
            b_v = b_v + tl.dot(b_w3, b_h3)
        if K > 192:
            b_w4 = tl.load(w_off + 192, mask=mask_t_col, other=0.0).to(tl.float32)
            b_v = b_v + tl.dot(b_w4, b_h4)

        # ── 3. LOAD u chunk [BT, BV], dv = u - b_v ────────────────────
        u_off = u_ptr + off_u + (t_start + o_bt[:, None]) * stride_u_t + o_v[None, :]
        b_u = tl.load(u_off, mask=mask_t_col & mask_v_row, other=0.0).to(tl.float32)
        b_v = b_u - b_v

        # ── 4. GATE: dv *= exp(g_last - g_row) ────────────────────────
        g_last = tl.load(g_ptr + off_g + last_t * stride_g_t)
        g_off = g_ptr + off_g + (t_start + o_bt) * stride_g_t
        b_g = tl.load(g_off, mask=mask_t, other=0.0)
        b_v = b_v * tl.where(mask_t, tl.exp(g_last - b_g), 0.0)[:, None]

        # ── 5. DECAY S by exp(g_last) (scalar broadcast) ──────────────
        decay_g = tl.exp(g_last)
        b_h1 = b_h1 * decay_g
        if K > 64:
            b_h2 = b_h2 * decay_g
        if K > 128:
            b_h3 = b_h3 * decay_g
        if K > 192:
            b_h4 = b_h4 * decay_g

        # ── 6. Per-K-channel decay S *= exp(gk_last) ──────────────────
        # gk_last is [64], broadcast as [64, 1] over [64, BV] tiles.
        gk_off_base = gk_ptr + off_gk + last_t * stride_w_t
        gk_last1 = tl.load(gk_off_base + o_k1, mask=o_k1 < K, other=0.0)
        b_h1 = b_h1 * tl.exp(gk_last1)[:, None]
        if K > 64:
            gk_last2 = tl.load(gk_off_base + 64 + o_k1, mask=(64 + o_k1) < K, other=0.0)
            b_h2 = b_h2 * tl.exp(gk_last2)[:, None]
        if K > 128:
            gk_last3 = tl.load(gk_off_base + 128 + o_k1, mask=(128 + o_k1) < K, other=0.0)
            b_h3 = b_h3 * tl.exp(gk_last3)[:, None]
        if K > 192:
            gk_last4 = tl.load(gk_off_base + 192 + o_k1, mask=(192 + o_k1) < K, other=0.0)
            b_h4 = b_h4 * tl.exp(gk_last4)[:, None]

        # ── 7. LOAD k chunk [64, BT], S += k^T @ dv  ->  [64, BV] ────
        # b_k1 is [64, BT], b_v is [BT, BV] -> tl.dot -> [64, BV]. No trans needed.
        b_v_f32 = b_v.to(tl.float32)
        k_off = k_ptr + off_k + (t_start + o_bt[None, :]) * stride_k_t + o_k1[:, None]
        b_k1 = tl.load(k_off, mask=mask_t[None, :], other=0.0).to(tl.float32)
        b_h1 = b_h1 + tl.dot(b_k1, b_v_f32)
        if K > 64:
            b_k2 = tl.load(k_off + 64, mask=mask_t[None, :], other=0.0).to(tl.float32)
            b_h2 = b_h2 + tl.dot(b_k2, b_v_f32)
        if K > 128:
            b_k3 = tl.load(k_off + 128, mask=mask_t[None, :], other=0.0).to(tl.float32)
            b_h3 = b_h3 + tl.dot(b_k3, b_v_f32)
        if K > 192:
            b_k4 = tl.load(k_off + 192, mask=mask_t[None, :], other=0.0).to(tl.float32)
            b_h4 = b_h4 + tl.dot(b_k4, b_v_f32)


def npu_triton_impl(inputs: dict) -> dict:
    """NPU triton-ascend implementation of the chunk gated delta rule.

    Inputs dict keys: k, w, u, g, gk (all float32).
    Returns dict with key "output": h [B, NT, H, V, K] float32.
    """
    k = inputs["k"].contiguous()
    w = inputs["w"].contiguous()
    u = inputs["u"].contiguous()
    g = inputs["g"].contiguous()
    gk = inputs["gk"].contiguous()

    B, T, Hg, K = k.shape
    H = u.shape[-2]
    V = u.shape[-1]
    device = k.device

    BT = 64  # chunk size
    NT = (T + BT - 1) // BT

    # Output: per-chunk state snapshots [B, NT, H, V, K]
    h = torch.empty(B, NT, H, V, K, dtype=torch.float32, device=device)

    BV = 64  # V-dimension block size
    num_v_blocks = (V + BV - 1) // BV

    def grid(args):
        return (num_v_blocks, B * H)

    _chunk_delta_fwd_kernel[grid](
        k, w, u, g, gk, h,
        T=T,
        B=B,
        H=H,
        Hg=Hg,
        K=K,
        V=V,
        BV=BV,
        BT=BT,
        num_warps=2,
        num_stages=2,
    )

    return {"output": h}
