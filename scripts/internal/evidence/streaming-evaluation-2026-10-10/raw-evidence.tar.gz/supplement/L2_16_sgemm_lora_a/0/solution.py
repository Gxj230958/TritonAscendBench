"""Triton-Ascend implementation of the segmented LoRA-shrink kernel
 `_sgemm_lora_a_kernel` (upstream SGLang, vendored in kernel.py).

Semantics
---------
For every token segment i delimited by seg_indptr[i] .. seg_indptr[i+1],
the output rows in that span receive

    out[s:e, :rank] = x[s:e] @ weights[adapter_id(i), :rank, :].T

with `adapter_id(i) = weight_indices[i]` and
`rank = lora_ranks[adapter_id(i)]`. Columns beyond the segment's rank and
rows belonging to empty segments stay zero.

Implementation notes
--------------------
* A single Triton kernel implements the whole op. Segment geometry is read
  from `seg_indptr` inside the kernel (seg_len = indptr[i+1] - indptr[i]),
  so the host does no tensor arithmetic at all.
* Grid axis 1 is the segment id; grid axis 0 tiles the full S x R output
  space (token blocks x rank blocks). Programs whose token block lies past
  the segment end, or whose rank block lies past the active rank, perform no
  K-loop work (dynamic loop bound collapses to zero) and store nothing.
* Rank truncation is expressed with masks: weight tiles are zeroed for
  columns >= min(R, rank), and the store mask keeps those columns out of
  the output. The output is zero-initialized once on the host so cells the
  kernel never touches are exactly zero.
* Accumulation is fp32 (tl.dot with bf16 inputs); the result is cast to
  bf16 on store, matching the reference math.
* No early returns: every control flow is mask/bound based, which keeps the
  kernel portable across backends.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _sgemm_lora_a_kernel(
    # Pointers
    x,
    weights,
    output,
    # Dimensions
    N,  # stack_num * r (max_rank when stack_num == 1)
    K,  # input feature dim
    stack_num,
    # Strides
    x_stride_0,
    x_stride_1,
    w_stride_0,
    w_stride_1,
    w_stride_2,
    output_stride_0,
    output_stride_1,
    # Segment / adapter bookkeeping
    seg_indptr,
    weight_indices,
    lora_ranks,
    # Block sizes
    BLOCK_S: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    batch_id = tl.program_id(axis=1)
    pid = tl.program_id(axis=0)

    w_index = tl.load(weight_indices + batch_id).to(tl.int32)
    rank = tl.load(lora_ranks + w_index).to(tl.int32)

    # Active columns for this segment; >= 1 guard avoids zero-size tiles.
    n_valid = tl.minimum(N, rank * stack_num)
    n_safe = tl.maximum(n_valid, 1)

    num_pid_n = tl.cdiv(n_safe, BLOCK_N)
    pid_s = pid // num_pid_n
    pid_n = pid % num_pid_n

    seg_start = tl.load(seg_indptr + batch_id).to(tl.int32)
    seg_end = tl.load(seg_indptr + batch_id + 1).to(tl.int32)
    seg_len = seg_end - seg_start

    s_offset = tl.arange(0, BLOCK_S) + pid_s * BLOCK_S
    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    k_offset = tl.arange(0, BLOCK_K)

    s_mask = s_offset < seg_len
    # Skip all K-loop work for token/rank blocks outside this segment.
    active = (pid_s * BLOCK_S < seg_len) & (pid_n * BLOCK_N < n_valid)
    n_iters = tl.cdiv(K, BLOCK_K) * active.to(tl.int32)

    x_ptrs = (
        x
        + (seg_start + s_offset[:, None]) * x_stride_0
        + k_offset[None, :] * x_stride_1
    )
    w_ptrs = (
        weights
        + w_index * w_stride_0
        + k_offset[:, None] * w_stride_2
        + n_offset[None, :] * w_stride_1
    )

    partial_sum = tl.zeros((BLOCK_S, BLOCK_N), dtype=tl.float32)
    for k in range(0, n_iters):
        x_tile = tl.load(
            x_ptrs,
            mask=(s_mask[:, None]) & (k_offset[None, :] < K - k * BLOCK_K),
            other=0.0,
        )
        w_tile = tl.load(
            w_ptrs,
            mask=(k_offset[:, None] < K - k * BLOCK_K)
            & (n_offset[None, :] < n_valid),
            other=0.0,
        )
        partial_sum += tl.dot(x_tile, w_tile)
        x_ptrs += BLOCK_K * x_stride_1
        w_ptrs += BLOCK_K * w_stride_2

    partial_sum = partial_sum.to(x.dtype.element_ty)
    output_mask = s_mask[:, None] & (n_offset[None, :] < n_valid)
    output_ptrs = (
        output
        + (seg_start + s_offset[:, None]) * output_stride_0
        + n_offset[None, :] * output_stride_1
    )
    tl.store(output_ptrs, partial_sum, mask=output_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weights = inputs["weights"]
    seg_indptr = inputs["seg_indptr"]
    weight_indices = inputs["weight_indices"]
    lora_ranks = inputs["lora_ranks"]

    S, K = x.shape
    num_lora, R, Kw = weights.shape
    assert Kw == K

    output = torch.zeros((S, R), device=x.device, dtype=x.dtype)

    num_segments = seg_indptr.numel() - 1
    if num_segments == 0 or S == 0 or R == 0:
        return {"output": output}

    BLOCK_S = 16
    BLOCK_N = 16
    BLOCK_K = 256

    grid = (triton.cdiv(S, BLOCK_S) * triton.cdiv(R, BLOCK_N), num_segments)
    _sgemm_lora_a_kernel[grid](
        x,
        weights,
        output,
        R,
        K,
        1,
        x.stride(0),
        x.stride(1),
        weights.stride(0),
        weights.stride(1),
        weights.stride(2),
        output.stride(0),
        output.stride(1),
        seg_indptr,
        weight_indices,
        lora_ranks,
        BLOCK_S=BLOCK_S,
        BLOCK_N=BLOCK_N,
        BLOCK_K=BLOCK_K,
    )
    return {"output": output}
