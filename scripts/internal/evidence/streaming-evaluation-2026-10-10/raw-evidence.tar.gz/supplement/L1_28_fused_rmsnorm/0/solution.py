"""NPU Triton solution for L1_28_fused_rmsnorm — fused RMSNorm kernel.

Per-row RMSNorm: out = RMSNorm(x) * weight
  rms = sqrt(mean(x^2, last_dim) + eps)
  out = (x / rms) * weight

All reduction arithmetic performed in float32; output cast back to input dtype.

Round-4 fixes:
  1. Cap BLOCK_SIZE at 1024 and use a grid-stride loop for the sum-of-squares
     pass. This avoids oversized kernels that previously failed to compile
     (H7 shape with D=32768) and improves numerical precision (P4 fix).
  2. Keep a single program per row but iterate tiles over the hidden dim
     in the first pass (accumulate sum_sq) and in the second pass (write out).
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _fused_rmsnorm_kernel(
    output_ptr,
    input_ptr,
    weight_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """One program instance per row; two-pass over hidden dimension.

    Pass 1: grid-stride loop to accumulate sum of squares in float32.
    Pass 2: grid-stride loop to load input, normalize, scale, and store.
    """
    pid = tl.program_id(axis=0)
    row_start = pid * hidden_dim
    offsets = tl.arange(0, BLOCK_SIZE)

    # --- Pass 1: compute sum of squares via grid-stride loop ---
    sum_sq = 0.0
    col = 0
    while col < hidden_dim:
        idx = col + offsets
        mask = idx < hidden_dim
        a = tl.load(input_ptr + row_start + idx, mask=mask, other=0.0).to(tl.float32)
        sum_sq += tl.sum(a * a)
        col += BLOCK_SIZE

    rms = tl.sqrt(sum_sq / hidden_dim + eps)

    # --- Pass 2: normalize, scale, store via grid-stride loop ---
    col = 0
    while col < hidden_dim:
        idx = col + offsets
        mask = idx < hidden_dim
        a = tl.load(input_ptr + row_start + idx, mask=mask, other=0.0).to(tl.float32)
        w = tl.load(weight_ptr + idx, mask=mask, other=0.0).to(tl.float32)
        out = (a / rms) * w
        tl.store(output_ptr + row_start + idx, out, mask=mask)
        col += BLOCK_SIZE


def _fused_rmsnorm(x: torch.Tensor, weight: torch.Tensor, eps) -> torch.Tensor:
    """Host wrapper for the RMSNorm kernel."""
    assert x.dim() == 2, "expected 2-D tensor"
    bs, hidden_dim = x.shape
    output = torch.empty_like(x)

    # Cap BLOCK_SIZE at 1024 to avoid compilation issues with huge D
    # and improve numerical precision by breaking up large reductions.
    BLOCK_SIZE = min(1024, triton.next_power_of_2(hidden_dim))
    if BLOCK_SIZE < 2:
        BLOCK_SIZE = 2

    num_warps = 4 if BLOCK_SIZE <= 256 else 8

    _fused_rmsnorm_kernel[bs,](
        output,
        x,
        weight,
        eps=eps,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=num_warps,
    )
    return output


def npu_triton_impl(inputs: dict) -> dict:
    """Entrypoint: accepts and returns a dict of tensors / scalars."""
    x = inputs["x"].contiguous()
    weight = inputs["weight"].contiguous()
    eps = inputs["eps"]

    out = _fused_rmsnorm(x, weight, eps)
    return {"output": out}
