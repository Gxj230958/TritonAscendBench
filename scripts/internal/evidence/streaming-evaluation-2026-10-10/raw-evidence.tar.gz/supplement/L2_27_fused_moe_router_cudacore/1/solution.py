"""Round 4 — MoE router kernel using only Layer-C allowed Triton primitives.

Custom argmax via sum-of-masked-indices and manual invsumexp for softmax
weights. BLOCK_SIZE capped at 2048 to handle large hidden dimensions.
"""
import triton
import triton.language as tl
import torch


@triton.jit
def _argmax_idx(values, n: tl.constexpr):
    """Return index of the maximum element in a (n,) tensor."""
    idx = tl.arange(0, n)
    max_val = tl.max(values, axis=0)
    is_max = (values == max_val).to(tl.float32)
    return tl.sum(is_max * idx.to(tl.float32), axis=0).to(tl.int32)


@triton.jit
def _fused_moe_router_kernel(
    input_ptr,
    moe_router_weight_ptr,
    topk_weights_ptr,
    topk_ids_ptr,
    correction_bias_ptr,
    is_correction_bias: tl.constexpr,
    num_experts: tl.constexpr,
    topk: tl.constexpr,
    moe_softcapping: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)

    expert_offsets = tl.arange(0, num_experts)[:, None]

    # Accumulate logits by tiling over hidden_dim with BLOCK_SIZE
    logits = tl.zeros((num_experts,), dtype=tl.float32)
    for block_start in range(0, hidden_dim, BLOCK_SIZE):
        offsets = block_start + tl.arange(0, BLOCK_SIZE)
        mask = offsets < hidden_dim
        router_mask = mask[None, :]

        w_router = tl.load(
            moe_router_weight_ptr + expert_offsets * hidden_dim + offsets[None, :],
            mask=router_mask,
            other=0.0,
        )
        x = tl.load(
            input_ptr + pid * hidden_dim + offsets,
            mask=mask,
            other=0.0,
        )
        logits += tl.sum(
            w_router.to(tl.float32) * x[None, :].to(tl.float32), axis=-1
        )

    # Softcapping via exp identity: tanh(z) = (e^{2z}-1)/(e^{2z}+1)
    if moe_softcapping != 0:
        logits_scaled = logits / moe_softcapping
        exped = tl.exp(2.0 * logits_scaled)
        logits = (exped - 1.0) / (exped + 1.0) * moe_softcapping

    # Correction bias
    if is_correction_bias:
        bias = tl.load(
            correction_bias_ptr + tl.arange(0, num_experts),
            mask=tl.arange(0, num_experts) < num_experts,
            other=0.0,
        )
        logits = logits + bias

    # Iterative top-k selection using custom argmax and manual softmax weights
    expert_idx = tl.arange(0, num_experts)

    # Top-1
    top1 = _argmax_idx(logits, num_experts)
    tl.store(topk_ids_ptr + pid * topk + 0, top1)
    top1_v = tl.max(logits, axis=0)
    invsumexp = 1.0 / tl.sum(tl.exp(logits - top1_v), axis=0)
    tl.store(topk_weights_ptr + pid * topk + 0, invsumexp)

    # Top-2 (guarded by constexpr topk >= 2)
    if topk >= 2:
        masked = tl.where(expert_idx != top1, logits, float("-inf"))
        top2 = _argmax_idx(masked, num_experts)
        tl.store(topk_ids_ptr + pid * topk + 1, top2)
        top2_v = tl.sum(logits * (expert_idx == top2).to(tl.float32), axis=0)
        tl.store(
            topk_weights_ptr + pid * topk + 1,
            tl.exp(top2_v - top1_v) * invsumexp,
        )

    # Top-k for k > 2 (constexpr-guarded loop)
    if topk > 2:
        topk_mask = tl.full((num_experts,), 1.0, dtype=tl.float32)
        topk_mask = tl.where(expert_idx != top1, topk_mask, float("-inf"))
        topk_mask = tl.where(expert_idx != top2, topk_mask, float("-inf"))
        for i in range(2, topk):
            topi = _argmax_idx(logits + topk_mask, num_experts)
            tl.store(topk_ids_ptr + pid * topk + i, topi)
            topk_mask = tl.where(expert_idx != topi, topk_mask, float("-inf"))
            topi_v = tl.sum(logits * (expert_idx == topi).to(tl.float32), axis=0)
            tl.store(
                topk_weights_ptr + pid * topk + i,
                tl.exp(topi_v - top1_v) * invsumexp,
            )


def npu_triton_impl(inputs: dict) -> dict:
    """Entrypoint: receives tensors on NPU, returns topk_weights and topk_ids."""
    x = inputs["x"]
    router_weight = inputs["router_weight"]
    topk = inputs["topk"]
    moe_softcapping = inputs["moe_softcapping"]
    correction_bias = inputs["correction_bias"]

    bs, hidden_dim = x.shape
    num_experts = router_weight.shape[0]
    device = x.device

    topk_weights = torch.empty((bs, topk), dtype=torch.float32, device=device)
    topk_ids = torch.empty((bs, topk), dtype=torch.int32, device=device)

    # Cap BLOCK_SIZE at 2048 to avoid Triton-Ascend compile failures on
    # large hidden dimensions (D=4096, 6144, 8192).
    BLOCK_SIZE = min(triton.next_power_of_2(hidden_dim), 2048)
    num_warps = max(
        min(triton.next_power_of_2(triton.cdiv(hidden_dim, 256)), 32), 4
    )

    _fused_moe_router_kernel[bs, 1](
        x,
        router_weight,
        topk_weights,
        topk_ids,
        correction_bias,
        is_correction_bias=True,
        num_experts=num_experts,
        topk=topk,
        moe_softcapping=moe_softcapping,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=num_warps,
    )

    return {"topk_weights": topk_weights, "topk_ids": topk_ids}
