"""triton-ascend migration of the fused MoE grouped-GEMM + token-id scatter.

Semantics (per contract):
  a: [B, K] bf16 (token rows), b: [E, N, K] bf16 (expert weights),
  sorted_token_ids: [EM] int64 (EM = E * block_size, one expert per
  `block_size` consecutive slots, injective over valid token ids),
  expert_ids: [E] int64, topk_weights: [B, 1] fp32.
  For every block of `block_size` slots, matmul the gathered token rows
  against that block's expert weight in an fp32 accumulator (bf16
  operands), optionally scale rows by the routing weight, and scatter
  slot s to row `sorted_token_ids[s]`.  Slot ids >= B are padding and
  write nothing; un-routed token rows stay zero.  Output: [B, N] bf16.

Load-bearing details preserved from the upstream GPU kernel:
  * fp32 accumulation across the K loop, single cast to bf16 only at the
    store (matching the upstream cast-then-store ordering).
  * N-tail handled by modular wrap of the B tile indices (`% N` on the
    weight columns) plus a linear `< N` mask on the store; the K-tail by
    a per-iteration `offs_k < K - k*BLOCK_K` mask.  This keeps the result
    exact for any N and K (including N=1 / K=1) with power-of-2 tiles.
  * BLOCK_SIZE_M == block_size (4 in all fixtures): `expert_ids` is
    indexed by the M-tile index, so the tile must equal the alignment
    block.
  * top_k == 1: token id indexes both the gather and the scatter row.
"""
import torch
import triton
import triton.language as tl

_BLOCK_N = 64
_BLOCK_K = 32


@triton.jit
def _fused_moe_gemm_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    topk_weights_ptr,
    sorted_token_ids_ptr,
    expert_ids_ptr,
    EM,
    N,
    K,
    num_valid_tokens,
    stride_am,
    stride_ak,
    stride_be,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    num_pid_n,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    MUL_ROUTED_WEIGHT: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    # GROUP_SIZE_M == 1 layout: pid_m first, pid_n innermost.
    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n

    # Gather this block's token ids (padding slots -> sentinel >= B).
    offs_m = tl.arange(0, BLOCK_SIZE_M)
    offs_token_idx = pid_m * BLOCK_SIZE_M + offs_m
    offs_token = tl.load(
        sorted_token_ids_ptr + offs_token_idx,
        mask=offs_token_idx < EM,
        other=num_valid_tokens,
    ).to(tl.int64)
    token_mask = offs_token < num_valid_tokens

    off_expert = tl.load(expert_ids_ptr + pid_m).to(tl.int64)

    # B tile: wrap columns modulo N so N < BLOCK_SIZE_N stays correct.
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)

    a_ptrs = a_ptr + offs_token[:, None] * stride_am + offs_k[None, :] * stride_ak
    b_ptrs = (
        b_ptr
        + off_expert * stride_be
        + offs_k[:, None] * stride_bk
        + offs_bn[None, :] * stride_bn
    )

    # fp32 accumulation over the K loop; operands stay bf16.
    acc = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_mask = offs_k < K - k * BLOCK_SIZE_K
        a = tl.load(a_ptrs, mask=token_mask[:, None] & k_mask[None, :], other=0.0)
        b = tl.load(b_ptrs, mask=k_mask[:, None], other=0.0)
        acc += tl.dot(a, b)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    if MUL_ROUTED_WEIGHT:
        moe_weight = tl.load(
            topk_weights_ptr + offs_token, mask=token_mask, other=0.0
        )
        acc = acc * moe_weight[:, None]

    # Scatter by token id; linear (unwrapped) column mask at the store.
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = c_ptr + offs_token[:, None] * stride_cm + offs_cn[None, :] * stride_cn
    c_mask = token_mask[:, None] & (offs_cn[None, :] < N)
    tl.store(c_ptrs, acc.to(c_ptr.dtype.element_ty), mask=c_mask)


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"].contiguous()
    b = inputs["b"].contiguous()
    topk_weights = inputs["topk_weights"].contiguous()
    sorted_token_ids = inputs["sorted_token_ids"].to(torch.int64).contiguous()
    expert_ids = inputs["expert_ids"].to(torch.int64).contiguous()
    block_size = int(inputs["block_size"])
    mul_routed_weight = bool(inputs.get("apply_weight", True))

    B, K = a.shape
    E, N, Kb = b.shape
    assert Kb == K, (a.shape, b.shape)
    assert expert_ids.shape[0] == E
    EM = sorted_token_ids.shape[0]
    num_valid_tokens = B  # top_k == 1

    # Zero-init: un-routed token rows (partial routing) and never-written
    # columns stay zero, matching the reference's padded domain.
    out = torch.zeros((B, N), device=a.device, dtype=a.dtype)

    num_pid_n = triton.cdiv(N, _BLOCK_N)
    grid = (triton.cdiv(EM, block_size) * num_pid_n,)

    _fused_moe_gemm_kernel[grid](
        a,
        b,
        out,
        topk_weights,
        sorted_token_ids,
        expert_ids,
        EM,
        N,
        K,
        num_valid_tokens,
        a.stride(0),
        a.stride(1),
        b.stride(0),
        b.stride(2),  # K axis
        b.stride(1),  # N axis
        out.stride(0),
        out.stride(1),
        num_pid_n,
        BLOCK_SIZE_M=block_size,
        BLOCK_SIZE_N=_BLOCK_N,
        BLOCK_SIZE_K=_BLOCK_K,
        MUL_ROUTED_WEIGHT=mul_routed_weight,
    )

    return {"output": out}
