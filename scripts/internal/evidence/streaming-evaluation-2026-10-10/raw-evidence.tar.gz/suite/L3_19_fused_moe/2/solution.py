"""NPU (triton-ascend) implementation of the fused MoE grouped expert GEMM
with token-id scatter -- task L3_19_fused_moe.

Semantics kept from the graded GPU source (kernel.py, the plain bf16 /
no-bias, top_k == 1 path):

* ``sorted_token_ids`` holds ``EM = E * block_size`` slots; the slots of
  ``[pid_m * block_size, (pid_m + 1) * block_size)`` all belong to expert
  ``expert_ids[pid_m]``, so the M tile grain must equal ``block_size``. That
  grain is the fixture's alignment block, not a free tile: any other value
  mis-indexes ``expert_ids``.
* Per slot row the token id is ``offs_token`` (int64; ids ``>= B`` are the
  padding sentinel). Rows are gathered from ``a`` and scattered into ``c`` by
  *token id*, never by padded slot position. The fixture's slot ids are
  injective, so the plain (non-atomic) stores have distinct targets and the
  result is order independent.
* The K reduction accumulates in fp32 through the ``acc=`` chain of ``tl.dot``,
  the fp32 routing weight is applied after the loop, the tile is cast once to
  the operand dtype, and rows that no slot routes keep the zero initialisation
  of the output buffer.

Ascend-specific adaptations:

* The cube unit prefers 16-row tiles while a fixture expert block is only 4
  slots wide, so the dot's M dimension is padded to ``M_ROWS`` rows, the next
  power of two of at least ``BLOCK_SIZE_M`` and 16. Surplus rows fail the
  slot mask, are dropped from the A gather, the weight load and the C scatter,
  and only ever produce zeros that are never stored.
* Blocks whose slots are all padding exit early instead of streaming that
  expert's whole weight slab from HBM. That case is frequent here, since the
  slot buffer is ``E * block_size`` long while only ``B`` tokens exist (P5:
  E=128 blocks of 4 slots versus B=8 tokens).
* ``BLOCK_SIZE_N`` / ``BLOCK_SIZE_K`` only retile the reduction: the N tail is
  handled by ``% N`` plus the column mask, the K tail by the per-iteration
  mask, exactly as in the source.
* The graded launcher's ``GROUP_SIZE_M=1`` makes its pid swizzle an identity,
  so the decode here is the equivalent flat ``pid_m = pid // num_pid_n``.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _fused_moe_grouped_gemm_npu(
    a_ptr,
    b_ptr,
    c_ptr,
    topk_weights_ptr,
    sorted_token_ids_ptr,
    expert_ids_ptr,
    N,
    K,
    EM,
    num_valid_tokens,
    stride_am,
    stride_ak,
    stride_be,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_wm,
    BLOCK_SIZE_M: tl.constexpr,
    M_ROWS: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    MUL_ROUTED_WEIGHT: tl.constexpr,
    compute_type: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    # The graded launcher uses GROUP_SIZE_M=1, for which its swizzle reduces
    # exactly to this: consecutive pids sweep N inside one M tile, so the
    # gathered A tile stays hot while the expert's weight slab is walked.
    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n

    rows = tl.arange(0, M_ROWS)
    offs_slot = pid_m * BLOCK_SIZE_M + rows.to(tl.int64)
    # Only the block_size slots of this tile that exist inside the buffer can
    # be live.
    slot_mask = (rows < BLOCK_SIZE_M) & (offs_slot < EM)
    # Padded rows and padding slots read id 0 and drop out of token_mask, so --
    # exactly as in the source -- the masks alone keep them from touching A,
    # the weights or C.
    offs_token = tl.load(
        sorted_token_ids_ptr + offs_slot,
        mask=slot_mask,
        other=0,
    ).to(tl.int64)
    token_mask = slot_mask & (offs_token < num_valid_tokens)

    off_experts = tl.load(expert_ids_ptr + pid_m).to(tl.int64)

    # A block stores nothing when it has no live slot (all of its slots are
    # padding) or when it names no expert. Skipping it avoids streaming that
    # expert's whole weight slab from HBM, and keeps the address arithmetic for
    # a non-existent expert from ever being formed.
    live_rows = tl.sum(token_mask.to(tl.int32), axis=0)
    if (live_rows == 0) | (off_experts < 0):
        return

    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N).to(tl.int64)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    # top_k == 1, so offs_token // top_k == offs_token for the A gather as well.
    a_ptrs = a_ptr + offs_token[:, None] * stride_am + offs_k[None, :] * stride_ak
    b_ptrs = (
        b_ptr
        + off_experts * stride_be
        + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)
    )

    accumulator = tl.zeros((M_ROWS, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_rem = K - k * BLOCK_SIZE_K
        a = tl.load(
            a_ptrs,
            mask=token_mask[:, None] & (offs_k[None, :] < k_rem),
            other=0.0,
        )
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_rem, other=0.0)
        accumulator = tl.dot(a, b, acc=accumulator)
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    if MUL_ROUTED_WEIGHT:
        moe_weight = tl.load(
            topk_weights_ptr + offs_token * stride_wm,
            mask=token_mask,
            other=0.0,
        )
        accumulator = accumulator * moe_weight[:, None]

    accumulator = accumulator.to(compute_type)

    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N).to(tl.int64)
    c_ptrs = c_ptr + stride_cm * offs_token[:, None] + stride_cn * offs_cn[None, :]
    c_mask = token_mask[:, None] & (offs_cn[None, :] < N)
    tl.store(c_ptrs, accumulator, mask=c_mask)


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"].contiguous()
    b = inputs["b"].contiguous()
    topk_weights = inputs["topk_weights"].contiguous()

    sorted_token_ids = inputs["sorted_token_ids"]
    if sorted_token_ids.dtype != torch.int64:
        sorted_token_ids = sorted_token_ids.to(torch.int64)
    sorted_token_ids = sorted_token_ids.contiguous().reshape(-1)

    expert_ids = inputs["expert_ids"]
    if expert_ids.dtype != torch.int64:
        expert_ids = expert_ids.to(torch.int64)
    expert_ids = expert_ids.contiguous().reshape(-1)

    # Fixture scalars become tile meta-parameters and are passed through
    # verbatim (no host-side coercion). block_size is the alignment grain: one
    # expert per block_size sorted slots, which is what makes expert_ids safe
    # to index by the M-tile id. apply_weight is the 0/1 routing-weight knob.
    block_m = inputs["block_size"]
    mul_routed_weight = inputs["apply_weight"]

    B, K = a.shape
    E, N, _Kb = b.shape
    EM = sorted_token_ids.shape[0]
    num_valid_tokens = B

    # Tile heights. M_ROWS covers the alignment block at the cube's 16-row
    # grain (surplus rows fail the slot mask); N/K tiles only retile the
    # reduction, so they are capped for reuse and floored so tl.dot sees a
    # legal power-of-two tile.
    m_rows = triton.next_power_of_2(block_m)
    if m_rows < 16:
        m_rows = 16
    block_n = 128
    if N < block_n:
        block_n = triton.next_power_of_2(N)
        if block_n < 16:
            block_n = 16
    block_k = 64
    if K < block_k:
        block_k = triton.next_power_of_2(K)
        if block_k < 16:
            block_k = 16

    if a.dtype == torch.float32:
        compute_type = tl.float32
    elif a.dtype == torch.float16:
        compute_type = tl.float16
    elif a.dtype == torch.bfloat16:
        compute_type = tl.bfloat16
    else:
        raise ValueError("unsupported operand dtype for the grouped GEMM")

    # Output [B, N] in the token-id scatter domain, zero-initialised so rows
    # that no slot routes keeps the reference's zero padding.
    c = torch.zeros((B, N), device=a.device, dtype=a.dtype)
    if EM == 0 or B == 0 or N == 0 or K == 0:
        return {"output": c}

    num_pid_m = triton.cdiv(EM, block_m)
    grid = (num_pid_m * triton.cdiv(N, block_n),)

    _fused_moe_grouped_gemm_npu[grid](
        a,
        b,
        c,
        topk_weights,
        sorted_token_ids,
        expert_ids,
        N,
        K,
        EM,
        num_valid_tokens,
        a.stride(0),
        a.stride(1),
        b.stride(0),
        b.stride(2),
        b.stride(1),
        c.stride(0),
        c.stride(1),
        topk_weights.stride(0),
        BLOCK_SIZE_M=block_m,
        M_ROWS=m_rows,
        BLOCK_SIZE_N=block_n,
        BLOCK_SIZE_K=block_k,
        MUL_ROUTED_WEIGHT=mul_routed_weight,
        compute_type=compute_type,
        num_warps=4,
        num_stages=2,
    )

    return {"output": c}
