"""L3_19_fused_moe -- Triton-Ascend grouped MoE expert GEMM with token-id
output scatter.

Contract recap (one alignment block)
------------------------------------
`sorted_token_ids` carries EM = n_experts * BLOCK_SIZE_M slots that are already
grouped by expert, so slots [blk*BLOCK_SIZE_M, (blk+1)*BLOCK_SIZE_M) all belong
to the expert `expert_ids[blk]`.  For every live slot `s` holding token id `t`:

    out[t, :] = (a[t, :].f32() @ b[e, :, :].f32().T) * w[t]
    with      e = expert_ids[s // BLOCK_SIZE_M]

A slot whose value reaches `num_valid_tokens` is the alignment sentinel: it
loads nothing, computes nothing and stores nothing, so token rows that no slot
routes keep the zero left by the output allocation.

Why the M axis is padded
------------------------
One program has to own exactly one alignment block, because the block's expert
id is indexed by the M-tile id.  The fixture block is only 4 slots while the
cube unit needs at least 16 rows on both sides of the product, so each program
walks its block in TILE_M-wide lane windows.  Lanes past the block, or past the
slot buffer, are dropped by the slot-load mask, so their token predicate is
false and they are excluded from the operand loads, the weight load and the
store: they contribute exact zeros.  A window whose slots are all sentinels
performs no load and no store at all, which is what keeps an expert that
receives no token off the memory path.

Reduction order: fp32 accumulator across the whole K range, routing weight
applied in fp32, then one cast to the operand dtype at the store.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def fused_moe_grouped_gemm_scatter(
    a_ptr,                       # [n_tokens, K]        operand dtype
    b_ptr,                       # [n_experts, N, K]    operand dtype
    c_ptr,                       # [n_tokens, N]        compute dtype
    topk_weights_ptr,            # [n_tokens]           fp32
    sorted_token_ids_ptr,        # [EM]                 int64  slot -> token id
    expert_ids_ptr,              # [n_expert_blocks]    int64  block  -> expert
    N, K, EM, num_valid_tokens, n_experts, n_expert_blocks,
    stride_am, stride_ak,
    stride_wt,
    stride_be, stride_bk, stride_bn,
    stride_cm, stride_cn,
    BLOCK_SIZE_M: tl.constexpr,       # alignment block == block_size
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    TILE_M: tl.constexpr,             # slot lanes per window, >= 16
    GROUP_SIZE_M: tl.constexpr,
    SPLIT_K: tl.constexpr,
    MUL_ROUTED_WEIGHT: tl.constexpr,
    top_k: tl.constexpr,
    compute_type: tl.constexpr,
):
    pid_m = tl.program_id(axis=0)
    pid_n = tl.program_id(axis=1)

    # The grid covers cdiv(EM, BLOCK_SIZE_M) blocks, which can overshoot the
    # expert table only if the buffer is not an exact multiple; the index is
    # clamped so the read stays in range and such a block drops its lanes.
    block_in_table = pid_m < n_expert_blocks
    off_experts = tl.load(expert_ids_ptr + tl.where(block_in_table, pid_m, 0)
                          ).to(tl.int64)
    # A block without a usable expert id has nothing to read: clamp the weight
    # offset into range and drop all of its lanes.
    expert_usable = block_in_table & (off_experts >= 0) & (off_experts < n_experts)
    expert = tl.where(expert_usable, off_experts, 0)

    lanes = tl.arange(0, TILE_M).to(tl.int64)
    # Column tail of the output domain; the weight read wraps onto real columns
    # so its address stays inside this expert's slice, exactly as the graded
    # walk does, and the store mask below keeps those columns unwritten.
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N).to(tl.int64)
    n_mask = offs_cn < N
    offs_n = offs_cn % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)

    for m_lane in range(0, tl.cdiv(BLOCK_SIZE_M, TILE_M)):
        lane = m_lane * TILE_M + lanes
        in_block = lane < BLOCK_SIZE_M
        offs_slot = pid_m * BLOCK_SIZE_M + lane
        in_range = in_block & (offs_slot < EM)

        offs_token = tl.load(
            sorted_token_ids_ptr + offs_slot,
            mask=in_range,
            other=num_valid_tokens,
        ).to(tl.int64)
        # The live-slot predicate of the graded walk, plus the lane masks.
        token_mask = (
            (offs_token < num_valid_tokens)
            & (offs_token >= 0)
            & in_range
            & expert_usable
        )
        n_live = tl.sum(token_mask.to(tl.int32), axis=0)

        if n_live > 0:
            # Dropped lanes are folded onto row 0 and never reach memory, so
            # every address stays inside the operand and output tensors.
            row = tl.where(token_mask, offs_token, 0) // top_k

            a_ptrs = a_ptr + (row[:, None] * stride_am
                              + offs_k[None, :] * stride_ak)
            b_ptrs = (
                b_ptr
                + expert * stride_be
                + (offs_k[:, None] * stride_bk + offs_n[None, :] * stride_bn)
            )

            accumulator = tl.zeros((TILE_M, BLOCK_SIZE_N), dtype=tl.float32)
            for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
                k_rem = K - k * BLOCK_SIZE_K
                a = tl.load(
                    a_ptrs,
                    mask=token_mask[:, None] & (offs_k[None, :] < k_rem),
                    other=0.0,
                )
                b = tl.load(
                    b_ptrs,
                    mask=offs_k[:, None] < k_rem,
                    other=0.0,
                )
                accumulator = tl.dot(a, b, acc=accumulator)
                a_ptrs += BLOCK_SIZE_K * stride_ak
                b_ptrs += BLOCK_SIZE_K * stride_bk

            if MUL_ROUTED_WEIGHT:
                moe_weight = tl.load(
                    topk_weights_ptr + row * stride_wt,
                    mask=token_mask,
                    other=0.0,
                )
                accumulator = accumulator * moe_weight[:, None]

            accumulator = accumulator.to(compute_type)
            c_ptrs = c_ptr + (row[:, None] * stride_cm
                              + offs_cn[None, :] * stride_cn)
            c_mask = token_mask[:, None] & n_mask[None, :]
            tl.store(c_ptrs, accumulator, mask=c_mask)


# The tile shapes are fixed.  BLOCK_SIZE_M is forced by the fixture's alignment
# block (one expert per block_size sorted slots), so it is the incoming
# block_size rather than a free tile; the N/K tiles only shift the fp32
# accumulation order because both tails are masked.
_BLOCK_N = 64
_BLOCK_K = 32
_TILE_M = 16


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"].contiguous()
    b = inputs["b"].contiguous()
    topk_weights = inputs["topk_weights"].contiguous()
    sorted_token_ids = inputs["sorted_token_ids"].contiguous().to(torch.int64)
    expert_ids = inputs["expert_ids"].contiguous().to(torch.int64)
    block_size = inputs["block_size"]
    mul_routed_weight = inputs["apply_weight"]

    n_tokens, K = a.shape
    n_experts, N, Kb = b.shape
    EM = sorted_token_ids.shape[0]
    n_expert_blocks = expert_ids.shape[0]

    compute_type = tl.bfloat16
    if a.dtype == torch.float16:
        compute_type = tl.float16

    # Pre-zeroed output: rows that no live slot routes stay zero.
    c = torch.zeros((n_tokens, N), device=a.device, dtype=a.dtype)

    grid = (triton.cdiv(EM, block_size), triton.cdiv(N, _BLOCK_N))
    fused_moe_grouped_gemm_scatter[grid](
        a,
        b,
        c,
        topk_weights,
        sorted_token_ids,
        expert_ids,
        N,
        K,
        EM,
        n_tokens,
        n_experts,
        n_expert_blocks,
        a.stride(0),
        a.stride(1),
        topk_weights.stride(0),
        b.stride(0),
        b.stride(2),
        b.stride(1),
        c.stride(0),
        c.stride(1),
        BLOCK_SIZE_M=block_size,
        BLOCK_SIZE_N=_BLOCK_N,
        BLOCK_SIZE_K=_BLOCK_K,
        TILE_M=_TILE_M,
        GROUP_SIZE_M=1,
        SPLIT_K=1,
        MUL_ROUTED_WEIGHT=mul_routed_weight,
        top_k=1,
        compute_type=compute_type,
        num_warps=4,
        num_stages=2,
    )
    return {"output": c}
