"""triton-ascend candidate for L2_16_sgemm_lora_a (_sgemm_lora_a_kernel).

Semantics (per the task spec): segmented LoRA shrink.
  x: [B, K] bf16; weights A: [E, R, K] bf16; seg_indptr: [E+1] int64
  token offsets (monotone); weight_indices: [E] int64 adapter id per
  segment; lora_ranks: [E] int64 active rank per adapter.
  out: [B, R] -- for segment i over tokens [s, e) with adapter ad and
  rank r: out[s:e, :r] = x[s:e] @ A[ad, :r, :].T ; all other columns
  of out stay zero.

Migration notes vs the GPU source:
  * Tokens are contiguous (no reordering): the identity row mapping
    s_physical = seg_start + s_offset is inlined (the sorted-token
    indirection is removed).
  * Segment lengths are derived in-kernel from seg_indptr
    (seg_len = indptr[i+1] - indptr[i]), so the host path stays free of
    tensor element access.
  * fp32 accumulate, single bf16 cast before store (matches the
    contract's vector_reduce tolerance class).
  * Tile geometry follows the upstream verified configuration exactly
    (BLOCK_S=16, BLOCK_N=16, BLOCK_K=256) with the same K-loop
    accumulation pattern (`acc += tl.dot(a, b)`); the upstream kernel
    was cross-checked bit-exact against the fp32 reference on every
    shape in the task manifest, whereas the round-2 BLOCK_K=64 variant
    produced a longer fp32 addition chain that drifted one large-K
    shape (P3, K=512) out of the atol/rtol gate.
  * Output is zero-initialized so columns beyond each segment's rank
    (and any tokens not covered by a segment) are exactly 0.

Grid: axis 1 = segment id (E), axis 0 = flattened (token_tile, rank_tile)
over the full token count S (a safe upper bound on any segment length),
with early exit for tiles past the segment's length or rank.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _lora_shrink_a_kernel(
    # Pointers
    x,
    weights,
    output,
    # Dimensions: N = max rank R, K = input dim
    N,
    K,
    # Strides
    x_stride_0,
    x_stride_1,
    w_stride_0,
    w_stride_1,
    w_stride_2,
    output_stride_0,
    output_stride_1,
    # Per-segment metadata
    seg_indptr,
    weight_indices,
    lora_ranks,
    # Meta parameters
    BLOCK_S: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    batch_id = tl.program_id(axis=1)
    w_index = tl.load(weight_indices + batch_id)
    rank = tl.load(lora_ranks + w_index)
    if rank == 0:
        return

    pid = tl.program_id(axis=0)
    seg_start = tl.load(seg_indptr + batch_id)
    seg_end = tl.load(seg_indptr + batch_id + 1)
    seg_len = seg_end - seg_start
    if seg_len == 0:
        return

    # Clamp effective N to this adapter's active rank.
    N = tl.minimum(N, rank)

    num_pid_n = tl.cdiv(N, BLOCK_N)
    pid_s = pid // num_pid_n
    pid_n = pid % num_pid_n
    if pid_s * BLOCK_S >= seg_len:
        return

    # Contiguous tokens: identity row mapping.
    s_offset = tl.arange(0, BLOCK_S) + pid_s * BLOCK_S
    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    k_offset = tl.arange(0, BLOCK_K)
    s_physical = seg_start + s_offset

    x_ptrs = x + (s_physical[:, None] * x_stride_0 + k_offset[None, :] * x_stride_1)
    w_ptrs = (weights + w_index * w_stride_0) + (
        k_offset[:, None] * w_stride_2 + n_offset[None, :] * w_stride_1
    )

    partial_sum = tl.zeros((BLOCK_S, BLOCK_N), dtype=tl.float32)
    for kb in range(0, tl.cdiv(K, BLOCK_K)):
        x_tile = tl.load(
            x_ptrs,
            mask=(s_offset[:, None] < seg_len) & (k_offset[None, :] < K - kb * BLOCK_K),
            other=0.0,
        )
        w_tile = tl.load(
            w_ptrs,
            mask=(k_offset[:, None] < K - kb * BLOCK_K) & (n_offset[None, :] < N),
            other=0.0,
        )
        partial_sum += tl.dot(x_tile, w_tile)
        x_ptrs += BLOCK_K * x_stride_1
        w_ptrs += BLOCK_K * w_stride_2

    # fp32 accumulate -> single cast to element dtype before store.
    partial_sum = partial_sum.to(output.dtype.element_ty)
    output_mask = (s_offset[:, None] < seg_len) & (n_offset[None, :] < N)
    output_ptr = output + (
        s_physical[:, None] * output_stride_0 + n_offset[None, :] * output_stride_1
    )
    tl.store(output_ptr, partial_sum, mask=output_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    weights = inputs["weights"].contiguous()

    S, K = x.shape
    E, R, _Kw = weights.shape
    assert _Kw == K, (_Kw, K)

    seg_indptr_l = inputs["seg_indptr"].to(torch.int64).contiguous()
    bs = seg_indptr_l.numel() - 1
    weight_indices = inputs["weight_indices"].to(torch.int64).contiguous()
    lora_ranks = inputs["lora_ranks"].to(torch.int64).contiguous()

    if S == 0:
        return {"output": torch.zeros((0, R), device=x.device, dtype=x.dtype)}

    # Zero-init: columns beyond a segment's rank are outside the kernel's
    # defined write region and must be exactly 0.
    output = torch.zeros((S, R), device=x.device, dtype=x.dtype)

    if bs > 0:
        BLOCK_S = 16
        BLOCK_N = 16
        BLOCK_K = 256
        # S is a safe upper bound on any single segment length; tiles past
        # the actual seg_len (or rank) exit early in the kernel.
        grid = (triton.cdiv(S, BLOCK_S) * triton.cdiv(R, BLOCK_N), bs)
        _lora_shrink_a_kernel[grid](
            x,
            weights,
            output,
            R,
            K,
            x.stride(0),
            x.stride(1),
            weights.stride(0),
            weights.stride(1),
            weights.stride(2),
            output.stride(0),
            output.stride(1),
            seg_indptr_l,
            weight_indices,
            lora_ranks,
            BLOCK_S,
            BLOCK_N,
            BLOCK_K,
        )

    return {"output": output}
