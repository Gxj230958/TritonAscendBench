import torch
import triton
import triton.language as tl


@triton.jit
def _sgemm_lora_a_kernel(
    x_ptr, w_ptr, out_ptr,
    seg_ind_ptr, widx_ptr, ranks_ptr,
    K, G,
    x_s0, x_s1,
    w_s0, w_s1, w_s2,
    out_s0, out_s1,
    OUT_DTYPE: tl.constexpr,
    BLOCK_S: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_seg = tl.program_id(0)
    pid_s = tl.program_id(1)
    pid_n = tl.program_id(2)

    seg_start = tl.load(seg_ind_ptr + pid_seg)
    seg_end = tl.load(seg_ind_ptr + pid_seg + 1)
    seg_len = seg_end - seg_start

    if pid_s * BLOCK_S >= seg_len:
        return

    w_index = tl.load(widx_ptr + pid_seg)
    rank = tl.load(ranks_ptr + w_index)

    s_off = pid_s * BLOCK_S + tl.arange(0, BLOCK_S)
    n_off = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    k_off = tl.arange(0, BLOCK_K)

    s_global = seg_start + s_off

    x_ptrs = x_ptr + s_global[:, None] * x_s0 + k_off[None, :] * x_s1
    w_ptrs = w_ptr + w_index * w_s0 + k_off[:, None] * w_s2 + n_off[None, :] * w_s1

    acc = tl.zeros((BLOCK_S, BLOCK_N), dtype=tl.float32)

    for k in range(0, tl.cdiv(K, BLOCK_K)):
        kk = k * BLOCK_K
        xm = (s_off[:, None] < seg_len) & (k_off[None, :] < K - kk)
        x_tile = tl.load(x_ptrs, mask=xm, other=0.0)
        wm = (k_off[:, None] < K - kk) & (n_off[None, :] < G)
        w_tile = tl.load(w_ptrs, mask=wm, other=0.0)
        acc += tl.dot(x_tile, w_tile, input_precision="ieee")
        x_ptrs += BLOCK_K * x_s1
        w_ptrs += BLOCK_K * w_s2

    acc = acc.to(OUT_DTYPE)
    out_ptrs = out_ptr + s_global[:, None] * out_s0 + n_off[None, :] * out_s1
    out_mask = (s_off[:, None] < seg_len) & (n_off[None, :] < rank)
    tl.store(out_ptrs, acc, mask=out_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weights = inputs["weights"]
    seg_indptr = inputs["seg_indptr"]
    weight_indices = inputs["weight_indices"]
    lora_ranks = inputs["lora_ranks"]

    x = x.contiguous()
    weights = weights.contiguous()

    B, K = x.shape
    num_adapters, G, Kw = weights.shape
    assert Kw == K

    seg_indptr = seg_indptr.to(torch.int64).contiguous()
    weight_indices = weight_indices.to(torch.int64).contiguous()
    lora_ranks = lora_ranks.to(torch.int64).contiguous()

    E = seg_indptr.shape[0] - 1

    output = torch.zeros((B, G), device=x.device, dtype=x.dtype)

    if E > 0:
        xf = x.to(torch.float32)
        wf = weights.to(torch.float32)
        BLOCK_S = 16
        BLOCK_N = max(triton.next_power_of_2(G), 16)
        BLOCK_K = 256
        grid = (E, triton.cdiv(B, BLOCK_S), triton.cdiv(G, BLOCK_N))
        _sgemm_lora_a_kernel[grid](
            xf, wf, output,
            seg_indptr, weight_indices, lora_ranks,
            K, G,
            xf.stride(0), xf.stride(1),
            wf.stride(0), wf.stride(1), wf.stride(2),
            output.stride(0), output.stride(1),
            tl.bfloat16, BLOCK_S, BLOCK_N, BLOCK_K,
        )

    return {"output": output}
