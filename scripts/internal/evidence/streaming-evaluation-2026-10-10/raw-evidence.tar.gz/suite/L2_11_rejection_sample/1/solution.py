import torch
import triton
import triton.language as tl


@triton.jit
def qwen_rejection_sample_kernel(
    input_ptr,
    sample_ptr,
    NUM_TOKENS: tl.constexpr,
    CHUNK_SIZE: tl.constexpr,
    NUM_CHUNKS: tl.constexpr,
):
    input_token_id = tl.load(input_ptr).to(tl.int32)
    sample_base = tl.arange(0, CHUNK_SIZE)
    reject_count = 0
    reject_sum = 0
    pair_count = 0

    for chunk_id in tl.static_range(0, NUM_CHUNKS):
        chunk_start = chunk_id * CHUNK_SIZE
        chunk_index = sample_base + chunk_start
        valid = chunk_index < NUM_TOKENS
        chunk_ids = tl.load(input_ptr + chunk_index, mask=valid, other=0).to(tl.int64)
        equal = valid & (chunk_ids == input_token_id)
        reject_count += tl.sum(equal.to(tl.int32), axis=0)
        reject_sum += chunk_start * reject_count + tl.sum(
            tl.where(equal, sample_base, 0), axis=0
        )
        reject_index = reject_sum - chunk_start * reject_count
        accepted_index = reject_sum
        chunk_end = chunk_start + CHUNK_SIZE
        if accepted_index < NUM_TOKENS:
            pair_count += 1
            tl.store(
                sample_ptr + pair_count * 2 - 1,
                tl.where(equal, chunk_index, reject_index),
                mask=equal,
            )
            tl.store(
                sample_ptr + pair_count * 2,
                accepted_index,
            )

        for next_index in tl.range(reject_index + 1, chunk_end):
            next_id = tl.load(input_ptr + next_index).to(tl.int64)
            if next_id == input_token_id:
                reject_sum += 1

    tl.store(sample_ptr, pair_count)


def npu_triton_impl(inputs: dict) -> dict:
    input_ids = list(inputs["input_ids"].to(torch.int64).reshape(-1))
    num_tokens = len(input_ids)
    sample = torch.empty(
        num_tokens * 2 + 1, dtype=torch.int64, device=inputs["input_ids"].device
    )
    chunk_size = 8192
    num_chunks = triton.cdiv(num_tokens, chunk_size)
    qwen_rejection_sample_kernel[(1,)](
        input_ids,
        sample,
        NUM_TOKENS=num_tokens,
        CHUNK_SIZE=chunk_size,
        NUM_CHUNKS=num_chunks,
    )
    output_shape = (sample[0].item() * 2,)
    output = sample[1:].narrow(0, 0, output_shape[0]).reshape(output_shape)
    return {"sample": output}
