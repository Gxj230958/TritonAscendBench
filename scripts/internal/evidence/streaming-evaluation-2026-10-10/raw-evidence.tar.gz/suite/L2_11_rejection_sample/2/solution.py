import torch
import triton
import triton.language as tl


@triton.jit
def rejection_random_sample_kernel(
    output_token_ids_ptr,
    cu_num_draft_tokens_ptr,
    draft_token_ids_ptr,
    draft_probs_ptr,
    target_probs_ptr,
    bonus_token_ids_ptr,
    recovered_token_ids_ptr,
    uniform_probs_ptr,
    is_greedy_ptr,
    max_spec_len,
    vocab_size,
    synthetic_conditional_rates_ptr,
    NO_DRAFT_PROBS: tl.constexpr,
    SYNTHETIC_MODE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    is_greedy = tl.load(is_greedy_ptr + req_idx)

    end_idx = tl.load(cu_num_draft_tokens_ptr + req_idx)
    prev = tl.load(cu_num_draft_tokens_ptr + req_idx - 1, mask=(req_idx != 0), other=0)
    start_idx = tl.where(req_idx != 0, prev, 0)
    num_draft_tokens = end_idx - start_idx

    rejected = False

    for pos in range(0, num_draft_tokens):
        draft_token_id = tl.load(draft_token_ids_ptr + start_idx + pos)
        uniform_prob = tl.load(uniform_probs_ptr + start_idx + pos)

        if not rejected:
            if NO_DRAFT_PROBS:
                draft_prob = 1.0
            else:
                draft_prob = tl.load(
                    draft_probs_ptr + (start_idx + pos) * vocab_size + draft_token_id
                )
            target_prob = tl.load(
                target_probs_ptr + (start_idx + pos) * vocab_size + draft_token_id
            )
            if SYNTHETIC_MODE:
                rate = tl.load(synthetic_conditional_rates_ptr + pos)
                accepted = uniform_prob < rate
            else:
                accepted = (
                    (draft_prob > 0.0)
                    & (target_prob / draft_prob) >= uniform_prob
                )
            token_id = tl.where(accepted, draft_token_id, 0)
        else:
            token_id = tl.load(recovered_token_ids_ptr + start_idx + pos)

        tl.store(
            output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
            token_id,
        )

        if not rejected:
            rejected = True
            if pos < num_draft_tokens - 1:
                token_id = tl.load(recovered_token_ids_ptr + start_idx + pos)
                tl.store(
                    output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
                    token_id,
                )

    if not rejected:
        bonus_token_id = tl.load(bonus_token_ids_ptr + req_idx)
        tl.store(
            output_token_ids_ptr + req_idx * (max_spec_len + 1) + num_draft_tokens,
            bonus_token_id,
        )


def run(inputs: dict) -> dict:
    draft_token_ids = inputs["draft_token_ids"].contiguous()
    cu_num_draft_tokens = inputs["cu_num_draft_tokens"].contiguous()
    draft_probs = inputs["draft_probs"].contiguous()
    target_probs = inputs["target_probs"].contiguous()
    bonus_token_ids = inputs["bonus_token_ids"].contiguous()
    recovered_token_ids = inputs["recovered_token_ids"].contiguous()
    uniform_probs = inputs["uniform_probs"].contiguous()
    is_greedy = inputs["is_greedy"].contiguous()
    max_spec_len = int(inputs["max_spec_len"])

    batch_size = cu_num_draft_tokens.shape[0]
    vocab_size = target_probs.shape[-1]
    device = target_probs.device

    output_token_ids = torch.full(
        (batch_size, max_spec_len + 1),
        -1,
        dtype=torch.int32,
        device=device,
    )

    rejection_random_sample_kernel[(batch_size,)](
        output_token_ids,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        bonus_token_ids,
        recovered_token_ids,
        uniform_probs,
        is_greedy,
        max_spec_len,
        vocab_size,
        None,
        NO_DRAFT_PROBS=False,
        SYNTHETIC_MODE=False,
    )
    return {"output_token_ids": output_token_ids}
