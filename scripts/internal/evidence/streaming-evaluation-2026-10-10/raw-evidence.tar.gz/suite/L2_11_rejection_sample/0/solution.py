"""Triton-Ascend implementation of rejection_random_sample_kernel
(L2_11_rejection_sample).

One program owns one request row.  The graded acceptance rule is

    accept draft token x while  q(x) > 0  and  p(x) / q(x) >= U(x)

the first failure emits the pre-computed recovered token and ends the
chain, and a request whose whole draft chain survived appends its bonus
token at column num_draft.  Greedy requests are skipped here and their
rows keep the -1 sentinel.

The host-side GPU version walks the chain with a data-dependent loop and
an early exit.  That shape is a poor fit for an Ascend AI Core: the trip
count differs per program and each iteration is a handful of scalar
gathers, so the vector units stay idle and the bound is only known at
run time.  The same semantics are evaluated here as a fixed-width vector
over the position axis, which keeps data-dependent control flow out of
the body entirely:

  * every position in [0, BLOCK) is loaded at once (BLOCK comes from
    max_spec_len, see the launcher),
  * the first rejecting position is one min-reduction over the lanes,
  * the emitted id per position is selected from that index,
  * the surviving bonus lane is selected the same way.

Columns after the cut, and columns past the end of the row, are masked
out of the store, so they report the prefilled -1.  Truncating the
position window at BLOCK costs nothing at the graded columns: BLOCK
covers every storable column, and a chain long enough to run past it
leaves columns [0, max_spec_len] holding accepted draft ids -- which is
what the host loop produces for those columns too, since its own
rejection can only land at or beyond BLOCK.
"""

import torch
import triton
import triton.language as tl

# SamplerOutput.sampled_token_ids padding value: greedy rows and the
# columns trailing a rejection are never written by the kernel.
PLACEHOLDER_TOKEN_ID = -1


@triton.jit
def rejection_random_sample_npu_kernel(
    output_token_ids_ptr,
    cu_num_draft_tokens_ptr,
    draft_token_ids_ptr,
    draft_probs_ptr,
    target_probs_ptr,
    bonus_token_ids_ptr,
    recovered_token_ids_ptr,
    uniform_probs_ptr,
    is_greedy_ptr,
    max_spec_len,
    vocab_size,
    num_tokens,
    synthetic_conditional_rates_ptr,
    NO_DRAFT_PROBS: tl.constexpr,
    SYNTHETIC_MODE: tl.constexpr,
    BLOCK: tl.constexpr,
):
    req_idx = tl.program_id(0)

    # Greedy rows belong to the greedy path, so the store mask collapses
    # for them and the row keeps its sentinel.
    greedy = tl.load(is_greedy_ptr + req_idx)

    # Row [start_idx, end_idx) of the flattened draft-token axis.  The
    # previous cumulative entry is read through a clamped address plus a
    # select rather than a masked scalar load, which keeps every load in
    # this kernel unconditional and always in range.
    prev_end = tl.load(cu_num_draft_tokens_ptr + tl.maximum(req_idx - 1, 0))
    start_idx = tl.where(req_idx > 0, prev_end, 0)
    end_idx = tl.load(cu_num_draft_tokens_ptr + req_idx)
    num_draft = end_idx - start_idx

    pos = tl.arange(0, BLOCK)
    valid = pos < num_draft
    # Lanes past the end of the row only ever feed masked loads, so their
    # values are unused; clamping the index keeps every computed address
    # inside the allocation even for a request with no drafts at all,
    # where the whole window is dead.
    live_row = tl.minimum(start_idx + pos, tl.maximum(num_tokens - 1, 0))

    draft_tok = tl.load(draft_token_ids_ptr + live_row, mask=valid, other=0).to(tl.int32)
    recovered = tl.load(recovered_token_ids_ptr + live_row, mask=valid, other=0).to(tl.int32)
    # Dead lanes get a draw and a ratio that cannot clear it, and `valid`
    # masks them out of the reduction anyway.
    uniform = tl.load(uniform_probs_ptr + live_row, mask=valid, other=1.0)

    if SYNTHETIC_MODE:
        rate = tl.load(synthetic_conditional_rates_ptr + pos, mask=valid, other=0.0)
        accepted = valid & (uniform < rate)
    else:
        # Gather the probability the draft model put on the sampled id.
        # 64-bit here so a wide vocabulary cannot wrap the row stride.
        prob_addr = live_row.to(tl.int64) * vocab_size + draft_tok.to(tl.int64)
        if NO_DRAFT_PROBS:
            draft_prob = tl.full([BLOCK], 1.0, tl.float32)
        else:
            draft_prob = tl.load(draft_probs_ptr + prob_addr, mask=valid, other=1.0)
        target_prob = tl.load(target_probs_ptr + prob_addr, mask=valid, other=0.0)

        # q == 0 rejects, and guarding the divisor keeps inf/nan out of
        # the ratio without changing that outcome.
        positive_q = draft_prob > 0.0
        ratio = target_prob / tl.where(positive_q, draft_prob, 1.0)
        accepted = valid & positive_q & (ratio >= uniform)

    rejecting = valid & (~accepted)
    window = tl.full([BLOCK], BLOCK, tl.int32)
    first_reject = tl.min(tl.where(rejecting, pos, window))
    every_draft_survived = first_reject >= BLOCK

    bonus = tl.load(bonus_token_ids_ptr + req_idx).to(tl.int32)

    # Before the cut the draft id survives, at the cut the recovered id
    # takes over, beyond it the column keeps the sentinel.
    sentinel = tl.full([BLOCK], PLACEHOLDER_TOKEN_ID, tl.int32)
    chain = tl.where(
        pos < first_reject,
        draft_tok,
        tl.where(pos == first_reject, recovered, sentinel),
    )
    value = tl.where(valid, chain, sentinel)
    value = tl.where(every_draft_survived & (pos == num_draft), bonus, value)

    tl.store(
        output_token_ids_ptr + req_idx * (max_spec_len + 1) + pos,
        value,
        mask=(greedy == 0) & (pos <= max_spec_len),
    )


def npu_triton_impl(inputs: dict) -> dict:
    draft_token_ids = inputs["draft_token_ids"].contiguous()
    cu_num_draft_tokens = inputs["cu_num_draft_tokens"].contiguous()
    draft_probs = inputs["draft_probs"].contiguous()
    target_probs = inputs["target_probs"].contiguous()
    bonus_token_ids = inputs["bonus_token_ids"].contiguous()
    recovered_token_ids = inputs["recovered_token_ids"].contiguous()
    uniform_probs = inputs["uniform_probs"].contiguous()
    is_greedy = inputs["is_greedy"].contiguous()
    max_spec_len = int(inputs["max_spec_len"])

    batch_size = int(cu_num_draft_tokens.shape[0])
    vocab_size = int(target_probs.shape[-1])
    device = target_probs.device

    # int32 output prefilled with the sentinel, so the columns this
    # kernel leaves alone report the expected padding.
    output_token_ids = torch.full(
        (batch_size, max_spec_len + 1),
        PLACEHOLDER_TOKEN_ID,
        dtype=torch.int32,
        device=device,
    )

    # Every storable column index is <= max_spec_len, so a window of
    # max_spec_len + 1 positions settles each column however long the
    # draft chain is.
    block = triton.next_power_of_2(max_spec_len + 1)

    rejection_random_sample_npu_kernel[(batch_size,)](
        output_token_ids,
        cu_num_draft_tokens,
        draft_token_ids,
        draft_probs,
        target_probs,
        bonus_token_ids,
        recovered_token_ids,
        uniform_probs,
        is_greedy,
        max_spec_len,
        vocab_size,
        draft_token_ids.shape[0],
        # The graded path always uses the real probability ratio, so the
        # rate-table pointer is never dereferenced; it is fed an
        # always-valid buffer rather than None.
        uniform_probs,
        NO_DRAFT_PROBS=False,
        SYNTHETIC_MODE=False,
        BLOCK=block,
    )
    return {"output_token_ids": output_token_ids}
