import torch
import triton
import triton.language as tl


@triton.jit
def _prepare_eagle_inputs_kernel(
    eagle_input_ids_ptr,
    eagle_positions_ptr,
    eagle_query_start_loc_ptr,
    eagle_seq_lens_ptr,
    last_token_indices_ptr,
    target_input_ids_ptr,
    target_positions_ptr,
    idx_mapping_ptr,
    last_sampled_ptr,
    next_prefill_tokens_ptr,
    num_sampled_ptr,
    num_rejected_ptr,
    seq_lens_ptr,
    query_len,
    max_num_reqs,
    BLOCK_SIZE: tl.constexpr,
    PAD_BLOCK: tl.constexpr,
):
    """One program per request: token-shift + metadata prep (NPU port).

    The token buffer is packed contiguously with a constant raw query
    length per request, so request ``r`` owns the span
    ``[r * query_len, (r + 1) * query_len)``; the indptr is computed
    in-kernel instead of being materialised host-side.

    Output buffers are freshly allocated (uninitialised), so unlike the
    upstream pre-zeroed launch state this kernel also explicitly zeros
    the rejected-tail slots and the unused pad rows.
    """
    req_idx = tl.program_id(0)
    num_reqs = tl.num_programs(0)
    query_start = req_idx.to(tl.int32) * query_len
    query_end = (req_idx + 1).to(tl.int32) * query_len
    raw_len = query_end - query_start
    seq_len = tl.load(seq_lens_ptr + req_idx)
    num_rejected = tl.load(num_rejected_ptr + req_idx)
    query_len_trunc = raw_len - num_rejected
    req_state_idx = tl.load(idx_mapping_ptr + req_idx)
    num_sampled = tl.load(num_sampled_ptr + req_idx)
    if num_sampled > 0:
        next_token = tl.load(last_sampled_ptr + req_state_idx).to(tl.int32)
    else:
        next_token = tl.load(next_prefill_tokens_ptr + req_state_idx)

    # Left shift over the truncated prefix:
    #   eagle_input_ids[query_start + k - 1] = target_input_ids[query_start + k]
    for i in range(1, query_len_trunc, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        mask = block < query_len_trunc
        input_ids = tl.load(target_input_ids_ptr + query_start + block, mask=mask)
        tl.store(eagle_input_ids_ptr + query_start + block - 1, input_ids, mask=mask)
    last_token_index = query_start + query_len_trunc - 1
    tl.store(last_token_indices_ptr + req_idx, last_token_index.to(tl.int64))
    tl.store(eagle_input_ids_ptr + last_token_index, next_token)

    # Position copy over the truncated prefix.
    for i in range(0, query_len_trunc, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        mask = block < query_len_trunc
        target_pos = tl.load(target_positions_ptr + query_start + block, mask=mask)
        tl.store(eagle_positions_ptr + query_start + block, target_pos, mask=mask)

    # Rejected tail [query_start + Lt, query_end): keep the pre-launch
    # (zero) buffer contents -> explicit zeros here.
    for i in range(query_len_trunc, raw_len, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        mask = block < raw_len
        tl.store(eagle_input_ids_ptr + query_start + block, 0, mask=mask)
        tl.store(eagle_positions_ptr + query_start + block, 0, mask=mask)

    tl.store(eagle_query_start_loc_ptr + req_idx, query_start)
    tl.store(eagle_seq_lens_ptr + req_idx, seq_len)

    # Final program: pad rows [num_reqs, max_num_reqs(+1)) -> zeros; the
    # extra indptr row takes the raw (untruncated) end of the last
    # request, i.e. the total token count.
    if req_idx == num_reqs - 1:
        total_tokens = query_end
        for i in range(num_reqs, max_num_reqs, PAD_BLOCK):
            block = i + tl.arange(0, PAD_BLOCK)
            mask = block < max_num_reqs
            tl.store(eagle_seq_lens_ptr + block, 0, mask=mask)
            tl.store(last_token_indices_ptr + block, 0, mask=mask)
            tl.store(eagle_query_start_loc_ptr + block, total_tokens, mask=mask)
        # Row max_num_reqs itself (the buffer is sized max_num_reqs + 1)
        # is outside the loop range above and must take the same value.
        if max_num_reqs >= num_reqs:
            tl.store(eagle_query_start_loc_ptr + max_num_reqs, total_tokens)


@triton.jit
def _reset_draft_step_kernel(eagle_current_draft_step_ptr):
    tl.store(eagle_current_draft_step_ptr, 0)


def npu_triton_impl(inputs: dict) -> dict:
    """Host launcher: pure Python + triton-ascend kernels only.

    Scalars are read from tensor shapes (Python ints); no host-side
    tensor binary ops. Output buffers are uninitialised ``torch.empty``
    and fully defined by the kernel (truncated spans + explicit zero
    tails), which drops the six upstream fill launches.
    """
    B = inputs["idx_mapping"].shape[0]
    Q = inputs["target_input_ids"].shape[0] // B
    M = inputs["last_sampled"].shape[0]

    device = inputs["target_input_ids"].device
    total = B * Q

    target_input_ids = inputs["target_input_ids"]
    target_positions = inputs["target_positions"]
    idx_mapping = inputs["idx_mapping"]
    num_sampled = inputs["num_sampled"]
    num_rejected = inputs["num_rejected"]
    last_sampled = inputs["last_sampled"]
    next_prefill_tokens = inputs["next_prefill_tokens"]
    seq_lens = inputs["seq_lens"]

    eagle_input_ids = torch.empty(total, dtype=torch.int32, device=device)
    eagle_positions = torch.empty(total, dtype=torch.int64, device=device)
    eagle_query_start_loc = torch.empty(M + 1, dtype=torch.int32, device=device)
    eagle_seq_lens = torch.empty(M, dtype=torch.int32, device=device)
    last_token_indices = torch.empty(M, dtype=torch.int64, device=device)
    eagle_current_draft_step = torch.empty((), dtype=torch.int64, device=device)

    _prepare_eagle_inputs_kernel[(B,)](
        eagle_input_ids,
        eagle_positions,
        eagle_query_start_loc,
        eagle_seq_lens,
        last_token_indices,
        target_input_ids,
        target_positions,
        idx_mapping,
        last_sampled,
        next_prefill_tokens,
        num_sampled,
        num_rejected,
        seq_lens,
        Q,
        M,
        BLOCK_SIZE=1024,
        PAD_BLOCK=64,
    )
    _reset_draft_step_kernel[(1,)](eagle_current_draft_step)

    return {
        "eagle_input_ids": eagle_input_ids,
        "eagle_positions": eagle_positions,
        "eagle_query_start_loc": eagle_query_start_loc,
        "eagle_seq_lens": eagle_seq_lens,
        "last_token_indices": last_token_indices,
        "eagle_current_draft_step": eagle_current_draft_step,
    }
