"""Triton-Ascend implementation of the MoE unpermute-and-weighted-reduce step.

Entry point: ``npu_triton_impl(inputs: dict) -> dict``, returning ``{"output": ...}``.

Math (output token row t, feature d, topk slots k = 0..K-1):

    out[t, d] = sum_k  1[recv_topk_ids[t, k] >= 0]
                      * recv_topk_weight[t, k]
                      * input_tensor[input_index[t, k], d]

Load-bearing semantics honoured here, unchanged from the round that passed
every shape -- the kernel body is that round's body, predicate and all:
  * Slots whose expert id is negative contribute nothing: the row read is
    masked off, the slot weight is forced to 0.0, and the row index is clamped
    into range so a suppressed address stays inside the allocation anyway. That
    reproduces "skip this slot" without a runtime branch around a scalar
    condition, and it keeps a slot from ever putting a value it should not have
    looked at into the accumulator.
  * Accumulation runs entirely in float32 and is cast back to the element type
    exactly once, at the store. Slots are consumed in increasing k, so the
    accumulation order still matches the sequential topk reduce.
  * The reduce runs over the topk axis only; the feature axis is an independent
    partition, so feature tiling cannot change results.

Why this round changes the launch surface. Last round's candidate was rejected
before a single shape ran, so the useful reference point is the round that
passed, where a shape whose entire workload is one program reading two 16-bit
values measured the same 175-210 us as a shape a hundred times larger. A cost
that does not track the work is a per-call cost, so the measured number is
dominated by getting the launch off the host, not by the vector cores. Fourteen
of the nineteen arguments handed to the entry point on every call are stride and
extent values: each is read off the tensor, then walked by the argument binder,
then classified to pick the device variant, then packed into the launch struct,
even though the value is fixed by the shape and never changes between calls of
that shape.

The change is therefore to move that geometry into the declaration:

  * Every stride, extent, the clamp bound and the topk length are now declared
    ``tl.constexpr`` and passed as ordinary Python integers taken from
    ``.stride()`` and ``.shape``. The runtime argument list drops from nineteen
    entries to five -- the five buffers -- so the binding, the classification
    and the packing all shrink to the arguments that genuinely vary per call.
    The variant selected is still a function of exactly those values, so a call
    with a different layout simply gets its own variant; nothing is assumed
    about the layout, the values are still read from the tensors.
  * Folding the geometry in also lets the address arithmetic use immediates
    rather than registers: the row offset, the token offset and the topk offset
    are each built from constants the build already knows instead of values it
    has to fetch from the launch struct and hold in scalar registers across the
    whole slot loop.

Shapes covered: input_tensor [B, D] bfloat16, recv_topk_ids [T, K] int32
signed, recv_topk_weight [T, K] bfloat16, input_index [T, K] int32 in [0, B),
with D from 1 to 4096 including non-power-of-two widths (3, 96, 192, 384, ...),
K from 1 to 64, T from 1 to 512, B from 1 to 2048.

Implementation remarks carried over from the passing round:
  * The feature tile is predicated rather than required to divide the width, so
    one padded power-of-two tile covers any width; padded lanes are never read
    or written.
  * Each slot read is a single contiguous row segment taken at a uniformly
    computed base address, which keeps the read on the vector path rather than
    turning it into a per-lane indexed gather.
  * Parallelism is (feature tiles) x (tokens); one token per program, so there
    is no grid-stride token loop and no cap on the token axis.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _ep_unpermute_weighted_sum(
    in_ptr,
    ids_ptr,
    w_ptr,
    idx_ptr,
    out_ptr,
    stride_in0: tl.constexpr,
    stride_in1: tl.constexpr,
    stride_ids0: tl.constexpr,
    stride_ids1: tl.constexpr,
    stride_w0: tl.constexpr,
    stride_w1: tl.constexpr,
    stride_idx0: tl.constexpr,
    stride_idx1: tl.constexpr,
    stride_out0: tl.constexpr,
    stride_out1: tl.constexpr,
    max_src_row: tl.constexpr,
    width: tl.constexpr,
    TOPK: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    pid_d = tl.program_id(0)
    token = tl.program_id(1)

    d_off = pid_d * BLOCK_D + tl.arange(0, BLOCK_D)
    d_mask = d_off < width

    acc = tl.zeros([BLOCK_D], dtype=tl.float32)

    for k in range(0, TOPK):
        expert = tl.load(ids_ptr + token * stride_ids0 + k * stride_ids1)
        keep = expert >= 0
        src = tl.load(idx_ptr + token * stride_idx0 + k * stride_idx1)
        weight = tl.load(w_ptr + token * stride_w0 + k * stride_w1)

        # A negative expert id zeroes the slot's weight *and* suppresses the
        # row read, so the slot's term is exactly 0.0 and its source row is
        # never dereferenced. Suppressing the read as well as the weight is
        # deliberate: it keeps a slot from ever putting a value it should not
        # have looked at into the accumulator.
        w_val = tl.where(keep, weight.to(tl.float32), 0.0)
        # The clamp only bounds the address of a read that the mask above
        # already suppresses; every live slot's index is already a valid row,
        # so on the lanes that reach the accumulator it is the identity.
        src_row = tl.minimum(tl.maximum(src, 0), max_src_row)

        v = tl.load(in_ptr + src_row * stride_in0 + d_off * stride_in1,
                    mask=d_mask & keep, other=0.0)
        acc += v.to(tl.float32) * w_val

    tl.store(out_ptr + token * stride_out0 + d_off * stride_out1,
             acc.to(out_ptr.dtype.element_ty), mask=d_mask)


def _pow2_at_least(value: int) -> int:
    out = 1
    while out < value:
        out *= 2
    return out


# A feature tile of at most 1024 lanes mirrors the original launch shape, and
# rounding the tile up to a power of two keeps a short-token program to a
# single tile, so padded lanes cost nothing on the topk reduce.
_MAX_BLOCK_D = 1024
# Below 16 lanes a program spends more on the per-slot scalar fetches and the
# store than on useful width, so narrow rows are padded up to a 16-lane tile.
_MIN_BLOCK_D = 16
# Feature tiles are the only parallel axis a short-token launch can split, so
# when the token axis is skinny the tile shrinks until roughly this many
# programs exist. The device has a couple of dozen vector cores; past a few
# times that, extra programs buy nothing and only add scheduling cost.
_TARGET_PROGRAMS = 96


def _block_d(width: int, num_tokens: int) -> int:
    block_d = min(_pow2_at_least(width), _MAX_BLOCK_D)
    if width > _MIN_BLOCK_D * 2:
        # Shrink the tile only while the token axis is too short to fill the
        # device, and never below the narrow-row floor.
        tiles_needed = -(-_TARGET_PROGRAMS // max(1, num_tokens))
        smallest_ok = -(-width // tiles_needed)
        while block_d > _MIN_BLOCK_D and block_d > smallest_ok:
            block_d //= 2
    return max(_MIN_BLOCK_D, block_d)


def _num_warps(block_d: int) -> int:
    return 2 if block_d <= 256 else 4


def npu_triton_impl(inputs: dict) -> dict:
    input_tensor = inputs["input_tensor"]          # [B, D] bfloat16
    recv_topk_ids = inputs["recv_topk_ids"]        # [T, K] int32, signed
    recv_topk_weight = inputs["recv_topk_weight"]  # [T, K] bfloat16
    input_index = inputs["input_index"]            # [T, K] int32, in [0, B)

    num_src_rows = int(input_tensor.shape[0])
    width = int(input_tensor.shape[1])
    num_tokens = int(recv_topk_ids.shape[0])
    topk = int(recv_topk_ids.shape[1])

    output_tensor = torch.empty(
        (num_tokens, width),
        dtype=input_tensor.dtype,
        device=input_tensor.device,
    )

    block_d = _block_d(width, num_tokens)
    grid = (triton.cdiv(width, block_d), num_tokens)

    _ep_unpermute_weighted_sum[grid](
        input_tensor,
        recv_topk_ids,
        recv_topk_weight,
        input_index,
        output_tensor,
        input_tensor.stride(0),
        input_tensor.stride(1),
        recv_topk_ids.stride(0),
        recv_topk_ids.stride(1),
        recv_topk_weight.stride(0),
        recv_topk_weight.stride(1),
        input_index.stride(0),
        input_index.stride(1),
        output_tensor.stride(0),
        output_tensor.stride(1),
        num_src_rows - 1,
        width,
        TOPK=topk,
        BLOCK_D=block_d,
        num_warps=_num_warps(block_d),
    )

    return {"output": output_tensor}
