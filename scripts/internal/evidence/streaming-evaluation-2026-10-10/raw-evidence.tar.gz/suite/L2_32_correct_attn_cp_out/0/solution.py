"""Triton-Ascend port of the upstream Triton kernel for L2_32_correct_attn_cp_out.

Semantics (per the task contract): out [B,H,D] (bfloat16) is this rank's
partial attention output; lses [N,B,H] (float32) are the all-gathered
per-rank log-sum-exp values. Each (b,h) program reduces lses over the N
axis to the global log-sum-exp, then reweights the row out[b,h,:] by
exp(lses[cp_rank, b, h] - global_lse), reproducing the load-bearing
numerics of the upstream kernel exactly:

  - NROUNDED == N is required by the upstream launch, so every loaded lse
    element is in bounds and no masking is needed (the N axis of lses is
    contiguous).
  - NaN/+inf lse entries are clamped to -inf before the reduction.
  - max is subtracted before the exp accumulation; if the max is -inf it
    is replaced by 0 before the subtraction.
  - the global lse (vlse) is written to a fresh aux buffer addressed with
    the lses B/H strides, then the reweight factor uses a fresh scalar
    load of lses[cp_rank, b, h] minus that aux value; any NaN/+inf result
    is clamped to -inf before the final exp.

Base-2 support: the Layer C allowlist of this evaluation does not include
tl.exp2 / tl.math.exp2 / tl.log2, so the IS_BASE_E=False branches are
algebraically equivalent rewrites of the upstream base-2 path:
  upstream log2(exp2(x)) == log(exp(x*ln2)) * log2(e)
  upstream exp2(x)       == exp(x*ln2)
ln2 and log2(e) are hard-coded to 16 decimal places, which is far tighter
than the attention_flash tolerance band.

Launch: grid (B, H, 1), program_id(0)=batch, program_id(1)=head.
"""

import torch
import triton
import triton.language as tl

# base-conversion constants (hard-coded; no host tensor ops involved)
_LN2 = 0.6931471805599453
_LOG2E = 1.4426950408889634


@triton.jit
def _correct_attn_cp_out_kernel(
    outputs_ptr, new_output_ptr, lses_ptr, vlse_ptr,
    outputs_stride_B, outputs_stride_H, outputs_stride_D,
    lses_stride_N, lses_stride_B, lses_stride_H,
    lse_idx,
    HEAD_DIM: tl.constexpr, N_ROUNDED: tl.constexpr,
    IS_BASE_E: tl.constexpr,
):
    batch_idx = tl.program_id(axis=0)
    head_idx = tl.program_id(axis=1)
    d_offsets = tl.arange(0, HEAD_DIM)
    num_n_offsets = tl.arange(0, N_ROUNDED)
    lse_offsets = (
        num_n_offsets * lses_stride_N
        + batch_idx * lses_stride_B
        + head_idx * lses_stride_H
    )
    lse = tl.load(lses_ptr + lse_offsets)
    lse = tl.where(
        (lse != lse) | (lse == float("inf")), -float("inf"), lse
    )
    lse_max = tl.max(lse, axis=0)
    lse_max = tl.where(lse_max == -float("inf"), 0, lse_max)
    lse -= lse_max
    if IS_BASE_E:
        lse_exp = tl.exp(lse)
        lse_acc = tl.sum(lse_exp, axis=0)
        lse = tl.log(lse_acc)
    else:
        # log2(exp2(x - max)) == log(exp(x*ln2)) * log2(e)
        lse_exp = tl.exp(lse * 0.6931471805599453)
        lse_acc = tl.sum(lse_exp, axis=0)
        lse = tl.log(lse_acc) * 1.4426950408889634
    lse += lse_max
    vlse_offsets = batch_idx * lses_stride_B + head_idx * lses_stride_H
    tl.store(vlse_ptr + vlse_offsets, lse)
    output_offsets = (
        batch_idx * outputs_stride_B
        + head_idx * outputs_stride_H
        + d_offsets * outputs_stride_D
    )
    lse_offset = (
        lse_idx * lses_stride_N
        + batch_idx * lses_stride_B
        + head_idx * lses_stride_H
    )
    lse_tmp = tl.load(lses_ptr + lse_offset)
    lse_finally = lse_tmp - lse
    lse_finally = tl.where(
        (lse_finally != lse_finally) | (lse_finally == float("inf")),
        -float("inf"),
        lse_finally,
    )
    if IS_BASE_E:
        factor = tl.exp(lse_finally)
    else:
        # exp2(x) == exp(x*ln2)
        factor = tl.exp(lse_finally * 0.6931471805599453)
    output = tl.load(outputs_ptr + output_offsets)
    output = output * factor
    tl.store(new_output_ptr + output_offsets, output)


def npu_triton_impl(inputs: dict) -> dict:
    out = inputs["out"]
    lses = inputs["lses"]
    cp_rank = inputs["cp_rank"]
    is_lse_base_on_e = inputs["is_lse_base_on_e"]

    assert out.ndim == 3, "expected out [B,H,D]"
    assert lses.ndim == 3, "expected lses [N,B,H]"

    B, H, D = out.shape
    N = lses.shape[0]
    assert N & (N - 1) == 0, "N must be power of 2"

    # Do not mutate the caller's input; the upstream wrapper aliases
    # outputs_ptr and new_output_ptr on the same buffer.
    new_out = out.clone()
    o_sB, o_sH, o_sD = new_out.stride()
    l_sN, l_sB, l_sH = lses.stride()

    # Aux global-lse buffer, addressed with the lses B/H strides.
    vlse = torch.empty((B, H), device=lses.device, dtype=lses.dtype)

    grid = (B, H, 1)
    _correct_attn_cp_out_kernel[grid](
        new_out,
        new_out,
        lses,
        vlse,
        o_sB,
        o_sH,
        o_sD,
        l_sN,
        l_sB,
        l_sH,
        cp_rank,
        HEAD_DIM=D,
        N_ROUNDED=N,
        IS_BASE_E=is_lse_base_on_e,
    )
    return {"output": new_out}
