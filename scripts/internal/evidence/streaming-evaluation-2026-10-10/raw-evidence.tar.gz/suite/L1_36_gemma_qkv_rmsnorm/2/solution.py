"""NPU (triton-ascend) port of the per-head QKV RMSNorm kernel.

Semantics (per token m, per head h, vector over head_dim):

    out = x * rsqrt(mean(x^2, over head_dim) + eps) * weight

- q: scaled by q_weight[head_dim]
- k: scaled by k_weight[head_dim]
- v: unscaled (weight = 1)

eps = 1e-6. All arithmetic (square, reduction, rsqrt, scaling) runs in fp32
after loading; only the final store casts back to the storage dtype (bf16).
Masked lanes (block padding beyond head_dim) load as 0.0 and the mean
divides by head_dim itself (not the padded width), so padding never
perturbs the reduction. The kernel mutates q, k, v in place and the entry
point returns the post-norm tensors under the same keys ("q", "k", "v").

Layout: q is [M, QH*head_dim], k/v are [M, KVH*head_dim], heads packed
contiguously in the last dim at offset h * head_dim. The per-token stride
is passed as a runtime argument so strided views work as well.

Geometry (unchanged from round 3, which executed the full timing pass):
- Each program normalizes exactly one (token, head) vector over a flattened
  1D pid space of M * num_heads per tensor: m = pid // num_heads,
  h = pid % num_heads.
- Every value that varies across shapes (stride, pid offset, num_heads,
  head_dim, eps) is a do-not-specialize runtime argument. Weighted (q, k)
  and unscaled (v) paths are two separate kernels with fixed argument
  layouts (no constexpr-gated mixing of tensor sets).
- The per-tensor pid space is launched in chunks of at most _MAX_GRID_X
  with an explicit pid offset, so large shapes (e.g. M=8192, QH=16 ->
  131072 vectors) never exceed any single-launch grid-dimension limit.

Round-4 change (correctness fix): the block width is now
next_power_of_2(head_dim) instead of a fixed 512, exactly mirroring how
the upstream launcher sizes BLOCK. Round 3 (fixed BLOCK=512) passed only
25/48 shapes; every failing shape reported a 1-ulp-in-bf16 deviation
(max_abs in {2^-9, 2^-8, 2^-7, 2^-6, 2^-5}, max_rel ~0.4-0.78%), and the
pass/fail split correlated with whether 512 equals next_power_of_2(D):
all shapes with D=512 passed while the failures concentrate on D in
{32,64,96,128,256}. The per-vector reduction tree is what the fixed
512-lane block changes relative to a tight next_power_of_2(head_dim)
block: the fp32 partial-sum ladder has extra levels over masked-zero
lanes, shifting intermediate rounding just enough to flip bf16 boundary
values on a few elements per shape. With BLOCK = next_power_of_2(head_dim)
each vector reduces over exactly the same lane count and lane layout as
the frozen upstream kernel driven by its launcher, so the fp32 per-vector
arithmetic (masked load, square, reduction, division by head_dim, rsqrt,
scale, cast back to bf16) is the identical instruction sequence.
"""

import triton
import triton.language as tl

EPS = 1e-6

# Conservative per-launch grid cap; larger pid spaces are chunked.
_MAX_GRID_X = 32768

# Runtime scalars that must not create new kernel specializations; the only
# constexpr is BLOCK = next_power_of_2(head_dim), so one traced variant
# exists per distinct block width (10 across the whole shape suite).
_DNS = ["stride_x_m", "pid_offset", "num_heads", "head_dim", "eps"]


@triton.jit(
    do_not_specialize=_DNS,
    do_not_specialize_on_alignment=["X_ptr", "W_ptr"],
)
def _rmsnorm_weighted_kernel(
    X_ptr,
    W_ptr,
    stride_x_m,
    pid_offset,
    num_heads,
    head_dim,
    eps,
    BLOCK: tl.constexpr,
):
    """RMS-normalize one head vector in place, then scale by weight[D]."""
    pid = tl.program_id(0) + pid_offset
    m = pid // num_heads
    h = pid % num_heads

    cols = tl.arange(0, BLOCK)
    mask = cols < head_dim

    off = m * stride_x_m + h * head_dim + cols
    x = tl.load(X_ptr + off, mask=mask, other=0.0).to(tl.float32)
    w = tl.load(W_ptr + cols, mask=mask, other=0.0).to(tl.float32)

    rrms = tl.rsqrt(tl.sum(x * x, axis=0) / head_dim + eps)
    out = x * rrms * w
    tl.store(X_ptr + off, out.to(X_ptr.dtype.element_ty), mask=mask)


@triton.jit(
    do_not_specialize=_DNS,
    do_not_specialize_on_alignment=["X_ptr"],
)
def _rmsnorm_plain_kernel(
    X_ptr,
    stride_x_m,
    pid_offset,
    num_heads,
    head_dim,
    eps,
    BLOCK: tl.constexpr,
):
    """RMS-normalize one head vector in place (no weight scale)."""
    pid = tl.program_id(0) + pid_offset
    m = pid // num_heads
    h = pid % num_heads

    cols = tl.arange(0, BLOCK)
    mask = cols < head_dim

    off = m * stride_x_m + h * head_dim + cols
    x = tl.load(X_ptr + off, mask=mask, other=0.0).to(tl.float32)

    rrms = tl.rsqrt(tl.sum(x * x, axis=0) / head_dim + eps)
    out = x * rrms
    tl.store(X_ptr + off, out.to(X_ptr.dtype.element_ty), mask=mask)


def _launch_weighted(x, w, num_heads, head_dim, block):
    total = x.shape[0] * num_heads
    stride_m = x.stride(0)
    offset = 0
    while offset < total:
        n = min(_MAX_GRID_X, total - offset)
        _rmsnorm_weighted_kernel[(n,)](
            x,
            w,
            stride_m,
            offset,
            num_heads,
            head_dim,
            EPS,
            BLOCK=block,
        )
        offset += n


def _launch_plain(x, num_heads, head_dim, block):
    total = x.shape[0] * num_heads
    stride_m = x.stride(0)
    offset = 0
    while offset < total:
        n = min(_MAX_GRID_X, total - offset)
        _rmsnorm_plain_kernel[(n,)](
            x,
            stride_m,
            offset,
            num_heads,
            head_dim,
            EPS,
            BLOCK=block,
        )
        offset += n


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    q_weight = inputs["q_weight"]
    k_weight = inputs["k_weight"]

    head_dim = q_weight.shape[-1]
    num_q_heads = q.shape[1] // head_dim
    num_kv_heads = k.shape[1] // head_dim
    block = triton.next_power_of_2(head_dim)

    _launch_weighted(q, q_weight, num_q_heads, head_dim, block)
    _launch_weighted(k, k_weight, num_kv_heads, head_dim, block)
    _launch_plain(v, num_kv_heads, head_dim, block)

    return {"q": q, "k": k, "v": v}
