"""Round 1 solution: per-head QKV RMSNorm migrated to triton-ascend.

Semantics (from contract): each attention head's vector is RMS-normalized
independently over head_dim, in fp32:

    out = x * rsqrt(mean(x^2, over head_dim) + eps) * weight

- q [M, QH*D] bf16: scaled by q_weight [D] fp32.
- k [M, KVH*D] bf16: scaled by k_weight [D] fp32.
- v [M, KVH*D] bf16: no scale (weight = 1).

q, k, v are mutated in place; the returned dict holds the same tensors.

Migration notes (GPU -> Ascend):

- The upstream kernel does one program per token and statically unrolls the
  head loop. That pattern (tl.static_range over a constexpr head count) is
  not portable to triton-ascend; here each program handles exactly one
  (token, head) vector, launched with grid (M * num_heads). The math is
  unchanged: fp32 load, fp32 sum-of-squares, fp32 rsqrt, multiply by
  (fp32) weight, then cast back to the tensor element type for the store.
- head_dim need not be a power of two (e.g. 96), so we load with
  BLOCK = next_power_of_2(head_dim) and a mask.
"""

import torch
import triton
import triton.language as tl

EPS = 1e-6


@triton.jit
def _rmsnorm_head_kernel(
    X_ptr,
    W_ptr,
    num_heads,
    stride_m,
    eps,
    HEAD_DIM: tl.constexpr,
    BLOCK: tl.constexpr,
    HAS_W: tl.constexpr,
):
    """RMS-normalize a single (token, head) vector in X in place.

    program_id 0 encodes (m, h): pid = m * num_heads + h.
    If HAS_W is true, the result is scaled by W (loaded as fp32);
    otherwise the weight multiply is omitted (weight == 1).
    """
    pid = tl.program_id(0)
    m = pid // num_heads
    h = pid - m * num_heads
    cols = tl.arange(0, BLOCK)
    mask = cols < HEAD_DIM
    off = m * stride_m + h * HEAD_DIM + cols
    x = tl.load(X_ptr + off, mask=mask, other=0.0).to(tl.float32)
    rrms = tl.rsqrt(tl.sum(x * x, axis=0) / HEAD_DIM + eps)
    out = x * rrms
    if HAS_W:
        w = tl.load(W_ptr + cols, mask=mask, other=0.0).to(tl.float32)
        out = out * w
    tl.store(X_ptr + off, out.to(X_ptr.dtype.element_ty), mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    q_weight = inputs["q_weight"]
    k_weight = inputs["k_weight"]

    head_dim = q_weight.shape[-1]
    num_q_heads = q.shape[1] // head_dim
    num_kv_heads = k.shape[1] // head_dim
    BLOCK = triton.next_power_of_2(head_dim)
    num_warps = max(1, BLOCK // 32)

    _rmsnorm_head_kernel[(num_q_heads * q.shape[0],)](
        q, q_weight, num_q_heads, q.stride(0), EPS,
        HEAD_DIM=head_dim, BLOCK=BLOCK, HAS_W=True,
        num_warps=num_warps,
    )
    _rmsnorm_head_kernel[(num_kv_heads * k.shape[0],)](
        k, k_weight, num_kv_heads, k.stride(0), EPS,
        HEAD_DIM=head_dim, BLOCK=BLOCK, HAS_W=True,
        num_warps=num_warps,
    )
    _rmsnorm_head_kernel[(num_kv_heads * v.shape[0],)](
        v, v, num_kv_heads, v.stride(0), EPS,
        HEAD_DIM=head_dim, BLOCK=BLOCK, HAS_W=False,
        num_warps=num_warps,
    )

    return {"q": q, "k": k, "v": v}
