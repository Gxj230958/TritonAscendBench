"""Round 3 solution: per-head QKV RMSNorm migrated to triton-ascend.

Single change vs round 1 (isolate one variable; see notes.md):

  * ROUND 1 used a 1-D grid of size (M * num_heads). On the largest shape
    (H7: M=8192, QH=16) that is 131072 programs, which exceeds triton-ascend's
    per-launch limit (grid axis must be < 65536) and the launch crashed with
    "RuntimeError: grid should be less than 65536!".
    ROUND 3 uses a 2-D grid (M, num_heads): M<=8192 and num_heads<=256, so no
    axis exceeds 65535 and H7 becomes runnable.

Everything else (loads, fp32 accumulation, rsqrt, weight multiply, cast order,
masking, strided offsets) is byte-identical to round 1 so the round-3 receipt
gives clean empirical precision data for the 1-ULP bf16 flips seen on the
large shapes.
"""

import torch
import triton
import triton.language as tl

EPS = 1e-6


@triton.jit
def _rmsnorm_head_kernel(
    X_ptr,
    W_ptr,
    stride_m,
    eps,
    HEAD_DIM: tl.constexpr,
    BLOCK: tl.constexpr,
    HAS_W: tl.constexpr,
):
    """RMS-normalize a single (token, head) vector in X in place.

    Grid is 2-D: program_id(0) = m (row/token), program_id(1) = h (head).
    out = x * rsqrt(mean(x^2 over head_dim) + eps) * (W if HAS_W else 1)
    fp32 arithmetic; store cast back to X's element type (bf16).
    """
    m = tl.program_id(0)
    h = tl.program_id(1)
    cols = tl.arange(0, BLOCK)
    mask = cols < HEAD_DIM
    off = m * stride_m + h * HEAD_DIM + cols
    x = tl.load(X_ptr + off, mask=mask, other=0.0).to(tl.float32)
    rrms = tl.rsqrt(tl.sum(x * x, axis=0) / HEAD_DIM + eps)
    out = x * rrms
    if HAS_W:
        w = tl.load(W_ptr + cols, mask=mask, other=0.0).to(tl.float32)
        out = out * w
    tl.store(X_ptr + off, out.to(X_ptr.dtype.element_ty), mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    q_weight = inputs["q_weight"]
    k_weight = inputs["k_weight"]

    head_dim = q_weight.shape[-1]
    num_q_heads = q.shape[1] // head_dim
    num_kv_heads = k.shape[1] // head_dim
    BLOCK = triton.next_power_of_2(head_dim)
    num_warps = max(1, BLOCK // 32)

    _rmsnorm_head_kernel[(q.shape[0], num_q_heads)](
        q, q_weight, q.stride(0), EPS,
        HEAD_DIM=head_dim, BLOCK=BLOCK, HAS_W=True,
        num_warps=num_warps,
    )
    _rmsnorm_head_kernel[(k.shape[0], num_kv_heads)](
        k, k_weight, k.stride(0), EPS,
        HEAD_DIM=head_dim, BLOCK=BLOCK, HAS_W=True,
        num_warps=num_warps,
    )
    _rmsnorm_head_kernel[(v.shape[0], num_kv_heads)](
        v, v, v.stride(0), EPS,
        HEAD_DIM=head_dim, BLOCK=BLOCK, HAS_W=False,
        num_warps=num_warps,
    )

    return {"q": q, "k": k, "v": v}
