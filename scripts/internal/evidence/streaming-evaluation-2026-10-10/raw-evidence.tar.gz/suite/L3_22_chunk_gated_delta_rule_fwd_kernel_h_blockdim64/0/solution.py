"""Triton-Ascend port of the gated delta-rule chunk-state forward kernel.

Computes per-chunk recurrent state snapshots for the gated DeltaNet
forward pass (the block-K=64 variant). For every batch/head, a state
block S of shape [V, K] is carried across chunks of BT=64 timesteps:

  1. h[:, chunk] = S                      (snapshot at chunk start)
  2. dv = u_chunk - w_chunk @ S^T         ([BT, V])
  3. dv *= exp(g_last - g_row)            (within-chunk gate, row-wise)
  4. S  *= exp(g_last)                    (scalar state decay)
  5. S  *= exp(gk_last) per key channel   (per-channel state decay)
  6. S  += dv^T @ k_chunk                 (accumulate into the state)

Only the final row of g / gk inside each chunk is read for the decays,
mirroring the upstream semantics exactly.

NPU adaptation notes:
  * Matrix products run on the cube unit in fp32 with hf32 input
    precision (10-bit significand, fp32 range), matching the TF32
    mode used by the upstream GPU version; fp32 range is essential
    because the carried state grows by orders of magnitude along the
    sequence. All state, gating and accumulation stay fp32.
  * Tiles are addressed with explicit offsets plus masks instead of
    block pointers, which handles partial last chunks and V not
    divisible by the block size. dv is carried transposed ([BV, BT])
    so every cube product lands in its final orientation directly,
    without any tile transposition.
  * K is unrolled in fixed 64-wide blocks (K is a multiple of 64 and
    at most 256), keeping four [BV, 64] state registers in flight, as
    in the upstream structure.
"""

import torch
import triton
import triton.language as tl

_CHUNK_SIZE = 64


@triton.jit(do_not_specialize=["T"])
def _gdr_fwd_h_kernel(
    k,
    w,
    v,
    g,
    gk,
    h,
    h0,
    T,
    H: tl.constexpr,
    Hg: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BT: tl.constexpr,
    BV: tl.constexpr,
    USE_G: tl.constexpr,
    USE_GK: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
):
    i_v, i_nh = tl.program_id(0), tl.program_id(1)
    i_n, i_h = i_nh // H, i_nh % H
    bos = i_n * T
    NT = tl.cdiv(T, BT)

    # [BV, 64] state registers, one per 64-wide key block.
    b_h1 = tl.zeros([BV, 64], dtype=tl.float32)
    if K > 64:
        b_h2 = tl.zeros([BV, 64], dtype=tl.float32)
    if K > 128:
        b_h3 = tl.zeros([BV, 64], dtype=tl.float32)
    if K > 192:
        b_h4 = tl.zeros([BV, 64], dtype=tl.float32)

    # Base offsets (int64 so large batch/time extents stay in range).
    h += ((i_n * NT * H + i_h) * V * K).to(tl.int64)
    v += ((bos * H + i_h) * V).to(tl.int64)
    k += ((bos * Hg + i_h // (H // Hg)) * K).to(tl.int64)
    w += ((bos * H + i_h) * K).to(tl.int64)
    if USE_G:
        g += (bos * H + i_h).to(tl.int64)
    if USE_GK:
        gk += ((bos * H + i_h) * K).to(tl.int64)
    if USE_INITIAL_STATE:
        h0 = h0 + (i_nh * V * K).to(tl.int64)

    stride_v = H * V
    stride_k = Hg * K
    stride_w = H * K
    stride_h = H * V * K

    offs_v = i_v * BV + tl.arange(0, BV)
    m_v = offs_v < V
    offs_bt = tl.arange(0, BT)
    o_k1 = tl.arange(0, 64)
    m_k1 = o_k1 < K

    # Load the carried state from the initial state if provided.
    if USE_INITIAL_STATE:
        b_h1 += tl.load(
            h0 + offs_v[:, None] * K + o_k1[None, :],
            mask=m_v[:, None] & m_k1[None, :],
            other=0.0,
        )
        if K > 64:
            o_k2 = 64 + o_k1
            m_k2 = o_k2 < K
            b_h2 += tl.load(
                h0 + offs_v[:, None] * K + o_k2[None, :],
                mask=m_v[:, None] & m_k2[None, :],
                other=0.0,
            )
        if K > 128:
            o_k3 = 128 + o_k1
            m_k3 = o_k3 < K
            b_h3 += tl.load(
                h0 + offs_v[:, None] * K + o_k3[None, :],
                mask=m_v[:, None] & m_k3[None, :],
                other=0.0,
            )
        if K > 192:
            o_k4 = 192 + o_k1
            m_k4 = o_k4 < K
            b_h4 += tl.load(
                h0 + offs_v[:, None] * K + o_k4[None, :],
                mask=m_v[:, None] & m_k4[None, :],
                other=0.0,
            )

    for i_t in range(NT):
        # ---- 1. snapshot the pre-update state for this chunk ----
        h_ptr = h + i_t * stride_h
        tl.store(
            h_ptr + offs_v[:, None] * K + o_k1[None, :],
            b_h1,
            mask=m_v[:, None] & m_k1[None, :],
        )
        if K > 64:
            o_k2 = 64 + o_k1
            m_k2 = o_k2 < K
            tl.store(
                h_ptr + offs_v[:, None] * K + o_k2[None, :],
                b_h2,
                mask=m_v[:, None] & m_k2[None, :],
            )
        if K > 128:
            o_k3 = 128 + o_k1
            m_k3 = o_k3 < K
            tl.store(
                h_ptr + offs_v[:, None] * K + o_k3[None, :],
                b_h3,
                mask=m_v[:, None] & m_k3[None, :],
            )
        if K > 192:
            o_k4 = 192 + o_k1
            m_k4 = o_k4 < K
            tl.store(
                h_ptr + offs_v[:, None] * K + o_k4[None, :],
                b_h4,
                mask=m_v[:, None] & m_k4[None, :],
            )

        # ---- 2. dv = u - w @ S^T, kept transposed as [BV, BT] ----
        offs_t = i_t * BT + offs_bt
        m_t = offs_t < T

        # u tile in transposed orientation [BV, BT].
        b_uT = tl.load(
            v + offs_t[None, :] * stride_v + offs_v[:, None],
            mask=m_t[None, :] & m_v[:, None],
            other=0.0,
        )
        # Accumulate S @ w^T over the key blocks: w tile loaded as
        # [64_k, BT_t] with strides (1, stride_w).
        b_vT = tl.zeros([BV, BT], dtype=tl.float32)
        b_wT1 = tl.load(
            w + o_k1[:, None] + offs_t[None, :] * stride_w,
            mask=m_k1[:, None] & m_t[None, :],
            other=0.0,
        )
        b_vT += tl.dot(b_h1, b_wT1, input_precision="hf32")
        if K > 64:
            b_wT2 = tl.load(
                w + o_k2[:, None] + offs_t[None, :] * stride_w,
                mask=m_k2[:, None] & m_t[None, :],
                other=0.0,
            )
            b_vT += tl.dot(b_h2, b_wT2, input_precision="hf32")
        if K > 128:
            b_wT3 = tl.load(
                w + o_k3[:, None] + offs_t[None, :] * stride_w,
                mask=m_k3[:, None] & m_t[None, :],
                other=0.0,
            )
            b_vT += tl.dot(b_h3, b_wT3, input_precision="hf32")
        if K > 192:
            b_wT4 = tl.load(
                w + o_k4[:, None] + offs_t[None, :] * stride_w,
                mask=m_k4[:, None] & m_t[None, :],
                other=0.0,
            )
            b_vT += tl.dot(b_h4, b_wT4, input_precision="hf32")

        b_vT = b_uT - b_vT

        last_idx = tl.minimum((i_t + 1) * BT, T) - 1

        # ---- 3./4. gate dv and decay the carried state (scalar gate) ----
        if USE_G:
            b_g_last = tl.load(g + last_idx * H)
            b_g = tl.load(g + offs_t * H, mask=m_t, other=0.0)
            b_gate = tl.where(m_t, tl.exp(b_g_last - b_g), 0.0)
            b_vT = b_vT * b_gate[None, :]
            b_decay = tl.exp(b_g_last)
            b_h1 *= b_decay
            if K > 64:
                b_h2 *= b_decay
            if K > 128:
                b_h3 *= b_decay
            if K > 192:
                b_h4 *= b_decay

        # ---- 5. per-key-channel decay of the carried state ----
        if USE_GK:
            b_gk1 = tl.load(gk + last_idx * H * K + o_k1, mask=m_k1, other=0.0)
            b_h1 *= tl.exp(b_gk1)[None, :]
            if K > 64:
                b_gk2 = tl.load(gk + last_idx * H * K + o_k2, mask=m_k2, other=0.0)
                b_h2 *= tl.exp(b_gk2)[None, :]
            if K > 128:
                b_gk3 = tl.load(gk + last_idx * H * K + o_k3, mask=m_k3, other=0.0)
                b_h3 *= tl.exp(b_gk3)[None, :]
            if K > 192:
                b_gk4 = tl.load(gk + last_idx * H * K + o_k4, mask=m_k4, other=0.0)
                b_h4 *= tl.exp(b_gk4)[None, :]

        # ---- 6. S += dv^T @ k_chunk, one 64-wide key block at a time ----
        # k tile loaded as [BT_t, 64_k] with strides (stride_k, 1), so
        # dot(b_vT [BV, BT], b_k [BT, 64]) lands directly in [BV, 64].
        b_k1 = tl.load(
            k + offs_t[:, None] * stride_k + o_k1[None, :],
            mask=m_t[:, None] & m_k1[None, :],
            other=0.0,
        )
        b_h1 += tl.dot(b_vT, b_k1, input_precision="hf32")
        if K > 64:
            b_k2 = tl.load(
                k + offs_t[:, None] * stride_k + o_k2[None, :],
                mask=m_t[:, None] & m_k2[None, :],
                other=0.0,
            )
            b_h2 += tl.dot(b_vT, b_k2, input_precision="hf32")
        if K > 128:
            b_k3 = tl.load(
                k + offs_t[:, None] * stride_k + o_k3[None, :],
                mask=m_t[:, None] & m_k3[None, :],
                other=0.0,
            )
            b_h3 += tl.dot(b_vT, b_k3, input_precision="hf32")
        if K > 192:
            b_k4 = tl.load(
                k + offs_t[:, None] * stride_k + o_k4[None, :],
                mask=m_t[:, None] & m_k4[None, :],
                other=0.0,
            )
            b_h4 += tl.dot(b_vT, b_k4, input_precision="hf32")


def npu_triton_impl(inputs: dict) -> dict:
    """Gated delta-rule chunk-state forward on the NPU.

    Consumes k/w/u/g (and optionally gk / initial_state) and returns
    {"output": h} with h of shape [B, NT, H, V, K], NT = ceil(T / 64).
    """
    k = inputs["k"].contiguous()
    w = inputs["w"].contiguous()
    u = inputs["u"].contiguous()
    use_g = "g" in inputs
    use_gk = "gk" in inputs
    use_h0 = "initial_state" in inputs
    g = inputs["g"].contiguous() if use_g else None
    gk = inputs["gk"].contiguous() if use_gk else None
    h0 = inputs["initial_state"].contiguous() if use_h0 else None

    B, T, Hg, K = k.shape
    H = u.shape[-2]
    V = u.shape[-1]
    BT = _CHUNK_SIZE
    if K > 256:
        raise ValueError("head dimension larger than 256 is not supported")

    NT = triton.cdiv(T, BT)
    # Cube-friendly V blocking; keep at least 32 rows for the dot unit.
    if V <= 32:
        BV = 32
    else:
        BV = 64

    h = torch.empty((B, NT, H, V, K), dtype=torch.float32, device=k.device)
    grid = (triton.cdiv(V, BV), B * H)

    _gdr_fwd_h_kernel[grid](
        k,
        w,
        u,
        g,
        gk,
        h,
        h0,
        T,
        H=H,
        Hg=Hg,
        K=K,
        V=V,
        BT=BT,
        BV=BV,
        USE_G=use_g,
        USE_GK=use_gk,
        USE_INITIAL_STATE=use_h0,
    )
    return {"output": h}
