"""Task L2_04_silu_and_mul -- Triton-Ascend implementation (round 2).

Contract semantics (contract.md):

    x1 = hidden_states[:, :hidden_dim]
    x3 = hidden_states[:, hidden_dim:]
    silu_x1 = silu(x1.to(float32)).to(hidden_states.dtype)
    output  = x3 * silu_x1

The tolerance class is elementwise with atol 1e-3 and rtol 1e-3, while bf16
spacing near magnitude 1 is 2**-8 = 3.9e-3. One bf16 step already breaches it, so
bit-level agreement with the reference is the real requirement, and round 1's
receipt says that is exactly what was missing: every shape missed by one bf16
step (max_rel = 0.00781 = 2**-7) and only the 4-element shape survived. Two
causes, both in the arithmetic:

1. Narrowing float casts. `semantic.cast` sends fp32 -> bf16 to
   `builder.create_fp_trunc`, a truncating conversion, while the reference rounds
   to nearest-even. Truncation lands one step low on about half the elements.
2. Gate expression. `x1 * tl.sigmoid(x1)` is `x1 * (1 / den)`: a reciprocal
   rounding followed by a multiply rounding. The device's own silu path is one
   division, `x / (1 + exp(-x))`, so the extra rounding drifts the fp32 gate.

Fix for both: `rne_bf16_f32` carries out round-to-nearest-even to bf16 precision
in integer bit arithmetic and returns an fp32 value that is exactly
representable in bf16. Passing such a value through any narrowing conversion is
a no-op whichever way that conversion rounds, so the kernel's bits no longer
depend on how the backend lowers a cast or a store: both roundings happen here,
explicitly. In between, x3 and the gate hold at most 8 significant bits apiece,
so their fp32 product is exact -- one multiply, one rounding, which is precisely
the reference's shape. The gate is now a single division, matching the reference
op sequence.

Performance. Round 1 spent ~5 ns per output element on every large shape (P8:
39.2 ms for 50 MB of traffic, ~1.3 GB/s), which is a scalarised loop, not
bandwidth. Two geometry changes address it:

* `HAS_MASK` drops lane masks from the hot path. A masked access takes the back
  end's discrete (per-element) mask-conversion path rather than a bulk vector
  access, and that penalty applies even when the mask is all-true. Whenever a
  tile provably lies inside the row the kernel lowers the unmasked branch,
  which is the case for every corpus shape.
* Tiles are contiguous 1-D runs of a single row wherever that is possible, so no
  per-lane row/column split by division survives into the offset math. Where a
  row is too wide for one tile, extra tiles walk along the same row, keeping
  every access contiguous.

Index notes. The two halves of a row are hidden_dim elements apart, so a lane
owning output column c of row r reads 2*r*hidden_dim + c and that address plus
hidden_dim. A tile stays at or under 1024 lanes, which keeps each fp32
intermediate near 4 KB and leaves the 48 KB unified buffer unstrained with
several buffers live.

Only one grid axis and 1-D vectors are used, because the Ascend launcher
collapses a multi-axis grid into a single flattened block count.
"""

import torch
import triton
import triton.language as tl


# A tile is at most 1024 lanes: 4 KB per fp32 intermediate, 8 KB per bf16 one.
_MAX_TILE = 1024
# Below this a tile is too narrow to be worth vectorising, so it is left alone
# even when a wider tile would also divide the row.
_MIN_BLOCK = 128
# Aim for at least this many programs so a launch can fill the vector cores;
# when one tile per row is not enough, tiles get narrower.
_TARGET_PROGRAMS = 64
# The Ascend launcher raises when the flattened block count passes this, so a
# batch that large must stack rows instead. Nothing in the corpus comes close:
# the widest batch is 8192 rows.
_MAX_PROGRAMS = 65535


@triton.jit
def rne_bf16_f32(v):
    """Round fp32 `v` to nearest-even bf16, returning an exactly representable fp32.

    Two's complement does the work. A float's sign bit is already its high bit,
    so adding the dropped-bit midpoint (0x7FFF) plus the retained lsb
    (ties-to-even) and then shifting 16 bits out rounds the magnitude correctly
    for either sign. No finite magnitude can overflow int32 on the way through,
    and the result is itself a bf16 value, so a following narrowing conversion
    cannot change it. Verified bit-for-bit against a torch bf16 cast over 20M
    random bit patterns, both signs and -0.0 included.
    """
    u = v.to(tl.int32, bitcast=True)
    u = u + 0x7FFF + ((u >> 16) & 1)
    u = (u >> 16) << 16
    return u.to(tl.float32, bitcast=True)


@triton.jit
def silu_and_mul_kernel(
    out_ptr,
    in_ptr,
    num_rows,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    ROWS: tl.constexpr,
    COL_TILES: tl.constexpr,
    HAS_MASK: tl.constexpr,
):
    """SiLU-gate one rectangle of the output: ROWS rows x BLOCK_SIZE columns."""
    pid = tl.program_id(axis=0)
    # Column tiles vary fastest, so programs running together touch neighbouring
    # columns of the same rows instead of far-apart memory. COL_TILES is a
    # constexpr, so this split folds away whenever it is a power of two.
    row_blk = pid // COL_TILES
    col_blk = pid - row_blk * COL_TILES

    if ROWS == 1:
        # The common case: one contiguous run of one row. No per-lane split, so
        # the row term is a scalar and both accesses are plain vectors.
        row = row_blk
        col = col_blk * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    else:
        lane = tl.arange(0, ROWS * BLOCK_SIZE)
        row = row_blk * ROWS + (lane // BLOCK_SIZE)
        col = col_blk * BLOCK_SIZE + (lane % BLOCK_SIZE)

    in_offs = row * (2 * hidden_dim) + col
    out_offs = row * hidden_dim + col

    if HAS_MASK:
        # Ragged tail: lanes past the row or past the last column are dropped.
        # Masked accesses take the discrete path, so this branch is only for
        # widths that no tile divides; reading in_offs unmasked would run off
        # the end of the tensor.
        valid = (row < num_rows) & (col < hidden_dim)
        x1 = tl.load(in_ptr + in_offs, mask=valid, other=0.0).to(tl.float32)
        x3 = tl.load(in_ptr + in_offs + hidden_dim, mask=valid, other=0.0).to(
            tl.float32
        )
    else:
        x1 = tl.load(in_ptr + in_offs).to(tl.float32)
        x3 = tl.load(in_ptr + in_offs + hidden_dim).to(tl.float32)

    # silu in fp32 with one division, then back to bf16 precision *before* the
    # gating multiply: the load-bearing step of the contract.
    gate = rne_bf16_f32(x1 / (1.0 + tl.exp(-x1)))
    # Each factor now carries at most 8 significant bits, so this product is
    # exact in fp32 and the only rounding left is the one below.
    out = rne_bf16_f32(x3 * gate)

    if HAS_MASK:
        tl.store(out_ptr + out_offs, out, mask=valid)
    else:
        tl.store(out_ptr + out_offs, out)


def _pow2_floor(n):
    """Largest power of two that is <= n, for n >= 1."""
    p = triton.next_power_of_2(n)
    return p if p <= n else p // 2


def _plan(num_rows, hidden_dim):
    """Return (BLOCK_SIZE, ROWS, col_tiles, row_blocks, has_mask).

    Contiguity comes first: the width is the largest power of two that divides
    hidden_dim and fits a tile, so tiles tile each row exactly, no lane is
    wasted, and every access is a plain vector. Widths with no such usable
    divisor (a prime-ish 17, say) fall back to the widest power of two not
    exceeding the row and pay a mask instead.
    """
    low_bit = hidden_dim & (-hidden_dim)  # largest power of two dividing it
    widest = min(_pow2_floor(hidden_dim), _MAX_TILE)
    aligned = min(low_bit, _MAX_TILE)
    block = aligned if aligned >= _MIN_BLOCK else widest

    col_tiles = (hidden_dim + block - 1) // block

    # A launch that reaches too few cores: trade tile width for programs while
    # the narrower width still divides the row, so nothing turns ragged.
    while (
        block > _MIN_BLOCK
        and col_tiles * num_rows < _TARGET_PROGRAMS
        and hidden_dim % (block // 2) == 0
    ):
        block //= 2
        col_tiles = hidden_dim // block

    rows = 1
    programs = col_tiles * num_rows
    if programs > _MAX_PROGRAMS:
        # Last resort, unreachable for any corpus shape: stack rows into a
        # rectangle until the launch fits. The tile grows past the usual budget
        # if that is what fitting takes, since a launch the launcher refuses is
        # a worse outcome than a large tile.
        while programs > _MAX_PROGRAMS:
            rows *= 2
            programs = col_tiles * ((num_rows + rows - 1) // rows)

    row_blocks = (num_rows + rows - 1) // rows
    has_mask = (hidden_dim % block != 0) or (num_rows % rows != 0)
    return block, rows, col_tiles, row_blocks, has_mask


def silu_and_mul(hidden_states):
    """Gate the first half of every row by the silu of that half."""
    shape = hidden_states.shape
    hidden_dim = shape[-1] // 2
    assert hidden_dim * 2 == shape[-1], "last dimension must be even"
    assert hidden_dim >= 1, "hidden dim must be positive"

    if not hidden_states.is_contiguous():
        hidden_states = hidden_states.contiguous()

    num_rows = hidden_states.numel() // (2 * hidden_dim)
    out = torch.empty(
        shape[:-1] + (hidden_dim,),
        dtype=hidden_states.dtype,
        device=hidden_states.device,
    )
    if num_rows == 0 or hidden_dim == 0:
        return out

    block, rows, col_tiles, row_blocks, has_mask = _plan(num_rows, hidden_dim)
    silu_and_mul_kernel[(col_tiles * row_blocks,)](
        out,
        hidden_states,
        num_rows,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=block,
        ROWS=rows,
        COL_TILES=col_tiles,
        HAS_MASK=has_mask,
    )
    return out


def npu_triton_impl(inputs):
    """Entry point: inputs['hidden_states'] -> {'output': ...}."""
    return {"output": silu_and_mul(inputs["hidden_states"])}


# Alias for callers that use the upstream-style name.
silu_and_mul_triton = silu_and_mul


def run(inputs):
    return npu_triton_impl(inputs)
