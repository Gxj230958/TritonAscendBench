"""triton-ascend migration of compute_problem_sizes_w4a8 (L1_25).

Writes grouped-GEMM problem-size metadata for a W4A8 MoE:
  problem_sizes1[e] = (2*n, masked_m[e], k)   first GEMM (gate+up fused)
  problem_sizes2[e] = (k,   masked_m[e], n)   second GEMM (down proj)
Pure integer bookkeeping: one masked int64 load per expert, six masked
int32 stores. No numerics, so accumulation dtype / cast order are trivially
exact (int64 -> int32 narrowing of an in-range count, matching the
reference which narrows masked_m to int32 before stacking).

The scalar GEMM dims n / k / num_experts are passed to the kernel verbatim
(no host-side tensor coercion), as torch.empty / triton.cdiv / the kernel
all consume them natively.

Round 2 change (single, geometry-only): BLOCK_SIZE lowered 256 -> 64.
Every launched program runs the masked load + six masked stores once per
lane, so lanes beyond num_experts are wasted vector work that still costs
device time on this launch-floor-bound kernel (meta cost_model marks it
FLOOR_DOMINATED; measured bytes ~4KB per shape). 28 of the 46 graded
shapes have E=12 (several have E <= 16), where 256 lanes are ~90% dead;
64 lanes keeps the common small-E shapes on a single program while the
one E=256 shape spreads across four equal programs. Semantics unchanged:
the per-lane masks (pid < num_experts, ps*_idx < num_experts*3) cover the
union of all programs, so each expert's three int32 outputs are written
exactly once.

"""
import torch
import triton
import triton.language as tl


@triton.jit
def _compute_problem_sizes_w4a8_kernel(
    masked_m_ptr,
    ps1_ptr,
    ps2_ptr,
    n,
    k,
    num_experts,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0) * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = pid < num_experts
    final_occurrences = tl.load(masked_m_ptr + pid, mask=mask, other=0)
    # int64 -> int32 before storing, matching the reference cast.
    m32 = final_occurrences.to(tl.int32)

    ps1_idx_0 = pid * 3
    ps1_idx_1 = ps1_idx_0 + 1
    ps1_idx_2 = ps1_idx_0 + 2
    ps1_mask_0 = ps1_idx_0 < num_experts * 3
    ps1_mask_1 = ps1_idx_1 < num_experts * 3
    ps1_mask_2 = ps1_idx_2 < num_experts * 3

    tl.store(ps1_ptr + ps1_idx_0, (2 * n).to(tl.int32), mask=ps1_mask_0)
    tl.store(ps1_ptr + ps1_idx_1, m32, mask=ps1_mask_1)
    tl.store(ps1_ptr + ps1_idx_2, k.to(tl.int32), mask=ps1_mask_2)
    tl.store(ps2_ptr + ps1_idx_0, k.to(tl.int32), mask=ps1_mask_0)
    tl.store(ps2_ptr + ps1_idx_1, m32, mask=ps1_mask_1)
    tl.store(ps2_ptr + ps1_idx_2, n.to(tl.int32), mask=ps1_mask_2)


def npu_triton_impl(inputs: dict) -> dict:
    masked_m = inputs["masked_m"].contiguous()
    n = inputs["n"]
    k = inputs["k"]
    num_experts = inputs["num_experts"]

    problem_sizes1 = torch.empty(
        (num_experts, 3), dtype=torch.int32, device=masked_m.device
    )
    problem_sizes2 = torch.empty(
        (num_experts, 3), dtype=torch.int32, device=masked_m.device
    )

    BLOCK_SIZE = 64
    grid = (triton.cdiv(num_experts, BLOCK_SIZE),)
    _compute_problem_sizes_w4a8_kernel[grid](
        masked_m,
        problem_sizes1,
        problem_sizes2,
        n,
        k,
        num_experts,
        BLOCK_SIZE=BLOCK_SIZE,
    )

    return {"problem_sizes1": problem_sizes1, "problem_sizes2": problem_sizes2}
