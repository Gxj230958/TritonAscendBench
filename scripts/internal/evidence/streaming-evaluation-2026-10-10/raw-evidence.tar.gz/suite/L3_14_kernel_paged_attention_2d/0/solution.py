"""Task L3_14_kernel_paged_attention_2d -- Triton-Ascend implementation.

Semantics (contract.md): one query token per sequence. For sequence ``i``
gather the first ``seq_lens[i]`` KV positions out of the paged caches through
``block_table``, broadcast each KV head over its query-head group (GQA), form
the scaled dot product in fp32, optionally add an ALiBi bias and clip the
context to a sliding window, softmax in fp32, then combine V. Output is
``[n_tokens, n_query_heads, head_size]``.

Design
------
* Native cache layout. The paged caches are read in their flat
  ``[n_blocks, block_size, n_kv_heads, head_size]`` form, so the host side does
  no repacking step: each KV position resolves its physical block with a gather
  from the block table. The tile width and the physical block size are
  decoupled (``abs_pos // PHYS_BLOCK``, ``abs_pos % PHYS_BLOCK``), so a tile can
  straddle two physical blocks and a non power-of-two ``block_size`` (48 on
  shape H1) needs no special case.
* Program partition. A program owns one (token, query head) pair, so a tile is
  a ``[BLOCK_T, HEAD_PADDED]`` K block plus the matching V block, and the score
  reduction / weighted sum stay on the vector path in fp32 rather than being
  narrowed by a lower-precision matmul input type. With
  ``n_query_heads == n_kv_heads`` (true for every shape of this task) there is
  no redundant K/V traffic; grouped layouts stay correct and merely repeat a
  gather per head of the group.
* Softmax. Single pass with a running max and denominator, fp32 throughout.
  Only positions in ``[window_start, seq_len)`` are visited, so every tile
  holds at least one live lane and the running max can never be pushed to
  -inf. Positions older than the window are excluded from the walk, which is
  equivalent to the reference hard-zeroing their probabilities.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _paged_attention_2d_gather(
    out_ptr,                    # [n_tokens, n_query_heads, head_size]
    q_ptr,                      # [n_tokens, n_query_heads, head_size]
    k_ptr,                      # [n_blocks, block_size, n_kv_heads, head_size]
    v_ptr,                      # same layout as k_ptr
    block_table_ptr,            # [n_seqs, max_blocks]
    seq_lens_ptr,               # [n_seqs]
    alibi_ptr,                  # [n_query_heads]; read only when USE_ALIBI
    scale,                      # fp32 score scale
    q_stride_tok: tl.int64,
    q_stride_head: tl.int64,
    out_stride_tok: tl.int64,
    out_stride_head: tl.int64,
    block_table_stride: tl.int64,
    kv_slot_stride: tl.int64,   # n_kv_heads * head_size
    head_stride: tl.int64,      # head_size
    num_queries_per_kv: tl.constexpr,
    BLOCK_T: tl.constexpr,      # tile width over KV positions
    HEAD_SIZE: tl.constexpr,
    HEAD_PADDED: tl.constexpr,  # power of two >= HEAD_SIZE
    PHYS_BLOCK: tl.constexpr,   # block_size of the paged cache
    USE_ALIBI: tl.constexpr,
    WINDOW: tl.constexpr,       # sliding-window length; 0 keeps the context
):
    token_idx = tl.program_id(0).to(tl.int64)
    head_idx = tl.program_id(1)
    kv_head_idx = head_idx // num_queries_per_kv

    dim_idx = tl.arange(0, HEAD_PADDED)
    dim_ok = dim_idx < HEAD_SIZE

    q_row = q_ptr + token_idx * q_stride_tok + head_idx * q_stride_head
    Q = tl.load(q_row + dim_idx, mask=dim_ok, other=0.0).to(tl.float32)

    seq_len = tl.load(seq_lens_ptr + token_idx).to(tl.int32)

    # First visited position: the reference keeps the last WINDOW positions.
    start_pos = 0
    if WINDOW > 0:
        start_pos = tl.maximum(seq_len - WINDOW, 0)

    bt_row = block_table_ptr + token_idx * block_table_stride
    head_row = kv_head_idx * head_stride

    acc = tl.zeros([HEAD_PADDED], dtype=tl.float32)
    # The running max/denominator are shape-[1] fp32 vectors rather than rank-0
    # values, so the whole loop state lowers as tensors and broadcasts against
    # the tile lanes.
    run_max = tl.full([1], float("-inf"), dtype=tl.float32)
    run_sum = tl.zeros([1], dtype=tl.float32)

    tile_off = tl.arange(0, BLOCK_T)

    for tile_start in range(start_pos, seq_len, BLOCK_T):
        pos = tile_start + tile_off
        live = pos < seq_len
        pos64 = pos.to(tl.int64)

        phys_blk = tl.load(bt_row + pos64 // PHYS_BLOCK, mask=live, other=0)
        slot = pos64 % PHYS_BLOCK
        row = (phys_blk * PHYS_BLOCK + slot) * kv_slot_stride + head_row
        ptrs = row[:, None] + dim_idx[None, :]
        tile_mask = live[:, None] & dim_ok[None, :]

        K = tl.load(k_ptr + ptrs, mask=tile_mask, other=0.0).to(tl.float32)
        scores = tl.sum(K * Q[None, :], axis=1) * scale

        if USE_ALIBI:
            slope = tl.load(alibi_ptr + head_idx)
            alibi_pos = (pos - (seq_len - 1)).to(tl.float32)
            scores += slope.to(tl.float32) * alibi_pos

        scores = tl.where(live, scores, float("-inf"))

        prev_max = run_max
        new_max = tl.maximum(run_max, tl.max(scores, axis=0))
        probs = tl.exp(scores - new_max)
        probs = tl.where(live, probs, 0.0)
        decay = tl.exp(prev_max - new_max)

        V = tl.load(v_ptr + ptrs, mask=tile_mask, other=0.0).to(tl.float32)
        weighted = probs[:, None] * V
        acc = acc * decay + tl.sum(weighted, axis=0)
        run_sum = run_sum * decay + tl.sum(probs, axis=0)
        # adding a [1] zero keeps the loop-carried rank pinned at 1
        run_max = new_max + tl.zeros([1], dtype=tl.float32)

    denom = tl.where(run_sum > 0.0, run_sum, 1.0)
    acc = acc / denom

    out_row = out_ptr + token_idx * out_stride_tok + head_idx * out_stride_head
    tl.store(out_row + dim_idx, acc.to(out_ptr.dtype.element_ty), mask=dim_ok)


# Element budget of one K (or V) tile in fp32 elements; the tile width follows
# from it so a wide head (256 on shape P4) shrinks its KV span per tile instead
# of overflowing the on-chip buffer.
_TILE_ELEMENT_BUDGET = 4096
_MIN_TILE_POSITIONS = 16
_MAX_TILE_POSITIONS = 64


def npu_triton_impl(inputs: dict) -> dict:
    query = inputs["query"].contiguous()                # [B, H, D]
    key_cache = inputs["key_cache"].contiguous()        # [C, T, Hkv, D]
    value_cache = inputs["value_cache"].contiguous()    # [C, T, Hkv, D]
    block_table = inputs["block_table"].contiguous()    # [B, N]
    seq_lens = inputs["seq_lens"].contiguous()          # [B]
    # The contract scalars arrive as plain numbers (``scale`` is derived as
    # 1/sqrt(D)), so they can be handed to the launch directly.
    scale = inputs["scale"]
    has_alibi = "alibi_slopes" in inputs
    has_window = "sliding_window" in inputs
    alibi_slopes = inputs["alibi_slopes"] if has_alibi else query
    window = inputs["sliding_window"] if has_window else 0

    n_tokens, num_query_heads, head_size = query.shape
    n_blocks, phys_block, num_kv_heads, key_head_size = key_cache.shape

    head_padded = triton.next_power_of_2(head_size)
    block_t = _TILE_ELEMENT_BUDGET // head_padded
    block_t = max(_MIN_TILE_POSITIONS, min(_MAX_TILE_POSITIONS, block_t))

    output = torch.empty_like(query)                    # [B, H, D]

    _paged_attention_2d_gather[(n_tokens, num_query_heads)](
        out_ptr=output,
        q_ptr=query,
        k_ptr=key_cache,
        v_ptr=value_cache,
        block_table_ptr=block_table,
        seq_lens_ptr=seq_lens,
        alibi_ptr=alibi_slopes.contiguous(),
        scale=scale,
        q_stride_tok=query.stride(0),
        q_stride_head=query.stride(1),
        out_stride_tok=output.stride(0),
        out_stride_head=output.stride(1),
        block_table_stride=block_table.stride(0),
        kv_slot_stride=key_cache.stride(1),
        head_stride=key_cache.stride(2),
        num_queries_per_kv=num_query_heads // num_kv_heads,
        BLOCK_T=block_t,
        HEAD_SIZE=head_size,
        HEAD_PADDED=head_padded,
        PHYS_BLOCK=phys_block,
        USE_ALIBI=has_alibi,
        WINDOW=window,
    )
    return {"output": output}


def run(inputs: dict) -> dict:
    return npu_triton_impl(inputs)
