"""NPU (Triton-Ascend) implementation of the Mamba2/SSD chunked BMM.

Semantics (contract.md):
    a, b               : [seqlen, ngroups, K], bfloat16
    cu_chunk_seqlens   : [nchunks + 1], monotonic nondecreasing, starts at 0
    chunk_size         : scalar

    out[c, h, i, j] = sum_k a[s + i, h, k] * b[s + j, h, k],  s = cu[c]
    rows/cols past cu[c + 1] - cu[c] stay zero (tail chunks are zero padded).
    out is [nchunks, ngroups, chunk_size, chunk_size] with a's dtype.

Numerics, unchanged from the staged reference: each factor keeps its storage
precision (bfloat16) on the way into the contraction, the accumulation runs in
float32, and only the final value is cast back to the storage dtype.  Padded
tile lanes are fed exact zeros by the load masks, so they cannot contribute
phantom terms to the accumulator.

Round 2 changes, both read straight off the round 1 receipt.

1. Second-factor tile layout, i.e. the memory-access fix.  Round 1 built the
   `b` tile with the contraction axis first and the token axis last, which is
   what the matmul unit wants to consume directly -- but the token axis carries
   stride ngroups*K, so the innermost axis of that tile was the strided one and
   every element became its own two-byte gather: BLOCK_SIZE_K * chunk rows
   scalar loads per program per iteration, ~12.6M of them on the widest shape
   (P40, 23.9 ms measured against a ~50 us memory floor).  The tile is now
   built with the token axis first and the contraction axis last, so each row
   is a contiguous run and loads vectorise; `tl.permute(b, (1, 0))` hands the
   transposed view to `tl.dot`.  Same products, same fp32 accumulator, same
   summation order, so the cube work is bit-for-bit what it was.

2. K == 1 no longer goes through the matmul unit.  Round 1's P17 failed with
   max_abs=5.53, max_rel=1, i.e. output that does not follow the inputs at all,
   while P18..P21 (K = 2, 3, 4, 8) were fine on the same code path; the only
   thing special about depth 1 is that 15 of the 16 contraction lanes of the
   padded tile are masked zeros.  Depth 1 is instead computed as the single
   rank-one update it is: two 1-D vector loads and one float32 broadcast
   multiply-add, which is exactly the definition and is exact up to the one
   storage cast.  Those entries sit at the launch floor (~186 us for 8 KB of
   work), so giving up the matmul unit there costs nothing measurable.  Depths
   2..16 stay on the matmul unit, because round 1 already showed them passing.

Everything else (tile geometry, grid decomposition, masks, num_warps,
num_stages, the always-non-causal launch) is carried over untouched.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _bmm_chunk_fwd_kernel(
    a_ptr,
    b_ptr,
    out_ptr,
    cu_chunk_seqlens_ptr,
    seqlen,
    chunk_size: tl.constexpr,
    K: tl.constexpr,
    ngroups: tl.constexpr,
    stride_a_seqlen,
    stride_a_head,
    stride_ak: tl.constexpr,
    stride_b_seqlen,
    stride_b_head,
    stride_bk: tl.constexpr,
    stride_out_chunk,
    stride_out_head,
    stride_outm,
    stride_outn: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
    dot_dtype: tl.constexpr,
    USE_CUBE: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
):
    pid_ch = tl.program_id(axis=1)
    pid_c = pid_ch // ngroups
    pid_h = pid_ch - pid_c * ngroups

    num_pid_n = tl.cdiv(chunk_size, BLOCK_SIZE_N)
    pid_m = tl.program_id(axis=0) // num_pid_n
    pid_n = tl.program_id(axis=0) % num_pid_n

    # IS_CAUSAL keeps the upstream name so the launch signature lines up, but
    # the body ignores it: the graded region is the whole [chunk_size,
    # chunk_size] product, so no program may bail out early.  It is always
    # launched as not-causal, which is what the reference computes for every
    # shape in the corpus.

    chunk_seqlen_start = tl.load(cu_chunk_seqlens_ptr + pid_c).to(tl.int32)
    chunk_seqlen_end = tl.load(cu_chunk_seqlens_ptr + pid_c + 1).to(tl.int32)
    chunk_size_limit = chunk_seqlen_end - chunk_seqlen_start

    a_base = a_ptr + chunk_seqlen_start * stride_a_seqlen + pid_h * stride_a_head
    b_base = b_ptr + chunk_seqlen_start * stride_b_seqlen + pid_h * stride_b_head

    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_n = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)

    acc = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    row_ok = offs_m < chunk_size_limit
    col_ok = offs_n < chunk_size_limit

    if USE_CUBE:
        offs_k = tl.arange(0, BLOCK_SIZE_K)
        # Both factors are read with the contraction axis innermost, so a tile
        # row is one chunk token's contiguous run of K elements.
        a_ptrs = a_base + (offs_m[:, None] * stride_a_seqlen + offs_k[None, :] * stride_ak)
        b_ptrs = b_base + (offs_n[:, None] * stride_b_seqlen + offs_k[None, :] * stride_bk)

        # out[m, n] = sum_k a[m, k] * b[n, k], i.e. a_chunk @ b_chunk^T
        for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
            k_rem = K - k * BLOCK_SIZE_K
            k_ok = offs_k < k_rem
            a = tl.load(
                a_ptrs,
                mask=row_ok[:, None] & k_ok[None, :],
                other=0.0,
            ).to(dot_dtype)
            b = tl.load(
                b_ptrs,
                mask=col_ok[:, None] & k_ok[None, :],
                other=0.0,
            ).to(dot_dtype)
            acc = tl.dot(a, tl.permute(b, (1, 0)), acc)
            a_ptrs += BLOCK_SIZE_K * stride_ak
            b_ptrs += BLOCK_SIZE_K * stride_bk
    else:
        # K == 1: out[m, n] = a[m, 0] * b[n, 0], one rank-one update.
        a_col = tl.load(a_base + offs_m * stride_a_seqlen, mask=row_ok, other=0.0).to(
            tl.float32
        )
        b_col = tl.load(b_base + offs_n * stride_b_seqlen, mask=col_ok, other=0.0).to(
            tl.float32
        )
        acc += a_col[:, None] * b_col[None, :]

    out = acc.to(out_ptr.dtype.element_ty)

    out_base = out_ptr + pid_c * stride_out_chunk + pid_h * stride_out_head
    out_ptrs = out_base + (stride_outm * offs_m[:, None] + stride_outn * offs_n[None, :])
    tl.store(
        out_ptrs,
        out,
        mask=(offs_m[:, None] < chunk_size) & (offs_n[None, :] < chunk_size),
    )


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"]
    b = inputs["b"]
    cu_chunk_seqlens = inputs["cu_chunk_seqlens"]
    chunk_size = inputs["chunk_size"]

    seqlen, ngroups, K = a.shape
    nchunks = cu_chunk_seqlens.shape[0] - 1

    # Every element of this buffer is written by the launch below: the tile
    # grid covers [chunk_size, chunk_size] and the store mask keeps the
    # in-bounds part, so no pre-clearing pass is needed.
    out = torch.empty(
        (nchunks, ngroups, chunk_size, chunk_size), device=a.device, dtype=a.dtype
    )

    out_chunks, out_heads, tiles_m, tiles_n = out.shape
    block_m = min(max(triton.next_power_of_2(tiles_m), 16), 64)
    block_n = min(max(triton.next_power_of_2(tiles_n), 16), 64)
    use_cube = K > 1
    block_k = min(max(triton.next_power_of_2(K), 16), 128)

    dot_dtype = tl.bfloat16 if a.dtype == torch.bfloat16 else (
        tl.float16 if a.dtype == torch.float16 else tl.float32
    )

    grid = (
        triton.cdiv(tiles_m, block_m) * triton.cdiv(tiles_n, block_n),
        out_chunks * out_heads,
    )

    _bmm_chunk_fwd_kernel[grid](
        a,
        b,
        out,
        cu_chunk_seqlens,
        seqlen=seqlen,
        chunk_size=tiles_m,
        K=K,
        ngroups=ngroups,
        stride_a_seqlen=a.stride(0),
        stride_a_head=a.stride(1),
        stride_ak=a.stride(2),
        stride_b_seqlen=b.stride(0),
        stride_b_head=b.stride(1),
        stride_bk=b.stride(2),
        stride_out_chunk=out.stride(0),
        stride_out_head=out.stride(1),
        stride_outm=out.stride(2),
        stride_outn=out.stride(3),
        IS_CAUSAL=False,
        dot_dtype=dot_dtype,
        USE_CUBE=use_cube,
        BLOCK_SIZE_M=block_m,
        BLOCK_SIZE_N=block_n,
        BLOCK_SIZE_K=block_k,
        num_warps=4,
        num_stages=3,
    )

    return {"output": out}
