"""NPU (Triton-Ascend) implementation of the Mamba2/SSD chunked BMM.

Semantics (contract.md):
    a, b               : [seqlen, ngroups, K], bfloat16
    cu_chunk_seqlens   : [nchunks + 1], monotonic nondecreasing, starts at 0
    chunk_size         : scalar

    out[c, h, i, j] = sum_k a[s + i, h, k] * b[s + j, h, k],  s = cu[c]
    rows/cols past cu[c + 1] - cu[c] stay zero (tail chunks are zero padded).
    out is [nchunks, ngroups, chunk_size, chunk_size] with a's dtype.

Numerics, unchanged from the staged reference: each factor keeps its storage
precision (bfloat16) on the way into the contraction, the accumulation runs in
float32, and only the final value is cast back to the storage dtype.  Padded
tile lanes are fed exact zeros by the load masks, so they cannot contribute
phantom terms to the accumulator.

Round 5: round 2's kernel, with the per-call argument path taken off the
hot path.  Nothing about the tile, the grid, the masks or the arithmetic moves.

Round 2 is the best candidate so far (41/47, geomean 221 us) and rounds 3 and 4
each bought a device-side saving on the large shapes and paid for it 40x over.
Both gave a tile row an address that was no longer "a per-program scalar plus a
multiple of the row index": round 3 gathered a per-row chunk start out of
cu_chunk_seqlens, round 4 derived a per-row head with index_m // LANES.  In both
cases the engine lost the constant row stride it merges along and a contiguous
vector read collapsed into element-wide accesses -- P40 went 887 us (round 2) to
39.0 ms (round 3) and 38.6 ms (round 4).  Two independent attempts, one failure
mode, same magnitude, so the dead rows of a 16-lane tile holding a 4-token chunk
are not reachable from the index expressions, and this round leaves them
exactly as round 2 had them.  The kernel body below is round 2's, literally.

What this round does attack is the term that round 2's own receipt shows to be
the largest in the whole corpus: 30 of the 47 entries land between 166 us and
175 us regardless of what they compute.  H5 pays it for one program and 16
output elements, P12 for 16 programs, and P40's 887 us opens with the same 166
us.  It is also the same band across three rounds that changed the geometry
completely: 166 us (round 2), 182 us (round 3), 177 us (round 4), on shapes of
1 to 32 programs.  A charge that is flat in program count, in tile count and in
bytes, and flat across rounds, is per call, not per program -- and everything
inside the kernel is therefore already below its resolution.

What a call does before the kernel runs is marshal its arguments.  Round 2
hands the launcher sixteen scalars at every call and declares only five of them
constexpr, so eleven -- seqlen, chunk_size, K, ngroups and the seven strides --
travel as run-time values, get boxed and typed per call, and are read back as
runtime registers inside the loop.  Every one of them is a fixed integer for a
given shape (dimensions of tensors this function does not reshape), so none of
them needs to arrive at run time: declaring them constexpr bakes them into the
specialised kernel body and drops them out of the per-call signature.  `seqlen` is
dropped outright because round 2's body never reads it, and `IS_CAUSAL` because
the body ignores it -- the graded region is the whole [chunk_size, chunk_size]
product of every item, so no program may bail out early, and the upstream
early-return cannot fire at chunk_size 4 with a 16-lane tile anyway.

Why this is not a numeric change.  A constexpr integer and a run-time integer of
the same value take the same type here -- round 2's strides were small positive
Python ints, so they bound as i32 either way -- so every product, every offset
vector, every mask and every pointer increment evaluates to the same bits.  The
k-loop chain, the fp32 accumulator, the tl.dot ordering and the store cast are
untouched.  Graded values reproduce round 2 element for element, which is what
matters for the entries sitting at the storage-precision ceiling (P3, P4, P6,
P37, P39, P40 fail there at 1-2 bfloat16 ulps against a tolerance of atol 5e-3 /
rtol 1e-3, and meta.yaml records the staged kernel deviating by the same digits
on the same shapes) and for the near-line entries that currently pass (P36 at
max_abs 0.00195, P10, P11, P28, P35, P41).  Constant folding is not
reassociation, so none of those move in either direction.  The K == 1 rank-one
branch stays, still selected by a constexpr flag.

Expected effect.  The whole 166 us band shifts down by whatever fraction of it
is argument marshalling, and it shifts for all 47 entries at once -- the score
is a geometric mean over the entries, so 30 entries pinned at that band are
where the leverage is.  On top of that, a few percent on the k-loop-bound entries
(P8, P9, H3, P5, P40, P39), whose pointer increments `a_ptrs +=
BLOCK_SIZE_K * stride_ak` now fold to an immediate instead of a multiply by a
runtime register.  If the band does not move, the floor is not in the argument
list either, and the remaining candidate lever is the same one rounds 3 and 4
broke on: getting real work into the 12 padding rows without a non-affine row
base.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _bmm_chunk_fwd_kernel(
    a_ptr,
    b_ptr,
    out_ptr,
    cu_chunk_seqlens_ptr,
    # Every scalar below is constexpr.  Each one is a fixed integer for a given
    # shape, so it belongs to the specialised kernel body rather than to the
    # argument list; that is this round's whole change.  No run-time scalar is
    # left in the signature at all.
    chunk_size: tl.constexpr,
    K: tl.constexpr,
    ngroups: tl.constexpr,
    stride_a_seqlen: tl.constexpr,
    stride_a_head: tl.constexpr,
    stride_ak: tl.constexpr,
    stride_b_seqlen: tl.constexpr,
    stride_b_head: tl.constexpr,
    stride_bk: tl.constexpr,
    stride_out_chunk: tl.constexpr,
    stride_out_head: tl.constexpr,
    stride_outm: tl.constexpr,
    stride_outn: tl.constexpr,
    dot_dtype: tl.constexpr,
    USE_CUBE: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
):
    pid_ch = tl.program_id(axis=1)
    pid_c = pid_ch // ngroups
    pid_h = pid_ch - pid_c * ngroups

    num_pid_n = tl.cdiv(chunk_size, BLOCK_SIZE_N)
    pid_m = tl.program_id(axis=0) // num_pid_n
    pid_n = tl.program_id(axis=0) % num_pid_n

    chunk_seqlen_start = tl.load(cu_chunk_seqlens_ptr + pid_c)
    chunk_seqlen_end = tl.load(cu_chunk_seqlens_ptr + pid_c + 1)
    chunk_size_limit = chunk_seqlen_end - chunk_seqlen_start

    a_base = a_ptr + chunk_seqlen_start * stride_a_seqlen + pid_h * stride_a_head
    b_base = b_ptr + chunk_seqlen_start * stride_b_seqlen + pid_h * stride_b_head

    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_n = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)

    acc = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    row_ok = offs_m < chunk_size_limit
    col_ok = offs_n < chunk_size_limit

    if USE_CUBE:
        offs_k = tl.arange(0, BLOCK_SIZE_K)
        # Both factors are read with the contraction axis innermost, so a tile
        # row is one chunk token's contiguous run of K elements.
        a_ptrs = a_base + (offs_m[:, None] * stride_a_seqlen + offs_k[None, :] * stride_ak)
        b_ptrs = b_base + (offs_n[:, None] * stride_b_seqlen + offs_k[None, :] * stride_bk)

        # out[m, n] = sum_k a[m, k] * b[n, k], i.e. a_chunk @ b_chunk^T
        for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
            k_rem = K - k * BLOCK_SIZE_K
            k_ok = offs_k < k_rem
            a = tl.load(
                a_ptrs,
                mask=row_ok[:, None] & k_ok[None, :],
                other=0.0,
            ).to(dot_dtype)
            b = tl.load(
                b_ptrs,
                mask=col_ok[:, None] & k_ok[None, :],
                other=0.0,
            ).to(dot_dtype)
            acc = tl.dot(a, tl.permute(b, (1, 0)), acc)
            a_ptrs += BLOCK_SIZE_K * stride_ak
            b_ptrs += BLOCK_SIZE_K * stride_bk
    else:
        # K == 1: out[m, n] = a[m, 0] * b[n, 0], one rank-one update.
        a_col = tl.load(a_base + offs_m * stride_a_seqlen, mask=row_ok, other=0.0).to(
            tl.float32
        )
        b_col = tl.load(b_base + offs_n * stride_b_seqlen, mask=col_ok, other=0.0).to(
            tl.float32
        )
        acc += a_col[:, None] * b_col[None, :]

    out = acc.to(out_ptr.dtype.element_ty)

    out_base = out_ptr + pid_c * stride_out_chunk + pid_h * stride_out_head
    out_ptrs = out_base + (stride_outm * offs_m[:, None] + stride_outn * offs_n[None, :])
    tl.store(
        out_ptrs,
        out,
        mask=(offs_m[:, None] < chunk_size) & (offs_n[None, :] < chunk_size),
    )


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"]
    b = inputs["b"]
    cu_chunk_seqlens = inputs["cu_chunk_seqlens"]
    chunk_size = inputs["chunk_size"]

    seqlen, ngroups, K = a.shape
    nchunks = cu_chunk_seqlens.shape[0] - 1

    # Every element of this buffer is written by the launch below: the tile
    # grid covers [chunk_size, chunk_size] and the store mask keeps the
    # in-bounds part, so no pre-clearing pass is needed.
    out = torch.empty(
        (nchunks, ngroups, chunk_size, chunk_size), device=a.device, dtype=a.dtype
    )

    out_chunks, out_heads, tiles_m, tiles_n = out.shape
    block_m = min(max(triton.next_power_of_2(tiles_m), 16), 64)
    block_n = min(max(triton.next_power_of_2(tiles_n), 16), 64)
    use_cube = K > 1
    block_k = min(max(triton.next_power_of_2(K), 16), 128)

    dot_dtype = tl.bfloat16 if a.dtype == torch.bfloat16 else (
        tl.float16 if a.dtype == torch.float16 else tl.float32
    )

    grid = (
        triton.cdiv(tiles_m, block_m) * triton.cdiv(tiles_n, block_n),
        out_chunks * out_heads,
    )

    _bmm_chunk_fwd_kernel[grid](
        a,
        b,
        out,
        cu_chunk_seqlens,
        chunk_size=tiles_m,
        K=K,
        ngroups=ngroups,
        stride_a_seqlen=a.stride(0),
        stride_a_head=a.stride(1),
        stride_ak=a.stride(2),
        stride_b_seqlen=b.stride(0),
        stride_b_head=b.stride(1),
        stride_bk=b.stride(2),
        stride_out_chunk=out.stride(0),
        stride_out_head=out.stride(1),
        stride_outm=out.stride(2),
        stride_outn=out.stride(3),
        dot_dtype=dot_dtype,
        USE_CUBE=use_cube,
        BLOCK_SIZE_M=block_m,
        BLOCK_SIZE_N=block_n,
        BLOCK_SIZE_K=block_k,
        num_warps=4,
        num_stages=3,
    )

    return {"output": out}
