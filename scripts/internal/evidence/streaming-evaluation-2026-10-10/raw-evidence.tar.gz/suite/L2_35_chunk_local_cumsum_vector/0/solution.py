"""NPU migration of the per-chunk local cumulative sum (FLA vector op).

Semantics (see contract.md): within each segment defined by cu_seqlens,
the cumsum resets at every `chunk_size` (BT) boundary measured from the
segment start:

  out[..., t, :] = sum_{i = lo(t)}^{t} in[..., i, :]   when reverse == 0
  out[..., t, :] = sum_{i = t}^{hi(t)} in[..., i, :]   when reverse == 1
  lo(t) = (t // BT) * BT, hi(t) = min(lo(t) + BT, seg_len) - 1

Implemented with the upstream GPU algorithm itself: per (chunk row,
segment, head) a (BT x BS) tile is loaded (0-padded past the segment end
and past S via mask), multiplied by the (anti-)triangular 0/1 matrix
with tl.dot (fp32, allow_tf32=False so the sums are exact in fp32), and
stored back with the same padding mask.

Round 2 change vs round 1 (correctness fix): the triton-ascend backend
rejects grids with more than 65536 programs
(`RuntimeError: grid should be less than 65536!`). Round 1's grid
(cdiv(total_T, BT) x nseg x H) reaches 131584 on shape P4 and failed.
The row axis (program_id 0) is fully independent -- each program owns a
disjoint set of output rows -- so the launch is now split into a small
number of slices along that axis, each strictly under the limit. The
kernel body, numerics, masks and dtypes are byte-identical to round 1,
so the 46 previously passing shapes are unchanged.
"""
import torch
import triton
import triton.language as tl

# triton-ascend hard cap on programs per launch.
_MAX_PROGRAMS = 65535


@triton.jit
def _chunk_local_cumsum_vector_kernel(
    s, o, cu, r_lo,
    H: tl.constexpr, S: tl.constexpr,
    BT: tl.constexpr, BS: tl.constexpr,
    REV: tl.constexpr,
):
    i_i = tl.program_id(0) + r_lo  # chunk index (absolute, in packed token space)
    i_n = tl.program_id(1)  # segment
    i_h = tl.program_id(2)  # head
    bos = tl.load(cu + i_n).to(tl.int32)
    eos = tl.load(cu + i_n + 1).to(tl.int32)
    seg_len = eos - bos
    lo = i_i * BT
    if lo >= seg_len:
        return
    i_s = tl.arange(0, BS)
    i_t = tl.arange(0, BT)
    if REV:
        m_s = tl.where(i_t[:, None] <= i_t[None, :], 1.0, 0.0)
    else:
        m_s = tl.where(i_t[:, None] >= i_t[None, :], 1.0, 0.0)
    t = bos + lo + i_t
    m = (i_t < seg_len - lo)[:, None] & (i_s < S)[None, :]
    base = (bos + lo) * H + i_h
    p_s = s + base * S + i_s[None, :]
    p_s += (i_t * (H * S))[:, None]
    b_s = tl.load(p_s, mask=m, other=0.0).to(tl.float32)
    b_o = tl.dot(m_s, b_s, allow_tf32=False)
    p_o = o + base * S + i_s[None, :]
    p_o += (i_t * (H * S))[:, None]
    tl.store(p_o, b_o.to(o.dtype.element_ty), mask=m)


def npu_triton_impl(inputs: dict) -> dict:
    g = inputs["g"]
    cu = inputs["cu_seqlens"]
    bt = inputs["chunk_size"]
    rev = inputs["reverse"]
    total = g.shape[1]
    h = g.shape[2]
    s = g.shape[3]
    nseg = cu.shape[0] - 1
    bs = max(16, triton.next_power_of_2(s))
    o = torch.empty_like(g)
    rows = triton.cdiv(total, bt)
    per_other = nseg * h
    if rows * per_other <= _MAX_PROGRAMS:
        # single launch (identical to round 1)
        _chunk_local_cumsum_vector_kernel[(rows, nseg, h)](
            g, o, cu, 0, H=h, S=s, BT=bt, BS=bs, REV=rev, num_warps=4)
    else:
        # split the independent row axis into slices under the grid cap
        n_slices = (rows * per_other) // _MAX_PROGRAMS + 1
        base = rows // n_slices
        rem = rows % n_slices
        r_lo = 0
        for k in range(n_slices):
            r_hi = r_lo + base + (1 if k < rem else 0)
            _chunk_local_cumsum_vector_kernel[(r_hi - r_lo, nseg, h)](
                g, o, cu, r_lo, H=h, S=s, BT=bt, BS=bs, REV=rev, num_warps=4)
            r_lo = r_hi
    return {"output": o}
