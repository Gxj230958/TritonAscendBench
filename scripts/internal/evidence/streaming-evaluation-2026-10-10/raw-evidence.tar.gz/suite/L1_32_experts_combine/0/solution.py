"""Triton-Ascend port of the experts combine residual kernel (L1_32_experts_combine).

Math per output row r:
    moe_x = sum over the expert axis of moe_hidden_states[r, :, :]
    output[r, :] = (moe_x + mlp_hidden_states[r, :]) / sqrt(2)

The divisor is the literal 1.4142135623730951 from the reference kernel.
All arithmetic is kept in float32, matching the contract dtypes, and the
output has the same shape and dtype as mlp_hidden_states.

Round-2 change (single, geometry-only): each program now processes a tile of
ROWS_PER_PROG consecutive output rows instead of exactly one row. The grid is
ceil(bs / ROWS_PER_PROG). Everything else (masked expert-axis accumulation in
float32, the literal divisor, int64 row bases, the contiguous row-major
layouts) is unchanged from the round-1 candidate, which passed correctness on
all shapes.

Why this should lower device latency:
- The workload is dominated by small rows (hidden_dim as small as 1..384 and
  bs up to 2048). One program per row creates up to 2048 tiny programs, each
  issuing only combine_k + 2 short transfers. Grouping rows cuts the number
  of programs by up to 8x and lets the mlp load / output store become one
  contiguous ROWS_PER_PROG * hidden_dim burst.
- ROWS_PER_PROG is sized so one [ROWS_PER_PROG, BLOCK_SIZE] float32 tile is
  about 16 KB, keeping UB usage small for every shape (degenerates to a
  single-row tile for the largest hidden_dim, e.g. 4096).
- Rows beyond bs and columns beyond hidden_dim are masked exactly as before,
  so non-divisible batch sizes and non-power-of-two hidden_dim (e.g. 384)
  stay correct; the expert loop is still a static unroll, so no atomics and
  no order dependence are introduced (bit-identical reduction order to
  round 1).
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _experts_combine_kernel(
    out_ptr,
    moe_ptr,
    mlp_ptr,
    bs,
    hidden_dim: tl.constexpr,
    combine_k: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    ROWS_PER_PROG: tl.constexpr,
):
    pid = tl.program_id(0).to(tl.int64)

    rows = pid * ROWS_PER_PROG + tl.arange(0, ROWS_PER_PROG)
    cols = tl.arange(0, BLOCK_SIZE)
    mask = (rows < bs)[:, None] & (cols < hidden_dim)[None, :]

    # moe_x[r, :] = sum_{k < combine_k} moe_hidden_states[r, k, :]
    rows_i64 = rows.to(tl.int64)
    moe_base = rows_i64 * (hidden_dim * combine_k)
    acc = tl.zeros([ROWS_PER_PROG, BLOCK_SIZE], dtype=tl.float32)
    for k in tl.static_range(combine_k):
        acc += tl.load(
            moe_ptr + moe_base[:, None] + k * hidden_dim + cols[None, :],
            mask=mask,
            other=0.0,
        )

    mlp_base = rows_i64 * hidden_dim
    mlp_x = tl.load(
        mlp_ptr + mlp_base[:, None] + cols[None, :], mask=mask, other=0.0
    )

    combined = (acc + mlp_x) / 1.4142135623730951
    tl.store(
        out_ptr + mlp_base[:, None] + cols[None, :], combined, mask=mask
    )


def npu_triton_impl(inputs: dict) -> dict:
    moe_hidden_states = inputs["moe_hidden_states"].contiguous()
    mlp_hidden_states = inputs["mlp_hidden_states"].contiguous()

    if moe_hidden_states.dim() == 2:
        # Pre-combined layout (bs, hidden_dim): treat as one expert slice.
        moe_hidden_states = moe_hidden_states.unsqueeze(1)
    combine_k = moe_hidden_states.shape[1]

    bs, hidden_dim = mlp_hidden_states.shape
    out_hidden_states = torch.empty_like(mlp_hidden_states)

    BLOCK_SIZE = triton.next_power_of_2(hidden_dim)
    # Keep one tile near 16 KB (4096 float32 elements) regardless of width.
    ROWS_PER_PROG = max(1, min(8, 4096 // BLOCK_SIZE))

    grid = ((bs + ROWS_PER_PROG - 1) // ROWS_PER_PROG,)

    _experts_combine_kernel[grid](
        out_hidden_states,
        moe_hidden_states,
        mlp_hidden_states,
        bs,
        hidden_dim,
        combine_k,
        BLOCK_SIZE=BLOCK_SIZE,
        ROWS_PER_PROG=ROWS_PER_PROG,
    )

    return {"output": out_hidden_states}
