"""L2_34_solve_tril_16x16 -- triton-ascend candidate (round 5).

Per 16x16 time-chunk, per (batch, head): compute the inverse of
(I + S), where S is the strictly-lower-triangular part of the input
chunk (upper triangle and diagonal of the raw input are ignored).
All arithmetic is fp32.

Layout: input A / output are [B, T, H, 16]; a 16x16 block at time-chunk
i_t occupies rows [i_t*16, i_t*16+16) and all 16 columns. All indexing
uses the runtime strides of the tensor.

Algorithm (forward substitution), matching the upstream numerics:
  - Load the tile once, flip sign, zero the upper triangle:
    b_A = -S.  Row 0 of the inverse is then already exact.
  - For i = 1..15 (vectorized over the 16-wide tile rows), each
    iteration is register-only -- row i is extracted from the tile
    already in registers (b_A[i, :] is still the untouched -s_i
    because earlier iterations only wrote rows < i):
        b_a = b_A[i]                     (1-D, [16])
        b_a = b_a + b_a @ b_A            (b_a[k] == 0 for k >= i and
              rows >= i of b_A still hold -s_j, so the dot only
              accumulates already-computed rows j < i)
        b_A[i] = b_a
  - Add the identity, store fp32.

This is the round-3 implementation (verified 46/46 shapes) frozen
again for round 5 after the round-4 geometry change regressed
correctness.  The 15-step loop is unrolled with tl.static_range over
a constant range.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _solve_tril_16x16_kernel(
    A,
    Ai,
    stride_b,
    stride_t,
    stride_h,
    T,
):
    i_t = tl.program_id(0)
    i_h = tl.program_id(1)
    i_b = tl.program_id(2)

    o = tl.arange(0, 16)
    m_L = o[:, None] > o[None, :]
    m_I = o[:, None] == o[None, :]

    tile_row0 = i_t * 16
    row = tile_row0 + o[:, None]
    # tile validity (T % 16 == 0 makes this always true; guard kept)
    m_tile = (row < T) & (o[None, :] < 16)

    # element offsets derived from the runtime strides of the [B, T, H, 16]
    # layout (no assumption on H)
    base = i_b * stride_b + row * stride_t + i_h * stride_h + o[None, :]

    # single global load of the whole tile
    b_A = -tl.load(A + base, mask=m_tile, other=0.0).to(tl.float32)
    b_A = tl.where(m_L, b_A, 0.0)

    for i in tl.static_range(1, 16):
        # row i of the raw input tile, extracted from registers: [16]
        b_a = tl.sum(tl.where(o[:, None] == i, b_A, 0.0), 0)
        b_a = b_a + tl.sum(b_a[:, None] * b_A, 0)
        b_A = tl.where(o[:, None] == i, b_a, b_A)

    b_A = b_A + m_I

    tl.store(Ai + base, b_A.to(tl.float32), mask=m_tile)


def npu_triton_impl(inputs: dict) -> dict:
    A = inputs["A"]
    B, T, H, BT = A.shape
    assert BT == 16
    if not A.is_contiguous():
        A = A.contiguous()
    out = torch.empty_like(A)
    NT = T // 16
    _solve_tril_16x16_kernel[(NT, H, B)](
        A,
        out,
        A.stride(0),
        A.stride(1),
        A.stride(2),
        T,
        num_warps=1,
        num_stages=1,
    )
    return {"output": out}
