"""NPU Triton implementation of the varlen (packed) Mamba2 SSD intra-chunk state.

Output key `states`: [n_seq, nheads, headdim, dstate], fp32.

Intended meaning, per sequence span [cu[i], cu[i+1]) and per head h:

    states[i, h] = sum_t exp(dA[end-1] - dA[t]) * dt[t] * B[t, g] (outer) x[t, h]

with t over that sequence's tokens, `outer` the dstate x headdim outer product,
and g the group whose B the head reads (heads are grouped: nheads/ngroups heads
share one B group). An optional per-sequence `initial_states` seed enters the
same decay chain.

The sum is evaluated as a chunked scan, which is how the operation is defined.
Walking a sequence chunk by chunk: within a chunk the per-token weight is
exp(dA[chunk_end] - dA[t]) * dt[t], folded into B in fp32, rounded to the
operand dtype (bf16), then contracted against bf16 x on an fp32 accumulator.
Between chunks the accumulated state is decayed by
exp(dA[chunk_end] - dA[previous_chunk_end]) before the next chunk's intra-chunk
state is added. `dA_cumsum` is a running total along each sequence, so a
chunk-local cumsum cancels its own base inside a chunk weight and the chunk-end
differences telescope; a token's total coefficient comes out as
exp(dA[seq_end] - dA[t]) for any chunking, and a leading chunk measured against
a base of 0.0 matches the defined convention. Telescoping is why the chunk
length is a tiling knob rather than a semantic choice in exact arithmetic --
but the weight is rounded to the operand dtype per token, so the chunk
boundaries decide *where* rounding happens. Reproducing the rule below is what
keeps those rounding points aligned rather than merely close:

    chunk length = floor(minimum positive sequence length / 2), reduced until
    it divides every positive sequence length, floored at 1

so each sequence spans at least two chunks and no chunk straddles a boundary.
`_chunk_rule_kernel` evaluates that rule on device from cu_seqlens; the host
never inspects a sequence length.

Accumulation discipline: decay and dt scale in fp32, the weight is applied to B
before the operand-dtype cast (never to the product afterwards), exactly one
cast to bf16 per B tile, fp32 contraction accumulator from the first K tile to
the last, state cast to fp32 on load, result stored as fp32.

The recurrence is strictly sequential over chunks, so one program owns one
(sequence, head, output tile) block and walks its chunks in order: the carried
state stays in registers, no intermediate chunk-state buffer is materialised,
and sequence boundaries come from cu_seqlens inside the kernel, so packed
ragged layouts never bleed tokens from one sequence into the next.

Host side is index marshalling only: strides, the grid, an empty fp32 output,
and one int32 chunk length produced by a Triton kernel. Every multiply, decay,
contraction and store of the state runs in a Triton kernel.
"""

import torch
import triton
import triton.language as tl

BLOCK_SPAN = 32      # sequences inspected per rule pass
BLOCK_CAND = 256     # candidate chunk lengths inspected per rule pass
MAX_CHUNK = 2048     # largest chunk length the rule search can return


@triton.jit
def _chunk_rule_kernel(
    cu_seqlens_ptr,
    out_ptr,
    n_seq,
    BLOCK_S: tl.constexpr,
    BLOCK_C: tl.constexpr,
    MAX_C: tl.constexpr,
):
    """Largest chunk length that is at most floor(minimum positive sequence
    length / 2) and divides every positive sequence length. Stored as one
    int32. Zero-length spans are skipped, so they neither lower the minimum nor
    veto a candidate. Candidate lengths are swept in ascending blocks and the
    largest acceptable one is kept, which is the same descent the rule performs
    by hand."""
    shortest = 2000000000
    for off in range(0, n_seq, BLOCK_S):
        idx = off + tl.arange(0, BLOCK_S)
        live = idx < n_seq
        a = tl.load(cu_seqlens_ptr + idx, mask=live, other=0).to(tl.int32)
        b = tl.load(cu_seqlens_ptr + idx + 1, mask=live, other=0).to(tl.int32)
        positive = live & (b - a > 0)
        shortest = tl.minimum(
            shortest, tl.min(tl.where(positive, b - a, 2000000000))
        )
    cap = tl.maximum(tl.minimum(shortest // 2, MAX_C), 1)

    best = 0
    for base in range(0, MAX_C, BLOCK_C):
        cand = base + tl.arange(0, BLOCK_C) + 1
        not_divisible = tl.zeros((BLOCK_C,), dtype=tl.int32)
        for off in range(0, n_seq, BLOCK_S):
            idx = off + tl.arange(0, BLOCK_S)
            live = idx < n_seq
            a = tl.load(cu_seqlens_ptr + idx, mask=live, other=0).to(tl.int32)
            b = tl.load(cu_seqlens_ptr + idx + 1, mask=live, other=0).to(tl.int32)
            span = b - a
            positive = live & (span > 0)
            # span[:, None] % cand[None, :] vanishes exactly where the candidate
            # tiles that sequence without a remainder.
            remainder = tl.where(
                positive[:, None] & (span[:, None] % cand[None, :] != 0), 1, 0
            )
            not_divisible += tl.sum(remainder, axis=0)
        acceptable = (cand <= cap) & (not_divisible == 0)
        best = tl.maximum(best, tl.max(tl.where(acceptable, cand, 0)))
    tl.store(out_ptr, best)


@triton.jit
def _chunk_state_varlen_kernel(
    x_ptr,
    b_ptr,
    dt_ptr,
    dA_ptr,
    cu_seqlens_ptr,
    chunk_size_ptr,
    states_ptr,
    initstates_ptr,
    hdim,
    dstate,
    nheads_ngroups_ratio,
    stride_x_seqlen,
    stride_x_head,
    stride_x_hdim,
    stride_b_seqlen,
    stride_b_head,
    stride_b_dstate,
    stride_dt_seqlen,
    stride_dt_head,
    stride_dA_seqlen,
    stride_dA_head,
    stride_states_batch,
    stride_states_head,
    stride_states_hdim,
    stride_states_dstate,
    stride_init_batch,
    stride_init_head,
    stride_init_hdim,
    stride_init_dstate,
    HAS_INITSTATES: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
):
    pid_b = tl.program_id(axis=1).to(tl.int32)
    pid_h = tl.program_id(axis=2).to(tl.int32)
    num_pid_n = tl.cdiv(dstate, BLOCK_SIZE_N)
    pid_m = tl.program_id(axis=0) // num_pid_n
    pid_n = tl.program_id(axis=0) % num_pid_n

    start_idx = tl.load(cu_seqlens_ptr + pid_b).to(tl.int32)
    end_idx = tl.load(cu_seqlens_ptr + pid_b + 1).to(tl.int32)
    chunk_size = tl.load(chunk_size_ptr)
    span = tl.maximum(end_idx - start_idx, 0)

    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_n = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    m_ok = offs_m < hdim
    n_ok = offs_n < dstate
    tile_ok = m_ok[:, None] & n_ok[None, :]

    x_base = x_ptr + pid_h * stride_x_head + offs_m[:, None] * stride_x_hdim
    b_base = (
        b_ptr
        + (pid_h // nheads_ngroups_ratio) * stride_b_head
        + offs_n[None, :] * stride_b_dstate
    )
    dt_base = dt_ptr + pid_h * stride_dt_head
    dA_base = dA_ptr + pid_h * stride_dA_head

    # fp32 carry; also what an empty span writes, since both loops below stay
    # inert and the seed is suppressed for a zero-length sequence.
    carry = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    if HAS_INITSTATES:
        seeded = tl.load(
            initstates_ptr
            + pid_b * stride_init_batch
            + pid_h * stride_init_head
            + offs_m[:, None] * stride_init_hdim
            + offs_n[None, :] * stride_init_dstate,
            mask=tile_ok,
            other=0.0,
        ).to(tl.float32)
        carry = tl.where(span > 0, seeded, 0.0)

    nchunks = tl.cdiv(span, chunk_size)
    dA_prev = 0.0
    for c in range(0, nchunks):
        cs = start_idx + c * chunk_size
        chunk_len = tl.minimum(chunk_size, span - c * chunk_size)
        ce = cs + chunk_len
        # Chunk-end sample of the running total: the reference point for this
        # chunk's weights now, and the next iteration's decay partner.
        dA_end = tl.load(dA_base + (ce - 1) * stride_dA_seqlen).to(tl.float32)

        intra = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
        for k in range(0, chunk_len, BLOCK_SIZE_K):
            tok = cs + k + offs_k
            tok_ok = tok < ce
            x = tl.load(
                x_base + tok[None, :] * stride_x_seqlen,
                mask=m_ok[:, None] & tok_ok[None, :],
                other=0.0,
            )
            b = tl.load(
                b_base + tok[:, None] * stride_b_seqlen,
                mask=tok_ok[:, None] & n_ok[None, :],
                other=0.0,
            ).to(tl.float32)
            dA_k = tl.load(dA_base + tok * stride_dA_seqlen, mask=tok_ok, other=0.0)
            dt_k = tl.load(dt_base + tok * stride_dt_seqlen, mask=tok_ok, other=0.0)
            scale = tl.where(
                tok_ok,
                tl.exp(dA_end - dA_k.to(tl.float32)) * dt_k.to(tl.float32),
                0.0,
            )
            b = b * scale[:, None]
            intra = tl.dot(x, b.to(x_ptr.dtype.element_ty), acc=intra)
        carry = carry * tl.exp(dA_end - dA_prev) + intra
        dA_prev = dA_end

    states_ptrs = (
        states_ptr
        + pid_b * stride_states_batch
        + pid_h * stride_states_head
        + offs_m[:, None] * stride_states_hdim
        + offs_n[None, :] * stride_states_dstate
    )
    tl.store(states_ptrs, carry.to(states_ptr.dtype.element_ty), mask=tile_ok)


def _block_for(extent, cap):
    """Smallest power-of-two tile, never below the cube's 16 lane minimum."""
    block = 16
    while block < extent and block < cap:
        block *= 2
    return block


def npu_triton_impl(inputs: dict) -> dict:
    Bt = inputs["B"]                     # [total_seqlen, ngroups, dstate]
    x = inputs["x"]                      # [total_seqlen, nheads, headdim]
    dt = inputs["dt"]                    # [total_seqlen, nheads]
    dA_cumsum = inputs["dA_cumsum"]      # [total_seqlen, nheads]
    cu = inputs["cu_seqlens"].contiguous()

    # The seed is optional. Reading the key is guarded so that an absent key and
    # an explicitly absent seed take the identical path, and the pointer below
    # is always a real tensor.
    has_seed = False
    init_states = x
    try:
        seeded = inputs["initial_states"].contiguous()
        init_states = seeded
        has_seed = True
    except (KeyError, AttributeError, TypeError):
        has_seed = False

    nheads = x.shape[1]
    headdim = x.shape[2]
    ngroups = Bt.shape[1]
    dstate = Bt.shape[2]
    n_seq = cu.shape[0] - 1
    assert nheads % ngroups == 0
    ratio = max(nheads // ngroups, 1)

    states = torch.empty(
        (n_seq, nheads, headdim, dstate),
        dtype=torch.float32,
        device=x.device,
    )
    chunk_size = torch.empty(1, dtype=torch.int32, device=x.device)
    _chunk_rule_kernel[(1,)](
        cu,
        chunk_size,
        n_seq,
        BLOCK_S=BLOCK_SPAN,
        BLOCK_C=BLOCK_CAND,
        MAX_C=MAX_CHUNK,
    )

    block_m = _block_for(headdim, 64)
    block_n = _block_for(dstate, 64)
    grid = (
        triton.cdiv(headdim, block_m) * triton.cdiv(dstate, block_n),
        n_seq,
        nheads,
    )

    if not has_seed:
        _chunk_state_varlen_kernel[grid](
            x,
            Bt,
            dt,
            dA_cumsum,
            cu,
            chunk_size,
            states,
            states,
            headdim,
            dstate,
            ratio,
            x.stride(0),
            x.stride(1),
            x.stride(2),
            Bt.stride(0),
            Bt.stride(1),
            Bt.stride(2),
            dt.stride(0),
            dt.stride(1),
            dA_cumsum.stride(0),
            dA_cumsum.stride(1),
            states.stride(0),
            states.stride(1),
            states.stride(2),
            states.stride(3),
            0,
            0,
            0,
            0,
            HAS_INITSTATES=False,
            BLOCK_SIZE_M=block_m,
            BLOCK_SIZE_N=block_n,
            BLOCK_SIZE_K=32,
        )
    else:
        _chunk_state_varlen_kernel[grid](
            x,
            Bt,
            dt,
            dA_cumsum,
            cu,
            chunk_size,
            states,
            init_states,
            headdim,
            dstate,
            ratio,
            x.stride(0),
            x.stride(1),
            x.stride(2),
            Bt.stride(0),
            Bt.stride(1),
            Bt.stride(2),
            dt.stride(0),
            dt.stride(1),
            dA_cumsum.stride(0),
            dA_cumsum.stride(1),
            states.stride(0),
            states.stride(1),
            states.stride(2),
            states.stride(3),
            init_states.stride(0),
            init_states.stride(1),
            init_states.stride(2),
            init_states.stride(3),
            HAS_INITSTATES=True,
            BLOCK_SIZE_M=block_m,
            BLOCK_SIZE_N=block_n,
            BLOCK_SIZE_K=32,
        )

    return {"states": states}
