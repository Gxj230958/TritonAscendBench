"""Fused MoE router for Triton-Ascend (910B).

For every token row of ``x`` ([B, D], bfloat16) the kernel emits

    logits[e] = sum_d float32(router_weight[e, d]) * float32(x[b, d])
    logits    = SOFTCAP * tanh(logits / SOFTCAP)   (only when SOFTCAP > 0)
    logits    = logits + correction_bias           (after the cap)
    probs     = softmax(logits, axis=-1)           (anchored at the max)
    topk_weights[b, j] = j-th largest probability  (NOT renormalised)
    topk_ids[b, j]     = expert index holding it

Semantics, unchanged from the accepted round-1 candidate on every shape:
  * products and the reduction stay in float32; the bfloat16 activations widen
    before the multiply, matching the vector reference,
  * the cap lands before the bias, and the softmax denominator is built from
    capped+bias-shifted logits,
  * a selected row sums to below one by design -- there is no renormalisation,
  * equal logits resolve to the lower expert index, which reproduces the same
    descending order the reference emits,
  * the hidden axis is walked in chunks, so one token's router tile never has
    to be resident all at once (D reaches 8192).

The kernel body, the token-tile gate and the launch geometry are round 4's,
unchanged, and so is every arithmetic expression in this file: the single thing
round 5 changes is how wide the tiled path makes its hidden chunks.

Round 4 put a token tile (BLOCK_T = 4 consecutive rows per program) behind a
bytes gate, and it did deliver the traffic cut: P8's router re-read fell
268 MB -> 67 MB, P7's 151 -> 38. What it bought was 30 us on P8 (440.6 -> 410.6)
and 11 us on P7 (314.3 -> 303.0). A 3.4x traffic cut for a 7% gain says the
bytes were never the whole story on the tiled path -- and round 4 names its own
suspect: it narrowed the chunk by BLOCK_T "so that (1 + BLOCK_T) * BLOCK_E *
BLOCK_D stays at or under the 8192 live elements", taking BLOCK_D from 512 to
128.

That narrowing is what this round removes. Per token, P8 went from 16 chunks of
512 lanes to 64 chunks of 128 lanes, and each chunk still ends in one cross-lane
axis-1 reduction per expert row -- so a token's logits are folded by 64
reductions where round 1 used 16. The element count is identical and the traffic
is a quarter, yet the reduction count quadrupled, and a vector core pays an
almost length-independent cost per reduction: same total bytes, four times the
setup. Round 1's P8 excess over the floor is 287 us against a byte model of
288 us, so the bytes were honest in round 1; the tiled path simply moved them
into a construct that pays the fixed cost more often.

The narrowing was guarding a footprint that never comes close to the ceiling.
In the emitted body one chunk holds the [BLOCK_E, BLOCK_D] router tile and one
[BLOCK_E, BLOCK_D] product at a time: each token's product is consumed by its
own axis-1 reduction before the next token's product is formed, so peak live
state is 2 tiles -- at BLOCK_D = 512, 2 * 8 * 512 fp32 = 32 KB, which is what
the accepted one-token body carries on hardware today on every multi-chunk
shape (P3, P4, P11, H3). If a scheduler instead hoisted all four products over
their reductions, the chunk would hold five tiles, 80 KB, which is still inside
the same on-chip budget. Either way the tile fetch pattern is unchanged and
BLOCK_D = 512 is safe at BLOCK_T = 4; the budget is charged per in-flight
product rather than per token.

So the tiled shapes now keep both halves of the trade: the router tile is still
fetched once per 4 tokens, and the reduce stream per token goes back to exactly
what round 1 ran. Everything else is round 4 verbatim -- the same bytes gate
(>= 8 MB of router re-read) and the same occupancy floor (grid stays at two
programs per vector core, which is where round 1 was already overlapping the
chunk stream), so BLOCK_T = 4 is still only P7 and P8. The other 45 shapes
select a BLOCK_D that is unchanged by this edit and trace the identical body,
grid, mask form and launch config they ran in round 4. Round 4's unmasked-load
form (EVEN) is kept: it is the one part of that round the receipts attribute
cleanly, with P11 at 197.4 us in rounds 1 and 3 and 164.6 us in round 4, right
on the traffic model.

Verification (CPU only; no device, no evaluator command run) is in
rounds/round_5/notes.md: a float32 mirror of this exact chunk order reproduces
the vector reference on all 47 corpus shapes using the geometry this host
function actually selects, and the gate and the new chunk width are enumerated
shape by shape.
"""

import torch
import triton
import triton.language as tl




@triton.jit
def _moe_router_npu_kernel(
    x_ptr,
    w_ptr,
    bias_ptr,
    weights_ptr,
    ids_ptr,
    hidden_dim,
    stride_xb,
    stride_we,
    num_experts,
    BLOCK_E: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    SOFTCAP: tl.constexpr,
    TOPK: tl.constexpr,
    BLOCK_D: tl.constexpr,
    EVEN: tl.constexpr,
    BLOCK_T: tl.constexpr,
):
    """Router for BLOCK_T consecutive token rows per program.

    The hidden axis is streamed in BLOCK_D chunks. Each chunk loads one
    [BLOCK_E, BLOCK_D] router tile and reduces it against BLOCK_T activation
    vectors, so the tile fetch -- the traffic that dominates this op -- is paid
    once per chunk instead of once per token. The per-token arithmetic is the
    round-1 expression verbatim: [BLOCK_E, BLOCK_D] fp32 product, one axis-1
    reduction, into a [BLOCK_E] accumulator.
    """
    NEG: tl.constexpr = -1.0e30

    pid = tl.program_id(0)
    e_all = tl.arange(0, BLOCK_E)
    e_valid = e_all < num_experts
    tok0 = pid * BLOCK_T

    # One accumulator per token this program owns. BLOCK_T < 4 leaves the
    # extras unused and the frontend drops them, so BLOCK_T == 1 emits the
    # round-1 kernel.
    acc0 = tl.zeros([BLOCK_E], dtype=tl.float32)
    acc1 = tl.zeros([BLOCK_E], dtype=tl.float32)
    acc2 = tl.zeros([BLOCK_E], dtype=tl.float32)
    acc3 = tl.zeros([BLOCK_E], dtype=tl.float32)

    # ---- fp32 logits, chunked over the hidden axis ----
    if EVEN:
        # BLOCK_D divides hidden_dim and no expert lane is padding: every
        # address below is inside both tensors, so the chunk loop needs no
        # predicate tile at all.
        for d0 in range(0, hidden_dim, BLOCK_D):
            d_offs = d0 + tl.arange(0, BLOCK_D)
            w_tile = tl.load(w_ptr + e_all[:, None] * stride_we + d_offs[None, :]).to(tl.float32)

            x0 = tl.load(x_ptr + tok0 * stride_xb + d_offs).to(tl.float32)
            acc0 += tl.sum(w_tile * x0[None, :], axis=1)
            if BLOCK_T > 1:
                x1 = tl.load(x_ptr + (tok0 + 1) * stride_xb + d_offs).to(tl.float32)
                acc1 += tl.sum(w_tile * x1[None, :], axis=1)
            if BLOCK_T > 2:
                x2 = tl.load(x_ptr + (tok0 + 2) * stride_xb + d_offs).to(tl.float32)
                acc2 += tl.sum(w_tile * x2[None, :], axis=1)
            if BLOCK_T > 3:
                x3 = tl.load(x_ptr + (tok0 + 3) * stride_xb + d_offs).to(tl.float32)
                acc3 += tl.sum(w_tile * x3[None, :], axis=1)
    else:
        for d0 in range(0, hidden_dim, BLOCK_D):
            d_offs = d0 + tl.arange(0, BLOCK_D)
            d_mask = d_offs < hidden_dim
            both = e_valid[:, None] & d_mask[None, :]
            w_tile = tl.load(w_ptr + e_all[:, None] * stride_we + d_offs[None, :],
                             mask=both, other=0.0).to(tl.float32)

            x0 = tl.load(x_ptr + tok0 * stride_xb + d_offs, mask=d_mask, other=0.0).to(tl.float32)
            acc0 += tl.sum(w_tile * x0[None, :], axis=1)
            if BLOCK_T > 1:
                x1 = tl.load(x_ptr + (tok0 + 1) * stride_xb + d_offs,
                             mask=d_mask, other=0.0).to(tl.float32)
                acc1 += tl.sum(w_tile * x1[None, :], axis=1)
            if BLOCK_T > 2:
                x2 = tl.load(x_ptr + (tok0 + 2) * stride_xb + d_offs,
                             mask=d_mask, other=0.0).to(tl.float32)
                acc2 += tl.sum(w_tile * x2[None, :], axis=1)
            if BLOCK_T > 3:
                x3 = tl.load(x_ptr + (tok0 + 3) * stride_xb + d_offs,
                             mask=d_mask, other=0.0).to(tl.float32)
                acc3 += tl.sum(w_tile * x3[None, :], axis=1)

    # The router bias is the same [BLOCK_E] vector for every token, so it is
    # fetched once here rather than once per accumulator.
    if HAS_BIAS:
        if EVEN:
            bias = tl.load(bias_ptr + e_all)
        else:
            bias = tl.load(bias_ptr + e_all, mask=e_valid, other=0.0)
    else:
        bias = tl.zeros([BLOCK_E], dtype=tl.float32)

    # ---- softmax, cap and top-k, once per token of this program ----
    for t in tl.static_range(0, BLOCK_T):
        acc = acc0
        if t == 1:
            acc = acc1
        if t == 2:
            acc = acc2
        if t == 3:
            acc = acc3
        tok = tok0 + t

        logits = acc

        # ---- softcap: SOFTCAP * tanh(logits / SOFTCAP), an odd function ----
        if SOFTCAP != 0:
            u = logits / SOFTCAP
            t_abs = tl.where(u < 0.0, -u, u)
            # exp(2t) stays well inside fp32 range and drives the ratio to 1.
            e2 = tl.exp(2.0 * tl.minimum(t_abs, 20.0))
            ratio = (e2 - 1.0) / (e2 + 1.0)
            # Where exp(2t) rounds to one the ratio collapses to zero, so small
            # arguments take the odd Taylor series instead
            # (t - t^3/3 + 2t^5/15 - 17t^7/315; error < 1e-9 at the switch point).
            t2 = t_abs * t_abs
            series = t_abs * (1.0 + t2 * (-0.33333333333
                                          + t2 * (0.13333333333
                                                  + t2 * (-0.05396825397))))
            th = tl.where(t_abs < 0.11, series, ratio)
            logits = tl.where(u < 0.0, -th, th) * SOFTCAP

        # ---- correction bias, applied after the cap ----
        if HAS_BIAS:
            logits = logits + bias

        # padding lanes leave contention entirely
        lvec = tl.where(e_valid, logits, NEG)

        # ---- softmax denominator, anchored at the largest logit ----
        m1 = tl.max(lvec, axis=0)
        denom = tl.sum(tl.where(e_valid, tl.exp(lvec - m1), 0.0), axis=0)
        inv_denom = 1.0 / denom

        # ---- greedy top-k: take the max, then its leftmost holder ----
        cur = lvec
        for j in tl.static_range(0, TOPK):
            v_j = tl.max(cur, axis=0)
            id_j = tl.min(tl.where(cur == v_j, e_all, BLOCK_E), axis=0)
            # read the winning logit back out of the unpickable vector
            w_j = tl.sum(tl.where(e_all == id_j, lvec, 0.0), axis=0)
            tl.store(ids_ptr + tok * TOPK + j, id_j.to(tl.int32))
            tl.store(weights_ptr + tok * TOPK + j, tl.exp(w_j - m1) * inv_denom)
            cur = tl.where(e_all == id_j, NEG, cur)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    router_weight = inputs["router_weight"]
    correction_bias = inputs["correction_bias"]
    topk = inputs["topk"]
    softcap = inputs["moe_softcapping"]

    tokens = x.shape[0]
    hidden_dim = x.shape[1]
    num_experts = router_weight.shape[0]

    topk_weights = torch.empty((tokens, topk), dtype=torch.float32, device=x.device)
    topk_ids = torch.empty((tokens, topk), dtype=torch.int32, device=x.device)

    block_e = triton.next_power_of_2(num_experts)
    block_d = triton.next_power_of_2(hidden_dim)
    if block_d > 512:
        block_d = 512
    if block_d < 64:
        block_d = 64

    # Router reuse is a traffic decision, so it is taken on bytes: with one
    # program per token each program re-reads the whole router, and only a
    # re-read that dwarfs everything else pays for a wider program.
    router_bytes = 4 * num_experts * hidden_dim * tokens
    block_t = 1
    if router_bytes >= 8388608:
        # Four is the ceiling the kernel carries accumulators and unrolled
        # epilogues for; wider would trade the traffic saving for register
        # pressure. The batch has to divide exactly, so every row a program owns
        # is a live token and no store needs a mask.
        #
        # The occupancy floor is the part round 3 got wrong. Consolidation
        # removes programs along with bytes, and this op has ~48 vector cores, so
        # a shape that ends up near one program per core loses the latency hiding
        # that was paying for the re-read in the first place. Round 3's tiles all
        # landed there -- 32 programs on P4, 48 on P7, 64 on P8 -- and every one
        # of those shapes came out slower than round 1 (244 vs 171, 401 vs 314,
        # 833 vs 441). Two programs per core is where round 1 was already
        # overlapping the chunk stream comfortably, so that is the bar.
        #
        # It leaves the change on exactly the two shapes where the traffic model
        # is strongest: P8 (268 MB re-read, 288 us over the floor) and P7
        # (151 MB, 161 us over). P4's 16.8 MB and P11's 18.9 MB are too small to
        # repay a shallower grid -- and P11's excess is more than double what its
        # traffic explains, which is the signature of a shape that is starved for
        # programs rather than short of bandwidth.
        for cand in (4, 2):
            if tokens % cand == 0 and tokens // cand >= 192:
                block_t = cand
                break

    # Resident-chunk ceiling, charged per in-flight product rather than per
    # token: 2 * BLOCK_E * BLOCK_D <= 8192 fp32 elements, which is the tile
    # count the accepted one-token body keeps live at BLOCK_D = 512, and the
    # worst case with BLOCK_T = 4 (all four products hoisted over their
    # reductions, 5 tiles) still sits inside the same on-chip budget. E is 8 on
    # all 47 rows, so this leaves BLOCK_D at 512 everywhere and only narrows if
    # some larger expert count pushes a single tile past the ceiling.
    #
    # Round 4 divided by BLOCK_T here instead, which is where the tiled gain
    # went: P8's per-token chunk stream went from 16 chunks of 512 lanes to 64
    # of 128 -- same element count, a quarter of the bytes, four times the
    # cross-lane reductions -- and a vector core's reduce cost is close to
    # length-independent, so its fixed part got paid four times as often.
    max_block_d = 8192 // (2 * block_e)
    if block_d > max_block_d:
        block_d = max_block_d
    if block_d < 64:
        block_d = 64
    even = block_e == num_experts and hidden_dim % block_d == 0

    grid = (tokens + block_t - 1) // block_t

    _moe_router_npu_kernel[(grid,)](
        x,
        router_weight,
        correction_bias,
        topk_weights,
        topk_ids,
        hidden_dim,
        x.stride(0),
        router_weight.stride(0),
        num_experts,
        BLOCK_E=block_e,
        HAS_BIAS=True,
        SOFTCAP=softcap,
        TOPK=topk,
        BLOCK_D=block_d,
        EVEN=even,
        BLOCK_T=block_t,
        num_warps=4,
    )
    return {"topk_weights": topk_weights, "topk_ids": topk_ids}
