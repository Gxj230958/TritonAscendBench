"""Fused MoE router for Triton-Ascend (910B).

For every token row of ``x`` ([B, D], bfloat16) the kernel emits

    logits[e] = sum_d float32(router_weight[e, d]) * float32(x[b, d])
    logits    = SOFTCAP * tanh(logits / SOFTCAP)   (only when SOFTCAP > 0)
    logits    = logits + correction_bias           (after the cap)
    probs     = softmax(logits, axis=-1)           (anchored at the max)
    topk_weights[b, j] = j-th largest probability  (NOT renormalised)
    topk_ids[b, j]     = expert index holding it

Details that carry the tolerance:
  * products and the reduction stay in float32; the bfloat16 activations
    widen before the multiply, mirroring the vector reference,
  * the cap lands before the bias, and the softmax denominator is built
    from capped+bias-shifted logits,
  * a selected row sums to below one by design -- there is no
    renormalisation step,
  * equal logits resolve to the lower expert index, which reproduces the
    same descending order the reference emits,
  * the hidden axis is walked in masked chunks so the router tile for one
    token never has to be resident all at once (D reaches 8192).

Launch shape: one program per token. Each program streams a [BLOCK_E,
BLOCK_D] router tile against a [BLOCK_D] activation slice, then finishes
the softmax and the greedy top-k epilogue on a BLOCK_E-wide logit vector
with sum / max / min reductions only.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _moe_router_npu_kernel(
    x_ptr,
    w_ptr,
    bias_ptr,
    weights_ptr,
    ids_ptr,
    hidden_dim,
    stride_xb,
    stride_we,
    num_experts,
    BLOCK_E: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    SOFTCAP: tl.constexpr,
    TOPK: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    NEG: tl.constexpr = -1.0e30

    pid = tl.program_id(0)
    e_all = tl.arange(0, BLOCK_E)
    e_valid = e_all < num_experts

    # ---- fp32 logits, chunked over the hidden axis ----
    acc = tl.zeros([BLOCK_E], dtype=tl.float32)
    for d0 in range(0, hidden_dim, BLOCK_D):
        d_offs = d0 + tl.arange(0, BLOCK_D)
        d_mask = d_offs < hidden_dim
        both = e_valid[:, None] & d_mask[None, :]
        w_tile = tl.load(w_ptr + e_all[:, None] * stride_we + d_offs[None, :],
                         mask=both, other=0.0).to(tl.float32)
        x_tile = tl.load(x_ptr + pid * stride_xb + d_offs,
                         mask=d_mask, other=0.0).to(tl.float32)
        acc += tl.sum(w_tile * x_tile[None, :], axis=1)

    logits = acc

    # ---- softcap: SOFTCAP * tanh(logits / SOFTCAP), an odd function ----
    if SOFTCAP != 0:
        u = logits / SOFTCAP
        t = tl.where(u < 0.0, -u, u)
        # exp(2t) stays well inside fp32 range and drives the ratio to 1.
        e2 = tl.exp(2.0 * tl.minimum(t, 20.0))
        ratio = (e2 - 1.0) / (e2 + 1.0)
        # Where exp(2t) rounds to one the ratio collapses to zero, so small
        # arguments take the odd Taylor series instead
        # (t - t^3/3 + 2t^5/15 - 17t^7/315; error < 1e-9 at the switch point).
        t2 = t * t
        series = t * (1.0 + t2 * (-0.33333333333
                                  + t2 * (0.13333333333
                                          + t2 * (-0.05396825397))))
        th = tl.where(t < 0.11, series, ratio)
        logits = tl.where(u < 0.0, -th, th) * SOFTCAP

    # ---- correction bias, applied after the cap ----
    if HAS_BIAS:
        logits = logits + tl.load(bias_ptr + e_all, mask=e_valid, other=0.0)

    # padding lanes leave contention entirely
    lvec = tl.where(e_valid, logits, NEG)

    # ---- softmax denominator, anchored at the largest logit ----
    m1 = tl.max(lvec, axis=0)
    denom = tl.sum(tl.where(e_valid, tl.exp(lvec - m1), 0.0), axis=0)
    inv_denom = 1.0 / denom

    # ---- greedy top-k: take the max, then its leftmost holder ----
    cur = lvec
    for j in tl.static_range(0, TOPK):
        v_j = tl.max(cur, axis=0)
        id_j = tl.min(tl.where(cur == v_j, e_all, BLOCK_E), axis=0)
        # read the winning logit back out of the unpickable vector
        w_j = tl.sum(tl.where(e_all == id_j, lvec, 0.0), axis=0)
        tl.store(ids_ptr + pid * TOPK + j, id_j.to(tl.int32))
        tl.store(weights_ptr + pid * TOPK + j, tl.exp(w_j - m1) * inv_denom)
        cur = tl.where(e_all == id_j, NEG, cur)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    router_weight = inputs["router_weight"]
    correction_bias = inputs["correction_bias"]
    topk = inputs["topk"]
    softcap = inputs["moe_softcapping"]

    tokens = x.shape[0]
    hidden_dim = x.shape[1]
    num_experts = router_weight.shape[0]

    topk_weights = torch.empty((tokens, topk), dtype=torch.float32, device=x.device)
    topk_ids = torch.empty((tokens, topk), dtype=torch.int32, device=x.device)

    block_e = triton.next_power_of_2(num_experts)
    block_d = triton.next_power_of_2(hidden_dim)
    if block_d > 512:
        block_d = 512
    if block_d < 64:
        block_d = 64

    _moe_router_npu_kernel[(tokens,)](
        x,
        router_weight,
        correction_bias,
        topk_weights,
        topk_ids,
        hidden_dim,
        x.stride(0),
        router_weight.stride(0),
        num_experts,
        BLOCK_E=block_e,
        HAS_BIAS=True,
        SOFTCAP=softcap,
        TOPK=topk,
        BLOCK_D=block_d,
        num_warps=4,
    )
    return {"topk_weights": topk_weights, "topk_ids": topk_ids}
