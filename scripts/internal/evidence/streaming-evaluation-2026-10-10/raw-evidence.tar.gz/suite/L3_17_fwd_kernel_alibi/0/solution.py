"""Triton-Ascend migration of the causal SDPA + ALiBi prefill kernel.

Semantics implemented (single sequence, no prefix context):

    out[h, i, :] = sum_j softmax_j( scale * (q_i . k_j) - slope_h * (i - j) ) * v_j
    for j <= i, with q/k/v of shape [H, L, D] (fp16) and alibi_slopes [H] (fp32).

Migration notes
 * The upstream device routine also carries a paged KV-cache path (block
   table, 5D k_cache / 4D v_cache, per-block location indirection). That path
   is only live when the prefix context length is non zero. Here the context
   length is 0, so the prefix scan never runs and none of those operands are
   ever dereferenced; only the causal query-against-key scan is reachable. The
   reachable math is kept instruction for instruction.
 * The upstream host side reshaped [H, L, D] into token-major [L, H, D] and
   reshaped the result back. Both reshapes are pure data movement, so the 3D
   strides of the head-major tensors are handed to the kernel directly. That
   keeps the whole call at a single device launch.
 * Load-bearing numeric details preserved: fp32 online-softmax accumulators
   (m_i, l_i, acc), fp32 result of the QK dot, the ALiBi bias applied after
   the scale multiply, -inf masking of future keys and out-of-range rows, and
   the fp16 cast of p immediately before the P @ V dot. The final divide by
   l_i needs no epsilon because every causal row keeps at least its diagonal
   key, so l_i >= 1.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _fwd_kernel_alibi_npu(
    Q,
    K,
    V,
    Out,
    Alibi_slopes,
    sm_scale,
    Seq_Len,
    stride_qh,
    stride_qm,
    stride_qd,
    stride_kh,
    stride_kn,
    stride_kd,
    stride_vh,
    stride_vn,
    stride_vd,
    stride_oh,
    stride_om,
    stride_od,
    num_queries_per_kv: tl.constexpr,
    IN_PRECISION: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_DMODEL: tl.constexpr,
    BLOCK_DMODEL_PADDED: tl.constexpr,
    BLOCK_N: tl.constexpr,
    SKIP_DECODE: tl.constexpr,
):
    cur_head = tl.program_id(0)
    start_m = tl.program_id(1)
    cur_kv_head = cur_head // num_queries_per_kv

    # The reachable math keeps a zero-length prefix, so the query length is the
    # full sequence length and the ALiBi key origin is 0.
    cur_batch_seq_len = Seq_Len
    cur_batch_ctx_len = 0
    seq_q_len = cur_batch_seq_len - cur_batch_ctx_len

    block_start_loc = BLOCK_M * start_m

    offs_n = tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_DMODEL_PADDED)
    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)

    dim_mask = tl.where(offs_d < BLOCK_DMODEL, 1, 0).to(tl.int1)

    off_q = (
        cur_head * stride_qh
        + offs_m[:, None] * stride_qm
        + offs_d[None, :] * stride_qd
    )
    row_mask = offs_m[:, None] < seq_q_len
    q = tl.load(Q + off_q, mask=dim_mask[None, :] & row_mask, other=0.0)

    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32)
    acc = tl.zeros([BLOCK_M, BLOCK_DMODEL_PADDED], dtype=tl.float32)

    alibi_slope = tl.load(Alibi_slopes + cur_head)
    alibi_start_q = tl.arange(0, BLOCK_M) + block_start_loc + cur_batch_ctx_len

    k_ptrs = K + cur_kv_head * stride_kh + offs_d[:, None] * stride_kd
    v_ptrs = (
        V
        + cur_kv_head * stride_vh
        + offs_n[:, None] * stride_vn
        + offs_d[None, :] * stride_vd
    )

    block_mask = tl.where(block_start_loc < seq_q_len, 1, 0)

    for start_n in range(0, block_mask * (start_m + 1) * BLOCK_M, BLOCK_N):
        start_n = tl.multiple_of(start_n, BLOCK_N)
        # start_n is also the running ALiBi key origin once the context
        # length is 0, so the key positions are start_n + offs_n.
        key_pos = start_n + offs_n

        k = tl.load(
            k_ptrs + key_pos[None, :] * stride_kn,
            mask=dim_mask[:, None] & (key_pos[None, :] < seq_q_len),
            other=0.0,
        )

        qk = tl.dot(q, k)
        qk *= sm_scale
        qk = tl.where(offs_m[:, None] >= key_pos[None, :], qk, float("-inf"))

        alibi = (key_pos[None, :] - alibi_start_q[:, None]) * alibi_slope
        alibi = tl.where(
            (alibi <= 0) & (alibi_start_q[:, None] < cur_batch_seq_len),
            alibi,
            float("-inf"),
        )
        qk += alibi

        m_ij = tl.max(qk, 1)
        m_i_new = tl.maximum(m_i, m_ij)
        p = tl.exp(qk - m_i_new[:, None])
        l_ij = tl.sum(p, 1)
        alpha = tl.exp(m_i - m_i_new)
        l_i_new = alpha * l_i + l_ij
        acc = acc * alpha[:, None]

        v = tl.load(
            v_ptrs + start_n * stride_vn,
            mask=dim_mask[None, :] & (key_pos[:, None] < seq_q_len),
            other=0.0,
        )
        p = p.to(v.dtype)
        acc = tl.dot(p, v, acc=acc)

        l_i = l_i_new
        m_i = m_i_new

    acc = acc / l_i[:, None]

    off_o = (
        cur_head * stride_oh
        + offs_m[:, None] * stride_om
        + offs_d[None, :] * stride_od
    )
    tl.store(Out + off_o, acc.to(Out.dtype.element_ty),
             mask=dim_mask[None, :] & row_mask)


def _pow2(x):
    return triton.next_power_of_2(x if x > 1 else 1)


def _pick_tiles(D, L):
    """Tiling choice only; it has no effect on the computed values."""
    block_d = max(16, _pow2(D))

    if L <= 16:
        block_m = block_n = 16
    elif L <= 32:
        block_m = block_n = 32
    else:
        block_m = block_n = 64

    # Keep the fp32 accumulator tile within the on-chip budget for wide heads.
    if block_d >= 192:
        block_m = block_n = 32

    return block_m, block_n, block_d, 4, 2


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    alibi_slopes = inputs["alibi_slopes"]
    scale = inputs["scale"]

    H, L, D = q.shape
    out = torch.empty_like(q)

    BLOCK_M, BLOCK_N, BLOCK_D, num_warps, num_stages = _pick_tiles(D, L)

    _fwd_kernel_alibi_npu[(H, triton.cdiv(L, BLOCK_M))](
        q,
        k,
        v,
        out,
        alibi_slopes,
        scale,
        L,
        q.stride(0),
        q.stride(1),
        q.stride(2),
        k.stride(0),
        k.stride(1),
        k.stride(2),
        v.stride(0),
        v.stride(1),
        v.stride(2),
        out.stride(0),
        out.stride(1),
        out.stride(2),
        num_queries_per_kv=1,
        IN_PRECISION=None,
        BLOCK_M=BLOCK_M,
        BLOCK_DMODEL=D,
        BLOCK_DMODEL_PADDED=BLOCK_D,
        BLOCK_N=BLOCK_N,
        SKIP_DECODE=False,
        num_warps=num_warps,
        num_stages=num_stages,
    )

    return {"output": out}
