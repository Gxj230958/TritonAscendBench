"""NPU (triton-ascend) migration of _linear_attn_decode_kernel.

Lightning / linear-attention single-step decode:

    S'  = exp(-slope) * S + k^T v
    out = q . S'

q, k, v:    [B, H, 1, D]   (single decode step)
kv_caches:  [B, H, D, D]   (mutated in place, slot-routed by slot_idx)
slope_rate: [H] float32
slot_idx:   [B] int64
output:     [B, H*D] float32

Round-4 change vs round-3 (single, motivated): the tile geometry is
enlarged from 32x32 to 64x64 (BLOCK_D = BLOCK_V = 64) and the value-axis
grid is now the ceiling division  (D + BLOCK_V - 1) // BLOCK_V . The head
dimension D stays a RUNTIME argument (not a tl.constexpr), so every shape
still shares ONE kernel build -- the property that fixed the round-2/3
Layer E "blocked runtime operation" failure for P6 (D=512).

Why 64x64:
  * The contiguous cache axis (d1) is walked in BLOCK_V chunks. A 64-wide
    chunk is 256B per row (fp32), giving the memory subsystem a longer
    contiguous burst and better HBM utilization on the bandwidth-bound
    large shapes (P4/P7/P8/P10/P11) than the 32-wide (128B) chunk.
  * The q/k axis (d0) is walked in BLOCK_D tiles inside the loop. 64-wide
    tiles halve the number of iterations, cutting per-iteration index and
    mask bookkeeping (which dominates the small, launch-bound shapes).
  * 64x64x4B = 16KB of tile state per program; well inside the register/
    local-memory budget on the 910B, and the in-place store keeps the same
    single load + single store per cache element as before.
Masking (d0 < D, d1 < D) is preserved, so D values that are not multiples
of 64 (here D=32) remain numerically identical to the round-3 result.
Numeric body (fp32) is otherwise unchanged from round 3.
"""
import torch
import triton
import triton.language as tl

# Attention sentinel: a slot index equal to this marks a padded batch row
# that must be skipped. Value matches the upstream constant (never hit here
# because slot_idx is a non-negative permutation).
PAD_SLOT_ID = -1


@triton.jit
def _linear_attn_decode_kernel(
    q_ptr, k_ptr, v_ptr, kv_cache_ptr, slope_rate, slot_idx, output_ptr,
    D,
    qkv_b_stride, qkv_h_stride,
    cache_b_stride, cache_h_stride, cache_d0_stride, cache_d1_stride,
    pad_slot_id: tl.constexpr,
    BLOCK_D: tl.constexpr,
    BLOCK_V: tl.constexpr,
):
    """One (b, h, v-tile) program.

    Program (pid_b, pid_h, pid_v) owns the cache rows S[:, v] for
    v in [pid_v*BLOCK_V, (pid_v+1)*BLOCK_V), and walks the full D
    q/k axis in BLOCK_D tiles:
      1. load v once over its BLOCK_V slice;
      2. for each d-tile: load q,k over BLOCK_D, load the
         BLOCK_D x BLOCK_V cache tile, S_new = k*v + ratio*S_old,
         store S_new back in place, accumulate out += sum_d q*S_new;
      3. store out over the BLOCK_V slice.
    All arithmetic is fp32.
    """
    pid_b = tl.program_id(0)
    pid_h = tl.program_id(1)
    pid_v = tl.program_id(2)
    slot_id = tl.load(slot_idx + pid_b).to(tl.int64)
    if slot_id == pad_slot_id:
        return
    batch_id = pid_b
    head_id = pid_h
    ratio = tl.exp(-tl.load(slope_rate + pid_h))

    v_d_offsets = tl.arange(0, BLOCK_V) + pid_v * BLOCK_V
    v_mask = v_d_offsets < D

    qkv_offset = batch_id * qkv_b_stride + head_id * qkv_h_stride
    cache_offset = slot_id * cache_b_stride + head_id * cache_h_stride
    v_offset = qkv_offset + v_d_offsets

    v = tl.load(v_ptr + v_offset, mask=v_mask, other=0.0)

    out = tl.zeros((BLOCK_V,), dtype=tl.float32)
    for d0 in range(0, D, BLOCK_D):
        qk_d_offsets = tl.arange(0, BLOCK_D) + d0
        qk_mask = qk_d_offsets < D
        q = tl.load(q_ptr + qkv_offset + qk_d_offsets, mask=qk_mask, other=0.0)
        k = tl.load(k_ptr + qkv_offset + qk_d_offsets, mask=qk_mask, other=0.0)
        cache_d_offsets = qk_d_offsets[:, None] * cache_d0_stride + v_d_offsets[None, :] * cache_d1_stride
        kv_mask = qk_mask[:, None] & v_mask[None, :]
        kv_ptr = kv_cache_ptr + cache_offset + cache_d_offsets
        kv_cache_old = tl.load(kv_ptr, mask=kv_mask, other=0.0)
        kv_outer = k[:, None] * v[None, :] + ratio * kv_cache_old
        tl.store(kv_ptr, kv_outer, mask=kv_mask)
        out += tl.sum(q[:, None] * kv_outer, axis=0)

    tl.store(output_ptr + v_offset, out, mask=v_mask)


def npu_triton_impl(inputs: dict) -> dict:
    """Dict entrypoint: launch the decode kernel, return the flat output.

    Allocate the raw [B, H, 1, D] output, launch with grid
    (B, H, cdiv(D, BLOCK_V)) and fixed BLOCK_D == BLOCK_V == 64 (D stays a
    runtime value so all shapes share one kernel build), then flatten to
    [B, H*D]. kv_caches is updated in place by the kernel.
    """
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    kv_caches = inputs["kv_caches"]
    slope_rate = inputs["slope_rate"]
    slot_idx = inputs["slot_idx"]

    B, H, _, D = q.shape
    BLOCK_D = 64
    BLOCK_V = 64
    output = torch.empty_like(q)
    grid = (B, H, (D + BLOCK_V - 1) // BLOCK_V)
    _linear_attn_decode_kernel[grid](
        q, k, v, kv_caches, slope_rate, slot_idx, output,
        D,
        q.stride(0), q.stride(1),
        kv_caches.stride(0), kv_caches.stride(1),
        kv_caches.stride(2), kv_caches.stride(3),
        pad_slot_id=PAD_SLOT_ID,
        BLOCK_D=BLOCK_D,
        BLOCK_V=BLOCK_V,
    )
    out_flat = output.squeeze(2).reshape(B, H * D).contiguous()
    return {"output": out_flat}
