"""Triton-Ascend implementation of the pack_bitmatrix operation (round 2).

Entry point: npu_triton_impl(inputs: dict) -> dict

Semantics (unchanged from round 1, and the round-1 receipt confirms 49/49
shapes pass): given an int64 routing tensor ``topk_ids`` of shape
[n_rows, n_expts_act] whose entries are expert ids, and a scalar
``num_experts``, build the dense routing bit matrix as int32 words

    out[r, e // 32] bit (e % 32) is set  <=>  e appears in topk_ids[r]

Ids outside [0, num_experts) are ignored, a repeated id in the same row
changes nothing, and the returned tensor is int32 with shape
[n_rows, ceil(num_experts / 32)] under the key "bitmatrix".

What changed relative to round 1 (device latency only, no semantics change)
--------------------------------------------------------------------------
The round-1 numbers are a near-constant ~134 us floor plus a variable tail
that tracks the number of *unrolled slot iterations* and the per-iteration
instruction count (P24 G=8 -> 140 us, P25 G=16 -> 179 us, P26/P27 G=24/32 ->
258/231 us; the meta.yaml cost model calls this regime FLOOR_DOMINATED). So
round 2 attacks exactly those two factors and touches nothing else:

  1. The slot axis is now unrolled to the *exact* n_expts_act (passed as a
     constexpr) instead of next_power_of_2(n_expts_act). Round 1 spent 32
     slot bodies on G=24 and 16 on G=12; those padded iterations are gone,
     and because the trip count is now exact the per-load
     ``k < n_expts_act`` mask term disappears with them.
  2. num_experts is a constexpr too, so the range guard folds against a
     constant instead of a runtime scalar compare.
  3. A dedicated single-word kernel handles ceil(num_experts / 32) == 1,
     i.e. 40 of the 49 shapes in this task's grid (E <= 32). Round 1 ran
     every shape through the [rows, words] formulation, which per slot costs
     a word-index shift, a [M,1]==[1,W] equality broadcast and a 2-D masked
     store. With one word per row all of that collapses to 1-D vector work:
     one strided load, one range mask, one shift, one or, and a 1-D store.
     The per-slot clamp ``eid = where(in_range, raw, 0)`` is also dropped --
     the shift amount is always masked with 31, so an invalid lane shifts by
     a legal amount and is then discarded by the range mask.
  4. The multi-word kernel keeps the round-1 formulation verbatim (same
     broadcast/equality structure, same 2-D masked store) so the nine
     E > 32 shapes stay on a lowering that is already known to work here.

Launch geometry is deliberately left exactly as round 1 had it --
BLOCK_SIZE_M = min(32, next_pow2(n_rows)) shrunk while M*W > 4096 lanes, one
launch, grid = cdiv(n_rows, M) -- so this round is a clean ablation of "fewer
instructions per slot iteration" alone.

Bit-exactness details that must not move:
  * everything stays int32; ``1 << 31`` for expert id 31 produces the same
    two's-complement sign-bit pattern the closed-form reference holds as the
    negative value -2147483648. No unsigned type is introduced anywhere.
  * ``raw >> 5`` / ``raw & 31`` replace // 32 / % 32 (same values for the
    non-negative ids that survive the guard, and they keep the arithmetic off
    the multiply/subtract path that int32-overflow instrumentation widens).
  * in the multi-word kernel an invalid lane gets word index -1, so it matches
    no output word and contributes nothing.
  * the padded columns of BLOCK_SIZE_W are masked out of the store; storing
    unmasked would walk off the end of every output row for E that is not a
    multiple of 32.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _pack_bitmatrix_single_word(
    bitmatrix_ptr,             # int32 [n_rows] out, bm_cols == 1
    topk_ids_ptr,              # int64 [n_rows, n_expts_act] in
    n_rows,                    # runtime: routing rows (tokens)
    N_EXPTS_ACT: tl.constexpr,     # exact slots per row
    NUM_EXPERTS: tl.constexpr,     # exact width of the expert space, <= 32
    BLOCK_SIZE_M: tl.constexpr,
):
    pid_m = tl.program_id(0)
    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    row_ok = offs_m < n_rows

    base = topk_ids_ptr + offs_m * N_EXPTS_ACT
    acc = tl.zeros([BLOCK_SIZE_M], dtype=tl.int32)
    zero = tl.zeros([BLOCK_SIZE_M], dtype=tl.int32)
    one = tl.full([BLOCK_SIZE_M], 1, tl.int32)

    # Trip count is the real slot count: no padded iteration, no slot mask.
    for k in tl.static_range(N_EXPTS_ACT):
        raw = tl.load(base + k, mask=row_ok, other=-1).to(tl.int32)
        in_range = (raw >= 0) & (raw < NUM_EXPERTS)
        # & 31 keeps the shift amount legal for every lane, including the -1
        # sentinels, whose bit is then dropped by the select below.
        acc = acc | tl.where(in_range, one << (raw & 31), zero)

    tl.store(bitmatrix_ptr + offs_m, acc, mask=row_ok)


@triton.jit
def _pack_bitmatrix_multiword(
    bitmatrix_ptr,             # int32 [n_rows, bm_cols] out
    topk_ids_ptr,              # int64 [n_rows, n_expts_act] in
    n_rows,                    # runtime: routing rows (tokens)
    N_EXPTS_ACT: tl.constexpr,     # exact slots per row
    NUM_EXPERTS: tl.constexpr,     # exact width of the expert space, > 32
    bm_cols: tl.constexpr,         # words per output row = ceil(E / 32)
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_W: tl.constexpr,
):
    pid_m = tl.program_id(0)
    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_w = tl.arange(0, BLOCK_SIZE_W)

    row_ok = offs_m < n_rows
    word_ok = offs_w < bm_cols

    base = topk_ids_ptr + offs_m * N_EXPTS_ACT
    acc = tl.zeros([BLOCK_SIZE_M, BLOCK_SIZE_W], dtype=tl.int32)
    zero_tile = tl.zeros([BLOCK_SIZE_M, BLOCK_SIZE_W], dtype=tl.int32)
    one = tl.full([BLOCK_SIZE_M], 1, tl.int32)
    word_ids = offs_w[None, :]

    for k in tl.static_range(N_EXPTS_ACT):
        raw = tl.load(base + k, mask=row_ok, other=-1).to(tl.int32)
        in_range = (raw >= 0) & (raw < NUM_EXPERTS)
        bit = one << (raw & 31)
        # -1 matches no output word, so an out-of-range lane adds nothing.
        word = tl.where(in_range, raw >> 5, -1)
        acc = acc | tl.where(word[:, None] == word_ids, bit[:, None], zero_tile)

    out_ptrs = bitmatrix_ptr + offs_m[:, None] * bm_cols + offs_w[None, :]
    tl.store(out_ptrs, acc, mask=row_ok[:, None] & word_ok[None, :])


def npu_triton_impl(inputs: dict) -> dict:
    topk_ids = inputs["topk_ids"]
    num_experts = inputs["num_experts"]

    if not topk_ids.is_contiguous():
        topk_ids = topk_ids.contiguous()
    n_rows, n_expts_act = topk_ids.shape

    bm_cols = triton.cdiv(num_experts, 32)
    bitmatrix = torch.empty((n_rows, bm_cols), dtype=torch.int32,
                            device=topk_ids.device)

    # Geometry identical to round 1: the word tile covers bm_cols, the row
    # tile is capped and then shrunk so the [rows, words] temporaries stay
    # inside the on-chip budget.
    block_w = max(1, triton.next_power_of_2(bm_cols))
    block_m = max(1, min(32, triton.next_power_of_2(n_rows)))
    while block_m * block_w > 4096 and block_m > 1:
        block_m //= 2

    grid = (triton.cdiv(n_rows, block_m),)
    if bm_cols == 1:
        _pack_bitmatrix_single_word[grid](
            bitmatrix,
            topk_ids,
            n_rows,
            N_EXPTS_ACT=n_expts_act,
            NUM_EXPERTS=num_experts,
            BLOCK_SIZE_M=block_m,
            sanitize_overflow=False,
        )
    else:
        _pack_bitmatrix_multiword[grid](
            bitmatrix,
            topk_ids,
            n_rows,
            N_EXPTS_ACT=n_expts_act,
            NUM_EXPERTS=num_experts,
            bm_cols=bm_cols,
            BLOCK_SIZE_M=block_m,
            BLOCK_SIZE_W=block_w,
            sanitize_overflow=False,
        )

    return {"bitmatrix": bitmatrix}
