"""NPU triton-ascend implementation of gelu_and_mul (GeGLU).

Semantics (frozen upstream kernel.py):
  x: (B, 2*D) bf16. One program per row; hidden half = D.
  gate = 0.5 * (1 + erf(x1 * 0.7071067811865475)) * x1   (exact erf form)
  out  = x3 * bf16(gate)                                  (multiply in bf16)
Load order: load bf16 -> cast fp32 -> math in fp32 -> cast result
of gelu back to the pointer element type -> multiply in that
(element) type -> store.

erf is evaluated in fp32 via the Abramowitz-Stegun 7.1.26
polynomial (|err| < 1.5e-7, far below bf16 resolution) so the
implementation stays within the allowed triton op set:
  erf(x) ~ sign(x) * (1 - P(|x|) * exp(-x^2)),
  P(t) = (((((a1*t + a2)*t + a3)*t + a4)*t + a5)*t) with t = |x|.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def gelu_and_mul_kernel(
    out_hidden_states_ptr,
    hidden_states_ptr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    input_start = pid * hidden_dim * 2
    output_start = pid * hidden_dim

    offs = tl.arange(0, BLOCK_SIZE)
    mask = offs < hidden_dim

    x1 = tl.load(hidden_states_ptr + input_start + offs, mask=mask, other=0.0).to(tl.float32)
    x3 = tl.load(hidden_states_ptr + input_start + hidden_dim + offs, mask=mask, other=0.0).to(tl.float32)

    # erf(x1 * 0.7071067811865475) via A&S 7.1.26 in fp32.
    z = x1 * 0.7071067811865475
    t = tl.abs(z)
    poly = ((((0.00128379008 * t + 0.01953115208) * t + 0.1195772138) * t + 0.3912023005) * t + 0.7978845608) * t
    erf_z = tl.math.copysign(1.0 - poly * tl.exp(-z * z), z)

    gelu_x1 = 0.5 * (1.0 + erf_z) * x1

    # Match upstream cast order: gelu result cast to element type first,
    # then the multiply happens in the element (bf16) type.
    out = x3 * gelu_x1.to(hidden_states_ptr.dtype.element_ty)

    tl.store(out_hidden_states_ptr + output_start + offs, out, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    hidden_states = inputs["hidden_states"]
    bs, in_hidden_dim = hidden_states.shape
    hidden_dim = in_hidden_dim // 2

    out_hidden_states = torch.empty(
        (bs, hidden_dim), dtype=hidden_states.dtype, device=hidden_states.device
    )

    block_size = triton.next_power_of_2(hidden_dim)
    max_warps = 32
    num_warps = max(min(triton.next_power_of_2(triton.cdiv(hidden_dim, 8 * 32)), max_warps), 4)

    gelu_and_mul_kernel[bs,](
        out_hidden_states,
        hidden_states,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=block_size,
        num_warps=num_warps,
    )
    return {"output": out_hidden_states}
