"""L2_05_gelu_and_mul — Ascend triton solution.

GeGLU: split last dimension in half, apply exact erf GELU to the gate
(first half), then multiply element-wise by the up (second half).

The kernel uses the formula:
    gelu(x1) = 0.5 * (1.0 + erf(x1 / sqrt(2))) * x1
    output = gelu(x1) * x3

Inputs:
    hidden_states : [B, D] bfloat16 tensor
    approximate   : scalar string, always "none" (exact erf path)

Output:
    {"output": [B, D//2] tensor in same dtype as hidden_states}
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _gelu_and_mul_kernel(
    out_ptr,
    hidden_states_ptr,
    hidden_dim: tl.constexpr,
    stride: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """One program per row. Each program processes one sequence position.

    hidden_dim = D // 2 (half the last dimension).
    stride = D (full last dimension, the row stride in flat layout).
    """
    pid = tl.program_id(axis=0)

    # Offsets within the flat buffer for this row.
    input_start = pid * stride
    output_start = pid * hidden_dim

    offsets = tl.arange(0, BLOCK_SIZE)
    mask = offsets < hidden_dim

    # Gate half (first half_dim elements of the row).
    gate_offsets = input_start + offsets
    # Up half (second half_dim elements of the row).
    up_offsets = input_start + hidden_dim + offsets

    x1 = tl.load(hidden_states_ptr + gate_offsets, mask=mask, other=0.0).to(tl.float32)
    x3 = tl.load(hidden_states_ptr + up_offsets, mask=mask, other=0.0).to(tl.float32)

    # Exact erf GELU: 0.5 * (1.0 + erf(x / sqrt(2))) * x
    gelu_x1 = 0.5 * (1.0 + tl.erf(x1 * 0.7071067811865475)) * x1

    # Cast GELU result back to input dtype (bfloat16), multiply by up.
    out = x3 * gelu_x1.to(hidden_states_ptr.dtype.element_ty)

    # Store result.
    tl.store(out_ptr + output_start + offsets, out, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    hidden_states = inputs["hidden_states"]
    batch_size, total_dim = hidden_states.shape
    half_dim = total_dim // 2

    # Output buffer — same dtype as input.
    out = torch.empty((batch_size, half_dim), dtype=hidden_states.dtype, device=hidden_states.device)

    grid = (batch_size,)
    BLOCK_SIZE = triton.next_power_of_2(half_dim)

    _gelu_and_mul_kernel[grid](
        out,
        hidden_states,
        hidden_dim=half_dim,
        stride=total_dim,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=min(max(triton.next_power_of_2(triton.cdiv(half_dim, 8 * 32)), 4), 32),
    )

    return {"output": out}
