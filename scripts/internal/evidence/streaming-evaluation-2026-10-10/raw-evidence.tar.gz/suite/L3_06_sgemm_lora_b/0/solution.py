"""Round 1 triton-ascend candidate for L3_06_sgemm_lora_b.

Segmented (SGMV) expand for the LoRA B step:
    out[s:e] += scalings[adapter] * (x[s:e, :rank] @ B[adapter, :, :rank].T)

Per segment (one program on axis 1) the adapter rank is a runtime scalar;
the K loop is `cdiv(rank, BLOCK_K)` iterations and out-of-rank lanes are
zero-padded at load time, so the matrix product over the padded block is
exactly the product over the true rank. Accumulation is fp32; the scaled
result is added to the (in-place) output buffer and stored in the output
dtype, mirroring the upstream cast order:
    acc(fp32) * scaling(fp32) + base(dtype) -> fp32 -> dtype
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _lora_b_seg_gemm_kernel(
    x,
    weights,
    output,
    # Matrix dimensions
    N,  # output dim
    K,  # max rank
    # Strides
    x_stride_0,
    x_stride_1,
    w_stride_0,
    w_stride_1,
    w_stride_2,
    output_stride_0,
    output_stride_1,
    # Segment metadata
    seg_indptr,
    weight_indices,
    lora_ranks,
    scalings,
    # Block sizes
    BLOCK_S: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    batch_id = tl.program_id(axis=1)
    w_index = tl.load(weight_indices + batch_id)
    rank = tl.load(lora_ranks + w_index)

    # Rank 0 is a no-op (matmul with a zero-width dimension).
    if rank == 0:
        return

    seg_start = tl.load(seg_indptr + batch_id)
    seg_len = tl.load(seg_indptr + batch_id + 1) - seg_start
    if seg_len == 0:
        return

    scaling = tl.load(scalings + w_index).to(tl.float32)

    pid = tl.program_id(axis=0)
    num_pid_n = tl.cdiv(N, BLOCK_N)
    pid_s = pid // num_pid_n
    pid_n = pid % num_pid_n
    if pid_s * BLOCK_S >= seg_len:
        return

    s_offset = tl.arange(0, BLOCK_S) + pid_s * BLOCK_S
    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N

    x_base = x + seg_start.to(tl.int64) * x_stride_0
    w_base = weights + w_index * w_stride_0

    n_mask = n_offset[None, :] < N
    partial_sum = tl.zeros((BLOCK_S, BLOCK_N), dtype=tl.float32)
    for kb in range(0, tl.cdiv(rank, BLOCK_K)):
        k_off = kb * BLOCK_K + tl.arange(0, BLOCK_K)
        k_lo_rank = k_off < rank
        x_tile = tl.load(
            x_base + s_offset[:, None] * x_stride_0 + k_off[None, :] * x_stride_1,
            mask=(s_offset[:, None] < seg_len) & k_lo_rank[None, :],
            other=0.0,
        )
        w_tile = tl.load(
            w_base + k_off[:, None] * w_stride_2 + n_offset[None, :] * w_stride_1,
            mask=k_lo_rank[:, None] & n_mask,
            other=0.0,
        )
        partial_sum += tl.dot(x_tile, w_tile)

    # Fused scaled add into the (base) output, upstream cast order.
    partial_sum = partial_sum * scaling
    partial_sum = partial_sum.to(output.dtype.element_ty)
    out_ptrs = output + (
        (seg_start + s_offset)[:, None].to(tl.int64) * output_stride_0
        + n_offset[None, :] * output_stride_1
    )
    out_mask = (s_offset[:, None] < seg_len) & n_mask
    partial_sum += tl.load(out_ptrs, mask=out_mask, other=0.0)
    tl.store(out_ptrs, partial_sum, mask=out_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    weights = inputs["weights"].contiguous()

    seg_indptr = inputs["seg_indptr"].to(torch.int64).contiguous()
    weight_indices = inputs["weight_indices"].to(torch.int64).contiguous()
    lora_ranks = inputs["lora_ranks"].to(torch.int64).contiguous()
    scalings = inputs["scalings"].to(torch.float32).contiguous()

    S = x.shape[0]
    N = weights.shape[1]

    # Segments partition the S token rows (offsets:to=B), so a grid sized
    # on S covers the longest segment; programs past their segment's end
    # exit early. No host/device sync is needed.
    num_segments = seg_indptr.numel() - 1

    if "base_output" in inputs:
        base_output = inputs["base_output"]
        output = base_output.contiguous().clone()
    else:
        output = torch.zeros((S, N), device=x.device, dtype=x.dtype)

    BLOCK_S = 32
    BLOCK_N = 64
    BLOCK_K = 16

    if S > 0 and num_segments > 0:
        grid = (
            triton.cdiv(S, BLOCK_S) * triton.cdiv(N, BLOCK_N),
            num_segments,
        )
        _lora_b_seg_gemm_kernel[grid](
            x,
            weights,
            output,
            N,
            x.shape[1],
            x.stride(0),
            x.stride(1),
            weights.stride(0),
            weights.stride(1),
            weights.stride(2),
            output.stride(0),
            output.stride(1),
            seg_indptr,
            weight_indices,
            lora_ranks,
            scalings,
            BLOCK_S,
            BLOCK_N,
            BLOCK_K,
        )

    return {"output": output}
