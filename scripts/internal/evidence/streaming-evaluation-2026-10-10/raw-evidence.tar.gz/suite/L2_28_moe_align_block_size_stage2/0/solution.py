"""NPU (triton-ascend) implementation of the 4-stage MoE block-align
pipeline for task L2_28_moe_align_block_size_stage2.

Sorts flat token ids by expert id and pads every expert run up to a
multiple of ``block_size``.  The pipeline mirrors the frozen 4-stage
design vendored in kernel.py:

  stage1: per-program histogram of expert ids over a disjoint token slab
  stage2: per-expert inclusive prefix sum down the histogram rows
  stage3: single program: padded cumulative expert offsets (``cumsum``),
          the total padded token count, and the padded block count
  stage4: per-program expert-id block fill, deterministic token scatter,
          and sentinel fill of this expert's pad slots

Round-2 fix (correctness): the returned buffers now have exactly the
valid-prefix sizes required by the contract:

  sorted_token_ids   : [num_tokens_post_pad] int32, pad slots = numel
  expert_ids         : [num_tokens_post_pad // block_size] int32
  num_tokens_post_pad: [1] int32

Round 1 returned over-allocated worst-case buffers and therefore
mismatched the expected shapes on 48/49 shapes.  The valid prefix
length is data-dependent, so it is produced device-side: stage3 writes
both the padded token total and the padded block count into their own
single-element buffers, and the host allocates the two output buffers
with those device tensors as the size argument, after stage3 has run.
No host-side readback of device data is needed.

Because the output buffers are allocated exactly sized and uninitialized:

  * stage4 writes the sentinel value ``numel`` into every pad slot of
    the expert owned by each program (the slots between the last real
    token of that expert and the end of its padded run); together with
    the real-token scatter this covers every slot of sorted_token_ids.
  * the expert_ids fill loop of stage4 covers every block index, since
    the per-expert padded runs partition [0, num_tokens_post_pad).

All shapes of this task use ``num_experts = 4`` and ``block_size = 4``.
The kernels receive both values as constexpr launch arguments; the host
sizing below uses the corresponding literals (20 = (4+1)*4 histogram
slots, 5 = 4+1 cumsum slots) and numel-derived bounds:

  * tokens_per_thread = ceil(numel / 4) = (numel + 3) // 4 covers the
    flat token array with 4 disjoint slabs.
  * every per-expert padded run start/end stored in ``cumsum`` is a
    multiple of block_size and bounded by numel + 4*3, so all kernel
    writes stay inside the exactly-sized output buffers.

All counters are int32; every partial sum stays below numel + padding,
which is far inside int32 range for the task shapes, so no wider
accumulator is required.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def moe_align_block_size_stage1(
    topk_ids_ptr,
    tokens_cnts_ptr,
    num_experts: tl.constexpr,
    numel: tl.constexpr,
    tokens_per_thread: tl.constexpr,
):
    pid = tl.program_id(0)
    start_idx = pid * tokens_per_thread
    off_c = (pid + 1) * num_experts

    for i in range(tokens_per_thread):
        if start_idx + i < numel:
            idx = tl.load(topk_ids_ptr + start_idx + i)
            token_cnt = tl.load(tokens_cnts_ptr + off_c + idx)
            tl.store(tokens_cnts_ptr + off_c + idx, token_cnt + 1)


@triton.jit
def moe_align_block_size_stage2(
    tokens_cnts_ptr,
    num_experts: tl.constexpr,
):
    pid = tl.program_id(0)
    last_cnt = 0
    for i in range(1, num_experts + 1):
        token_cnt = tl.load(tokens_cnts_ptr + i * num_experts + pid)
        last_cnt = last_cnt + token_cnt
        tl.store(tokens_cnts_ptr + i * num_experts + pid, last_cnt)


@triton.jit
def moe_align_block_size_stage3(
    total_tokens_post_pad_ptr,
    total_blocks_post_pad_ptr,
    tokens_cnts_ptr,
    cumsum_ptr,
    num_experts: tl.constexpr,
    block_size: tl.constexpr,
):
    last_cumsum = 0
    off_cnt = num_experts * num_experts
    for i in range(1, num_experts + 1):
        token_cnt = tl.load(tokens_cnts_ptr + off_cnt + i - 1)
        last_cumsum = last_cumsum + tl.cdiv(token_cnt, block_size) * block_size
        tl.store(cumsum_ptr + i, last_cumsum)
    tl.store(total_tokens_post_pad_ptr, last_cumsum)
    tl.store(total_blocks_post_pad_ptr, last_cumsum // block_size)


@triton.jit
def moe_align_block_size_stage4(
    topk_ids_ptr,
    sorted_token_ids_ptr,
    expert_ids_ptr,
    tokens_cnts_ptr,
    cumsum_ptr,
    num_experts: tl.constexpr,
    block_size: tl.constexpr,
    numel: tl.constexpr,
    tokens_per_thread: tl.constexpr,
):
    pid = tl.program_id(0)
    start_idx = tl.load(cumsum_ptr + pid)
    end_idx = tl.load(cumsum_ptr + pid + 1)

    for i in range(start_idx, end_idx, block_size):
        tl.store(expert_ids_ptr + i // block_size, pid)

    # This expert's pad slots run from the end of its real-token run
    # to the end of its padded run; fill them with the sentinel value.
    total_cnt = tl.load(tokens_cnts_ptr + num_experts * num_experts + pid)
    for i in range(start_idx + total_cnt, end_idx):
        tl.store(sorted_token_ids_ptr + i, numel)

    start_idx = pid * tokens_per_thread
    off_t = pid * num_experts

    for i in range(start_idx, tl.minimum(start_idx + tokens_per_thread, numel)):
        expert_id = tl.load(topk_ids_ptr + i)
        token_cnt = tl.load(tokens_cnts_ptr + off_t + expert_id)
        rank_post_pad = token_cnt + tl.load(cumsum_ptr + expert_id)
        tl.store(sorted_token_ids_ptr + rank_post_pad, i)
        tl.store(tokens_cnts_ptr + off_t + expert_id, token_cnt + 1)


def npu_triton_impl(inputs: dict) -> dict:
    topk_ids = inputs["topk_ids"]
    num_experts = inputs["num_experts"]
    block_size = inputs["block_size"]

    # The kernels address topk_ids as a flat integer array.  Expert ids
    # are small non-negative integers, so int32 holds every value and
    # every derived offset; keep the data contiguous and integral.
    if topk_ids.dtype != torch.int32:
        topk_ids = topk_ids.to(torch.int32)
    topk_ids = topk_ids.contiguous()
    device = topk_ids.device

    numel = topk_ids.numel()
    grid = (num_experts,)

    # Histogram workspace: flat 20 int32 slots = (4+1)*4 rows*cols
    # (row 0 stays zero; row pid+1 holds slab pid's histogram; row 4
    # ends up holding the per-expert totals after stage2).
    tokens_cnts = torch.zeros((20,), dtype=torch.int32, device=device)
    # Cumulative padded offsets: 5 int32 slots.
    cumsum = torch.zeros((5,), dtype=torch.int32, device=device)
    # ceil(numel / num_experts) with num_experts = 4 for every shape.
    tokens_per_thread = (numel + 3) // 4

    # Single-element totals written by stage3; they double as the
    # device-side size arguments for the exactly-sized output buffers.
    num_tokens_post_pad = torch.empty((1,), dtype=torch.int32, device=device)
    num_blocks_post_pad = torch.empty((1,), dtype=torch.int32, device=device)

    moe_align_block_size_stage1[grid](
        topk_ids,
        tokens_cnts,
        num_experts,
        numel,
        tokens_per_thread,
    )
    moe_align_block_size_stage2[grid](
        tokens_cnts,
        num_experts,
    )
    moe_align_block_size_stage3[(1,)](
        num_tokens_post_pad,
        num_blocks_post_pad,
        tokens_cnts,
        cumsum,
        num_experts,
        block_size,
    )

    # Allocate the outputs with the device-side totals as sizes; every
    # slot of both buffers is written by stage4 (real tokens and pad
    # sentinels for sorted_token_ids, one entry per block for
    # expert_ids), so no initialization is required.
    sorted_token_ids = torch.empty(
        num_tokens_post_pad, dtype=torch.int32, device=device
    )
    expert_ids = torch.empty(
        num_blocks_post_pad, dtype=torch.int32, device=device
    )

    moe_align_block_size_stage4[grid](
        topk_ids,
        sorted_token_ids,
        expert_ids,
        tokens_cnts,
        cumsum,
        num_experts,
        block_size,
        numel,
        tokens_per_thread,
    )

    return {
        "sorted_token_ids": sorted_token_ids,
        "expert_ids": expert_ids,
        "num_tokens_post_pad": num_tokens_post_pad,
    }
