# triton-ascend migration of deepep_post_reorder (DeepEP combine post-reorder).
#
# Round 2 (vs round 1): parallelism re-partitioned from
#   grid = (n_tokens,) with an inner D-loop over ceil(D/512) tiles
# to
#   grid = (n_tokens, ceil(D/512)) with no D-loop.
# Every program now owns exactly one 512-wide D tile of one output token:
# the topk scalar gathers (src2dst row ids + weights) are loaded once up
# front, then the two (topk=2 for every shape in shapes.yaml) row-tile
# vector loads and the weighted sum are straight-line. Rationale:
#   * small-token shapes (n_tokens=1..4) previously launched 1-4 programs
#     that each serially walked D/512 tiles (up to 16 for D=8192); now the
#     same work is spread over n_tokens * D/512 programs.
#   * large shapes (P8: 1024 x 8192) get 16x more programs than the
#     (n_tokens,) grid, shrinking the per-program critical path and the
#     tail latency.
#   * the per-tile scalar re-gathers are 2 int + 2 float loads, negligible
#     vs the 2 x 512-float row loads they guard.
#
# Semantics (identical to round 1, one program per (token, d-tile)):
#   out[i, d] = sum over j in [0, topk) of w[i, j] * x[src2dst[i*topk + j], d]
# where x is the expert-major [n_tokens*topk, D] buffer, src2dst is the flat
# int index map into x, and w is [n_tokens, topk].  A slot j whose src2dst
# entry is negative contributes zero (the upstream `if dst >= 0` guard is
# replaced by where()/valid-mask so the body stays branch-free; numerically
# identical because the invalid slot's weight is zeroed before the FMA).
#
# Accumulation dtype follows x's dtype (float32 here), matching the upstream
# load/cast order: the weight is cast to x's dtype before the multiply-accumulate.
import torch
import triton
import triton.language as tl


@triton.jit
def _deepep_post_reorder_kernel(
    down_output_ptr, output_ptr, src2dst_ptr, topk_weights_ptr,
    topk, hidden_size,
    BLOCK_SIZE: tl.constexpr,
):
    InDtype = down_output_ptr.dtype.element_ty
    src_idx = tl.program_id(0)
    d_idx = tl.program_id(1)
    offset = d_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offset < hidden_size
    s2d_ptr = src2dst_ptr + src_idx * topk
    w_ptr = topk_weights_ptr + src_idx * topk
    sum_vec = tl.zeros([BLOCK_SIZE], dtype=InDtype)
    for idx in range(0, topk):
        dst_idx = tl.load(s2d_ptr + idx)
        valid = dst_idx >= 0
        # Clamp the row for address safety; invalid slots are zeroed via valid.
        row = tl.where(valid, dst_idx, 0)
        weigh_scale = (tl.load(w_ptr + idx) * valid.to(InDtype)).to(InDtype)
        in_data = tl.load(down_output_ptr + row * hidden_size + offset,
                          mask=mask)
        sum_vec += in_data * weigh_scale
    tl.store(output_ptr + src_idx * hidden_size + offset, sum_vec, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]                          # [n_tokens*topk, D]
    src2dst = inputs["src2dst"]              # [n_tokens*topk] flat index map
    topk_weights = inputs["topk_weights"]    # [n_tokens, topk]
    # topk is x.shape[0] / n_tokens (flat map length / token count).
    topk = x.shape[0] // topk_weights.shape[0]

    n_tokens = topk_weights.shape[0]
    hidden_size = x.shape[1]

    if src2dst.dtype not in (torch.int32, torch.int64):
        src2dst = src2dst.to(torch.int64)
    x = x.contiguous()
    src2dst = src2dst.contiguous()
    topk_weights = topk_weights.contiguous()

    output = torch.empty(
        (n_tokens, hidden_size), device=x.device, dtype=x.dtype
    )

    # Upstream default tile; masked so it is exact even when D is not a
    # multiple of the block size (including D < BLOCK_SIZE).
    BLOCK_SIZE = 512
    num_d_tiles = (hidden_size + BLOCK_SIZE - 1) // BLOCK_SIZE
    grid = (n_tokens, num_d_tiles)

    _deepep_post_reorder_kernel[grid](
        x, output, src2dst, topk_weights,
        topk, hidden_size,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=4,
    )

    return {"output": output}
