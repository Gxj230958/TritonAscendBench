"""Triton-Ascend implementation of the gate/up LoRA-B expand operator (round 2).

Entry point: ``npu_triton_impl(inputs: dict) -> dict`` returning
``{"output": tensor}`` with dtype ``x.dtype`` and shape ``[s, 2*output_dim]``.

Math (per batch segment ``b``, per half ``g in {0, 1}`` -- gate and up)::

    w    = weight_indices[b]
    rank = lora_ranks[w]
    K    = min(r, rank)          # r = weights.shape[-1] (max rank)
    sc   = scalings[w]
    rows = contiguous row span [seg_indptr[b], seg_indptr[b+1])
    out[rows, g*N:(g+1)*N] += sc * (x[rows, g*K:g*K+K] @ W[w, g*N:(g+1)*N, :K]^T)

Load-bearing details preserved from the reference semantics:
  * the up half (g=1) reads x starting at column ``K`` where ``K`` is the
    CLAMPED effective rank ``min(r, rank)``, not the max rank ``r``;
  * segments with ``rank == 0`` (or empty row span) leave the output
    untouched (no-op convention of an empty inner dimension);
  * accumulation is full fp32 and the result is rounded to the input dtype
    exactly once, at store time (see precision note below).

Round-2 change (correctness fix): round 1 used ``tl.dot`` on the cube unit
with the same 16/64/16 tiling. Three shapes whose effective rank reaches
8-16 (P7 r=12, P8 r=16, H3 r=8 with many rows) failed tolerance with
|error| ~ K * 2^-11, the signature of a narrow (~fp16-class) internal
accumulator inside the cube path. The reference accumulates the rank
dimension in full fp32 and rounds once at the end, so this version replaces
the cube dot with an explicit rank-1 outer-product accumulation in fp32:
for k in [0, K_eff) it adds ``x[:, k] * w[:, k]^T`` with both factors
upcast bf16->fp32 (exact), and multiplies by the adapter scaling in fp32
before the single bf16 rounding at store time. Since K <= 16 on this task,
the vector path is cheap and matches the reference rounding behavior.

Grid strategy (unchanged from round 1): one program per
(segment, half, column block); the program walks the row blocks of its own
segment in a device-side loop, so the host never needs a data-dependent
(segment length) grid extent. Output writes are partitioned: each (row, col)
belongs to exactly one program, so when no pre-initialized output is
supplied the store is direct (masked), avoiding a redundant read of the
(output is the largest tensor of the task); the read-modify-write variant
is kept for the pre-initialized case.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _gate_up_lora_b_kernel(
    # Pointers to matrices
    x,
    weights,
    output,
    # Sizes
    K,  # max rank r (= weights.shape[-1])
    output_dim,
    # Strides
    x_stride_0,
    x_stride_1,
    w_stride_0,
    w_stride_1,
    w_stride_2,
    output_stride_0,
    output_stride_1,
    # Segment / adapter descriptors
    seg_indptr,
    weight_indices,
    lora_ranks,
    scalings,
    # Grid decomposition helper (runtime, not constexpr)
    num_pid_n,
    # Tile sizes
    BLOCK_S: tl.constexpr,
    BLOCK_N: tl.constexpr,
    # Store mode: True -> read-modify-write onto a pre-initialized output
    ACCUMULATE: tl.constexpr,
):
    # Flat 1-D grid ordered as [batch_id, half (gate/up), column block].
    pid = tl.program_id(axis=0)
    per_batch = 2 * num_pid_n
    batch_id = pid // per_batch
    rem = pid % per_batch
    gate_up_id = rem // num_pid_n
    pid_n = rem % num_pid_n

    w_index = tl.load(weight_indices + batch_id).to(tl.int32)
    rank = tl.load(lora_ranks + w_index).to(tl.int32)
    seg_start = tl.load(seg_indptr + batch_id).to(tl.int32)
    seg_end = tl.load(seg_indptr + batch_id + 1).to(tl.int32)
    seg_len = seg_end - seg_start

    # Effective rank for this adapter, clamped by the max rank.
    K_eff = tl.minimum(K, rank)

    n_start = gate_up_id * output_dim
    scaling = tl.load(scalings + w_index)

    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    n_mask = n_offset < output_dim

    # Tokens are contiguous per segment (no reordering), so the physical row
    # ids are simply seg_start + s_offset. Walk the segment's row blocks.
    for pid_s in range(0, tl.cdiv(seg_len, BLOCK_S)):
        s_offset = tl.arange(0, BLOCK_S) + pid_s * BLOCK_S
        rows = seg_start + s_offset
        s_mask = s_offset < seg_len

        # x half for gate/up starts at column gate_up_id * K_eff (clamped
        # offset, matching the reference pointer arithmetic).
        x_base = x + (gate_up_id * K_eff) * x_stride_1
        w_base = weights + w_index * w_stride_0 + n_start * w_stride_1

        # fp32 outer-product accumulation over the rank dimension. bf16 ->
        # fp32 upcasts are exact and the products have <= 16 mantissa bits,
        # so every product and every partial sum is exact fp32 arithmetic,
        # mirroring the reference's full-precision accumulation.
        acc = tl.zeros((BLOCK_S, BLOCK_N), dtype=tl.float32)
        for k in range(0, K_eff):
            x_k = tl.load(
                x_base + rows * x_stride_0 + k * x_stride_1,
                mask=s_mask,
                other=0.0,
            ).to(tl.float32)
            w_k = tl.load(
                w_base + n_offset * w_stride_1 + k * w_stride_2,
                mask=n_mask,
                other=0.0,
            ).to(tl.float32)
            acc += x_k[:, None] * w_k[None, :]

        # Scale in fp32, then round to the input dtype exactly once.
        acc = acc * scaling
        acc = acc.to(x.dtype.element_ty)

        out_ptrs = (
            output
            + n_start * output_stride_1
            + rows[:, None] * output_stride_0
            + n_offset[None, :] * output_stride_1
        )
        # rank == 0 segments must leave the output untouched: fold the
        # condition into the store mask (no data-dependent control flow).
        out_mask = (
            (s_offset[:, None] < seg_len)
            & (n_offset[None, :] < output_dim)
            & (rank > 0)
        )
        if ACCUMULATE:
            existing = tl.load(out_ptrs, mask=out_mask, other=0.0)
            tl.store(out_ptrs, acc + existing, mask=out_mask)
        else:
            tl.store(out_ptrs, acc, mask=out_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    weights = inputs["gate_up_lora_b"].contiguous()
    seg_indptr = inputs["seg_indptr"].to(torch.int64).contiguous()
    weight_indices = inputs["weight_indices"].to(torch.int64).contiguous()
    lora_ranks = inputs["lora_ranks"].to(torch.int64).contiguous()
    scalings = inputs["scalings"].to(torch.float32).contiguous()

    n_slices = 2
    s = x.shape[0]
    # weights: [num_lora, 2*output_dim, r]; derive output_dim from the shape.
    output_dim = weights.shape[1] // n_slices
    r = weights.shape[2]

    # Accumulate into base_output when provided, otherwise into zeros.
    if "base_output" in inputs:
        output = inputs["base_output"].to(dtype=x.dtype).contiguous().clone()
        accumulate = True
    else:
        output = torch.zeros(
            (s, n_slices * output_dim), device=x.device, dtype=x.dtype
        )
        # Writes are partitioned across programs ((row, col) owned by exactly
        # one program), so a direct masked store is equivalent to RMW onto
        # zeros and skips a full read of the output tensor.
        accumulate = False

    num_segments = seg_indptr.numel() - 1

    # Row/column tiles. BLOCK_S=16, BLOCK_N=64 match round 1 (which satisfies
    # the static checker and ran correctly); the rank dimension is handled as
    # a scalar loop by the fp32 vector path, so no rank tile is needed.
    BLOCK_S = 16
    BLOCK_N = 64

    if num_segments > 0 and output_dim > 0:
        num_pid_n = triton.cdiv(output_dim, BLOCK_N)
        grid = (num_segments * n_slices * num_pid_n,)
        _gate_up_lora_b_kernel[grid](
            x,
            weights,
            output,
            r,
            output_dim,
            x.stride(0),
            x.stride(1),
            weights.stride(0),
            weights.stride(1),
            weights.stride(2),
            output.stride(0),
            output.stride(1),
            seg_indptr,
            weight_indices,
            lora_ranks,
            scalings,
            num_pid_n,
            BLOCK_S=BLOCK_S,
            BLOCK_N=BLOCK_N,
            ACCUMULATE=accumulate,
        )

    return {"output": output}
