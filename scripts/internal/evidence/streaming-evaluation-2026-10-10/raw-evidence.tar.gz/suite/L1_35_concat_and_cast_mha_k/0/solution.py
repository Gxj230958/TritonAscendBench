"""Round 2 candidate — L1_35_concat_and_cast_mha_k (DeepSeek-V3 MLA K assembly).

Faithful port of the frozen upstream GPU triton kernel (kernel.py,
`concat_and_cast_mha_k_kernel`) to Triton-Ascend. Semantics:

    k[:, h, :Dn] = k_nope[:, h, :]        for every head h
    k[:, h, Dn:] = k_rope[:, 0, :]        shared rope slice replicated across heads

with the implicit cast to `out_dtype` (bf16/fp16/fp32) performed at store time.
Grid is one program per token, exactly like upstream. `Dn` and `Dr` are kept as
separate unmasked `tl.arange` ranges (never fused into `Dn+Dr`), so the power-of-two
constraint the frozen kernel relies on is preserved for every public/hidden shape.
"""
import torch
import triton
import triton.language as tl

_DTYPES = {
    "bf16": torch.bfloat16,
    "bfloat16": torch.bfloat16,
    "fp16": torch.float16,
    "float16": torch.float16,
    "fp32": torch.float32,
    "float32": torch.float32,
}


@triton.jit
def concat_and_cast_mha_k_kernel(
    k_ptr, k_nope_ptr, k_rope_ptr,
    head_cnt: tl.constexpr,
    k_stride0: tl.constexpr, k_stride1: tl.constexpr,
    nope_stride0: tl.constexpr, nope_stride1: tl.constexpr,
    rope_stride0: tl.constexpr,
    nope_dim: tl.constexpr, rope_dim: tl.constexpr,
):
    pid_loc = tl.program_id(0)
    head_range = tl.arange(0, head_cnt)
    k_head_ptr = k_ptr + pid_loc * k_stride0 + head_range[:, None] * k_stride1

    nope_offs = tl.arange(0, nope_dim)
    src_nope_ptr = (k_nope_ptr + pid_loc * nope_stride0
                    + head_range[:, None] * nope_stride1 + nope_offs[None, :])
    dst_nope_ptr = k_head_ptr + nope_offs[None, :]
    src_nope = tl.load(src_nope_ptr)
    tl.store(dst_nope_ptr, src_nope)

    rope_offs = tl.arange(0, rope_dim)
    src_rope_ptr = k_rope_ptr + pid_loc * rope_stride0 + rope_offs[None, :]
    dst_rope_ptr = k_head_ptr + nope_dim + rope_offs[None, :]
    src_rope = tl.load(src_rope_ptr)
    tl.store(dst_rope_ptr, src_rope)


def _run(k: torch.Tensor, k_nope: torch.Tensor, k_rope: torch.Tensor):
    assert k.ndim == 3 and k_nope.ndim == 3 and k_rope.ndim == 3
    assert k.shape[0] == k_nope.shape[0] == k_rope.shape[0]
    assert k.shape[1] == k_nope.shape[1] and k_rope.shape[1] == 1
    assert k.shape[-1] == k_nope.shape[-1] + k_rope.shape[-1]
    nope_dim, rope_dim = k_nope.shape[-1], k_rope.shape[-1]
    grid = (k.shape[0],)
    concat_and_cast_mha_k_kernel[grid](
        k, k_nope, k_rope,
        k.shape[1],
        k.stride(0), k.stride(1),
        k_nope.stride(0), k_nope.stride(1),
        k_rope.stride(0),
        nope_dim, rope_dim,
    )


def npu_triton_impl(inputs: dict) -> dict:
    k_nope = inputs["k_nope"]
    k_rope = inputs["k_rope"]
    out_dtype = str(inputs["out_dtype"])
    dt = _DTYPES[out_dtype]

    n_tokens, head_cnt, nope_dim = k_nope.shape
    rope_dim = k_rope.shape[-1]
    k = k_nope.new_empty((n_tokens, head_cnt, nope_dim + rope_dim), dtype=dt)
    _run(k, k_nope, k_rope)
    return {"k": k}
