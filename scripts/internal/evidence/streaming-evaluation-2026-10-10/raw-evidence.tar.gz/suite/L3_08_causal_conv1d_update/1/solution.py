"""Triton-Ascend implementation of the single-step decode causal conv1d
state update with cache gather (L3_08_causal_conv1d_update).

Semantics (decode path: one new token per batch row):
  For batch row i with cache line c = conv_state_indices[i]:
    window   = concat(conv_state[c, :, :], x[i, :])        # [D, KW]
    y[i, :]  = sum_k( bf16_round(window_k * w_k) as fp32 ) + bias_f32
    optional SiLU on y (fp32), store back as bf16
    conv_state[c] <- window[:, 1:]   (rolled left, append new token)

Numerics contract
-----------------
The reference rounds every tap product to bfloat16 (round-to-nearest-even)
BEFORE accumulating into fp32:

    y = sum_k( rne_bf16(window_k * w_k) widened to fp32 ) + bias_f32

Expressing that rounding as an fp32 multiply followed by an
fp32->bf16->fp32 cast chain does not work on this device: rounds 1-2
measured that the optimizer folds such cast chains away, so the product
rounding never materialized and the outputs missed the reference by 1-2
bf16 ulps on 45/46 shapes. Round 3 therefore performs the
RNE-to-bfloat16 rounding with INTEGER arithmetic on the product's bit
pattern, which the optimizer cannot fold; round 4 carried that kernel to
46/46 passing shapes.

Round 5 change (single, dtype-scoped)
-------------------------------------
Round 4 implemented the integer rounding through int64: zero-extend the
int32 bit pattern to int64, add/mask in int64, truncate back to int32.
The int64 widening is unnecessary:

  * For every finite fp32 bit pattern `b`, the RNE increment
    `b + 0x7FFF + ((b >> 16) & 1)` cannot overflow int32. Worst case
    positive: 0x7F7FFFFF + 0x8000 = 0x7F807FFF < INT32_MAX. Worst case
    negative: the most negative pattern 0x80000001 plus 0x8000 stays
    above INT32_MIN. Products of two finite bf16 values are always finite
    (or inf, and inf bit patterns map to themselves), so only finite
    patterns (and inf) ever reach the rounding code.
  * The two's-complement carry idiom is sign-symmetric: for negative
    patterns the arithmetic right shift sign-extends, but `& 1` still
    extracts bit 16, and adding the increment then masking with
    0xFFFF0000 performs the identical carry logic on the high 16 bits.

Round 5 therefore computes the rounding entirely in int32:

    bits    = bit_pattern(f32 product)                (fp32 -> int32)
    rounded = (bits + 0x7FFF + ((bits >> 16) & 1)) & 0xFFFF0000
    bf16p   = rounded -> fp32 bitcast

The numerics are bit-for-bit identical to round 4 (same RNE rule, same
tap-by-tap fp32 accumulation order, fp32 bias added last, SiLU as
acc / (1 + exp(-acc)) in fp32 -- the same formula the frozen upstream
kernel and the reference use). The change removes the int64
zero-extend/truncate pair and halves the integer vector width per tap
product, cutting the elementwise integer ALU work of the rounding path.
Everything else is unchanged from round 4: kernel geometry
(grid (B, ceil(D/256)), BLOCK_N=256), masked loads/stores along D, and
the in-place race-free state roll. The rolled state is written back into
the input cache: conv_state_indices is a cyclic permutation (a bijection
over the cache lines) and programs along the feature axis cover disjoint
feature slices, so no two programs touch the same state element and all
source columns are loaded before any state store. The mutated conv_state
is returned alongside the conv output so both outputs of the operation
are present (the round-1 fix for the missing second output).
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _rne_bf16_as_f32(v):
    """Round a fp32 tensor to the bfloat16 grid (RNE), returned in fp32.

    Implemented with int32 ops on the bit pattern so the optimizer
    cannot fold it into the surrounding fp32 arithmetic. For finite fp32
    bit patterns the increment cannot overflow int32, and the masked
    two's-complement carry is sign-symmetric, so int64 is not needed.
    """
    b = v.to(tl.int32, bitcast=True)          # fp32 bit pattern
    rounded = (b + 0x7FFF + ((b >> 16) & 1)) & (-65536)
    return rounded.to(tl.float32, bitcast=True)


@triton.jit
def _causal_conv1d_update_decode_kernel(
    x_ptr,
    w_ptr,
    bias_ptr,
    conv_state_ptr,
    conv_state_indices_ptr,
    o_ptr,
    batch,
    dim,
    stride_x_seq,
    stride_x_dim,
    stride_w_dim,
    stride_w_width,
    stride_cs_seq,
    stride_cs_dim,
    stride_cs_tok,
    stride_state_indices,
    stride_o_seq,
    stride_o_dim,
    HAS_BIAS: tl.constexpr,
    KERNEL_WIDTH: tl.constexpr,
    ACTIVATION: tl.constexpr,
    BLOCK_N: tl.constexpr,
):
    idx_seq = tl.program_id(0)
    idx_feats = tl.program_id(1) * BLOCK_N + tl.arange(0, BLOCK_N)
    mask_w = idx_feats < dim

    # Cache line selected for this batch row.
    coord = tl.load(conv_state_indices_ptr + idx_seq * stride_state_indices)
    coord = coord.to(tl.int64)

    cs_base = conv_state_ptr + coord * stride_cs_seq + idx_feats * stride_cs_dim

    # Load the KW-1 history columns of the selected cache line.
    if KERNEL_WIDTH >= 2:
        col0 = tl.load(cs_base + 0 * stride_cs_tok, mask=mask_w, other=0.0)
    if KERNEL_WIDTH >= 3:
        col1 = tl.load(cs_base + 1 * stride_cs_tok, mask=mask_w, other=0.0)
    if KERNEL_WIDTH >= 4:
        col2 = tl.load(cs_base + 2 * stride_cs_tok, mask=mask_w, other=0.0)
    if KERNEL_WIDTH >= 5:
        col3 = tl.load(cs_base + 3 * stride_cs_tok, mask=mask_w, other=0.0)
    if KERNEL_WIDTH >= 6:
        col4 = tl.load(cs_base + 4 * stride_cs_tok, mask=mask_w, other=0.0)

    # Load the new decode token for this row.
    x_ptrs = x_ptr + idx_seq * stride_x_seq + idx_feats * stride_x_dim
    x_new = tl.load(x_ptrs, mask=mask_w, other=0.0)

    # Roll the state left and append the new token (in place). All source
    # columns were read before any state store, and distinct programs touch
    # disjoint state elements, so this is race-free. The state has exactly
    # KERNEL_WIDTH-1 columns, so the last store target is column KW-2.
    if KERNEL_WIDTH >= 3:
        tl.store(cs_base + 0 * stride_cs_tok, col1, mask=mask_w)
    if KERNEL_WIDTH >= 4:
        tl.store(cs_base + 1 * stride_cs_tok, col2, mask=mask_w)
    if KERNEL_WIDTH >= 5:
        tl.store(cs_base + 2 * stride_cs_tok, col3, mask=mask_w)
    if KERNEL_WIDTH >= 6:
        tl.store(cs_base + 3 * stride_cs_tok, col4, mask=mask_w)
    tl.store(cs_base + (KERNEL_WIDTH - 2) * stride_cs_tok, x_new, mask=mask_w)

    # Tap reduction: per-tap product rounded to the bf16 grid via the
    # integer RNE trick, then accumulated sequentially in fp32 (matches
    # the left-to-right last-dim reduction of the reference for KW <= 6).
    acc = tl.zeros((BLOCK_N,), dtype=tl.float32)
    w_base = w_ptr + idx_feats * stride_w_dim
    if KERNEL_WIDTH >= 2:
        w_col = tl.load(w_base + 0 * stride_w_width, mask=mask_w, other=0.0)
        acc += _rne_bf16_as_f32(col0.to(tl.float32) * w_col.to(tl.float32))
    if KERNEL_WIDTH >= 3:
        w_col = tl.load(w_base + 1 * stride_w_width, mask=mask_w, other=0.0)
        acc += _rne_bf16_as_f32(col1.to(tl.float32) * w_col.to(tl.float32))
    if KERNEL_WIDTH >= 4:
        w_col = tl.load(w_base + 2 * stride_w_width, mask=mask_w, other=0.0)
        acc += _rne_bf16_as_f32(col2.to(tl.float32) * w_col.to(tl.float32))
    if KERNEL_WIDTH >= 5:
        w_col = tl.load(w_base + 3 * stride_w_width, mask=mask_w, other=0.0)
        acc += _rne_bf16_as_f32(col3.to(tl.float32) * w_col.to(tl.float32))
    if KERNEL_WIDTH >= 6:
        w_col = tl.load(w_base + 4 * stride_w_width, mask=mask_w, other=0.0)
        acc += _rne_bf16_as_f32(col4.to(tl.float32) * w_col.to(tl.float32))
    w_last = tl.load(w_base + (KERNEL_WIDTH - 1) * stride_w_width, mask=mask_w, other=0.0)
    acc += _rne_bf16_as_f32(x_new.to(tl.float32) * w_last.to(tl.float32))

    if HAS_BIAS:
        bias_v = tl.load(bias_ptr + idx_feats, mask=mask_w, other=0.0).to(tl.float32)
        acc += bias_v

    if ACTIVATION == "silu" or ACTIVATION == "swish":
        acc = acc / (1.0 + tl.exp(-acc))

    o_ptrs = o_ptr + idx_seq * stride_o_seq + idx_feats * stride_o_dim
    tl.store(o_ptrs, acc, mask=mask_w)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]                              # [B, D] bfloat16
    conv_state = inputs["conv_state"]            # [num_cache_lines, D, KW-1]
    weight = inputs["weight"]                    # [D, KW]
    bias = inputs["bias"]                        # [D]
    activation = inputs["activation"]            # 'silu' / 'swish' / 'none'
    conv_state_indices = inputs["conv_state_indices"]  # [B] int32, permutation

    batch, dim = x.shape
    _, kernel_width = weight.shape

    out = torch.empty_like(x)

    # Same geometry as rounds 1-4 (grid (B, ceil(D/256)), BLOCK_N=256).
    block_n = 256
    grid = (batch, (dim + block_n - 1) // block_n)
    _causal_conv1d_update_decode_kernel[grid](
        x,
        weight,
        bias,
        conv_state,
        conv_state_indices,
        out,
        batch,
        dim,
        x.stride(0),
        x.stride(1),
        weight.stride(0),
        weight.stride(1),
        conv_state.stride(0),
        conv_state.stride(1),
        conv_state.stride(2),
        conv_state_indices.stride(0),
        out.stride(0),
        out.stride(1),
        HAS_BIAS=True,
        KERNEL_WIDTH=kernel_width,
        ACTIVATION=activation,
        BLOCK_N=block_n,
    )
    # conv_state was rolled in place; return it explicitly so both outputs
    # of the operation are present in the result dict.
    return {"output": out, "conv_state": conv_state}
