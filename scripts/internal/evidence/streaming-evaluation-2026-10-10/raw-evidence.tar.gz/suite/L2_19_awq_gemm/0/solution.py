"""Task L2_19_awq_gemm -- Triton-Ascend implementation of awq_gemm_kernel.

Entrypoint: npu_triton_impl(inputs: dict) -> dict with key "C".

Tile structure, index arithmetic, packed lane ordering and the per-split
partial layout mirror the frozen GPU source shipped with this task
(``kernel.py``).  Three intentional differences, all needed on the NPU target:

1. The 8 nibbles carried by one packed int32 word are gathered directly with a
   column index (word column ``n // 8``, nibble lane ``perm[n % 8] * 4`` with
   ``perm = [0, 4, 1, 5, 2, 6, 3, 7]``) instead of three nested
   ``tl.interleave`` duplications.  ``perm`` is exactly the order produced by
   ``reverse_awq_order_tensor`` after those duplications, so the expanded tile
   is element-for-element identical (checked on CPU for several
   ``(BLOCK_SIZE_K, BLOCK_SIZE_N)`` pairs) while using only ``tl.load`` plus
   plain integer arithmetic.

2. Both matmul operands are rounded first with the same 19-bit mask the
   reference applies -- the low 13 float32 mantissa bits are cleared, sign and
   exponent untouched -- and only then handed to the cube unit as float16 with
   a float32 accumulator.  A float16 mantissa holds precisely those 11
   significant bits, so the narrowing cast is loss free and the values
   entering the products equal the reference operands.  Omitting the mask
   perturbs every operand by up to 2**-11 relative, which integrates to an
   absolute error near 1.3 on the long-K shapes, far outside the 5e-3 bound.
   With the mask, float16 cube plus float32 accumulate stays inside tolerance
   on every shape listed in ``shapes.yaml``.

3. The split factor only distributes work: split ``z`` owns the K blocks
   ``z, z + S, z + 2S, ...``, so any ``S`` covers every K block exactly once and
   leaves the result unchanged.  Shapes whose tile grid already fills the
   device run with ``S = 1`` and write the result in place; only tile-starved
   shapes keep per-split partial tiles and fold them in a second pass.
"""

import torch
import triton
import triton.language as tl

_MIN_BLOCK_M = 16
_MAX_BLOCK_M = 64
_MIN_BLOCK_N = 32
_MAX_BLOCK_N = 128
_REDUCE_BLOCK = 1024
_MAX_SPLIT = 8
# Tile count at or above which an extra split only buys partial-tile traffic.
_TILES_ENOUGH = 32


@triton.jit
def _reference_round(x):
    """Clear the low 13 mantissa bits of a float32 tile without touching the
    sign or the exponent, reproducing the reference operand rounding."""
    bits = x.to(tl.int32, bitcast=True)
    # -8192 is ~((1 << 13) - 1): the low 13 mantissa bits read as 0.
    bits = bits & -8192
    return bits.to(tl.float32, bitcast=True)


@triton.jit
def awq_gemm_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    zeros_ptr,
    scales_ptr,
    M,
    N,
    K,
    group_size,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    SPLIT_K: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    pid_z = tl.program_id(1)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)

    # Output column n sits in packed word column n // 8, nibble lane
    # ((n % 8) & 1) * 4 + ((n % 8) >> 1) of that word.
    offsets_n = tl.arange(0, BLOCK_SIZE_N)
    lane = offsets_n % 8
    shifts = ((lane & 1) * 4 + (lane >> 1)) * 4

    offsets_am = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    masks_am = offsets_am < M
    offsets_bn = pid_n * (BLOCK_SIZE_N // 8) + offsets_n // 8
    masks_bn = offsets_bn < N // 8
    offsets_zn = pid_n * (BLOCK_SIZE_N // 8) + offsets_n // 8
    masks_zn = offsets_zn < N // 8
    offsets_sn = pid_n * BLOCK_SIZE_N + offsets_n
    masks_sn = offsets_sn < N

    offsets_k = pid_z * BLOCK_SIZE_K + tl.arange(0, BLOCK_SIZE_K)
    offsets_a = K * offsets_am[:, None] + offsets_k[None, :]
    offsets_b = N // 8 * offsets_k[:, None] + offsets_bn[None, :]
    a_ptrs = a_ptr + offsets_a
    b_ptrs = b_ptr + offsets_b

    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K * SPLIT_K)):
        masks_k = offsets_k < K
        masks_a = masks_am[:, None] & masks_k[None, :]
        a = tl.load(a_ptrs, mask=masks_a, other=0.0)
        a = _reference_round(a).to(tl.float16)

        masks_b = masks_k[:, None] & masks_bn[None, :]
        b = tl.load(b_ptrs, mask=masks_b, other=0)

        # Group row owning this K block; BLOCK_SIZE_K == group_size keeps the
        # quotient exact for every element of the block.
        offsets_szk = (BLOCK_SIZE_K * SPLIT_K * k + pid_z * BLOCK_SIZE_K) // group_size + tl.arange(0, 1)
        masks_zk = offsets_szk < K // group_size

        offsets_z = N // 8 * offsets_szk[:, None] + offsets_zn[None, :]
        masks_z = masks_zk[:, None] & masks_zn[None, :]
        zeros_ptrs = zeros_ptr + offsets_z
        zeros = tl.load(zeros_ptrs, mask=masks_z, other=0)

        offsets_s = N * offsets_szk[:, None] + offsets_sn[None, :]
        masks_s = masks_zk[:, None] & masks_sn[None, :]
        scales_ptrs = scales_ptr + offsets_s
        scales = tl.load(scales_ptrs, mask=masks_s, other=0.0)

        # Both lanes hold 0..15, so their difference is exact in float32 and
        # the scaled difference below matches the reference lane bit for bit.
        b = (b >> shifts[None, :] & 15).to(tl.float32)
        zeros = (zeros >> shifts[None, :] & 15).to(tl.float32)
        b = (b - zeros) * scales
        b = _reference_round(b).to(tl.float16)

        accumulator = tl.dot(a, b, accumulator, input_precision="ieee", out_dtype=tl.float32)

        offsets_k += BLOCK_SIZE_K * SPLIT_K
        a_ptrs += BLOCK_SIZE_K * SPLIT_K
        b_ptrs += BLOCK_SIZE_K * SPLIT_K * (N // 8)

    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = c_ptr + pid_z * N * M + N * offs_cm[:, None] + offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, accumulator, mask=c_mask)


@triton.jit
def awq_split_sum_kernel(
    p_ptr,
    c_ptr,
    TOTAL,
    SPLIT_K: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Fold the SPLIT_K partial tiles into one flat [M * N] result."""
    pid = tl.program_id(0)
    offs = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = offs < TOTAL
    acc = tl.zeros((BLOCK_SIZE,), dtype=tl.float32)
    for z in tl.static_range(0, SPLIT_K):
        acc += tl.load(p_ptr + z * TOTAL + offs, mask=mask, other=0.0)
    tl.store(c_ptr + offs, acc, mask=mask)


def _pow2_clamped(value, lo, hi):
    size = lo
    while size < value and size < hi:
        size *= 2
    return min(size, hi)


def _split_factor(tiles, k_dim, block_k):
    split_k = 1
    if tiles < _TILES_ENOUGH:
        while split_k < _MAX_SPLIT and split_k * 2 * block_k <= k_dim and tiles * split_k * 2 <= k_dim // block_k:
            split_k *= 2
    return split_k


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["input"].contiguous()
    qweight = inputs["qweight"].contiguous()
    scales = inputs["scales"].contiguous()
    qzeros = inputs["qzeros"].contiguous()

    M, K = a.shape
    N = qweight.shape[1] * 8
    # A K block must sit inside one scale group, so pick the widest power-of-two
    # block width that divides the group length.  Then every block start, which
    # is always a multiple of the block width, shares one group index.
    group_len = K // qzeros.shape[0]
    block_k = 32
    while block_k > 1 and group_len % block_k:
        block_k //= 2

    block_m = _pow2_clamped(M, _MIN_BLOCK_M, _MAX_BLOCK_M)
    block_n = _pow2_clamped(N, _MIN_BLOCK_N, _MAX_BLOCK_N)
    tiles = triton.cdiv(M, block_m) * triton.cdiv(N, block_n)
    split_k = _split_factor(tiles, K, block_k)

    out = torch.empty((M, N), dtype=scales.dtype, device=a.device)
    grid = (tiles, split_k)

    if split_k == 1:
        awq_gemm_kernel[grid](
            a, qweight, out, qzeros, scales, M, N, K, group_len,
            BLOCK_SIZE_M=block_m, BLOCK_SIZE_N=block_n,
            BLOCK_SIZE_K=block_k, SPLIT_K=1,
        )
        return {"C": out}

    parts = torch.empty((split_k, M, N), dtype=scales.dtype, device=a.device)
    awq_gemm_kernel[grid](
        a, qweight, parts, qzeros, scales, M, N, K, group_len,
        BLOCK_SIZE_M=block_m, BLOCK_SIZE_N=block_n,
        BLOCK_SIZE_K=block_k, SPLIT_K=split_k,
    )
    total = M * N
    awq_split_sum_kernel[(triton.cdiv(total, _REDUCE_BLOCK),)](
        parts, out, total, SPLIT_K=split_k, BLOCK_SIZE=_REDUCE_BLOCK
    )
    return {"C": out}
