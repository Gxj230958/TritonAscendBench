"""NPU (Triton-Ascend) implementation for L2_26_fwd_kernel_ep_scatter_1.

Semantics (DeepGEMM contiguous-group layout builder).  Given the per-expert
received-token counts ``counts`` of length ``E``:

  * ``pad[e]  = round_up_128(counts[e]) = ((counts[e] + 127) // 128) * 128``
  * ``expert_start_loc``: [E] int32 -- exclusive prefix sum of ``pad``, i.e. the
    first row of expert ``e``'s back-to-back region.
  * ``m_indices``: [M] int32 -- rows ``[start_e, start_e + counts[e])`` hold the
    value ``e``; the ``pad[e] - counts[e]`` rounding rows hold the ``-1``
    sentinel so the grouped GEMM skips them.
  * ``M = sum_e pad[e]``, always a multiple of 128.  ``counts[e] == 0`` gives
    ``pad[e] == 0``: that expert owns no rows at all.

Host protocol
-------------
Unchanged from the candidate that passed all 22 shapes: two launches and one
four-byte read-back.

  1. ``_chunk_prefix_kernel`` (grid = cdiv(E, BLOCK_C)) lays the experts out in
     fixed-size chunks and records where each chunk begins.  The last chunk also
     publishes ``M``.
  2. That device-published cell is handed to ``torch.empty`` as the length of
     ``m_indices``, so the destination is sized by the device-reduced value
     itself -- exact for every fixture, ``M == 0`` included, with no count
     rounded, summed or compared on the host.
  3. ``_scatter_kernel`` writes the layout.

What is new
-----------
Pass 3 is now a *tiled* walk instead of one program per expert.  Its grid is
``cdiv(E, TILE)`` and program ``t`` owns experts ``[t * TILE, (t + 1) * TILE)``:
one scalar read of the chunk table and one masked ``BLOCK_C`` reduction give it
its tile's leading row, and it then advances through the tile with a
loop-carried scalar region base, writing each expert's ``expert_start_loc`` cell
and its whole region in turn.

The measured cost of the previous pass 3 was linear in ``E`` at about 0.19 us per
expert, and the two things a per-expert program paid for were the dispatch
itself and the ``BLOCK_C``-wide reduction that is identical for every expert in a
chunk.  Tiling keeps that reduction one-per-program (it now covers a whole tile
rather than one lane of it) and divides the dispatch count by ``TILE``.  At
``E = 2048`` that is 64 programs instead of 2048.

Nothing about the value construction moves: every partial sum still collapses to
a scalar through a masked ``tl.sum``, ``expert_start_loc`` is still written by a
scalar store, and the region write is still one predicated ``[BLOCK_F]`` tile
store per step of a runtime-bounded loop.  The only new construct is the outer
``for k in range(0, n_live)`` whose bound is a runtime scalar, so a tile that
runs past the last expert simply stops early and no masked scalar store is ever
needed.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

# Rows written per store of the scatter kernel.
BLOCK_F = 256
# Experts owned by one program of the scatter kernel.
TILE = 32
# Narrowest/widest expert chunk.  Below ``BLOCK_MIN`` a chunk reduction would
# waste lanes on every program; above ``BLOCK_MAX`` a program starts paying for
# predecessors it could hand to a neighbour and the fixture loses the
# single-chunk fast path.  ``BLOCK_MIN == TILE`` keeps every tile inside exactly
# one chunk, which is what lets the scatter kernel find its base with a single
# reduction.
BLOCK_MIN = 32
BLOCK_MAX = 256


@triton.jit
def _chunk_prefix_kernel(
    num_recv_tokens_per_expert,
    chunk_start_loc,
    padded_total,
    num_experts,
    num_chunks,
    BLOCK_C: tl.constexpr,
):
    """Program ``chunk`` records where its chunk begins and, if last, ``M``.

    A chunk begins where every earlier chunk's padded counts end.  Those
    predecessors are walked one vector per step, so this pass is linear in ``E``
    (at most ``cdiv(E, BLOCK_C)`` steps).  Every index below the chunk base is a
    real expert, so the walk cannot leave the buffer; the mask keeps that
    guarantee explicit for a chunk that runs past the last expert.

    The last program's walk plus its own chunk covers every expert, so it alone
    publishes the row total for the allocator.
    """
    chunk = tl.program_id(0)
    lane = tl.arange(0, BLOCK_C)
    chunk_base = chunk * BLOCK_C

    run = tl.zeros([], dtype=tl.int32)
    for pre in range(0, chunk_base, BLOCK_C):
        off = pre + lane
        cnt = tl.load(
            num_recv_tokens_per_expert + off, mask=off < num_experts, other=0
        )
        run = run + tl.sum(((cnt + 127) // 128) * 128)

    tl.store(chunk_start_loc + chunk, run)

    if chunk == num_chunks - 1:
        own_off = chunk_base + lane
        own_cnt = tl.load(
            num_recv_tokens_per_expert + own_off,
            mask=own_off < num_experts,
            other=0,
        )
        own_total = tl.sum(((own_cnt + 127) // 128) * 128)
        tl.store(padded_total, run + own_total)


@triton.jit
def _scatter_kernel(
    num_recv_tokens_per_expert,
    chunk_start_loc,
    expert_start_loc,
    m_indices,
    num_experts,
    BLOCK_C: tl.constexpr,
    BLOCK_F: tl.constexpr,
    TILE: tl.constexpr,
):
    """Program ``t`` writes ``TILE`` consecutive experts' layout and regions.

    Its tile begins where its chunk begins plus the padded counts of the earlier
    experts inside that chunk, so one scalar read of the chunk table and one
    masked ``BLOCK_C``-wide reduction replace a walk over the whole count vector.
    ``off < tile_base`` keeps that reduction strictly exclusive of the tile.

    ``base`` then carries the region start forward expert by expert: the value
    stored for expert ``idx`` is the exclusive prefix of the padded counts, which
    is exactly the previous expert's start plus its padded length.  Because the
    region of ``idx`` begins at ``base`` and its rows are ``[0, tokens)``, one
    predicated tile store covers both the expert id and the ``-1`` sentinel, so
    the destination needs no pre-fill.  ``rows < pad`` stops a tile from running
    into the neighbouring expert (chunk boundaries are 128-aligned but not
    necessarily 256-aligned), a region of length zero skips its inner loop, and
    ``n_live`` stops the walk at the last expert so a partial final tile writes
    nothing past the end.
    """
    t = tl.program_id(0)
    tile_base = t * TILE
    lane = tl.arange(0, BLOCK_C)

    chunk = tile_base // BLOCK_C
    off = chunk * BLOCK_C + lane
    cnt = tl.load(
        num_recv_tokens_per_expert + off, mask=off < num_experts, other=0
    )
    padded_vec = ((cnt + 127) // 128) * 128
    intra = tl.sum(tl.where(off < tile_base, padded_vec, 0))

    base = tl.load(chunk_start_loc + chunk) + intra
    n_live = tl.minimum(TILE, num_experts - tile_base)
    row = tl.arange(0, BLOCK_F)

    for k in range(0, n_live):
        idx = tile_base + k
        tokens = tl.load(num_recv_tokens_per_expert + idx)
        pad = ((tokens + 127) // 128) * 128

        tl.store(expert_start_loc + idx, base)

        ptr = m_indices + base
        for step in range(0, pad, BLOCK_F):
            rows = step + row
            tl.store(ptr + rows, tl.where(rows < tokens, idx, -1), mask=rows < pad)

        base = base + pad


def npu_triton_impl(inputs: dict) -> dict:
    counts = inputs["num_recv_tokens_per_expert"]
    if counts.dtype != torch.int32:
        counts = counts.to(torch.int32)

    num_experts = counts.shape[0]
    device = counts.device

    # One chunk per BLOCK experts, sized to the fixture so a program's chunk
    # index is a shift and, for E <= BLOCK, a single chunk covers every expert.
    block_c = triton.next_power_of_2(num_experts)
    if block_c > BLOCK_MAX:
        block_c = BLOCK_MAX
    if block_c < BLOCK_MIN:
        block_c = BLOCK_MIN
    num_chunks = (num_experts + block_c - 1) // block_c
    # Keep both grids non-zero so the total cell is always published, even by a
    # degenerate fixture with no experts at all.
    if num_chunks < 1:
        num_chunks = 1

    num_tiles = (num_experts + TILE - 1) // TILE
    if num_tiles < 1:
        num_tiles = 1

    expert_start_loc = torch.empty((num_experts,), device=device, dtype=torch.int32)
    chunk_start_loc = torch.empty((num_chunks,), device=device, dtype=torch.int32)
    padded_total = torch.empty((1,), device=device, dtype=torch.int32)

    _chunk_prefix_kernel[(num_chunks,)](
        counts,
        chunk_start_loc,
        padded_total,
        num_experts,
        num_chunks,
        BLOCK_C=block_c,
        num_warps=4,
    )

    # Sizing from the device-published cell is the only host-visible read; it
    # lands on the same stream as the pass above, so the value is final by then.
    m_indices = torch.empty(padded_total, device=device, dtype=torch.int32)

    _scatter_kernel[(num_tiles,)](
        counts,
        chunk_start_loc,
        expert_start_loc,
        m_indices,
        num_experts,
        BLOCK_C=block_c,
        BLOCK_F=BLOCK_F,
        TILE=TILE,
        num_warps=4,
    )

    return {"expert_start_loc": expert_start_loc, "m_indices": m_indices}


def run(inputs: dict) -> dict:
    return npu_triton_impl(inputs)
