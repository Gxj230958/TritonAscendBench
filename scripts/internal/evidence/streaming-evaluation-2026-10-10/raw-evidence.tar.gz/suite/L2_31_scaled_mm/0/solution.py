"""Task L2_31_scaled_mm -- round 3 solution.

Port of the frozen task file kernel.py (@triton.jit ``scaled_mm_kernel`` plus
its heuristic-tile launcher), adapted for the triton-ascend (NPU) backend.

Math (matches contract.md / reference exactly):
  acc[m, n] = sum_k A[m, k] * B[k, n]           # int8 x int8 -> int32 (exact)
  C[m, n]   = scale_a[m] * scale_b[n] * acc     # cast to out_dtype (bf16)
  C[m, n]  += bias[n]                           # added after the cast
"""

import torch

import triton
import triton.language as tl


@triton.jit
def scaled_mm_kernel(
    a_ptr,
    b_ptr,
    scale_a_ptr,
    scale_b_ptr,
    c_ptr,
    bias_ptr,
    M,
    N,
    K,
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    OUT_TY: tl.constexpr,
    ACCUMULATOR_DTYPE: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    BLOCK_SIZE_SCALE_A: tl.constexpr,
    BLOCK_SIZE_SCALE_B: tl.constexpr,
):
    pid = tl.program_id(axis=0)

    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)

    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n

    accumulator_dtype = ACCUMULATOR_DTYPE
    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=accumulator_dtype)

    # NOTE: Some tensor inputs are so large, they will cause int32 overflow
    # so it is necessary to use tl.int64 for all the offsets, else SEGV will
    # eventually occur.

    # Offsets and masks.
    offsets_am = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M).to(tl.int64)
    masks_am = offsets_am < M

    offsets_bn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N).to(tl.int64)
    masks_bn = offsets_bn < N

    offsets_k = tl.arange(0, BLOCK_SIZE_K).to(tl.int64)
    offsets_a = stride_am * offsets_am[:, None] + stride_ak * offsets_k[None, :]
    offsets_b = stride_bk * offsets_k[:, None] + stride_bn * offsets_bn[None, :]

    # NOTE: BLOCK_SIZE_SCALE_A could be 1 or BLOCK_SIZE_M, so need to create
    # appropriate offsets and masks for each case. Same goes for
    # BLOCK_SIZE_SCALE_B.
    offsets_scale_am = (
        tl.arange(0, BLOCK_SIZE_SCALE_A)
        + (BLOCK_SIZE_SCALE_A > 1) * pid_m * BLOCK_SIZE_M
    )
    masks_scale_am = offsets_scale_am < M

    offsets_scale_bn = (
        tl.arange(0, BLOCK_SIZE_SCALE_B)
        + (BLOCK_SIZE_SCALE_B > 1) * pid_n * BLOCK_SIZE_N
    )
    masks_scale_bn = offsets_scale_bn < N

    a_ptrs = a_ptr + offsets_a
    b_ptrs = b_ptr + offsets_b

    scale_a_ptrs = scale_a_ptr + offsets_scale_am
    scale_b_ptrs = scale_b_ptr + offsets_scale_bn

    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        masks_k = offsets_k < K
        masks_a = masks_am[:, None] & masks_k[None, :]
        a = tl.load(a_ptrs, mask=masks_a)

        masks_b = masks_k[:, None] & masks_bn[None, :]
        b = tl.load(b_ptrs, mask=masks_b)

        # Accumulate results.
        accumulator = tl.dot(a, b, accumulator, out_dtype=accumulator_dtype)

        offsets_k += BLOCK_SIZE_K
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    # Apply scale at end. scale_a is loaded as (BLOCK_SIZE_SCALE_A, 1);
    # ordinary elementwise broadcast handles both the per-token
    # (BLOCK_SIZE_M, 1) and the scalar (1, 1) cases.
    masks_scale_a = masks_scale_am[:, None] & (tl.arange(0, 1) < 1)[:, None]
    scale_a = tl.load(scale_a_ptrs[:, None], masks_scale_a)
    accumulator = scale_a * accumulator.to(tl.float32)

    # scale_b is loaded with a transposed offset pattern so it comes out as
    # (1, BLOCK_SIZE_SCALE_B) and broadcasts along rows; this covers both the
    # per-channel (BLOCK_SIZE_N, 1) and the scalar (1, 1) cases without any
    # reshape/transpose op in the kernel.
    masks_scale_b = (tl.arange(0, 1) < 1)[:, None] & masks_scale_bn[None, :]
    scale_b = tl.load(scale_b_ptrs[None, :], masks_scale_b)
    accumulator = scale_b * accumulator.to(tl.float32)

    # Convert to output format (bfloat16 per the I/O contract).
    c = accumulator.to(OUT_TY)

    # Add bias, it's already in output format, so add it after conversion.
    if bias_ptr:
        offsets_bias = offsets_bn
        bias_ptrs = bias_ptr + offsets_bias
        bias_mask = offsets_bias < N
        bias = tl.load(bias_ptrs, bias_mask)
        c += bias

    # Save output
    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M).to(tl.int64)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N).to(tl.int64)
    c_ptrs = c_ptr + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)

    tl.store(c_ptrs, c, mask=c_mask)


# input   - [M, K]
# weight  - [K, N]

OUT_DTYPE = torch.bfloat16


def npu_triton_impl(inputs: dict) -> dict:
    A = inputs["A"]
    B = inputs["B"]
    scale_a = inputs["scale_a"]
    scale_b = inputs["scale_b"]
    bias = inputs["bias"]

    M, K = A.shape
    N = B.shape[1]
    assert B.shape[0] == K

    # Scale tensors arrive as [M, 1] / [N, 1] (2D) per the I/O contract.

    result = torch.empty((M, N), dtype=OUT_DTYPE, device=A.device)

    # Heuristic tile selection -- verbatim from the frozen launcher.
    next_power_of_2_M = max(32, triton.next_power_of_2(M))
    is_small_N = N < 8192
    if next_power_of_2_M <= 32:
        tile_shape = (64, 64, 256)
        if not is_small_N:
            tile_shape = (64, 128, 256)
    elif next_power_of_2_M <= 64:
        tile_shape = (64, 64, 256)
    elif next_power_of_2_M <= 128:
        tile_shape = (64, 128, 128)
    else:
        # Round-4 perf change (vs round-3 frozen heuristic): the M>128 branch
        # previously used (128, 128, 128). On 910B (cube 16x16x64 int8), a
        # BLOCK_SIZE_K of 128 makes every K-tile exactly one full cube depth,
        # and each 128x128x128 block is split into 64 cube ops; doubling K to
        # 256 halves the K-loop trip count and the per-iteration load/scale
        # overhead for the compute-bound shapes (P7 1536x1536x3072,
        # P8 2048x2048x4096, H3 512x256x2048, H4 1024x64x128,
        # H8 8192x1x320) -- all of which have K >= 128, so the tail stays
        # exactly covered (H4 K=128 becomes a single K-tile, P7 K=3072 stays
        # 3072/256=12 iterations, P8 4096/256=16). The M/N tiles are
        # unchanged, so grid geometry, int64 offsets, masks and the
        # scale-load pattern are untouched. Accumulation is still int32 over
        # the full K in the same order (tl.dot chain), so results are
        # bit-identical to round 3.
        tile_shape = (128, 128, 256)
    block_size_m, block_size_n, block_size_k = tile_shape

    if scale_a.shape[0] == 1 and scale_a.shape[1] == 1:
        block_size_sa = 1
    else:
        block_size_sa = block_size_m
    if scale_b.shape[0] == 1 and scale_b.shape[1] == 1:
        block_size_sb = 1
    else:
        block_size_sb = block_size_n

    # int8 inputs -> int32 accumulation (contract guarantees int8 A/B).
    accumulator_dtype = tl.int32

    grid = lambda META: (
        triton.cdiv(M, META["BLOCK_SIZE_M"]) * triton.cdiv(N, META["BLOCK_SIZE_N"]),
    )

    scaled_mm_kernel[grid](
        A,
        B,
        scale_a,
        scale_b,
        result,
        bias,
        M,
        N,
        K,
        A.stride(0),
        A.stride(1),
        B.stride(0),
        B.stride(1),
        result.stride(0),
        result.stride(1),
        tl.bfloat16,
        accumulator_dtype,
        BLOCK_SIZE_M=block_size_m,
        BLOCK_SIZE_N=block_size_n,
        BLOCK_SIZE_K=block_size_k,
        BLOCK_SIZE_SCALE_A=block_size_sa,
        BLOCK_SIZE_SCALE_B=block_size_sb,
    )

    return {"C": result}


# Interface alias: the round protocol grades npu_triton_impl; keep run for
# parity with the frozen launcher.
run = npu_triton_impl
