"""triton-ascend implementation of the chunked SGMV LoRA shrink kernel.

Semantics (per token segment): out = x @ A[adapter]^T, computed in fp32
accumulate and cast to bf16 at the end. Columns beyond the segment's active
rank stay zero, and rows outside any segment stay zero.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _chunked_lora_shrink_kernel(
    x,
    weights,
    output,
    seg_indptr,
    weight_indices,
    lora_ranks,
    num_segs,
    N: tl.constexpr,
    K: tl.constexpr,
    NUM_SLICES: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    pid_n = tl.program_id(0)
    # Clamp the segment id: out-of-range programs become harmless no-ops
    # (their segment length is zero, so the M loop body never runs) instead
    # of dereferencing index arrays past the end.
    pid_s = tl.minimum(tl.program_id(1), num_segs - 1)

    w_index = tl.load(weight_indices + pid_s)
    rank = tl.load(lora_ranks + w_index).to(tl.int32)
    cur_n = tl.minimum(N, rank * NUM_SLICES)

    seg_start = tl.load(seg_indptr + pid_s)
    seg_end = tl.load(seg_indptr + pid_s + 1)
    seg_len = (seg_end - seg_start).to(tl.int32)

    n_off = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    k_off = tl.arange(0, BLOCK_K)
    w_base = weights + w_index * (N * K)

    for m in range(0, seg_len, BLOCK_M):
        s_off = seg_start + m + tl.arange(0, BLOCK_M)
        row_mask = s_off < seg_end

        partial_sum = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
        x_ptrs = x + s_off[:, None] * K + k_off[None, :]
        w_ptrs = w_base + k_off[:, None] + n_off[None, :] * K

        for k in range(0, tl.cdiv(K, BLOCK_K)):
            k_rem = K - k * BLOCK_K
            x_tile = tl.load(
                x_ptrs,
                mask=row_mask[:, None] & (k_off[None, :] < k_rem),
                other=0.0,
            )
            w_tile = tl.load(
                w_ptrs,
                mask=(k_off[:, None] < k_rem) & (n_off[None, :] < cur_n),
                other=0.0,
            )
            # Upcast both operands to fp32 before the dot so the products are
            # computed and accumulated in fp32, matching the reference's
            # precision (the bf16 dot drifted past tolerance for P3).
            partial_sum += tl.dot(x_tile.to(tl.float32), w_tile.to(tl.float32))
            x_ptrs += BLOCK_K
            w_ptrs += BLOCK_K

        partial_sum = partial_sum.to(x.dtype.element_ty)
        out_ptrs = output + s_off[:, None] * N + n_off[None, :]
        tl.store(
            out_ptrs,
            partial_sum,
            mask=row_mask[:, None] & (n_off[None, :] < cur_n),
        )


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weights = inputs["weights"]
    seg_indptr = inputs["seg_indptr"]
    weight_indices = inputs["weight_indices"]
    lora_ranks = inputs["lora_ranks"]

    x = x.contiguous()
    weights = weights.contiguous()
    seg_indptr = seg_indptr.to(torch.int64).contiguous()
    weight_indices = weight_indices.to(torch.int64).contiguous()
    lora_ranks = lora_ranks.to(torch.int64).contiguous()

    n_tokens, K = x.shape
    N = weights.shape[1]
    num_segs = seg_indptr.numel() - 1

    output = torch.zeros((n_tokens, N), device=x.device, dtype=x.dtype)
    if num_segs <= 0:
        return {"output": output}

    BLOCK_M = 64
    BLOCK_N = 16
    BLOCK_K = 128
    grid = (triton.cdiv(N, BLOCK_N), num_segs)
    _chunked_lora_shrink_kernel[grid](
        x=x,
        weights=weights,
        output=output,
        seg_indptr=seg_indptr,
        weight_indices=weight_indices,
        lora_ranks=lora_ranks,
        num_segs=num_segs,
        N=N,
        K=K,
        NUM_SLICES=1,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        BLOCK_K=BLOCK_K,
    )
    return {"output": output}
