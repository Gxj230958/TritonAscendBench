"""Triton-Ascend (910B) migration of the upstream chunked SGMV LoRA-shrink
operator (task L2_15_chunked_lora_shrink, kernel ``_chunked_lora_shrink_kernel``).

Semantics (per segment of the token batch):
    out[seg_start:seg_end, :cur_n] = x[seg_start:seg_end] @ A[adapter]^T
where
    A        = weights[weight_indices[seg]]
    cur_n    = min(N, lora_ranks[adapter] * NUM_SLICES)
Everything outside the active window is left at zero (the launcher
zero-initializes the output, matching the reference semantics that tail
columns stay zero).

Migration notes vs. the upstream GPU source:
  * Upstream computes BLOCK_M on the host as the exact (non-power-of-two)
    max segment length and launches one program per (n-tile, segment).
    On 910B the tensor-core matmul primitive requires power-of-two tile
    extents of at least 16 on every axis, and several benchmark shapes have
    B < 16 (even B = 1) or K = 1.  We therefore keep the per-segment
    launch, fix BLOCK_N=16 / BLOCK_K=16 (powers of two, >= 16) with a fixed
    BLOCK_M, and add a separate m-block grid axis so arbitrarily long
    segments are tiled.  All out-of-range rows/cols/K are masked with ``other=0``
    exactly like upstream, so tiling never changes the result.
  * ROUND-3/4 CORRECTNESS FIX: The fp32 reference
    (_segmented_lora_shrink in the task's eager reference) computes each
    segment product in fp32 -- x and weights are upcast from bf16 to fp32
    (where the values are exact, so _to_tf32's TF32 rounding is a no-op on
    bf16 data) with fp32 accumulation, and only the final fp32 sum is
    rounded to bf16.  Round 2 fed bf16 tiles straight into tl.dot, so its
    fp32 partial sum differed from the reference fp32 matmul enough to
    cross a bf16 rounding boundary at large K (P3, K=512: result magnitude
    ~22, bf16 ULP 0.125 -> observed max_abs=0.0625, i.e. half a bf16 ULP)
    and fail the borderline vector_reduce atol/rtol.  We now upcast BOTH
    loaded tiles to fp32 before tl.dot so the fp32 partial sum matches the
    reference and the final bf16 rounding is bit-identical.  Accumulation
    stays fp32 and the partial sum is cast to the input dtype immediately
    before the store.
  * ``permutation`` (the adapter-sort row map used in production) is the
    identity for these dense fixtures; we read it from a host-provided
    identity arange exactly as the frozen launcher does, so the kernel body
    is otherwise a straight port.
  * Scalar loop bounds use tl.cdiv over a runtime K argument plus masked
    loads, so K=1 needs no special-casing.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _chunked_lora_shrink_kernel(
    # Pointers to matrices
    x,
    weights,
    output,
    # Information on sequence lengths, ranks and weight id
    seg_indptr,
    weight_indices,
    lora_ranks,
    permutation,
    num_segs,
    # Meta parameters
    N: tl.constexpr,  # max_rank * num_slices
    K: tl.constexpr,  # input_dim
    NUM_SLICES: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    x_stride_1: tl.constexpr = 1
    x_stride_0: tl.constexpr = K

    w_stride_0: tl.constexpr = N * K
    w_stride_1: tl.constexpr = K
    w_stride_2: tl.constexpr = 1

    output_stride_0: tl.constexpr = N
    output_stride_1: tl.constexpr = 1

    pid_m = tl.program_id(0)
    pid_s = tl.program_id(1)
    if pid_s >= num_segs:
        return

    pid_n = tl.program_id(2)

    # Current block computes the segment with batch id ``pid_s``, which
    # starts at row seg_start of x with length seg_len.
    w_index = tl.load(weight_indices + pid_s)
    rank = tl.load(lora_ranks + w_index)

    if rank == 0:
        return

    seg_start = tl.load(seg_indptr + pid_s)
    seg_end = tl.load(seg_indptr + pid_s + 1)

    # Adjust the N extent according to the specific adapter.
    cur_n = tl.minimum(N, rank * NUM_SLICES)

    # Map logical sequence index to physical index (identity here).
    s_offset_logical = tl.arange(0, BLOCK_M) + seg_start + pid_m * BLOCK_M
    s_offset_physical = tl.load(
        permutation + s_offset_logical, mask=s_offset_logical < seg_end
    )

    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    k_offset = tl.arange(0, BLOCK_K)
    x_ptrs = x + (
        s_offset_physical[:, None] * x_stride_0 + k_offset[None, :] * x_stride_1
    )
    w_ptrs = (weights + w_index * w_stride_0) + (
        k_offset[:, None] * w_stride_2 + n_offset[None, :] * w_stride_1
    )

    # fp32 accumulate; bf16 inputs (matches the upstream accumulation).
    partial_sum = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_K)):
        x_tile = tl.load(
            x_ptrs,
            mask=(s_offset_logical[:, None] < seg_end)
            & (k_offset[None, :] < K - k * BLOCK_K),
            other=0.0,
        )
        w_tile = tl.load(
            w_ptrs,
            mask=(k_offset[:, None] < K - k * BLOCK_K) & (n_offset[None, :] < cur_n),
            other=0.0,
        )
        # Upcast to fp32 so the tl.dot matches the reference fp32 matmul
        # (bf16 -> fp32 is exact; see ROUND-3/4 note above).
        partial_sum += tl.dot(x_tile.to(tl.float32), w_tile.to(tl.float32))

        x_ptrs += BLOCK_K * x_stride_1
        w_ptrs += BLOCK_K * w_stride_2

    # Cast the fp32 partial sum to the input dtype before the store
    # (upstream cast order).
    partial_sum = partial_sum.to(x.dtype.element_ty)
    output_ptr = output + (
        s_offset_physical[:, None] * output_stride_0
        + n_offset[None, :] * output_stride_1
    )
    output_mask = (s_offset_logical[:, None] < seg_end) & (n_offset[None, :] < cur_n)
    tl.store(output_ptr, partial_sum, mask=output_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    weights = inputs["weights"].contiguous()
    seg_indptr = inputs["seg_indptr"].to(torch.int64).contiguous()
    weight_indices = inputs["weight_indices"].to(torch.int64).contiguous()
    lora_ranks = inputs["lora_ranks"].to(torch.int64).contiguous()
    num_slices = inputs["num_slices"]  # scalar int in the fixture

    S = x.shape[0]
    N = weights.shape[1]
    K = weights.shape[2]
    assert x.shape[-1] == K, (x.shape, weights.shape)

    num_segments = seg_indptr.numel() - 1

    # Identity row mapping (fixtures are unsorted; mirrors the reference).
    permutation = torch.arange(S, device=x.device, dtype=torch.int64)

    # Block sizes: powers of two >= 16 (tensor-core minimum).  BLOCK_M is a
    # fixed 128 and the m-block grid extent is bounded by ceil(S / BLOCK_M)
    # (the true max segment length needs a host sync we avoid); every tile is
    # fully masked, so extra empty m-blocks are exact no-ops.
    BLOCK_M = 128
    BLOCK_N = 16
    BLOCK_K = 16

    # Columns beyond each segment's active rank stay zero (reference pads
    # the full tensor with zeros).
    output = torch.zeros((S, N), device=x.device, dtype=x.dtype)

    if num_segments > 0:
        m_blocks = (S + BLOCK_M - 1) // BLOCK_M
        grid = (m_blocks, num_segments, triton.cdiv(N, BLOCK_N))
        _chunked_lora_shrink_kernel[grid](
            x=x,
            weights=weights,
            output=output,
            seg_indptr=seg_indptr,
            weight_indices=weight_indices,
            lora_ranks=lora_ranks,
            permutation=permutation,
            num_segs=num_segments,
            N=N,
            K=K,
            NUM_SLICES=num_slices,
            BLOCK_M=BLOCK_M,
            BLOCK_N=BLOCK_N,
            BLOCK_K=BLOCK_K,
            num_warps=4,
            num_stages=3,
        )

    return {"output": output}
