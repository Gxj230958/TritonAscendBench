"""L1_12 RMS norm — triton-ascend candidate (round 2).

Faithful line-by-line migration of the upstream GPU triton kernel
(kernel.py, vendored snapshot) to triton-ascend.

Implements:
    y[..., j] = input[..., j] / sqrt(mean_j(input[..., j]^2) + eps) * weight[j]

Accumulation is in float32 regardless of input dtype; the result is cast
back to the input dtype at the end. One program per flattened row, two
masked block-loads per row (sum-of-squares pass, then scale-and-store
pass).
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _rms_norm_kernel(
    input_ptr,
    weight_ptr,
    output_ptr,
    input_row_stride,
    output_row_stride,
    n_cols,
    eps,
    BLOCK_SIZE: tl.constexpr,
):
    """RMS Norm: y = x / sqrt(mean(x^2) + eps) * weight. One block per row."""
    row_idx = tl.program_id(0).to(tl.int64)
    row_start_ptr = input_ptr + row_idx * input_row_stride
    output_row_start_ptr = output_ptr + row_idx * output_row_stride

    sum_sq = tl.zeros([1], dtype=tl.float32)
    for col_offset in range(0, n_cols, BLOCK_SIZE):
        col_idx = col_offset + tl.arange(0, BLOCK_SIZE)
        mask = col_idx < n_cols
        vals = tl.load(row_start_ptr + col_idx, mask=mask, other=0.0)
        vals_f32 = vals.to(tl.float32)
        sq_vals = vals_f32 * vals_f32
        sum_sq += tl.sum(tl.where(mask, sq_vals, 0.0))

    mean_sq = sum_sq / n_cols
    rms = tl.sqrt(mean_sq + eps)
    inv_rms = 1.0 / rms

    for col_offset in range(0, n_cols, BLOCK_SIZE):
        col_idx = col_offset + tl.arange(0, BLOCK_SIZE)
        mask = col_idx < n_cols
        vals = tl.load(row_start_ptr + col_idx, mask=mask, other=0.0)
        weight = tl.load(weight_ptr + col_idx, mask=mask, other=1.0)
        vals_f32 = vals.to(tl.float32)
        weight_f32 = weight.to(tl.float32)
        output_f32 = vals_f32 * inv_rms * weight_f32
        output = output_f32.to(vals.dtype)
        tl.store(output_row_start_ptr + col_idx, output, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    """Host wrapper: flatten to 2D, launch one kernel, restore shape.

    Args:
        inputs: dict with keys `input` (..., hidden_size), `weight`
            (hidden_size,), `eps` (float).

    Returns:
        dict with key `output`: tensor of same shape/dtype as `input`.
    """
    input = inputs["input"]
    weight = inputs["weight"]
    eps = inputs["eps"]

    original_shape = input.shape
    input_2d = input.reshape(-1, input.shape[-1]).contiguous()
    weight = weight.contiguous()

    n_rows, n_cols = input_2d.shape
    output = torch.empty_like(input_2d)

    BLOCK_SIZE = 1024
    grid = (n_rows,)
    _rms_norm_kernel[grid](
        input_2d,
        weight,
        output,
        input_2d.stride(0),
        output.stride(0),
        n_cols,
        eps,
        BLOCK_SIZE=BLOCK_SIZE,
    )
    return {"output": output.reshape(original_shape)}
