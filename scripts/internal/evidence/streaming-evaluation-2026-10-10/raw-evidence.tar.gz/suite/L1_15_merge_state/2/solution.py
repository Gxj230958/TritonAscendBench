"""L1_15_merge_state -- Triton-Ascend candidate (round 4).

Split-KV merge of two partial attention states. For every (token, head)
pair, with m = max(p_lse, s_lse):

    p_w    = exp(p_lse - m)
    s_w    = exp(s_lse - m)
    out_se = p_w + s_w                        (deliberately un-clamped)
    output = p_out * (p_w / out_se) + s_out * (s_w / out_se)   -> bf16
    lse    = log(out_se) + m                                     -> fp32

The load-bearing semantics are unchanged from the frozen definition:

* ``+inf`` is the empty-split sentinel and is rewritten to ``-inf`` before
  the max, with ``tl.where`` so both arms stay elementwise. When both sides
  are ``-inf`` the recombination is undefined: ``-inf - -inf`` is NaN and NaN
  propagates into both outputs. That is reproduced here, not smoothed away.
* LSE arithmetic is fp32 throughout. The bf16 head vectors widen with
  ``.to(tl.float32)`` before the multiply-add and narrow only at the store.
* ``lse`` output keeps the dtype of the incoming LSE tensors.

Round 3 -> round 4: one change, and it is a subtraction. The two identity
``tl.where`` guards that round 3 put between the products and the addition are
removed. Everything else -- tile ladder, grid, masking, launch options,
returned keys, and the arithmetic itself -- is byte-equivalent to round 3.

Why the guards go. Round 3 claimed a product feeding an addition gets
contracted into one fused multiply-add, and that the resulting single-fewer
rounding was what moved 22 shapes off tolerance. That claim is now settled
against the tool chain itself rather than argued from the numbers, and it is wrong:

* The round-2 and round-3 runs came back with the same 20/42 and, shape by
  shape, the same ``max_abs`` and ``max_rel`` to six significant figures (P3
  0.00781/0.0169 against 0.00781/0.0169, P24 0.00195/0.00427 against
  0.00195/0.00427, H7 0.00195/0.00398 against 0.00195/0.00398, all 42). Two
  different lowering-level programs producing identical output on 42 shapes
  means the guards changed no value and no instruction sequence that matters.
* The installed tool chain's own build cache still holds the emitted programs
  for both forms: 35 builds end ``mulf, mulf, addf, truncf`` and 5 end
  ``mulf, mulf, select, select, addf, truncf``. The guards did reach the
  back end -- they were not canonicalised away, as round 3 had guessed -- and
  the sequence was never ``fma`` in either case. There is no contraction at
  this level to prevent, so the guards guarded nothing.
* ``enable_fp_fusion`` is declared by the installed Ascend option set but is
  read by no stage in it, and a probe built with the flag set both ways
  produces byte-identical Triton IR (``mulf``, ``mulf``, ``addf``). The switch
  that would express this hypothesis is inert here, so it is not used either.

Removing two vector selects per element is therefore a free deletion on the
arithmetic and a small one on the instruction stream. It is also the honest
move: keeping ops whose only justification is a disproven theory adds cost
and misleads whoever reads this next.

What the 22 failures actually are. Every failure is ``_out0`` alone; the fp32
``_out1`` has never failed on any of the 42 shapes. Each ``max_abs`` is
exactly one bf16 step at the magnitude of the offending element (0.00195 at
|v| in [0.25,0.5), 0.00391 at [0.5,1), 0.00781 at [1,2), 0.0156 at [2,4)),
and the shapes with a large reported ``max_rel`` (P4 1.78, P30 0.0909) report
it at a ``max_abs`` of one step, which is a rounding-direction flip on an
element near zero. The pass set and the fail set are separated by element
count, not by shape or head size: everything up to 131072 elements passes,
then it is a coin flip, and past about 1.6M elements nothing passes. Fitting
that curve gives one perturbed bf16 element per 5e5 to 1e6 elements, i.e. a
per-element rate of order 1e-6 for a value that already differs by a whole
fp32 step from the reference.

That is a rounding agreement rate of about 99.9985 percent of the fp32 value
fed to the store, which is what an ``exp`` that agrees with the reference to
better than one fp32 step but not bit for bit produces: the reference
round-trips these values through a bf16 store, whose spacing is 2e-3 relative,
so a residual fp32 disagreement of ~1e-6 relative can only ever show up as the
single-step flip on the ~1 element in 6e5 that sits within that disagreement
of a bf16 midpoint. Consistent with this, the perturbation is row-correlated
(the ``exp`` is evaluated once per (token, head) pair) yet small enough that
the shapes with tens of millions of elements are the only ones that fail with
certainty.

Two independent facts say this ceiling is not ours alone. The frozen upstream
implementation is recorded in this task's own metadata as
``golden_source: dtype_ceiling_accepted``, and the 24 shapes it lists as
``CEILING_ACCEPTED`` are precisely the 22 that fail here plus two; their
recorded ``max_abs`` are the same single bf16 steps we report (P3 0.0078125,
P24 0.001953125, P4 0.015625, H7 0.001953125). An implementation that
reproduces the reference's arithmetic on the reference's own hardware does not
meet atol/rtol = 1e-3 on these shapes either. So the remaining gap is the
precision of the fp32 transcendental against the eager reference, not kernel
structure, and the last two rounds spent it on structure.

Levers deliberately not pulled this round, with the reasons recorded so they
are not retried blind:

* ``tl.math.div_rn`` on the two scales. It looks like a real lever and is
  not: it reaches the front end as a distinct operation, but the installed
  adapter lowers that straight back to the same ``arith.divf`` a plain ``/``
  gets, so the emitted program is unchanged. Inert, like the fusion switch.
  Checked rather than assumed, because a second round spent on a no-op switch
  is the failure mode this task has now hit twice.
* Reassociating to ``(p_w*p_out + s_w*s_out)/out_se``. Measured on the same
  host probe this is worse by a factor of two (violations 2.47e-6 against
  1.21e-6): it is a different expression, not a cheaper evaluation of the
  same one, and it breaks the contract's arithmetic.
* ``tl.fma`` is exactly the wrong direction and is not used.
* ``TRITON_DISABLE_FFTS`` is an environment variable read by the run time;
  setting it from a candidate is a global environment override and selects a
  different memory path, so it is out on both grounds.
* Mask-free specialisation, which would skip the masked-access lowering on the
  shapes where the tile divides exactly, is held back. It multiplies the
  number of distinct program variants, and round 1 lost H7 to a refused late
  JIT request. Trading 20 shapes that already pass for a few percent on the
  host-time floor that dominates 40 of the 42 measurements is a bad exchange.

Geometry, tile ladder, launch cap and masking are untouched from rounds 2 and
3: that part ran on all 42 shapes in both. Layout assumption stays contiguous
``*_output`` [B, H, D] and contiguous ``*_lse`` / LSE output [B, H], so the
pair index ``token * num_heads + head`` is exactly the row index of those
tensors, head scaling folds into the row index, and the stride-1 accesses stay
wide.
"""

import torch
import triton
import triton.language as tl

# Hard ceiling the installed run-time enforces on the program product.
_PROGRAM_LIMIT = 65535

# Closed tile ladder: head upper bound -> (BLOCK_D, BLOCK_T). Every rung is
# 4096 lanes per program, so one num_warps serves them all, and a rung is
# entered by any head size up to its bound, which keeps masked-off lanes to
# at most one rung step.
_LADDER = ((16, 16, 256), (64, 64, 64), (256, 256, 16), (1 << 30, 1024, 4))


@triton.jit(do_not_specialize=["N_PAIRS", "HEAD_SIZE"])
def _merge_state_tile(
    out_ptr,
    out_lse_ptr,
    p_out_ptr,
    p_lse_ptr,
    s_out_ptr,
    s_lse_ptr,
    N_PAIRS,
    HEAD_SIZE,
    BLOCK_T: tl.constexpr,
    BLOCK_D: tl.constexpr,
    INT64_IDX: tl.constexpr,
):
    rows = tl.program_id(0) * BLOCK_T + tl.arange(0, BLOCK_T)
    cols = tl.program_id(1) * BLOCK_D + tl.arange(0, BLOCK_D)
    if INT64_IDX:
        # Only reachable past 2**31 head-plane elements; widening the row base
        # is enough because the column offset is bounded by BLOCK_D.
        rows = rows.to(tl.int64)
    row_ok = rows < N_PAIRS
    tile_ok = row_ok[:, None] & (cols[None, :] < HEAD_SIZE)
    base = rows[:, None] * HEAD_SIZE + cols[None, :]

    # Row-wise LSE recombination; one evaluation serves every column.
    p_lse = tl.load(p_lse_ptr + rows, mask=row_ok, other=0.0)
    s_lse = tl.load(s_lse_ptr + rows, mask=row_ok, other=0.0)
    p_lse = tl.where(p_lse == float("inf"), float("-inf"), p_lse)
    s_lse = tl.where(s_lse == float("inf"), float("-inf"), s_lse)

    max_lse = tl.maximum(p_lse, s_lse)
    p_w = tl.exp(p_lse - max_lse)
    s_w = tl.exp(s_lse - max_lse)
    out_se = p_w + s_w

    # When a head vector spans several column chunks each chunk recomputes and
    # rewrites the identical LSE value, so the extra stores are idempotent
    # rather than racy.
    tl.store(out_lse_ptr + rows, tl.log(out_se) + max_lse, mask=row_ok)

    p_scale = (p_w / out_se)[:, None]
    s_scale = (s_w / out_se)[:, None]

    p_vec = tl.load(p_out_ptr + base, mask=tile_ok, other=0.0).to(tl.float32)
    s_vec = tl.load(s_out_ptr + base, mask=tile_ok, other=0.0).to(tl.float32)

    # Two products and their sum, each rounded on its own, which is the
    # sequence the definition performs. The emitted program ends
    # mulf, mulf, addf, truncf -- three fp32 roundings and the bf16 narrow.
    merged = p_vec * p_scale + s_vec * s_scale

    tl.store(out_ptr + base, merged.to(out_ptr.dtype.element_ty), mask=tile_ok)


def _tile_shape(head_size):
    """One fixed tile per head size, drawn from the closed ladder."""
    block_d, block_t = _LADDER[-1][1], _LADDER[-1][2]
    for head_max, rung_d, rung_t in _LADDER:
        if head_size <= head_max:
            block_d, block_t = rung_d, rung_t
            break
    return block_t, block_d


def _grid(n_pairs, head_size):
    """(grid_x, grid_y, BLOCK_T, BLOCK_D); program product stays under the cap."""
    block_t, block_d = _tile_shape(head_size)
    chunks = -(-head_size // block_d)
    while -(-n_pairs // block_t) * chunks > _PROGRAM_LIMIT:
        block_t *= 2
    return -(-n_pairs // block_t), chunks, block_t, block_d


def npu_triton_impl(inputs: dict) -> dict:
    prefix_output = inputs["prefix_output"].contiguous()
    prefix_lse = inputs["prefix_lse"].contiguous()
    suffix_output = inputs["suffix_output"].contiguous()
    suffix_lse = inputs["suffix_lse"].contiguous()

    head_size = prefix_output.shape[2]
    n_pairs = prefix_output.shape[0] * prefix_output.shape[1]
    grid_rows, grid_cols, block_t, block_d = _grid(n_pairs, head_size)
    int64_idx = n_pairs * head_size >= 2**31

    out = torch.empty_like(prefix_output)
    out_lse = torch.empty_like(prefix_lse)

    _merge_state_tile[(grid_rows, grid_cols)](
        out,
        out_lse,
        prefix_output,
        prefix_lse,
        suffix_output,
        suffix_lse,
        n_pairs,
        head_size,
        BLOCK_T=block_t,
        BLOCK_D=block_d,
        INT64_IDX=int64_idx,
        num_warps=8,
    )

    # Positional names of the two-value result, exactly as the output
    # manifest resolves them. No aliases, unchanged from round 3.
    return {"_out0": out, "_out1": out_lse}
