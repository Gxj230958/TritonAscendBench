"""L1_15_merge_state -- Triton-Ascend candidate (round 2).

Split-KV merge of two partial attention states. For every (token, head)
pair, with m = max(p_lse, s_lse):

    p_w        = exp(p_lse - m)
    s_w        = exp(s_lse - m)
    out_se     = p_w + s_w                       (deliberately un-clamped)
    output     = p_out * (p_w / out_se) + s_out * (s_w / out_se)   -> bf16
    output_lse = log(out_se) + m                                    -> fp32

The load-bearing semantics are unchanged from the frozen definition:

* ``+inf`` is the empty-split sentinel and is rewritten to ``-inf`` before
  the max, with ``tl.where`` so both arms stay elementwise. When both sides
  are ``-inf`` the recombination is undefined: ``-inf - -inf`` is NaN and NaN
  propagates into both outputs. That is reproduced here, not smoothed away.
* LSE arithmetic is fp32 throughout. The bf16 head vectors widen with
  ``.to(tl.float32)`` before the multiply-add and narrow only at the store,
  so no intermediate rounding is added.
* ``output_lse`` keeps the dtype of the incoming LSE tensors.

Round 1 -> round 2: three mechanical fixes, no numeric change. Every public
shape failed on "missing output '_out1'", P4 failed on a rejected grid, and
the last hidden shape failed on a blocked JIT request.

1. Returned keys. The evaluator resolves outputs through the positional
   manifest names ``_out0`` / ``_out1`` that a two-value return is folded
   into, so round 1's LSE tensor never resolved. Both the positional names
   and the descriptive ones are returned now and refer to the same tensors,
   so either manifest scheme resolves.
2. Launch geometry. The installed runtime refuses any launch whose program
   product exceeds 65535 unless all-blocks-parallel is exported, and round 1
   asked for exactly 65536 programs on P4. The grid is axis 0 = row blocks,
   axis 1 = head chunks, and the row-block size doubles until the product
   clears the cap, so no reachable shape can hit it.
3. JIT variant count. Round 1 fed ``HEAD_SIZE`` in as a constexpr and derived
   the tile shape from it, so every fresh head length forked a new
   specialization -- H7 with its head length of 1 asked for one no earlier
   shape had produced, and the audit layer refused it. The tile now comes
   from a closed four-rung ladder and ``N_PAIRS`` / ``HEAD_SIZE`` are runtime
   scalars excluded from specialization, so at most four specializations
   exist for the entire shape set, every rung is already demanded by a public
   shape, and no hidden shape can fork a fifth. There is deliberately no
   dynamic tile loop: one program does exactly one tile, so nothing beyond
   the round-1 load/store pattern is asked of the back-end.

Layout assumption: contiguous ``*_output`` [B, H, D] and contiguous
``*_lse`` / lse output [B, H]. The pair index ``token * num_heads + head`` is
exactly the row index of those tensors, so head scaling folds into the row
index and loads and stores stay wide and stride-1.
"""

import torch
import triton
import triton.language as tl

# Hard ceiling the installed run-time enforces on the program product.
_PROGRAM_LIMIT = 65535

# Closed tile ladder: head upper bound -> (BLOCK_D, BLOCK_T). Every rung is
# 4096 lanes per program, so one num_warps serves them all, and a rung is
# entered by any head size up to its bound, which keeps masked-off lanes to
# at most one rung step.
_LADDER = ((16, 16, 256), (64, 64, 64), (256, 256, 16), (1 << 30, 1024, 4))


@triton.jit(do_not_specialize=["N_PAIRS", "HEAD_SIZE"])
def _merge_state_tile(
    out_ptr,
    out_lse_ptr,
    p_out_ptr,
    p_lse_ptr,
    s_out_ptr,
    s_lse_ptr,
    N_PAIRS,
    HEAD_SIZE,
    BLOCK_T: tl.constexpr,
    BLOCK_D: tl.constexpr,
    INT64_IDX: tl.constexpr,
):
    rows = tl.program_id(0) * BLOCK_T + tl.arange(0, BLOCK_T)
    cols = tl.program_id(1) * BLOCK_D + tl.arange(0, BLOCK_D)
    if INT64_IDX:
        # Only reachable past 2**31 head-plane elements; widening the row base
        # is enough because the column offset is bounded by BLOCK_D.
        rows = rows.to(tl.int64)
    row_ok = rows < N_PAIRS
    tile_ok = row_ok[:, None] & (cols[None, :] < HEAD_SIZE)
    base = rows[:, None] * HEAD_SIZE + cols[None, :]

    # Row-wise LSE recombination; one evaluation serves every column.
    p_lse = tl.load(p_lse_ptr + rows, mask=row_ok, other=0.0)
    s_lse = tl.load(s_lse_ptr + rows, mask=row_ok, other=0.0)
    p_lse = tl.where(p_lse == float("inf"), float("-inf"), p_lse)
    s_lse = tl.where(s_lse == float("inf"), float("-inf"), s_lse)

    max_lse = tl.maximum(p_lse, s_lse)
    p_w = tl.exp(p_lse - max_lse)
    s_w = tl.exp(s_lse - max_lse)
    out_se = p_w + s_w

    # When a head vector spans several column chunks each chunk recomputes and
    # rewrites the identical LSE value, so the extra stores are idempotent
    # rather than racy.
    tl.store(out_lse_ptr + rows, tl.log(out_se) + max_lse, mask=row_ok)

    p_scale = (p_w / out_se)[:, None]
    s_scale = (s_w / out_se)[:, None]

    p_vec = tl.load(p_out_ptr + base, mask=tile_ok, other=0.0)
    s_vec = tl.load(s_out_ptr + base, mask=tile_ok, other=0.0)
    merged = p_vec.to(tl.float32) * p_scale + s_vec.to(tl.float32) * s_scale
    tl.store(out_ptr + base, merged.to(out_ptr.dtype.element_ty), mask=tile_ok)


def _tile_shape(head_size):
    """One fixed tile per head size, drawn from the closed ladder."""
    block_d, block_t = _LADDER[-1][1], _LADDER[-1][2]
    for head_max, rung_d, rung_t in _LADDER:
        if head_size <= head_max:
            block_d, block_t = rung_d, rung_t
            break
    return block_t, block_d


def _grid(n_pairs, head_size):
    """(grid_x, grid_y, BLOCK_T, BLOCK_D); program product stays under the cap."""
    block_t, block_d = _tile_shape(head_size)
    chunks = -(-head_size // block_d)
    while -(-n_pairs // block_t) * chunks > _PROGRAM_LIMIT:
        block_t *= 2
    return -(-n_pairs // block_t), chunks, block_t, block_d


def npu_triton_impl(inputs: dict) -> dict:
    prefix_output = inputs["prefix_output"].contiguous()
    prefix_lse = inputs["prefix_lse"].contiguous()
    suffix_output = inputs["suffix_output"].contiguous()
    suffix_lse = inputs["suffix_lse"].contiguous()

    head_size = prefix_output.shape[2]
    n_pairs = prefix_output.shape[0] * prefix_output.shape[1]
    grid_rows, grid_cols, block_t, block_d = _grid(n_pairs, head_size)
    int64_idx = n_pairs * head_size >= 2**31

    out = torch.empty_like(prefix_output)
    out_lse = torch.empty_like(prefix_lse)

    _merge_state_tile[(grid_rows, grid_cols)](
        out,
        out_lse,
        prefix_output,
        prefix_lse,
        suffix_output,
        suffix_lse,
        n_pairs,
        head_size,
        BLOCK_T=block_t,
        BLOCK_D=block_d,
        INT64_IDX=int64_idx,
        num_warps=8,
    )

    # `_out0` / `_out1` mirror the positional output manifest that a
    # two-value result is folded into; `output` / `output_lse` are the
    # descriptive names. Each pair refers to the same tensors.
    return {
        "_out0": out,
        "_out1": out_lse,
        "output": out,
        "output_lse": out_lse,
    }
