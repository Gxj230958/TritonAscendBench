"""Triton-Ascend implementation of the chunked 16x16 -> 32x32 unit
lower-triangular inverse merge.

For every 32x32 chunk of the strictly lower triangular input ``A``
(laid out as ``[B, T, H, BT]`` with ``BT == 32``) the returned tensor is

    (I + tril(A, -1))^{-1}

computed with the block identity

    [[A11, 0 ],      [[A11^-1,        0        ],
     [A21, A22]]  -> [-A22^-1 A21 A11^-1, A22^-1]]

where A11 / A22 are the two 16x16 diagonal blocks of ``I + A`` and A21 is
the bottom-left 16x16 block of ``A``.  The 16x16 diagonal inverses are
produced by the row-at-a-time recurrence (row ``i`` of ``X`` is
``-A[i, :16]`` corrected by the already-resolved rows), and the off-block
is one pair of 16x16x16 matrix products so the cube unit does the work.

Chunk grouping (this round's change)
------------------------------------
The measured per-shape cost of the previous candidate is a fixed launch
floor plus a term that grows linearly with the number of launched chunk
programs, about 1 us per program.  That term is the serial part of the
work: the row recurrence is a chain of 14 steps, every step ends in a
reduction over the tile's first axis, and nothing inside one chunk can
move past that chain.

Neighbouring chunks are completely independent, so a program now serves
``NC`` consecutive chunks from a statically unrolled body.  The arithmetic
per chunk is untouched, but the independent chains of the ``NC`` chunks can
issue side by side, and the per-program setup and epilogue cost is shared
across ``NC`` chunks instead of being paid once per chunk.  The grid shrinks
by ``NC``.  A group slot past the last chunk clamps onto that last chunk and
has its stores masked off, so no partial group needs a branch and no chunk
is left unwritten.

Everything runs in float32 with IEEE-precision dots, which keeps the
accumulation order and the cast order of the reference math.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _one_chunk(
    A_ptr,
    Ai_ptr,
    chunk,
    hs,
    K: tl.constexpr,
    m_st,
):
    # Element offset of this chunk inside both tensors; hs is the element
    # stride between consecutive rows of the chunk (H * BT).
    p_src = A_ptr + chunk
    p_dst = Ai_ptr + chunk

    o_k = tl.arange(0, K)
    m_strict = o_k[:, None] > o_k[None, :]
    m_eye = o_k[:, None] == o_k[None, :]

    # Diagonal 16x16 blocks and the bottom-left 16x16 block of the chunk.
    b_a11 = tl.load(p_src + o_k[:, None] * hs + o_k[None, :]).to(tl.float32)
    b_a22 = tl.load(
        p_src + (K + o_k[:, None]) * hs + (K + o_k[None, :])
    ).to(tl.float32)
    b_a21 = tl.load(p_src + (K + o_k[:, None]) * hs + o_k[None, :]).to(tl.float32)

    # Strictly lower part, negated: rows below the current one are still
    # placeholders, rows above the current one get overwritten in the loop.
    b_x11 = -tl.where(m_strict, b_a11, 0.0)
    b_x22 = -tl.where(m_strict, b_a22, 0.0)

    # T is a multiple of BT, so every chunk is full: 16 rows per diagonal
    # block, rows 0 and 1 already hold their final value.
    for i in tl.static_range(2, K):
        m_row = (o_k == i)[:, None]
        m_lhs = o_k < i  # only resolved rows may feed the correction term

        b_r11 = -tl.load(p_src + i * hs + o_k).to(tl.float32)
        b_r11 = tl.where(m_lhs, b_r11, 0.0)
        b_r11 = b_r11 + tl.sum(b_r11[:, None] * b_x11, 0)
        b_x11 = tl.where(m_row, b_r11, b_x11)

        b_r22 = -tl.load(p_src + (K + i) * hs + K + o_k).to(tl.float32)
        b_r22 = tl.where(m_lhs, b_r22, 0.0)
        b_r22 = b_r22 + tl.sum(b_r22[:, None] * b_x22, 0)
        b_x22 = tl.where(m_row, b_r22, b_x22)

    b_x11 = b_x11 + m_eye.to(tl.float32)
    b_x22 = b_x22 + m_eye.to(tl.float32)

    # -A22^-1 @ A21 @ A11^-1
    b_x21 = -tl.dot(
        tl.dot(b_x22, b_a21, input_precision="ieee"),
        b_x11,
        input_precision="ieee",
    )

    b_zero = tl.zeros((K, K), dtype=tl.float32)

    tl.store(p_dst + o_k[:, None] * hs + o_k[None, :], b_x11, mask=m_st)
    tl.store(
        p_dst + (K + o_k[:, None]) * hs + (K + o_k[None, :]), b_x22, mask=m_st
    )
    tl.store(p_dst + (K + o_k[:, None]) * hs + o_k[None, :], b_x21, mask=m_st)
    tl.store(p_dst + o_k[:, None] * hs + (K + o_k[None, :]), b_zero, mask=m_st)


@triton.jit
def _merge_16x16_to_32x32_inverse_npu(
    A_ptr,
    Ai_ptr,
    T,
    M,
    NT: tl.constexpr,
    H: tl.constexpr,
    BT: tl.constexpr,
    K: tl.constexpr,
    NC: tl.constexpr,
):
    # 1-D launch grid of size ceil(M / NC) with M = NT * B * H chunk programs
    # worth of work; axis 0 is the chunk index inside the sequence, the
    # remaining factor is the folded (batch, head) index.
    pid = tl.program_id(0)

    o_k = tl.arange(0, K)
    m_all = (o_k[:, None] >= 0) & (o_k[None, :] >= 0)

    hs = H * BT  # element stride between consecutive rows of one chunk

    for s in tl.static_range(NC):
        g = pid * NC + s
        valid = g < M
        # Clamping keeps every address in range for the padding slots of a
        # short last group; their stores are masked off below.
        g = tl.minimum(g, M - 1)

        i_t = g % NT
        i_bh = g // NT
        i_b = i_bh // H
        i_h = i_bh % H

        chunk = (i_b * T + i_t * BT) * hs + i_h * BT
        _one_chunk(A_ptr, Ai_ptr, chunk, hs, K, m_all & valid)


def npu_triton_impl(inputs: dict) -> dict:
    A = inputs["A"]
    if A.dtype != torch.float32:
        A = A.to(torch.float32)
    A = A.contiguous()

    B, T, H, BT = A.shape
    K = 16
    NT = T // BT
    NC = 4

    Ai = torch.empty((B, T, H, BT), dtype=torch.float32, device=A.device)

    _merge_16x16_to_32x32_inverse_npu[(NT * B * H + NC - 1) // NC,](
        A,
        Ai,
        T,
        NT * B * H,
        NT,
        H,
        BT,
        K,
        NC,
        num_warps=4,
    )
    return {"output": Ai}
