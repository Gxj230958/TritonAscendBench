"""Triton-Ascend migration of L2_33_moe_mmk (moe_mmk) -- round 4.

Contract semantics: a dense per-expert batched matmul with a per-expert row
window.

    a  [E, T, D]      bf16   activations gathered per expert
    b  [E, N, D]      bf16   expert weights
    expert_num_tokens [E]    int64, each entry in [0, T]

    out[e, :m, :] = a[e, :m] @ b[e].T    with m = expert_num_tokens[e]
    out[e, m:, :] = 0                    (rows past the window)
    out dtype: fp32

The graded device routine is the matmul-K accumulator `moe_mmk`: an fp32
accumulator seeded before the loop, one `tl.dot(a, b, acc=accumulator)` per
[BLOCK_M, BLOCK_K] x [BLOCK_K, BLOCK_N] tile spanning the whole K extent, and a
single `.to(compute_type)` after the loop with compute_type = fp32. No scale
term and no per-group multiply sits on this path, so the migrated arithmetic is
exactly: bf16 operands, fp32 accumulation from the first K tile, one cast after
the loop. b is [E, N, K] and is walked as [K, N] through its own strides
(`stride_bk` takes the last axis, `stride_bn` the middle one), which is the
transposed read that contracts the shared axis K and produces a @ b.T. The row
window is the launcher's job, and here it is enforced twice over -- the stored
value is selected against the window and the store itself is gated -- which is
the part round 2 proved on the device.

What round 4 changes, and why
-----------------------------
Round 3 passed 41 of 45 shapes, and the four it lost are not arithmetic
failures: P10, P11, P12 and P13 report

    RuntimeAuditViolation: Layer E: blocked runtime operation 'compile'

with no timing at all. Those four are exactly the shapes routed to the kernel
round 3 added for a contracted extent below the 16 that `tl.dot` demands -- the
one device function whose body is a `tl.static_range(K)` chain of rank-one fp32
updates and contains no `tl.dot`. The two shapes with the same geometry at
`D` = 1 (P9, H5) went through that same kernel and passed, so the construct is
not broken in general; what scales with `K` is the unrolled body, which grows
`K` copies of a [BLOCK_M, BLOCK_N] fp32 multiply-add into the single tensor-op
free function. At `D` = 1 the body is one statement. Whatever the audit layer
objects to, the honest reading of the evidence is that this round should stop
exercising it: no second kernel, no `tl.static_range`, no tensor of rank-one
updates, and in fact not one new lowering on this task.

So the contracted axis is widened in memory instead of in the reduction. For
`D` < 16 the host materialises `a` and `b` with their last axis padded to 16 --
zeros beyond the real extent -- and hands the *identical* round 3 cube kernel
the padded extent as `K`. The dot product then has 16 lanes, `16 - D` of them
multiplying a real value by an exact zero, which returns the same fp32 sum as
the `D` real terms alone: each pad term is `x * 0.0 = 0.0` and folding zeros
into an fp32 accumulator cannot change it, because every real partial sum is
already representable in fp32. This is the arithmetic the reference performs for
every `D` that is a multiple of `BLOCK_K` -- a fixed lane count whose trailing
lanes contribute zero -- and it is the shape of the reduction this kernel
already runs on the 41 shapes that passed. The pad lives in the operands, not
in the accumulator, so no operand lane is ever asked to stand for zero by a
select, which is the construct round 2 lost P10..P13 over, and no register tile
is ever multiplied out by a loop the frontend has to unroll, which is the
construct round 3 lost them over.

The cost of that choice is bounded and small: the pad touches only `D` in
{2, 3, 4, 8}, four shapes whose whole problem is 7.1 MFLOP at most and whose
weights are 1.2 MB at most, and the pad copies (24 KB and 393 KB) are dwarfed by
the [E, T, N] fp32 destination that every version of this candidate allocates
and zeroes. The cube path itself does not move this round at all: the same tile
caps, the same grid, the same clamped loads, the same window gate, `num_warps=1`
and `num_stages=2`, and the same zero-initialised destination. Nothing about the
geometry that passed 41 shapes moves, and the only device function in the file
is the one those 41 shapes ran.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def moe_batched_gemm(
    a_ptr,
    b_ptr,
    c_ptr,
    num_tokens_ptr,
    T,
    N,
    K,
    stride_ae: tl.int64,
    stride_am: tl.int64,
    stride_ak: tl.int64,
    stride_be: tl.int64,
    stride_bk: tl.int64,
    stride_bn: tl.int64,
    stride_ce: tl.int64,
    stride_cm: tl.int64,
    stride_cn: tl.int64,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    M_TAIL: tl.constexpr,
    N_TAIL: tl.constexpr,
    K_TAIL: tl.constexpr,
):
    expert = tl.program_id(0).to(tl.int64)
    # Token counts and extents fit comfortably in int32; only the byte offsets
    # reached through the int64 strides need the wider type.
    num_tokens = tl.load(num_tokens_ptr + expert).to(tl.int32)

    pid_mn = tl.program_id(1)
    num_pid_n = tl.cdiv(N, BLOCK_N)
    pid_m = pid_mn // num_pid_n
    pid_n = pid_mn - pid_m * num_pid_n
    m_start = pid_m * BLOCK_M

    offs_m = m_start + tl.arange(0, BLOCK_M)
    offs_n = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    offs_k = tl.arange(0, BLOCK_K)

    mask_w = offs_m < num_tokens
    # Coverage plus the window: the grid reaches this expert's whole [T, N]
    # plane, and rows past the window are left to the zeroed destination.
    mask_c = mask_w[:, None] & (offs_m[:, None] < T) & (offs_n[None, :] < N)
    c_ptrs = (
        c_ptr
        + expert * stride_ce
        + offs_m[:, None] * stride_cm
        + offs_n[None, :] * stride_cn
    )

    row = offs_m
    if M_TAIL:
        row = tl.minimum(offs_m, T - 1)
    col = offs_n
    if N_TAIL:
        col = tl.minimum(offs_n, N - 1)

    # Full tiles only: BLOCK_K is chosen to divide K, so every lane of every
    # tile is a real element and no load needs a mask. K_TAIL guards the one
    # case where a divisor at or above 16 does not exist (K = 24, 40, ...),
    # and it is a masked load on the last tile -- not a widened reduction.
    k_full = K // BLOCK_K

    # Floored at one pass so that what gets stored is always the result of a
    # real tl.dot, even for a tile the window does not reach.
    k_tiles = tl.where(m_start < num_tokens, k_full, 1)

    accumulator = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    a_ptrs = (
        a_ptr
        + expert * stride_ae
        + row[:, None] * stride_am
        + offs_k[None, :] * stride_ak
    )
    b_ptrs = (
        b_ptr
        + expert * stride_be
        + offs_k[:, None] * stride_bk
        + col[None, :] * stride_bn
    )
    for k in range(0, k_tiles):
        a = tl.load(a_ptrs)
        b = tl.load(b_ptrs)
        accumulator = tl.dot(a, b, acc=accumulator)
        a_ptrs += BLOCK_K * stride_ak
        b_ptrs += BLOCK_K * stride_bk

    if K_TAIL:
        # The ragged last tile, masked on the elements that do not exist.
        k_rem = K - k_full * BLOCK_K
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_rem, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_rem, other=0.0)
        accumulator = tl.dot(a, b, acc=accumulator)

    # The window is enforced on the value as well as on the store: a row outside
    # it can only ever contribute an exact zero.
    value = tl.where(mask_w[:, None], accumulator, 0.0)
    tl.store(c_ptrs, value.to(tl.float32), mask=mask_c)


def _block(extent, cap):
    """Power-of-two tile in [16, cap]: a divisor of `extent` when one exists
    (then no remainder is generated at all), else the largest tile the extent
    can still fill."""
    divisor = 16
    while divisor * 2 <= cap and extent % (divisor * 2) == 0:
        divisor *= 2
    if extent % divisor == 0 and divisor <= extent:
        return divisor
    block = 16
    while block * 2 <= cap and block * 2 <= extent:
        block *= 2
    return block


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"].contiguous()
    b = inputs["b"].contiguous()
    num_tokens = inputs["expert_num_tokens"].contiguous()

    E, T, D = a.shape
    N = b.shape[1]

    # A contracted extent below the tl.dot floor is widened in memory, never in
    # the reduction: the padded lanes are zeros in the operands.
    K = max(D, 16)
    if K != D:
        # Contracted axis widened in memory: a zero-filled operand with the real
        # columns copied in. The extra lanes are exact zeros in the operands, so
        # the dot product gains `K - D` terms of the form x * 0.0 = 0.0 and the
        # fp32 sum is bit-for-bit the short one.
        a_pad = torch.zeros((E, T, K), device=a.device, dtype=a.dtype)
        a_pad[:, :, :D] = a
        b_pad = torch.zeros((b.shape[0], N, K), device=b.device, dtype=b.dtype)
        b_pad[:, :, :D] = b
        a, b = a_pad, b_pad

    BLOCK_M = _block(T, 64)
    BLOCK_N = _block(N, 64)
    BLOCK_K = _block(K, 64)

    # Zero-initialised, so a store lane skipped by the window gate is a real
    # zero instead of allocator residue. The kernel does reach every in-window
    # element, so this backs up the padding rather than producing it.
    output = torch.zeros((E, T, N), device=a.device, dtype=torch.float32)
    grid = (E, triton.cdiv(T, BLOCK_M) * triton.cdiv(N, BLOCK_N))

    moe_batched_gemm[grid](
        a,
        b,
        output,
        num_tokens,
        T,
        N,
        K,
        a.stride(0),
        a.stride(1),
        a.stride(2),
        b.stride(0),
        b.stride(2),  # stride_bk: b is walked transposed over its last axis
        b.stride(1),  # stride_bn
        output.stride(0),
        output.stride(1),
        output.stride(2),
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        BLOCK_K=BLOCK_K,
        M_TAIL=T % BLOCK_M != 0,
        N_TAIL=N % BLOCK_N != 0,
        K_TAIL=K % BLOCK_K != 0,
        num_warps=1,
        num_stages=2,
    )

    return {"output": output}
