"""Triton-Ascend implementation of `_fwd_grouped_kernel_stage1`.

Grouped (GQA) decode-attention STAGE-1 partials for a latent-KV decoder.
Each program owns one (batch, query-head block, Dv chunk, kv split) tile and
runs a chunk-local online softmax over its half-open context window
[split_kv_start, split_kv_end).  Per (b, h, s) the kernel writes

    att_out[b, h, s, :Lv] = sum_n softmax(qk)_n * v_n    (acc / e_sum)
    att_out[b, h, s,   Lv] = e_max + log(e_sum)          (window log-sum-exp)

Windows that are empty (start >= end) are never written, so they keep the
zero-initialised buffer value.  Key/value rows are gathered through the
per-request page table (page size 1 => kv_loc == req_to_tokens[b, n]), so the
permuted layout of the dense fixtures is load bearing.

Ascend notes
------------
* BLOCK_H stays pinned at 16: the query-head -> KV-head mapping
  (`cur_kv_head = cur_head_id // cdiv(kv_group_num, BLOCK_H)`) depends on it,
  and the reference reproduces that exact mapping.
* The Dv axis is tiled in blocks of at most 256 lanes so the fp32 accumulator
  and the V tile stay inside the Unified Buffer budget.  The tiles ride on the
  head axis, whose block count the kernel re-derives from its own constexprs.
  Each Dv chunk re-runs the identical score reduction, so a chunk owns its
  context slice and only the chunk with dv_id == 0 writes the log-sum-exp
  column: every address is written by exactly one program, and the values match
  the untiled case.
* `sm_scale` reaches the kernel as a device scalar and is read with `tl.load`,
  the same mechanism the upstream body uses for its k/v scale pointers.
* Cache hints are dropped (scheduler advice only, no effect on the result) and
  the fp8 scaling branches of the upstream body are omitted because every
  fixture here is bf16, so those branches cannot be reached.  The `BLOCK_DPE`
  split-dimension path is kept for faithfulness and stays inert (BLOCK_DPE = 0)
  exactly as the grouped host wrapper pins it.
"""

import torch
import triton
import triton.language as tl


BLOCK_H_UPSTREAM = 16      # grouped host wrapper pins the head block to 16
BLOCK_N_UPSTREAM = 32      # grouped host wrapper pins the token block to 32
MAX_BLOCK_DV = 256         # Unified Buffer friendly Dv tile width
MIN_DOT_BLOCK = 16         # smallest block the dot unit accepts


@triton.jit
def _tanh(x):
    return 2 * tl.sigmoid(2 * x) - 1


@triton.jit
def _fwd_grouped_kernel_stage1(
    Q,
    K_Buffer,
    V_Buffer,
    Scale,
    Req_to_tokens,
    B_Seqlen,
    Att_Out,
    stride_req_to_tokens_b,
    stride_qbs,
    stride_qh,
    stride_buf_kbs,
    stride_buf_kh,
    stride_buf_vbs,
    stride_buf_vh,
    stride_mid_ob,
    stride_mid_oh,
    stride_mid_os,
    kv_group_num: tl.constexpr,
    q_head_num: tl.constexpr,
    BLOCK_DMODEL: tl.constexpr,
    BLOCK_DPE: tl.constexpr,
    BLOCK_DV: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_H: tl.constexpr,
    NUM_KV_SPLITS: tl.constexpr,
    PAGE_SIZE: tl.constexpr,
    logit_cap: tl.constexpr,
    Lk: tl.constexpr,
    Lv: tl.constexpr,
    IS_MLA: tl.constexpr = False,
):
    sm_scale = tl.load(Scale)

    cur_batch = tl.program_id(0)
    # Axis 1 packs (head block, Dv chunk).  The head block varies fastest, so
    # the chunks of one head block are adjacent in the launch order and the
    # dv_id / head decode below stays a pair of integer divisions.
    VALID_BLOCK_H: tl.constexpr = BLOCK_H if kv_group_num > BLOCK_H else kv_group_num
    HEAD_BLOCKS: tl.constexpr = (q_head_num + VALID_BLOCK_H - 1) // VALID_BLOCK_H
    cur_head_id = tl.program_id(1) % HEAD_BLOCKS
    dv_id = tl.program_id(1) // HEAD_BLOCKS
    cur_kv_head = cur_head_id // tl.cdiv(kv_group_num, BLOCK_H)
    split_kv_id = tl.program_id(2)

    cur_head = cur_head_id * VALID_BLOCK_H + tl.arange(0, BLOCK_H)
    mask_h = cur_head < (cur_head_id + 1) * VALID_BLOCK_H
    mask_h = mask_h & (cur_head < q_head_num)

    offs_d = tl.arange(0, BLOCK_DMODEL)
    offs_dv = dv_id * BLOCK_DV + tl.arange(0, BLOCK_DV)
    mask_d = offs_d < Lk
    mask_dv = offs_dv < Lv

    cur_batch_seq_len = tl.load(B_Seqlen + cur_batch).to(tl.int32)
    cur_batch_req_idx = cur_batch

    offs_q = cur_batch * stride_qbs + cur_head[:, None] * stride_qh + offs_d[None, :]
    q = tl.load(Q + offs_q, mask=mask_h[:, None] & mask_d[None, :], other=0.0)

    if BLOCK_DPE > 0:
        offs_dpe = BLOCK_DMODEL + tl.arange(0, BLOCK_DPE)
        mask_dpe = offs_dpe < Lk
        off_qpe = cur_batch * stride_qbs + cur_head[:, None] * stride_qh + offs_dpe[None, :]
        qpe = tl.load(Q + off_qpe, mask=mask_h[:, None] & mask_dpe[None, :], other=0.0)

    kv_len_per_split = tl.cdiv(cur_batch_seq_len, NUM_KV_SPLITS)
    split_kv_start = kv_len_per_split * split_kv_id
    split_kv_end = tl.minimum(split_kv_start + kv_len_per_split, cur_batch_seq_len)

    e_max = tl.zeros([BLOCK_H], dtype=tl.float32) - float("inf")
    e_sum = tl.zeros([BLOCK_H], dtype=tl.float32)
    acc = tl.zeros([BLOCK_H, BLOCK_DV], dtype=tl.float32)

    if split_kv_end > split_kv_start:
        base_offs_k = cur_kv_head * stride_buf_kh + offs_d[:, None]
        base_offs_v = cur_kv_head * stride_buf_vh + offs_dv[None, :]
        if BLOCK_DPE > 0:
            base_offs_kpe = cur_kv_head * stride_buf_kh + offs_dpe[:, None]

        for start_n in range(split_kv_start, split_kv_end, BLOCK_N):
            offs_n = start_n + tl.arange(0, BLOCK_N)
            kv_page_number = tl.load(
                Req_to_tokens + stride_req_to_tokens_b * cur_batch_req_idx + offs_n // PAGE_SIZE,
                mask=offs_n < split_kv_end,
                other=0,
            )
            kv_loc = (kv_page_number * PAGE_SIZE + offs_n % PAGE_SIZE).to(tl.int32)

            offs_buf_k = kv_loc[None, :] * stride_buf_kbs + base_offs_k
            k = tl.load(K_Buffer + offs_buf_k,
                        mask=(offs_n[None, :] < split_kv_end) & mask_d[:, None],
                        other=0.0)
            qk = tl.dot(q, k.to(q.dtype))

            if BLOCK_DPE > 0:
                offs_buf_kpe = kv_loc[None, :] * stride_buf_kbs + base_offs_kpe
                kpe = tl.load(K_Buffer + offs_buf_kpe,
                              mask=(offs_n[None, :] < split_kv_end) & mask_dpe[:, None],
                              other=0.0)
                qk += tl.dot(qpe, kpe.to(qpe.dtype))

            qk *= sm_scale
            if logit_cap > 0:
                qk = logit_cap * _tanh(qk / logit_cap)

            qk = tl.where(mask_h[:, None] & (offs_n[None, :] < split_kv_end), qk, float("-inf"))

            offs_buf_v = kv_loc[:, None] * stride_buf_vbs + base_offs_v
            v = tl.load(V_Buffer + offs_buf_v,
                        mask=(offs_n[:, None] < split_kv_end) & mask_dv[None, :],
                        other=0.0)

            n_e_max = tl.maximum(tl.max(qk, 1), e_max)
            re_scale = tl.exp(e_max - n_e_max)
            p = tl.exp(qk - n_e_max[:, None])
            acc *= re_scale[:, None]
            acc += tl.dot(p.to(v.dtype), v)
            e_sum = e_sum * re_scale + tl.sum(p, 1)
            e_max = n_e_max

        offs_mid_o = (cur_batch * stride_mid_ob + cur_head[:, None] * stride_mid_oh
                      + split_kv_id * stride_mid_os + offs_dv[None, :])
        tl.store(Att_Out + offs_mid_o, acc / e_sum[:, None],
                 mask=mask_h[:, None] & mask_dv[None, :])

        mask_lse = mask_h & (dv_id == 0)
        offs_mid_o_1 = (cur_batch * stride_mid_ob + cur_head * stride_mid_oh
                        + split_kv_id * stride_mid_os + Lv)
        tl.store(Att_Out + offs_mid_o_1, e_max + tl.log(e_sum), mask=mask_lse)


def _launch(q, k_buffer, v_buffer, scale, req_to_tokens, b_seqlen, att_out,
            num_kv_splits, page_size=1, logit_cap=0.0):
    """Grid / strides / constexprs mirror the grouped non-MLA host wrapper."""
    B, head_num, _ = q.shape
    Lk = k_buffer.shape[-1]
    Lv = v_buffer.shape[-1]
    H_KV = k_buffer.shape[-2]

    # Both dot operands need at least 16 lanes on the cube unit; the masks
    # built from Lk / Lv keep the padded lanes at zero.
    BLOCK_DMODEL = max(triton.next_power_of_2(Lk), MIN_DOT_BLOCK)
    BLOCK_DPE = 0
    BLOCK_DV = max(min(triton.next_power_of_2(Lv), MAX_BLOCK_DV), MIN_DOT_BLOCK)
    kv_group_num = head_num // H_KV
    BLOCK_H = BLOCK_H_UPSTREAM
    BLOCK_N = BLOCK_N_UPSTREAM

    head_blocks = triton.cdiv(head_num, min(BLOCK_H, kv_group_num))
    dv_chunks = triton.cdiv(Lv, BLOCK_DV)

    grid = (B, head_blocks * dv_chunks, num_kv_splits)

    _fwd_grouped_kernel_stage1[grid](
        q,
        k_buffer,
        v_buffer,
        scale,
        req_to_tokens,
        b_seqlen,
        att_out,
        req_to_tokens.stride(0),
        q.stride(0),
        q.stride(1),
        k_buffer.stride(-3),
        k_buffer.stride(-2),
        v_buffer.stride(-3),
        v_buffer.stride(-2),
        att_out.stride(0),
        att_out.stride(1),
        att_out.stride(2),
        kv_group_num=kv_group_num,
        q_head_num=head_num,
        BLOCK_DMODEL=BLOCK_DMODEL,
        BLOCK_DPE=BLOCK_DPE,
        BLOCK_DV=BLOCK_DV,
        BLOCK_N=BLOCK_N,
        BLOCK_H=BLOCK_H,
        NUM_KV_SPLITS=num_kv_splits,
        PAGE_SIZE=page_size,
        logit_cap=logit_cap,
        Lk=Lk,
        Lv=Lv,
        IS_MLA=False,
        num_warps=4,
        num_stages=1,
    )
    return att_out


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"].contiguous()
    k_buffer = inputs["k_buffer"].contiguous()
    v_buffer = inputs["v_buffer"].contiguous()
    req_to_tokens = inputs["req_to_tokens"].contiguous()
    b_seqlen = inputs["b_seqlen"].contiguous()
    scale = torch.as_tensor(inputs["scale"], dtype=torch.float32, device=q.device)
    num_kv_splits = inputs["num_kv_splits"]

    B, head_num, _ = q.shape
    Lv = v_buffer.shape[-1]
    C = inputs["req_to_tokens"].numel() // B

    # Page table is a flat permutation of length B*C; the kernel indexes it as
    # [batch, position] with page size 1.
    req_to_tokens = req_to_tokens.reshape(B, C)
    # Zero fill: an empty window is skipped by the kernel and must read back 0.
    att_out = torch.zeros((B, head_num, num_kv_splits, Lv + 1),
                          dtype=torch.float32,
                          device=q.device)
    # Read the split count back off the allocation so it is a plain Python int
    # whether the harness supplied a scalar or a rank-0 index tensor.
    num_kv_splits = att_out.shape[2]

    _launch(q, k_buffer, v_buffer, scale, req_to_tokens, b_seqlen, att_out,
            num_kv_splits=num_kv_splits)

    return {"att_out": att_out}


run = npu_triton_impl
