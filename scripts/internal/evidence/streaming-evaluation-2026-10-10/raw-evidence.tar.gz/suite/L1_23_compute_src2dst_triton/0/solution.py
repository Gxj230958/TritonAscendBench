import torch
import triton
import triton.language as tl


@triton.jit
def compute_src2dst_triton_kernel(reorder_ids, src2dst, num_toks, BLOCK_SIZE: tl.constexpr):
    pid = tl.program_id(axis=0)
    dst_id = pid * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = dst_id < num_toks
    src_id = tl.load(reorder_ids + dst_id, mask=mask)
    tl.store(src2dst + src_id, dst_id, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    reorder_ids = inputs["reorder_ids"]
    num_toks = inputs["num_toks"]
    num = reorder_ids.shape[0]
    BLOCK_SIZE = 512
    grid = (triton.cdiv(num, BLOCK_SIZE),)
    src2dst = torch.empty(num, device=reorder_ids.device, dtype=torch.int32)
    compute_src2dst_triton_kernel[grid](
        reorder_ids, src2dst, num_toks, BLOCK_SIZE
    )
    return {"src2dst": src2dst}
