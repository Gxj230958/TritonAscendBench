"""triton-ascend port of the post-reorder scatter-combine MoE kernel (round 5).

For every output token ``i``, gather its ``topk`` routed expert rows from
``down_output`` (located via ``src2dst``), weight each gathered row by its
router probability in ``topk_weights``, skip slots whose expert id equals the
padding sentinel ``num_local_experts``, sum the weighted rows, scale by
``routed_scaling_factor`` and store the bf16 result into output row ``i``.

Round 5 change (the only change vs round 4): adaptive tile width
----------------------------------------------------------------
Round 4 passed numerics on all 49 shapes with a fixed ``BLOCK_H = 1024``.
That single width is a poor fit for most of the shape grid:

* 43 of the 49 shapes have ``hidden_size <= 512``. With ``BLOCK_H = 1024``
  the kernel body still executes at 1024-lane width while a mask suppresses
  up to 1023/1024 of the lanes (hidden sizes go down to 1), so every
  program does up to 1024x more vector work than its useful width.
* The shapes whose device time rises well above the per-call floor
  (hidden 6144 / 8192, and the 4096-token hidden=512 shape) pay a
  per-program cost: their measured time grows roughly linearly with the
  program count ``num_tokens * cdiv(hidden_size, 1024)``.

Round 5 therefore picks the tile width from the shape:

    BLOCK_H = min over {64,128,256,512,1024,2048} with BLOCK_H >= hidden_size
              (2048 when hidden_size > 2048)

* ``hidden_size <= 2048`` gets one next-power-of-2 tile per row: an exact
  cover for power-of-2 widths and a minimal tail mask otherwise
  (384 -> 512, 96 -> 128, 3 -> 4 floored to 64, ...).
* ``hidden_size > 2048`` tiles the row into ``cdiv(hidden_size, 2048)``
  exact 2048-wide blocks (6144 -> 3, 8192 -> 4), halving the program count
  of the round-4 geometry with no masked-away lanes.
* The 64 lower bound keeps the kernel away from degenerate sub-vector tile
  widths for hidden sizes 1..32; those shapes sit on the per-call floor.

Only six distinct tile widths (64/128/256/512/1024/2048) occur across the
whole shape grid, so the number of distinct kernel specializations stays
small.

Semantics are untouched: the per-element accumulation order (slot 0 then
slot 1, fp32, single-rounding fused multiply-add emulation, final scale,
one bf16 cast at store time) does not depend on the tile width or on how a
row is partitioned across programs, so the output is bit-identical to round
4 for every shape. The host wrapper is unchanged too: the output buffer is
allocated uninitialized and the triton kernel remains the only op that
writes it (every stored lane is written exactly once; all-padded tokens get
an explicitly computed and stored zero row).

Accumulation (carried over from rounds 3/4)
-------------------------------------------
The graded reference accumulates each gathered row with a single-rounding
fused multiply-add. Plain ``acc += row * w`` lowers on this triton-ascend
3.2.0 pipeline to separately rounded multiply and add, which flipped the
final bf16 rounding on 8 shapes in round 1 by one ulp. Round 3 therefore
emulated the single-rounding fused multiply-add with plain fp32 ``*``,
``+``, ``-`` only (Dekker/Veltkamp product splitting plus Knuth two-sum),
which is exact under IEEE round-to-nearest with separately rounded
operators, and all 49 shapes matched bit-for-bit. That emulation is kept
verbatim.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _fused_mul_add_emu(x, w, acc, DEKKER_C: tl.constexpr):
    # Emulate one single-rounding fused multiply-add:
    #   result = RN_f32(x * w + acc)
    # using only separately-rounded fp32 mul/add/sub.
    #
    # 1) Dekker/Veltkamp split of both operands into <=12-significand-bit
    #    halves, then recover the exact product error e with
    #    x*w = p + e exactly (all partial products <= 24 significand bits).
    cx = DEKKER_C * x
    x_hi = cx - (cx - x)
    x_lo = x - x_hi
    cw = DEKKER_C * w
    w_hi = cw - (cw - w)
    w_lo = w - w_hi
    p = x * w
    e = (((x_hi * w_hi - p) + x_hi * w_lo) + x_lo * w_hi) + x_lo * w_lo
    # 2) Knuth two-sum: p + acc = s + e2 exactly.
    s = p + acc
    v = s - p
    e2 = (p - (s - v)) + (acc - v)
    # 3) Fold both exact errors back in: single rounding of x*w + acc.
    return s + (e + e2)


@triton.jit
def _post_reorder_kernel(
    down_output_ptr,
    output_ptr,
    src2dst_ptr,
    topk_ids_ptr,
    topk_weights_ptr,
    num_local_experts,
    routed_scaling_factor,
    hidden_size,
    topk: tl.constexpr,
    BLOCK_H: tl.constexpr,
):
    pid_token = tl.program_id(0)
    pid_h = tl.program_id(1)

    offs_h = pid_h * BLOCK_H + tl.arange(0, BLOCK_H)
    mask_h = offs_h < hidden_size

    acc = tl.zeros([BLOCK_H], dtype=tl.float32)

    # topk is constexpr, so this is a Python-level unrolled loop.
    for j in range(topk):
        slot = pid_token * topk + j
        expert_id = tl.load(topk_ids_ptr + slot)
        valid = (expert_id != num_local_experts).to(tl.float32)
        dst_idx = tl.load(src2dst_ptr + slot)
        w = tl.load(topk_weights_ptr + slot).to(tl.float32)
        row = tl.load(
            down_output_ptr + dst_idx * hidden_size + offs_h,
            mask=mask_h,
            other=0.0,
        ).to(tl.float32)
        # Single-rounding accumulation. ``w_eff`` is exactly ``w`` when the
        # slot is valid and exactly 0 when padded, so the branchless gate
        # adds no extra rounding and padded slots leave acc unchanged.
        acc = _fused_mul_add_emu(row, w * valid, acc, DEKKER_C=4097.0)

    acc = acc * routed_scaling_factor

    out_dtype = output_ptr.dtype.element_ty
    tl.store(
        output_ptr + pid_token * hidden_size + offs_h,
        acc.to(out_dtype),
        mask=mask_h,
    )


_TILE_CANDIDATES = (64, 128, 256, 512, 1024, 2048)


def _tile_width(hidden_size: int) -> int:
    # Smallest power-of-two tile >= hidden_size, clamped into [64, 2048]:
    # exact-width tiles for the common widths, halved program count for wide
    # rows, and a sane lower bound for the hidden sizes 1..32.
    for width in _TILE_CANDIDATES:
        if width >= hidden_size:
            return width
    return 2048


def npu_triton_impl(inputs: dict) -> dict:
    down_output = inputs["down_output"].contiguous()
    src2dst = inputs["src2dst"].contiguous()
    topk_ids = inputs["topk_ids"].contiguous()
    topk_weights = inputs["topk_weights"].contiguous()
    # num_local_experts / topk / routed_scaling_factor arrive as plain Python
    # scalars per the input spec and are passed straight to the kernel.
    num_local_experts = inputs["num_local_experts"]
    topk = inputs["topk"]
    routed_scaling_factor = inputs["routed_scaling_factor"]

    num_tokens = triton.cdiv(src2dst.shape[0], topk)
    hidden_size = down_output.shape[1]
    # Uninitialized allocation: the triton kernel writes every output element
    # exactly once (including explicit zero rows for all-padded tokens), so no
    # torch-side zero-fill op is needed or wanted in the device trace.
    output = down_output.new_empty((num_tokens, hidden_size))

    BLOCK_H = _tile_width(hidden_size)
    grid = (num_tokens, triton.cdiv(hidden_size, BLOCK_H))

    _post_reorder_kernel[grid](
        down_output,
        output,
        src2dst,
        topk_ids,
        topk_weights,
        num_local_experts,
        routed_scaling_factor,
        hidden_size,
        topk=topk,
        BLOCK_H=BLOCK_H,
    )
    return {"output": output}


# Some harnesses look for ``run``; keep a stable alias.
run = npu_triton_impl
