"""Triton-Ascend port of the chunked-GLA output kernel (L3_26), round 3.

Round history:
- Round 1 compiled and ran on the 910B but failed numerically (it skipped
  the reference's TF32 truncation on the inter-chunk dot) and timed out on
  every shape's measurement (both dots used input_precision="ieee", which
  is pathologically slow on this backend even for the tiniest shape).
- Round 2 fixed the numerics (exact TF32 bit-mask + native fp16 cube dot)
  but the kernel no longer compiled on device: every shape failed with
  "Layer E: blocked runtime operation 'compile'" and the compile preflight
  failed. Round 2's structural news vs round 1 was (a) an int32
  bitcast/AND mask, (b) fp16 dots, and (c) -- most invasively -- the
  intra-chunk term rewritten as a fully unrolled BT-iteration (up to 64)
  scalar-row loop with per-iteration masked loads and rank-1 outer-product
  updates, the prime suspect for the device-compile blow-up.

Round 3 = round 1's exact, device-proven kernel structure + round 2's
exact reference numerics:

1. Inter-chunk: gated-query x per-chunk state, with both inputs
   bit-masked to TF32 (identical to the reference `_to_tf32`: keep the
   sign/exponent and top 10 mantissa bits, i.e. drop the low 13 fp32
   mantissa bits) and cast to fp16 before one native cube dot per K-tile.
   A TF32 value has a 10-bit mantissa, so inside the fp16 normal exponent
   range it is EXACTLY an fp16 value; at this task's magnitudes
   (h ~ randn; |qg| = |q|*scale*exp(g) << 65504 for randn g -- fp16
   overflow would need g > ~11, i.e. >11 sigma) the casts are lossless and
   the fp16-cube products with fp32 accumulate reproduce the reference
   TF32 products bit-for-bit (residual <= 2^-25 absolute only for
   sub-fp16-subnormal magnitudes, far below the recurrent_chunk
   tolerance).
2. Intra-chunk: back to round 1's single 2D masked tile dot (no scalar
   loop), but the reference keeps A and v in FULL fp32 there (upstream
   allow_tf32=False), so the fp32 products are emulated on the fast fp16
   cube with a 3-pass hi/lo split:
       a = a_hi + a_lo,  v = v_hi + v_lo    (fp16 parts)
       A @ v ~= a_hi@v_hi + a_hi@v_lo + a_lo@v_hi
   Each split reconstructs its fp32 input to ~2^-22 relative and the
   dropped a_lo@v_lo term is ~2^-22 relative, so per-product error is
   ~7e-7 relative -- ~1e-6 absolute after a 64-term reduction, four
   orders of magnitude under the verified GPU-vs-reference residuals in
   meta.yaml (max_abs <= 6e-3).

Math (per chunk c, local row i, local col j, contract.md):
  o[b, r, h, :] = sum_k (q*scale*exp(g))[b,r,h,k] * h[b,c,h,:,k]
                + sum_{j<=i} A[b,r,h,j] * v[b,c*BT+j,h,:]

Layouts (dense, head-structured, block-diagonal per chunk):
  q, g : [B, T, H, K]
  v    : [B, T, H, V]
  A    : [B, T, H, BT]    last axis is the LOCAL within-chunk column
  h    : [B, NT, H, V, K] per-chunk state, read as a [V, K] tile
  o    : [B, T, H, V]
"""

import torch
import triton
import triton.language as tl


def _next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


# int32 mask keeping everything but the low 13 mantissa bits of an fp32
# word: truncates fp32 to TF32 exactly like the reference `_to_tf32`.
_TF32_MASK: tl.constexpr = -8192  # ~0x1FFF


@triton.jit(do_not_specialize=["T"])
def _chunk_gla_fwd_kernel_o(
    q, v, g, h, o, A,
    scale,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
):
    i_v, i_t, i_bh = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    i_b, i_h = i_bh // H, i_bh % H
    NT = tl.cdiv(T, BT)
    i_tg = i_b * NT + i_t
    bos = i_b * T

    offs_i = i_t * BT + tl.arange(0, BT)      # global rows of this chunk
    mask_i = offs_i < T
    offs_c = tl.arange(0, BT)                 # local within-chunk columns
    offs_v = i_v * BV + tl.arange(0, BV)      # output columns
    mask_v = offs_v < V

    # Lower-triangular (diagonal kept) mask over the local chunk columns.
    m_s = offs_c[:, None] >= offs_c[None, :]

    qg_base = q + (bos * H + i_h) * K
    gg_base = g + (bos * H + i_h) * K
    h_base = h + (i_tg * H + i_h) * K * V

    b_o = tl.zeros([BT, BV], dtype=tl.float32)

    # Inter-chunk: TF32-truncated gated query x per-chunk [V, K] state.
    # h is stored [V, K]; element (v, k) lives at h_base + v*K + k, so the
    # tile is gathered directly oriented as [BK, BV] (swapped strides) --
    # no transpose op needed before the dot.
    for i_k in range(tl.cdiv(K, BK)):
        offs_k = i_k * BK + tl.arange(0, BK)
        mask_k = offs_k < K
        mk = mask_i[:, None] & mask_k[None, :]
        b_q = tl.load(qg_base + offs_i[:, None] * (H * K) + offs_k[None, :],
                      mask=mk, other=0.0)
        b_q = (b_q * scale).to(b_q.dtype)
        b_g = tl.load(gg_base + offs_i[:, None] * (H * K) + offs_k[None, :],
                      mask=mk, other=0.0)
        b_qg = (b_q * tl.exp(b_g)).to(b_q.dtype)
        b_qg = (b_qg.to(tl.int32, bitcast=True) & _TF32_MASK).to(
            tl.float32, bitcast=True)
        b_h = tl.load(h_base + offs_k[:, None] + offs_v[None, :] * K,
                      mask=mask_k[:, None] & mask_v[None, :], other=0.0)
        b_h = (b_h.to(tl.int32, bitcast=True) & _TF32_MASK).to(
            tl.float32, bitcast=True)
        # Lossless at this task's magnitudes: TF32 values are exactly
        # representable in fp16 inside the fp16 normal exponent range.
        b_o += tl.dot(b_qg.to(tl.float16), b_h.to(tl.float16),
                      out_dtype=tl.float32)

    # Intra-chunk: causal-masked score x value in FULL fp32 semantics
    # (upstream allow_tf32=False), emulated on the fp16 cube with a
    # 3-pass hi/lo split; round 1's single 2D masked tile layout.
    v_base = v + (bos * H + i_h) * V
    a_base = A + (bos * H + i_h) * BT
    b_A = tl.load(a_base + offs_i[:, None] * (H * BT) + offs_c[None, :],
                  mask=mask_i[:, None], other=0.0)
    b_A = tl.where(m_s, b_A, 0.0)
    b_v = tl.load(v_base + (i_t * BT + offs_c)[:, None] * (H * V) +
                  offs_v[None, :],
                  mask=((i_t * BT + offs_c) < T)[:, None] & mask_v[None, :],
                  other=0.0)
    a_hi = b_A.to(tl.float16)
    a_lo = (b_A - a_hi.to(tl.float32)).to(tl.float16)
    v_hi = b_v.to(tl.float16)
    v_lo = (b_v - v_hi.to(tl.float32)).to(tl.float16)
    b_o += tl.dot(a_hi, v_hi, out_dtype=tl.float32)
    b_o += tl.dot(a_hi, v_lo, out_dtype=tl.float32)
    b_o += tl.dot(a_lo, v_hi, out_dtype=tl.float32)

    o_base = o + (bos * H + i_h) * V
    p_o = o_base + offs_i[:, None] * (H * V) + offs_v[None, :]
    tl.store(p_o, b_o.to(p_o.dtype.element_ty),
             mask=mask_i[:, None] & mask_v[None, :])


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    v = inputs["v"]
    g = inputs["g"]
    A = inputs["A"]
    h = inputs["h"]
    scale = inputs["scale"]

    B, T, H, K = q.shape
    V = v.shape[-1]
    BT = A.shape[-1]
    NT = (T + BT - 1) // BT

    # Same geometry as round 1 (which compiled on device): cube tiles with
    # >= 16 lanes; masked loads absorb degenerate K/V extents.
    BK = min(32, max(16, _next_pow2(K)))
    BV = min(64, max(16, _next_pow2(V)))

    o = torch.empty_like(v)
    grid = ((V + BV - 1) // BV, NT, B * H)
    _chunk_gla_fwd_kernel_o[grid](
        q, v, g, h, o, A,
        scale, T,
        H=H, K=K, V=V, BT=BT, BK=BK, BV=BV,
    )
    return {"output": o}


# Alias so either entry name resolves to the same implementation.
run = npu_triton_impl
