"""triton-ascend port of the chunked-GLA output kernel (non-varlen path).

Entry point: npu_triton_impl(inputs: dict) -> dict with key "output".

Math per chunk c (rows r = c*BT + i, local row i, local col j in [0, BT)):

    o[b, r, h, :] =
        sum_k (q[b,r,h,k] * scale * exp(g[b,r,h,k])) * h[b, c, h, :, k]
      + sum_{j<=i} A[b, r, h, j] * v[b, c*BT+j, h, :]

The first term reads the per-chunk [V, K] state tile addressed so the dot
consumes it already transposed ([K, V]); the second is the causal-masked
(lower-triangular, diagonal kept) intra-chunk score-times-value product.
All arithmetic stays in fp32 with fp32 dot accumulation, matching the
reference contract end to end.

Grid: (NT, B * H). One program computes one full (batch, head, chunk)
output tile of shape [BT, V], looping over V in BV-wide blocks and over K
in BK-wide blocks for the state read.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def chunk_gla_fwd_kernel_o_npu(
    q, v, g, h, o, A,
    scale, T,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    NK: tl.constexpr,
    NV: tl.constexpr,
):
    i_t, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H
    NT = tl.cdiv(T, BT)
    bos = i_b * T
    i_tg = i_b * NT + i_t  # global chunk id, indexes the per-chunk state

    offs_t = i_t * BT + tl.arange(0, BT)
    m_t = offs_t < T
    offs_j = tl.arange(0, BT)

    # Causal mask for the intra-chunk term: keep j <= i.
    m_s = offs_j[:, None] >= offs_j[None, :]

    q_base = q + (bos * H + i_h) * K
    g_base = g + (bos * H + i_h) * K
    v_base = v + (bos * H + i_h) * V
    h_base = h + (i_tg * H + i_h) * K * V
    A_base = A + (bos * H + i_h) * BT

    for i_v in range(NV):
        b_o = tl.zeros([BT, BV], dtype=tl.float32)
        offs_v = i_v * BV + tl.arange(0, BV)
        m_v = offs_v < V

        # Inter-chunk: gated query x chunk state (state tile loaded as
        # [BK, BV] by indexing h[v, k] at address v * K + k).
        for i_k in range(NK):
            offs_k = i_k * BK + tl.arange(0, BK)
            m_k = offs_k < K

            qk_off = offs_t[:, None] * (H * K) + offs_k[None, :]
            m_q = m_t[:, None] & m_k[None, :]
            b_q = tl.load(q_base + qk_off, mask=m_q, other=0.0)
            b_g = tl.load(g_base + qk_off, mask=m_q, other=0.0)
            b_qg = (b_q * scale * tl.exp(b_g)).to(tl.float32)

            h_off = offs_v[None, :] * K + offs_k[:, None]
            m_h = m_v[None, :] & m_k[:, None]
            b_hT = tl.load(h_base + h_off, mask=m_h, other=0.0)
            b_o += tl.dot(b_qg, b_hT)

        # Intra-chunk: masked score x value.
        vv_off = offs_t[:, None] * (H * V) + offs_v[None, :]
        m_vv = m_t[:, None] & m_v[None, :]
        b_v = tl.load(v_base + vv_off, mask=m_vv, other=0.0)

        A_off = offs_t[:, None] * (H * BT) + offs_j[None, :]
        b_A = tl.load(A_base + A_off, mask=m_t[:, None], other=0.0)
        b_A = tl.where(m_s, b_A, 0.0)
        b_o += tl.dot(b_A, b_v)

        tl.store(o + (bos * H + i_h) * V + vv_off, b_o, mask=m_vv)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    v = inputs["v"]
    g = inputs["g"]
    A = inputs["A"]
    h = inputs["h"]
    scale = inputs["scale"]

    q = q.contiguous()
    v = v.contiguous()
    g = g.contiguous()
    A = A.contiguous()
    h = h.contiguous()

    B, T, H, K = q.shape
    V = v.shape[-1]
    BT = A.shape[-1]
    NT = (T + BT - 1) // BT

    o = torch.empty_like(v)

    def _pow2_clamped(x, lo, hi):
        n = 1
        while n < x:
            n *= 2
        return min(max(n, lo), hi)

    # Cube-friendly tile sizes; masked loads cover ragged K/V extents.
    BK = _pow2_clamped(K, 16, 64)
    BV = _pow2_clamped(V, 16, 128)
    NK = (K + BK - 1) // BK
    NV = (V + BV - 1) // BV

    grid = (NT, B * H)
    chunk_gla_fwd_kernel_o_npu[grid](
        q, v, g, h, o, A,
        scale, T,
        H=H, K=K, V=V, BT=BT, BK=BK, BV=BV, NK=NK, NV=NV,
    )
    return {"output": o}
