"""Triton-Ascend implementation of per-(token, group) symmetric INT8 scaling.

Semantics (must match the reference math in contract.md):
  x: [..., N], N % group_size == 0, x is bfloat16.
  For each contiguous group of `group_size` elements:
    absmax = amax(|g|) computed in fp32 (input promoted bf16 -> fp32 first)
    s      = max(absmax, eps) / 127          (fp32)
    q      = clamp(g / s, -128, 127) -> int8 (fp32 divide, int conversion
             follows the vendored reference kernel's cast order)
Outputs: q int8 [..., N]; s fp32 [..., N // group_size].

Round-4 change vs round 3 (single geometry change, math bit-identical):
  Round 3 tiled the grid with ROWS = 16 groups/program (grid = ceil(M/16),
  num_warps = 2) and was correctness-verified on all 49 shapes at a
  measured geomean of 0.215 ms (baseline parity). Two observations drove
  this change:
    * The largest shapes (P7 2.35 GB, P8 3.94 GB traffic) run at ~1.0 TB/s
      effective (bf16 in + int8 out + fp32 scales), well below the 910B
      HBM peak; small-shape times sit on a ~157 us per-invocation floor
      that is insensitive to geometry.
    * With ROWS=16 x BLOCK=8 fp32 tiles and only 2 warps, each AICore
      program handles 128 elements with coarse in/out vectors; doubling
      the per-program tile gives the vectorizer wider contiguous runs.
  So this round raises ROWS_PER_PROG 16 -> 32 (32 x 8 = 256 elements per
  program: 512 B bf16 load, 256 B int8 store, 128 B fp32 scale store)
  and num_warps 2 -> 4 (one fp32 lane per thread on the tile).
  grid = ceil(M/32) is 16384 on the largest declared shape (M = 524288,
  P8), further from the 65536 launcher limit, and the per-group math (fp32 promote,
  tl.max over the 8 columns, max-with-eps, divide, saturate + int8 cast)
  is unchanged from round 3. Trailing-group masking on both stores
  keeps shapes with M not a multiple of 32 correct as well (H5 has
  M = 1, P19 M = 48, P21 M = 144, P22 M = 192).
"""
import torch
import triton
import triton.language as tl

# Programs process this many consecutive groups; the largest declared
# shape has M = 524288 groups (P8) -> grid = 16384 programs, far under the
# 65536 launcher limit, and widens the per-program tile for the
# memory-bound large shapes.
ROWS_PER_PROG = 32


@triton.jit
def _per_token_group_int8(y_ptr, y_q_ptr, y_s_ptr, M, y_stride, N, eps,
                          int8_min, int8_max,
                          ROWS: tl.constexpr, BLOCK: tl.constexpr):
    pid = tl.program_id(0)
    rows = pid * ROWS + tl.arange(0, ROWS)
    cols = tl.arange(0, BLOCK)
    # groups are contiguous, so group g starts at element g * N
    offs = rows[:, None] * y_stride + cols[None, :]
    mask = (rows[:, None] < M) & (cols[None, :] < N)
    y = tl.load(y_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    # |y| without tl.abs (not on the static allowlist): sign-branch form is
    # bit-identical for fp32 values used here.
    ay = tl.where(y < 0.0, -y, y)
    _absmax = tl.maximum(tl.max(ay, axis=1), eps)
    y_s = _absmax / int8_max
    # clamp(y / y_s, int8_min, int8_max) via two saturations; same value as
    # the reference's single clamp, then the int8 cast.
    y_q = tl.minimum(tl.maximum(y / y_s[:, None], int8_min), int8_max).to(tl.int8)
    tl.store(y_q_ptr + offs, y_q, mask=mask)
    tl.store(y_s_ptr + rows, y_s, mask=rows < M)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    group_size = inputs["group_size"]
    eps = inputs["eps"]

    x = x.contiguous()

    # int8 symmetric limits (python int constants).
    int8_max = 127
    int8_min = -128

    # Shape bookkeeping done entirely on tensors:
    #   M   = numel // group_size (number of groups, python int)
    #   grp = (lead..., N // g, g) -> scale shape = leading dims + (N // g,)
    M = x.view(-1, group_size).shape[0]
    grp = x.view(*x.shape[:-1], -1, group_size)
    out_shape = grp.shape[:-2] + (grp.shape[-2],)

    x_q = torch.empty_like(x, device=x.device, dtype=torch.int8)
    x_s = torch.empty(out_shape, device=x.device, dtype=torch.float32)

    BLOCK = triton.next_power_of_2(group_size)
    grid = triton.cdiv(M, ROWS_PER_PROG)

    _per_token_group_int8[(grid,)](
        x,
        x_q,
        x_s,
        M,
        group_size,
        group_size,
        eps,
        int8_min,
        int8_max,
        ROWS=ROWS_PER_PROG,
        BLOCK=BLOCK,
        num_warps=4,
        num_stages=1,
    )

    return {"q": x_q, "scale": x_s}
