"""L2_22_fused_dual_residual_rmsnorm -- Triton-Ascend candidate (round 2).

Per-row math (identical to round 1 and to the eager reference):

    rms1    = sqrt(sum(x32 * x32) / D + eps)
    normed1 = bf16_rne(x32 / rms1 * w1_32)      # rounded BEFORE the add
    mid     = bf16_rne(residual_32 + normed1)   # stored and returned
    rms2    = sqrt(sum(mid_32 * mid_32) / D + eps)   # reduces the ROUNDED mid
    output  = bf16_rne(mid_32 / rms2 * w2_32)

What changed vs round 1
-----------------------
Round 1 wrote the two narrowing points as Triton casts
(``(a / rms * w1).to(r.dtype)`` and ``a2r.to(r.dtype)``) and the verified run
failed all 49 shapes.  The failure magnitudes identify the mechanism rather
than leaving it open: the absolute error per shape is ~half an ulp of
``normed1`` (<= 0.0156 for |normed1| up to 8) scaled by ``w2 / rms2`` (~4),
which is exactly the observed 0.039 / 0.0625 / 0.125 on the wide shapes, and
the relative error blows up only where ``residual`` cancels ``normed1``.  That
is what happens when the fp32 -> bf16 -> fp32 round trip is elided: the add
consumes the unrounded float32 product, and the second reduction then reads a
``mid`` that never touched the bf16 grid.  A vector backend that carries bf16
tensors in float32 registers widens at load and narrows only at the store, so
an in-flight cast is not observable to it.

So the round trips are now spelled as float32 bit arithmetic that no
simplifier can recognise as removable: add the round-to-nearest-even bias
(``(bits >> 16) & 1`` for the tie-to-even bit, plus 0x7FFF) and truncate the
low 16 bits.  This yields the float32 value on the bf16 grid that an RNE
narrowing would produce -- it was checked to agree bit-for-bit with torch's
``.to(torch.bfloat16)`` cast -- and it keeps every subsequent op in float32,
which is where the reference does its arithmetic.  The values handed to the
second reduction are therefore the stored ones by construction.

The explicit rounding is also applied immediately before each store.  A
already-representable value narrows exactly, so this makes the result
independent of the backend's store rounding mode, and it is idempotent
otherwise.

Layout is unchanged from round 1 (it ran clean: runtime_status ok on every
shape, so the adaptation is not the suspect):

  * D <= TILE: one program per row, whole row in one tile, single pass.
  * D >  TILE: one program per row, swept in TILE-width chunks over three
    passes -- sum of squares of x; build and store mid while accumulating its
    sum of squares; read mid back and emit output.

Masked lanes load as zero, so padding cannot perturb either sum, and no row is
ever split across programs, so there is no cross-program reduction, no atomics,
and a fixed reduction order.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

# Widest row handled in a single tile.  This cap keeps the largest live set of
# float32 tiles near 50 KB, comfortably inside the 192 KB AI Core UB.
_TILE = 2048

_RNE_BIAS = tl.constexpr(32767)
_KEEP_HIGH = tl.constexpr(-65536)  # 0xFFFF0000


@triton.jit
def _round_to_bf16(x):
    """Round a float32 tensor to the bfloat16 grid, round-to-nearest-even.

    Returns float32.  Bit manipulation on purpose: a ``.to(bf16).to(f32)``
    round trip can be dropped by a backend that represents bf16 vectors in
    float32 registers, which is the failure this file exists to avoid.
    """
    b = x.to(tl.int32, bitcast=True)
    lsb = (b >> 16) & 1
    b = (b + lsb + _RNE_BIAS) & _KEEP_HIGH
    return b.to(tl.float32, bitcast=True)


@triton.jit
def _dual_residual_rmsnorm_row(
    output_ptr,
    mid_ptr,
    activ_ptr,
    residual_ptr,
    weight1_ptr,
    weight2_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    """Whole row in one tile."""
    row = tl.program_id(axis=0)
    base = row * hidden_dim
    offs = tl.arange(0, BLOCK_D)
    mask = offs < hidden_dim

    x_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
    a = x_.to(tl.float32)
    rms = tl.sqrt(tl.sum(a * a, axis=0) / hidden_dim + eps)
    r = tl.load(residual_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
    w1 = tl.load(weight1_ptr + offs, mask=mask, other=0.0).to(tl.float32)

    normed1 = _round_to_bf16(a / rms * w1)
    mid = _round_to_bf16(r + normed1)
    tl.store(mid_ptr + base + offs, mid.to(x_.dtype), mask=mask)

    rms2 = tl.sqrt(tl.sum(mid * mid, axis=0) / hidden_dim + eps)
    w2 = tl.load(weight2_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    out = _round_to_bf16(mid / rms2 * w2)
    tl.store(output_ptr + base + offs, out.to(x_.dtype), mask=mask)


@triton.jit
def _dual_residual_rmsnorm_chunked(
    output_ptr,
    mid_ptr,
    activ_ptr,
    residual_ptr,
    weight1_ptr,
    weight2_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_D: tl.constexpr,
    NUM_CHUNKS: tl.constexpr,
):
    """Row swept in NUM_CHUNKS tiles of BLOCK_D columns."""
    row = tl.program_id(axis=0)
    base = row * hidden_dim
    cols = tl.arange(0, BLOCK_D)

    acc1 = tl.zeros([BLOCK_D], dtype=tl.float32)
    for chunk in range(NUM_CHUNKS):
        offs = chunk * BLOCK_D + cols
        mask = offs < hidden_dim
        a = tl.load(activ_ptr + base + offs, mask=mask, other=0.0).to(tl.float32)
        acc1 += a * a
    rms = tl.sqrt(tl.sum(acc1, axis=0) / hidden_dim + eps)

    acc2 = tl.zeros([BLOCK_D], dtype=tl.float32)
    for chunk in range(NUM_CHUNKS):
        offs = chunk * BLOCK_D + cols
        mask = offs < hidden_dim
        a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
        r_ = tl.load(residual_ptr + base + offs, mask=mask, other=0.0)
        a = a_.to(tl.float32)
        r = r_.to(tl.float32)
        w1 = tl.load(weight1_ptr + offs, mask=mask, other=0.0).to(tl.float32)
        normed1 = _round_to_bf16(a / rms * w1)
        mid = _round_to_bf16(r + normed1)
        # mid sits on the residual-dtype grid already, so this narrows exactly.
        tl.store(mid_ptr + base + offs, mid.to(r_.dtype), mask=mask)
        acc2 += mid * mid
    rms2 = tl.sqrt(tl.sum(acc2, axis=0) / hidden_dim + eps)

    for chunk in range(NUM_CHUNKS):
        offs = chunk * BLOCK_D + cols
        mask = offs < hidden_dim
        m_ = tl.load(mid_ptr + base + offs, mask=mask, other=0.0)
        w2 = tl.load(weight2_ptr + offs, mask=mask, other=0.0).to(tl.float32)
        out = _round_to_bf16(m_.to(tl.float32) / rms2 * w2)
        tl.store(output_ptr + base + offs, out.to(m_.dtype), mask=mask)


def _warps_for(block):
    """One warp per ~256 columns, so no core is handed an empty tile."""
    w = triton.next_power_of_2(triton.cdiv(block, 256))
    if w < 1:
        w = 1
    if w > 8:
        w = 8
    return w


def _pick(inputs, primary, aliases):
    """Fetch a tensor by its shapes.yaml key, tolerating alias spellings."""
    if primary in inputs:
        return inputs[primary]
    for alias in aliases:
        if alias in inputs:
            return inputs[alias]
    raise KeyError(primary)


def npu_triton_impl(inputs: dict) -> dict:
    x = _pick(inputs, "x", ("activ", "activation", "hidden_states"))
    residual = _pick(inputs, "residual", ("res", "residual_a"))
    weight1 = _pick(inputs, "weight1", ("w1", "weight"))
    weight2 = _pick(inputs, "weight2", ("w2",))
    # eps arrives as a python scalar and feeds a tl.constexpr parameter,
    # so it is used as-is (no host-side conversion).
    eps = _pick(inputs, "eps", ())

    assert x.dim() == 2
    if x.is_contiguous() is False:
        x = x.contiguous()
    if residual.is_contiguous() is False:
        residual = residual.contiguous()
    if weight1.is_contiguous() is False:
        weight1 = weight1.contiguous()
    if weight2.is_contiguous() is False:
        weight2 = weight2.contiguous()

    rows = x.shape[0]
    hidden_dim = x.shape[1]
    output = torch.empty_like(x)
    mid = torch.empty_like(x)

    if hidden_dim <= _TILE:
        block = triton.next_power_of_2(hidden_dim)
        _dual_residual_rmsnorm_row[(rows,)](
            output,
            mid,
            x,
            residual,
            weight1,
            weight2,
            eps=eps,
            hidden_dim=hidden_dim,
            BLOCK_D=block,
            num_warps=_warps_for(block),
        )
    else:
        block = _TILE
        _dual_residual_rmsnorm_chunked[(rows,)](
            output,
            mid,
            x,
            residual,
            weight1,
            weight2,
            eps=eps,
            hidden_dim=hidden_dim,
            BLOCK_D=block,
            NUM_CHUNKS=triton.cdiv(hidden_dim, block),
            num_warps=_warps_for(block),
        )
    return {"output": output, "mid": mid}
