"""Triton-Ascend port of the fused dual-residual RMSNorm operator (round 3).

Per row (batch element) the math is:

    normed1 = RMSNorm(x) * weight1     (fp32 reduction/scale, result rounded
                                        to the input dtype, round-to-nearest-even)
    mid     = residual + normed1       (bf16 RNE add; ``mid`` is the value
                                        handed to the next residual stage)
    output  = RMSNorm(mid) * weight2   (fp32 reduction/scale, stored in the
                                        input dtype)

Round 2 fixed the fp32->bf16 store rounding (explicit RNE in integer bits)
and reached 43/49 shapes. The six remaining failures (P7, P8, P9, P11, P38,
P41) all deviate on ``output`` by single bf16 ulps, only on the shapes with
long rows / many elements, while the elementwise math was already verified
bitwise. The remaining degree of freedom is the ASSOCIATION ORDER of the
fp32 sum-of-squares reduction feeding ``rms`` / ``rms2``: the reference
computes ``mean`` as an fp32 ``sum`` followed by an fp32 divide, and that
``sum`` is a 4-level cascaded (binary-counter) reduction:

  - elements are processed as 8-wide float32 vectors ("units");
  - four units form a super-column, accumulated into four independent
    lane-vectors (ILP factor 4);
  - after every super-column the running accumulators are carried into the
    next cascade level; every 16 super-columns the level-1 accumulators are
    carried into level 2, every 256 into level 3;
  - leftover super-columns and then leftover whole units accumulate
    sequentially into lane-set 0; the four lane-sets combine lane-wise as
    ``(q0 + q1) + q2) + q3`` and the lanes fold sequentially 0..7.

This kernel reproduces that exact association order (the cascade skeleton
was validated bitwise against the reference ``sum`` for every row length of
this task, and the full kernel was validated bitwise against the reference
math in interpreter mode for all D classes and multi-row batches), so
``rms`` / ``rms2`` come out bit-identical to the reference math. Lane
extraction for the sequential fold uses zero-masked single-lane reductions
(exact: masked lanes contribute +0.0 to non-negative sums), then sequential
scalar adds, to keep the fold order deterministic.

Everything else is unchanged from round 2: explicit round-to-nearest-even
fp32->bf16 rounding in integer bits at all three conversion points (first
norm, mid add, final store), fp32 divide by hidden_dim, eps added inside
the sqrt, one program per row. Rows shorter than 8 elements take the scalar
variant of the same cascade.

The entrypoint is ``npu_triton_impl(inputs: dict) -> dict`` which returns
``{"output": ..., "mid": ...}``.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _rne_bf16(v):
    """Round a float32 tensor to the nearest bf16 value (ties to even),
    returned as a float32 tensor whose values are exactly representable in
    bf16 (low 16 mantissa bits zero). Subsequent bf16 conversion/store of
    such a value is exact under any rounding mode.
    """
    u = v.to(tl.int32, bitcast=True)
    u = (u + 32767 + ((u >> 16) & 1)) & (-65536)
    return u.to(tl.float32, bitcast=True)


@triton.jit
def _fold8(Q):
    """Sequential fold of an 8-lane float32 vector, lanes 0..7:
    ``((...((q0 + q1) + q2) ...) + q7)``. Each lane is extracted with a
    zero-masked reduction: every masked-out lane contributes +0.0, and
    adding +0.0 to a non-negative value is exact, so the extraction is
    exact under ANY reduction association order the backend may use. The
    scalar adds that follow are emitted sequentially by construction."""
    offs = tl.arange(0, 8)
    t = tl.sum(tl.where(offs == 0, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 1, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 2, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 3, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 4, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 5, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 6, Q, 0.0), axis=0)
    t = t + tl.sum(tl.where(offs == 7, Q, 0.0), axis=0)
    return t


@triton.jit
def _supercol_sq(x_ptr, p, offs):
    """Load four 8-wide bf16 units at ``p`` and return their fp32 squares."""
    v0 = tl.load(x_ptr + p + offs).to(tl.float32)
    v1 = tl.load(x_ptr + p + 8 + offs).to(tl.float32)
    v2 = tl.load(x_ptr + p + 16 + offs).to(tl.float32)
    v3 = tl.load(x_ptr + p + 24 + offs).to(tl.float32)
    return v0 * v0, v1 * v1, v2 * v2, v3 * v3


@triton.jit
def _fused_dual_residual_rmsnorm_kernel_vec(
    output_ptr,
    mid_ptr,
    activ_ptr,
    residual_ptr,
    weight1_ptr,
    weight2_ptr,
    eps,
    hidden_dim,
    n256,
    ngroups,
    nilp,
    nunits,
):
    """Rows of at least 8 elements, D % 8 == 0. The cascade geometry is
    passed as runtime ints: n256 full 256-super-column blocks, ngroups
    leftover 16-super-column groups, nilp leftover super-columns, nunits
    leftover whole units (row length is a multiple of 8, so no scalar
    tail)."""
    pid = tl.program_id(axis=0)
    base = pid * hidden_dim
    d32 = hidden_dim.to(tl.float32)
    offs = tl.arange(0, 8)
    z = tl.zeros([8], dtype=tl.float32)

    # ---- Pass 1: cascaded sum of squares of x. ----
    b0 = z
    b1 = z
    b2 = z
    b3 = z
    c0 = z
    c1 = z
    c2 = z
    c3 = z
    d0 = z
    d1 = z
    d2 = z
    d3 = z
    for g2 in range(n256):
        for g in range(16):
            for s in range(16):
                sc = g2 * 256 + g * 16 + s
                s0, s1, s2, s3 = _supercol_sq(activ_ptr, base + sc * 32, offs)
                b0 += s0
                b1 += s1
                b2 += s2
                b3 += s3
            c0 += b0
            b0 = z
            c1 += b1
            b1 = z
            c2 += b2
            b2 = z
            c3 += b3
            b3 = z
        d0 += c0
        c0 = z
        d1 += c1
        c1 = z
        d2 += c2
        c2 = z
        d3 += c3
        c3 = z
    for g in range(ngroups):
        for s in range(16):
            sc = n256 * 256 + g * 16 + s
            s0, s1, s2, s3 = _supercol_sq(activ_ptr, base + sc * 32, offs)
            b0 += s0
            b1 += s1
            b2 += s2
            b3 += s3
        c0 += b0
        b0 = z
        c1 += b1
        b1 = z
        c2 += b2
        b2 = z
        c3 += b3
        b3 = z
    for s in range(nilp):
        sc = n256 * 256 + ngroups * 16 + s
        s0, s1, s2, s3 = _supercol_sq(activ_ptr, base + sc * 32, offs)
        b0 += s0
        b1 += s1
        b2 += s2
        b3 += s3
    q0 = (b0 + c0) + d0
    q1 = (b1 + c1) + d1
    q2 = (b2 + c2) + d2
    q3 = (b3 + c3) + d3
    size_ilp = n256 * 256 + ngroups * 16 + nilp
    for u in range(nunits):
        uu = 4 * size_ilp + u
        v = tl.load(activ_ptr + base + uu * 8 + offs).to(tl.float32)
        q0 += v * v
    Q = ((q0 + q1) + q2) + q3
    S = _fold8(Q)
    rms = tl.sqrt(S / d32 + eps)

    # ---- Pass 2: first norm (explicit RNE to bf16), residual add
    # reproduced as exact fp32 add + explicit RNE, store mid, cascaded sum
    # of squares of the rounded mid. ----
    b0 = z
    b1 = z
    b2 = z
    b3 = z
    c0 = z
    c1 = z
    c2 = z
    c3 = z
    d0 = z
    d1 = z
    d2 = z
    d3 = z
    for g2 in range(n256):
        for g in range(16):
            for s in range(16):
                sc = g2 * 256 + g * 16 + s
                p = base + sc * 32
                wp = sc * 32
                a0 = tl.load(activ_ptr + p + offs).to(tl.float32)
                a1 = tl.load(activ_ptr + p + 8 + offs).to(tl.float32)
                a2 = tl.load(activ_ptr + p + 16 + offs).to(tl.float32)
                a3 = tl.load(activ_ptr + p + 24 + offs).to(tl.float32)
                r0 = tl.load(residual_ptr + p + offs).to(tl.float32)
                r1 = tl.load(residual_ptr + p + 8 + offs).to(tl.float32)
                r2 = tl.load(residual_ptr + p + 16 + offs).to(tl.float32)
                r3 = tl.load(residual_ptr + p + 24 + offs).to(tl.float32)
                w0 = tl.load(weight1_ptr + wp + offs).to(tl.float32)
                w1 = tl.load(weight1_ptr + wp + 8 + offs).to(tl.float32)
                w2 = tl.load(weight1_ptr + wp + 16 + offs).to(tl.float32)
                w3 = tl.load(weight1_ptr + wp + 24 + offs).to(tl.float32)
                m0 = _rne_bf16(r0 + _rne_bf16(a0 / rms * w0))
                m1 = _rne_bf16(r1 + _rne_bf16(a1 / rms * w1))
                m2 = _rne_bf16(r2 + _rne_bf16(a2 / rms * w2))
                m3 = _rne_bf16(r3 + _rne_bf16(a3 / rms * w3))
                tl.store(mid_ptr + p + offs, m0.to(tl.bfloat16))
                tl.store(mid_ptr + p + 8 + offs, m1.to(tl.bfloat16))
                tl.store(mid_ptr + p + 16 + offs, m2.to(tl.bfloat16))
                tl.store(mid_ptr + p + 24 + offs, m3.to(tl.bfloat16))
                b0 += m0 * m0
                b1 += m1 * m1
                b2 += m2 * m2
                b3 += m3 * m3
            c0 += b0
            b0 = z
            c1 += b1
            b1 = z
            c2 += b2
            b2 = z
            c3 += b3
            b3 = z
        d0 += c0
        c0 = z
        d1 += c1
        c1 = z
        d2 += c2
        c2 = z
        d3 += c3
        c3 = z
    for g in range(ngroups):
        for s in range(16):
            sc = n256 * 256 + g * 16 + s
            p = base + sc * 32
            wp = sc * 32
            a0 = tl.load(activ_ptr + p + offs).to(tl.float32)
            a1 = tl.load(activ_ptr + p + 8 + offs).to(tl.float32)
            a2 = tl.load(activ_ptr + p + 16 + offs).to(tl.float32)
            a3 = tl.load(activ_ptr + p + 24 + offs).to(tl.float32)
            r0 = tl.load(residual_ptr + p + offs).to(tl.float32)
            r1 = tl.load(residual_ptr + p + 8 + offs).to(tl.float32)
            r2 = tl.load(residual_ptr + p + 16 + offs).to(tl.float32)
            r3 = tl.load(residual_ptr + p + 24 + offs).to(tl.float32)
            w0 = tl.load(weight1_ptr + wp + offs).to(tl.float32)
            w1 = tl.load(weight1_ptr + wp + 8 + offs).to(tl.float32)
            w2 = tl.load(weight1_ptr + wp + 16 + offs).to(tl.float32)
            w3 = tl.load(weight1_ptr + wp + 24 + offs).to(tl.float32)
            m0 = _rne_bf16(r0 + _rne_bf16(a0 / rms * w0))
            m1 = _rne_bf16(r1 + _rne_bf16(a1 / rms * w1))
            m2 = _rne_bf16(r2 + _rne_bf16(a2 / rms * w2))
            m3 = _rne_bf16(r3 + _rne_bf16(a3 / rms * w3))
            tl.store(mid_ptr + p + offs, m0.to(tl.bfloat16))
            tl.store(mid_ptr + p + 8 + offs, m1.to(tl.bfloat16))
            tl.store(mid_ptr + p + 16 + offs, m2.to(tl.bfloat16))
            tl.store(mid_ptr + p + 24 + offs, m3.to(tl.bfloat16))
            b0 += m0 * m0
            b1 += m1 * m1
            b2 += m2 * m2
            b3 += m3 * m3
        c0 += b0
        b0 = z
        c1 += b1
        b1 = z
        c2 += b2
        b2 = z
        c3 += b3
        b3 = z
    for s in range(nilp):
        sc = n256 * 256 + ngroups * 16 + s
        p = base + sc * 32
        wp = sc * 32
        a0 = tl.load(activ_ptr + p + offs).to(tl.float32)
        a1 = tl.load(activ_ptr + p + 8 + offs).to(tl.float32)
        a2 = tl.load(activ_ptr + p + 16 + offs).to(tl.float32)
        a3 = tl.load(activ_ptr + p + 24 + offs).to(tl.float32)
        r0 = tl.load(residual_ptr + p + offs).to(tl.float32)
        r1 = tl.load(residual_ptr + p + 8 + offs).to(tl.float32)
        r2 = tl.load(residual_ptr + p + 16 + offs).to(tl.float32)
        r3 = tl.load(residual_ptr + p + 24 + offs).to(tl.float32)
        w0 = tl.load(weight1_ptr + wp + offs).to(tl.float32)
        w1 = tl.load(weight1_ptr + wp + 8 + offs).to(tl.float32)
        w2 = tl.load(weight1_ptr + wp + 16 + offs).to(tl.float32)
        w3 = tl.load(weight1_ptr + wp + 24 + offs).to(tl.float32)
        m0 = _rne_bf16(r0 + _rne_bf16(a0 / rms * w0))
        m1 = _rne_bf16(r1 + _rne_bf16(a1 / rms * w1))
        m2 = _rne_bf16(r2 + _rne_bf16(a2 / rms * w2))
        m3 = _rne_bf16(r3 + _rne_bf16(a3 / rms * w3))
        tl.store(mid_ptr + p + offs, m0.to(tl.bfloat16))
        tl.store(mid_ptr + p + 8 + offs, m1.to(tl.bfloat16))
        tl.store(mid_ptr + p + 16 + offs, m2.to(tl.bfloat16))
        tl.store(mid_ptr + p + 24 + offs, m3.to(tl.bfloat16))
        b0 += m0 * m0
        b1 += m1 * m1
        b2 += m2 * m2
        b3 += m3 * m3
    q0 = (b0 + c0) + d0
    q1 = (b1 + c1) + d1
    q2 = (b2 + c2) + d2
    q3 = (b3 + c3) + d3
    for u in range(nunits):
        uu = 4 * size_ilp + u
        p = base + uu * 8
        a = tl.load(activ_ptr + p + offs).to(tl.float32)
        r = tl.load(residual_ptr + p + offs).to(tl.float32)
        w = tl.load(weight1_ptr + uu * 8 + offs).to(tl.float32)
        m = _rne_bf16(r + _rne_bf16(a / rms * w))
        tl.store(mid_ptr + p + offs, m.to(tl.bfloat16))
        q0 += m * m
    Q = ((q0 + q1) + q2) + q3
    S2 = _fold8(Q)
    rms2 = tl.sqrt(S2 / d32 + eps)

    # ---- Pass 3: second norm on mid, scaled by weight2, explicit RNE
    # before the bf16 store. ----
    for g2 in range(n256):
        for g in range(16):
            for s in range(16):
                sc = g2 * 256 + g * 16 + s
                p = base + sc * 32
                wp = sc * 32
                m0 = tl.load(mid_ptr + p + offs).to(tl.float32)
                m1 = tl.load(mid_ptr + p + 8 + offs).to(tl.float32)
                m2 = tl.load(mid_ptr + p + 16 + offs).to(tl.float32)
                m3 = tl.load(mid_ptr + p + 24 + offs).to(tl.float32)
                w0 = tl.load(weight2_ptr + wp + offs).to(tl.float32)
                w1 = tl.load(weight2_ptr + wp + 8 + offs).to(tl.float32)
                w2 = tl.load(weight2_ptr + wp + 16 + offs).to(tl.float32)
                w3 = tl.load(weight2_ptr + wp + 24 + offs).to(tl.float32)
                tl.store(output_ptr + p + offs, _rne_bf16(m0 / rms2 * w0).to(tl.bfloat16))
                tl.store(output_ptr + p + 8 + offs, _rne_bf16(m1 / rms2 * w1).to(tl.bfloat16))
                tl.store(output_ptr + p + 16 + offs, _rne_bf16(m2 / rms2 * w2).to(tl.bfloat16))
                tl.store(output_ptr + p + 24 + offs, _rne_bf16(m3 / rms2 * w3).to(tl.bfloat16))
    for g in range(ngroups):
        for s in range(16):
            sc = n256 * 256 + g * 16 + s
            p = base + sc * 32
            wp = sc * 32
            m0 = tl.load(mid_ptr + p + offs).to(tl.float32)
            m1 = tl.load(mid_ptr + p + 8 + offs).to(tl.float32)
            m2 = tl.load(mid_ptr + p + 16 + offs).to(tl.float32)
            m3 = tl.load(mid_ptr + p + 24 + offs).to(tl.float32)
            w0 = tl.load(weight2_ptr + wp + offs).to(tl.float32)
            w1 = tl.load(weight2_ptr + wp + 8 + offs).to(tl.float32)
            w2 = tl.load(weight2_ptr + wp + 16 + offs).to(tl.float32)
            w3 = tl.load(weight2_ptr + wp + 24 + offs).to(tl.float32)
            tl.store(output_ptr + p + offs, _rne_bf16(m0 / rms2 * w0).to(tl.bfloat16))
            tl.store(output_ptr + p + 8 + offs, _rne_bf16(m1 / rms2 * w1).to(tl.bfloat16))
            tl.store(output_ptr + p + 16 + offs, _rne_bf16(m2 / rms2 * w2).to(tl.bfloat16))
            tl.store(output_ptr + p + 24 + offs, _rne_bf16(m3 / rms2 * w3).to(tl.bfloat16))
    for s in range(nilp):
        sc = n256 * 256 + ngroups * 16 + s
        p = base + sc * 32
        wp = sc * 32
        m0 = tl.load(mid_ptr + p + offs).to(tl.float32)
        m1 = tl.load(mid_ptr + p + 8 + offs).to(tl.float32)
        m2 = tl.load(mid_ptr + p + 16 + offs).to(tl.float32)
        m3 = tl.load(mid_ptr + p + 24 + offs).to(tl.float32)
        w0 = tl.load(weight2_ptr + wp + offs).to(tl.float32)
        w1 = tl.load(weight2_ptr + wp + 8 + offs).to(tl.float32)
        w2 = tl.load(weight2_ptr + wp + 16 + offs).to(tl.float32)
        w3 = tl.load(weight2_ptr + wp + 24 + offs).to(tl.float32)
        tl.store(output_ptr + p + offs, _rne_bf16(m0 / rms2 * w0).to(tl.bfloat16))
        tl.store(output_ptr + p + 8 + offs, _rne_bf16(m1 / rms2 * w1).to(tl.bfloat16))
        tl.store(output_ptr + p + 16 + offs, _rne_bf16(m2 / rms2 * w2).to(tl.bfloat16))
        tl.store(output_ptr + p + 24 + offs, _rne_bf16(m3 / rms2 * w3).to(tl.bfloat16))
    for u in range(nunits):
        uu = 4 * size_ilp + u
        p = base + uu * 8
        m = tl.load(mid_ptr + p + offs).to(tl.float32)
        w = tl.load(weight2_ptr + uu * 8 + offs).to(tl.float32)
        tl.store(output_ptr + p + offs, _rne_bf16(m / rms2 * w).to(tl.bfloat16))


@triton.jit
def _fused_dual_residual_rmsnorm_kernel_small(
    output_ptr,
    mid_ptr,
    activ_ptr,
    residual_ptr,
    weight1_ptr,
    weight2_ptr,
    eps,
    hidden_dim,
    size_ilp_sc,
):
    """Rows shorter than 8 elements: the reference reduces these with the
    scalar variant of the same cascade (4 scalar slots per super-column).
    For this task there is at most one super-column, far below the
    16-super-column level step, so no cascade carry ever fires: the
    super-column lands in the level-0 slots, the scalar tail accumulates
    sequentially into slot 0, then slots 0..3 combine sequentially."""
    pid = tl.program_id(axis=0)
    base = pid * hidden_dim

    # Pass 1: sum of squares of x.
    za = 0.0
    a0 = za
    a1 = za
    a2 = za
    a3 = za
    for sc in range(size_ilp_sc):
        p = base + sc * 4
        s0 = tl.load(activ_ptr + p).to(tl.float32)
        s1 = tl.load(activ_ptr + p + 1).to(tl.float32)
        s2 = tl.load(activ_ptr + p + 2).to(tl.float32)
        s3 = tl.load(activ_ptr + p + 3).to(tl.float32)
        a0 += s0 * s0
        a1 += s1 * s1
        a2 += s2 * s2
        a3 += s3 * s3
    t = a0
    for p in range(4 * size_ilp_sc, hidden_dim):
        s = tl.load(activ_ptr + base + p).to(tl.float32)
        t = t + s * s
    S = ((t + a1) + a2) + a3
    rms = tl.sqrt(S / hidden_dim.to(tl.float32) + eps)

    # Pass 2: first norm + residual add (explicit RNE), store mid, sum the
    # squares of mid with the same scalar structure.
    a0 = za
    a1 = za
    a2 = za
    a3 = za
    for sc in range(size_ilp_sc):
        p = base + sc * 4
        q = sc * 4
        s0 = tl.load(activ_ptr + p).to(tl.float32)
        s1 = tl.load(activ_ptr + p + 1).to(tl.float32)
        s2 = tl.load(activ_ptr + p + 2).to(tl.float32)
        s3 = tl.load(activ_ptr + p + 3).to(tl.float32)
        r0 = tl.load(residual_ptr + p).to(tl.float32)
        r1 = tl.load(residual_ptr + p + 1).to(tl.float32)
        r2 = tl.load(residual_ptr + p + 2).to(tl.float32)
        r3 = tl.load(residual_ptr + p + 3).to(tl.float32)
        w0 = tl.load(weight1_ptr + q).to(tl.float32)
        w1 = tl.load(weight1_ptr + q + 1).to(tl.float32)
        w2 = tl.load(weight1_ptr + q + 2).to(tl.float32)
        w3 = tl.load(weight1_ptr + q + 3).to(tl.float32)
        m0 = _rne_bf16(r0 + _rne_bf16(s0 / rms * w0))
        m1 = _rne_bf16(r1 + _rne_bf16(s1 / rms * w1))
        m2 = _rne_bf16(r2 + _rne_bf16(s2 / rms * w2))
        m3 = _rne_bf16(r3 + _rne_bf16(s3 / rms * w3))
        tl.store(mid_ptr + p, m0.to(tl.bfloat16))
        tl.store(mid_ptr + p + 1, m1.to(tl.bfloat16))
        tl.store(mid_ptr + p + 2, m2.to(tl.bfloat16))
        tl.store(mid_ptr + p + 3, m3.to(tl.bfloat16))
        a0 += m0 * m0
        a1 += m1 * m1
        a2 += m2 * m2
        a3 += m3 * m3
    t = a0
    for p in range(4 * size_ilp_sc, hidden_dim):
        s = tl.load(activ_ptr + base + p).to(tl.float32)
        r = tl.load(residual_ptr + base + p).to(tl.float32)
        w = tl.load(weight1_ptr + p).to(tl.float32)
        m = _rne_bf16(r + _rne_bf16(s / rms * w))
        tl.store(mid_ptr + base + p, m.to(tl.bfloat16))
        t = t + m * m
    S2 = ((t + a1) + a2) + a3
    rms2 = tl.sqrt(S2 / hidden_dim.to(tl.float32) + eps)

    # Pass 3: second norm on mid, scaled by weight2.
    for p in range(hidden_dim):
        m = tl.load(mid_ptr + base + p).to(tl.float32)
        w = tl.load(weight2_ptr + p).to(tl.float32)
        tl.store(output_ptr + base + p, _rne_bf16(m / rms2 * w).to(tl.bfloat16))


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    residual = inputs["residual"].contiguous()
    weight1 = inputs["weight1"].contiguous()
    weight2 = inputs["weight2"].contiguous()
    eps = inputs["eps"]

    assert x.dim() == 2
    assert x.shape == residual.shape and x.dtype == residual.dtype
    bs, hidden_dim = x.shape

    output = torch.empty_like(x)
    mid = torch.empty_like(x)

    if hidden_dim < 8:
        # Scalar cascade path (D in {2, 4, 6} for this task).
        _fused_dual_residual_rmsnorm_kernel_small[(bs,)](
            output,
            mid,
            x,
            residual,
            weight1,
            weight2,
            eps,
            hidden_dim,
            hidden_dim // 4,
        )
    else:
        # Vector cascade path. All task shapes with D >= 8 satisfy
        # D % 32 == 0; the nunits branch covers 8/16-wide rows generically.
        assert hidden_dim % 8 == 0
        vec_size = hidden_dim // 8
        size_ilp = vec_size // 4
        _fused_dual_residual_rmsnorm_kernel_vec[(bs,)](
            output,
            mid,
            x,
            residual,
            weight1,
            weight2,
            eps,
            hidden_dim,
            size_ilp // 256,
            (size_ilp % 256) // 16,
            size_ilp % 16,
            vec_size - 4 * size_ilp,
        )
    return {"output": output, "mid": mid}
