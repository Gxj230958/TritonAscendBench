"""Triton-Ascend FlashAttention-style prefill attention for L3_16_fwd.

Implements ``context_attention_fwd`` semantics: variable-length sequences
packed into a single token axis, in-place write into the runner-allocated
``o`` buffer, GQA head expansion, causal masking and online softmax.

The kernel mirrors the upstream dtype flow: bf16 q/k/v go into ``tl.dot``
with fp32 accumulation, softmax bookkeeping (running max / row sum / scaled
acc) is carried in fp32, and the result is stored into ``o``'s own dtype.

Tile geometry follows the 910B unified-buffer budget. For head dim 256 the
query tile is 32 rows while the key/value tile stays 64 columns: the
fp32 accumulator plus the per-iteration k/v/qk/p tiles (plus the causal-mask
temporaries) fit the AI core's UB, and the 64-wide N block halves the online
softmax loop iterations and gives the cube a larger K/N tile. The 64x64
query/key geometry that a naive port uses exceeds the UB budget at D=256.

Loop pipelining (``num_stages=2``) is enabled for the D <= 128 branches
where the double-buffered k/v tiles keep the total UB footprint near
~110 KB, well inside the 256 KB AI core budget. The D > 128 branch stays
at ``num_stages=1``: adding the second k/v buffers there would push the UB
budget past the ~200 KB compile-blocking threshold observed with the 64x64
geometry. Pipelining only overlaps GM->UB transfers with compute; it does
not change any numeric bookkeeping.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _fwd_kernel(
    Q,
    K,
    V,
    sm_scale,
    B_Start_Loc,
    B_Seqlen,
    Out,
    stride_qbs,
    stride_qh,
    stride_kbs,
    stride_kh,
    stride_vbs,
    stride_vh,
    stride_obs,
    stride_oh,
    kv_group_num: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_DMODEL: tl.constexpr,
    BLOCK_N: tl.constexpr,
    IS_CAUSAL: tl.constexpr,
    Lk: tl.constexpr,
):
    cur_batch = tl.program_id(0)
    cur_head = tl.program_id(1)
    start_m = tl.program_id(2)

    cur_kv_head = cur_head // kv_group_num

    cur_batch_seq_len = tl.load(B_Seqlen + cur_batch)
    cur_batch_in_all_start_index = tl.load(B_Start_Loc + cur_batch)

    block_start_loc = BLOCK_M * start_m

    offs_n = tl.arange(0, BLOCK_N)
    offs_d = tl.arange(0, BLOCK_DMODEL)
    offs_m = start_m * BLOCK_M + tl.arange(0, BLOCK_M)
    off_q = (
        (cur_batch_in_all_start_index + offs_m[:, None]) * stride_qbs
        + cur_head * stride_qh
        + offs_d[None, :]
    )
    off_k = offs_n[None, :] * stride_kbs + cur_kv_head * stride_kh + offs_d[:, None]
    off_v = offs_n[:, None] * stride_vbs + cur_kv_head * stride_vh + offs_d[None, :]

    mask_d = offs_d < Lk

    q = tl.load(
        Q + off_q,
        mask=(offs_m[:, None] < cur_batch_seq_len) & (mask_d[None, :]),
        other=0.0,
    )

    k_ptrs = K + off_k
    v_ptrs = V + off_v

    m_i = tl.zeros([BLOCK_M], dtype=tl.float32) - float("inf")
    l_i = tl.zeros([BLOCK_M], dtype=tl.float32)
    acc = tl.zeros([BLOCK_M, BLOCK_DMODEL], dtype=tl.float32)

    block_mask = tl.where(block_start_loc < cur_batch_seq_len, 1, 0)

    end_n = (
        cur_batch_seq_len
        if not IS_CAUSAL
        else tl.minimum((start_m + 1) * BLOCK_M, cur_batch_seq_len)
    )
    for start_n in range(0, block_mask * end_n, BLOCK_N):
        start_n = tl.multiple_of(start_n, BLOCK_N)
        k = tl.load(
            k_ptrs + (cur_batch_in_all_start_index + start_n) * stride_kbs,
            mask=((start_n + offs_n[None, :]) < cur_batch_seq_len) & (mask_d[:, None]),
            other=0.0,
        )

        qk = tl.zeros([BLOCK_M, BLOCK_N], dtype=tl.float32)
        qk += tl.dot(q, k)
        qk *= sm_scale

        if IS_CAUSAL:
            qk += tl.where(
                (start_n + offs_n[None, :] < cur_batch_seq_len)
                & (offs_m[:, None] >= (start_n + offs_n[None, :])),
                0,
                float("-inf"),
            )
        else:
            qk += tl.where(
                (start_n + offs_n[None, :]) < cur_batch_seq_len, 0, float("-inf")
            )

        m_ij = tl.max(qk, 1)
        p = tl.exp(qk - m_ij[:, None])
        l_ij = tl.sum(p, 1)
        m_i_new = tl.maximum(m_i, m_ij)
        alpha = tl.exp(m_i - m_i_new)
        beta = tl.exp(m_ij - m_i_new)
        l_i_new = alpha * l_i + beta * l_ij
        p_scale = beta / l_i_new
        p = p * p_scale[:, None]
        acc_scale = l_i / l_i_new * alpha
        acc = acc * acc_scale[:, None]
        v = tl.load(
            v_ptrs + (cur_batch_in_all_start_index + start_n) * stride_vbs,
            mask=((start_n + offs_n[:, None]) < cur_batch_seq_len) & (mask_d[None, :]),
            other=0.0,
        )

        p = p.to(v.dtype)
        acc += tl.dot(p, v)
        l_i = l_i_new
        m_i = m_i_new

    off_o = (
        (cur_batch_in_all_start_index + offs_m[:, None]) * stride_obs
        + cur_head * stride_oh
        + offs_d[None, :]
    )
    out_ptrs = Out + off_o
    tl.store(
        out_ptrs, acc, mask=(offs_m[:, None] < cur_batch_seq_len) & (mask_d[None, :])
    )


def npu_triton_impl(inputs: dict) -> dict:
    """Standalone entrypoint: binds the kernel onto the task tensors and
    surfaces the in-place ``o`` buffer plus the untouched read-only inputs,
    mirroring the upstream entrypoint structure."""
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    o = inputs["o"]
    b_start_loc = inputs["b_start_loc"]
    b_seq_len = inputs["b_seq_len"]
    max_input_len = inputs["max_input_len"]
    is_causal = inputs["is_causal"]

    Lq, Lk, Lv = q.shape[-1], k.shape[-1], v.shape[-1]
    # Contract fixes sm_scale at 1/sqrt(D); deriving it here is bit-identical
    # to the shapes.yaml derive value and avoids a host-side branch.
    sm_scale = 1.0 / (Lq ** 0.5)
    batch, head = b_seq_len.shape[0], q.shape[1]
    kv_group_num = q.shape[1] // k.shape[1]

    BLOCK_DMODEL = triton.next_power_of_2(Lk)
    # UB-budget geometry for the 910B AI core: large head dims shrink the
    # query tile so acc/q/k/v/qk/p plus causal-mask temporaries fit.
    # Pipelined loops double-buffer k/v; budget them before enabling.
    if BLOCK_DMODEL <= 64:
        BLOCK_M = 64
        BLOCK_N = 64
        num_warps = 4
        num_stages = 2
    elif BLOCK_DMODEL <= 128:
        BLOCK_M = 32
        BLOCK_N = 64
        num_warps = 4
        num_stages = 2
    else:
        BLOCK_M = 32
        BLOCK_N = 64
        num_warps = 4
        num_stages = 1

    grid = (batch, head, triton.cdiv(max_input_len, BLOCK_M))

    _fwd_kernel[grid](
        q,
        k,
        v,
        sm_scale,
        b_start_loc,
        b_seq_len,
        o,
        q.stride(0),
        q.stride(1),
        k.stride(0),
        k.stride(1),
        v.stride(0),
        v.stride(1),
        o.stride(0),
        o.stride(1),
        kv_group_num=kv_group_num,
        BLOCK_M=BLOCK_M,
        BLOCK_DMODEL=BLOCK_DMODEL,
        BLOCK_N=BLOCK_N,
        IS_CAUSAL=is_causal,
        num_warps=num_warps,
        num_stages=num_stages,
        Lk=Lk,
    )
    return {
        "q": q,
        "k": k,
        "v": v,
        "o": o,
        "b_start_loc": b_start_loc,
        "b_seq_len": b_seq_len,
    }
