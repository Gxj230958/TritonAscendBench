"""Triton-Ascend implementation of Qwen2-VL multimodal RoPE (mrope) forward.

Task: L1_19_triton_mrope_forward  ·  operator: _triton_mrope_forward
Entry point: npu_triton_impl(inputs: dict) -> dict

Math (non-interleaved / chunked mrope layout)

  q : [n_tokens, n_qh * head_size]  bfloat16
  k : [n_tokens, n_kh * head_size]  bfloat16
  cos, sin : [3, n_tokens, rotary_dim // 2]  float32
      channel 0 = temporal, 1 = height, 2 = width
  mrope_section = [t, h, w] with t + h + w == rotary_dim // 2

Inside a head the rotated prefix [0, rotary_dim) is read as two halves,
x1 = x[:rd/2] and x2 = x[rd/2:rd]; frequency i borrows its angle from the
T/H/W channel that mrope_section assigns to it, and

  y1 = x1 * cos_i - x2 * sin_i
  y2 = x2 * cos_i + x1 * sin_i

The trailing head_size - rotary_dim dims of every head pass through
untouched. Products and sums are formed in float32 and narrowed back to the
storage dtype exactly once, at the store, which is the rounding order of the
reference.

Why the block is shaped [head, frequency]

The rotary partner of an element sits rd/2 columns away and its angle depends
on its frequency, so a one-lane-per-element reading of the row needs two
computed addresses per lane: one for the mirror element, one for the
channel-selected cache entry. Neither collapses into a strided vector access,
so the core spends its cycles on address arithmetic and shuffles rather than
on the multiply-adds that are the actual work.

Splitting the lane index into a head axis and a frequency axis makes every
address in the block affine in the lane coordinates:

  * each half of the rotated prefix becomes a dense [head, frequency] tile
    with unit inner stride, so x1 and x2 are read once each and y1 and y2
    written once each, four vector accesses per program;
  * the angle vector is resolved before the head axis is introduced, from six
    masked loads over the rd/2 frequencies of this token, then broadcast.
    Every head shares one angle vector, so the T/H/W pick is per-program work
    rather than per-element work, and the section boundaries are constant
    masks folded at build time instead of an address computation;
  * the pass-through tail, which exists only when rotary_dim < head_size, is a
    masked copy over the same contiguous span, so those dims move verbatim.

Head counts, heads per program and the frequency width are recovered on the
device from the row widths and the head size, so the host reads shapes and
derives nothing from the scalar arguments. One launch serves both streams:
the first query tile of a token also owns that token's key row, which is
narrow by construction, so no second dispatch is spent on it. Results land in
freshly allocated buffers and the inputs are left as found, so the operation
stays a pure function of its arguments and keeps token order independent.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _rope_stream(
    x_ptr,
    o_ptr,
    cos_ptr,
    sin_ptr,
    tok,                     # row index this program serves
    W: tl.constexpr,         # row width in elements, NH * HD
    CST: tl.constexpr,       # cos/sin token stride
    CSTEP: tl.constexpr,     # cos/sin plane step, n_tokens * CST
    HD: tl.constexpr,        # head size
    RD: tl.constexpr,        # rotary dim
    SEC0: tl.constexpr,      # mrope_section[0], temporal
    SEC1: tl.constexpr,      # mrope_section[1], height; the rest is width
    PF: tl.constexpr,        # frequency lanes, a pow2 >= rotary_dim // 2
    HPB: tl.constexpr,       # heads per program
    NH: tl.constexpr,        # heads in this row
    h_base,
):
    """Rotate `HPB` consecutive heads of one token's flattened row."""
    r2: tl.constexpr = RD // 2
    sec_hw: tl.constexpr = SEC0 + SEC1

    # --- the angle pair for this token: one vector over r2 frequencies ------
    # The three sections tile [0, r2), so on any frequency exactly one mask
    # survives and the other two loads contribute zero: their sum *is* the
    # channel selection, which keeps the channel axis out of the addressing.
    freq = tl.arange(0, PF)
    live_f = freq < r2
    cbase = cos_ptr + tok * CST
    sbase = sin_ptr + tok * CST
    m_t = freq < SEC0
    m_h = (freq >= SEC0) & (freq < sec_hw)
    m_w = (freq >= sec_hw) & live_f

    cos_v = (
        tl.load(cbase + freq, mask=m_t, other=0.0)
        + tl.load(cbase + CSTEP + freq, mask=m_h, other=0.0)
        + tl.load(cbase + 2 * CSTEP + freq, mask=m_w, other=0.0)
    )
    sin_v = (
        tl.load(sbase + freq, mask=m_t, other=0.0)
        + tl.load(sbase + CSTEP + freq, mask=m_h, other=0.0)
        + tl.load(sbase + 2 * CSTEP + freq, mask=m_w, other=0.0)
    )

    # --- both halves of the rotated prefix, as dense affine tiles -----------
    head = h_base + tl.arange(0, HPB)
    in_row = head < NH
    keep = in_row[:, None] & live_f[None, :]
    pos = tok * W + head[:, None] * HD + freq[None, :]

    c = cos_v[None, :]
    s = sin_v[None, :]
    x1 = tl.load(x_ptr + pos, mask=keep, other=0.0).to(tl.float32)
    x2 = tl.load(x_ptr + (pos + r2), mask=keep, other=0.0).to(tl.float32)

    # y = [x1, x2] * [cos, cos] + [-x2, x1] * [sin, sin]
    tl.store(o_ptr + pos, (x1 * c - x2 * s).to(o_ptr.dtype.element_ty),
             mask=keep)
    tl.store(o_ptr + (pos + r2), (x2 * c + x1 * s).to(o_ptr.dtype.element_ty),
             mask=keep)

    # --- dims [RD, HD) of each head, copied verbatim -----------------------
    if RD < HD:
        lane = tl.arange(0, HD)
        live_t = (lane >= RD) & (lane < HD)
        tpos = tok * W + head[:, None] * HD + lane[None, :]
        tkeep = in_row[:, None] & live_t[None, :]
        tl.store(o_ptr + tpos,
                 tl.load(x_ptr + tpos, mask=tkeep, other=0.0), mask=tkeep)


@triton.jit
def _mrope_forward(
    q_ptr,
    k_ptr,
    oq_ptr,
    ok_ptr,
    cos_ptr,
    sin_ptr,
    WQ: tl.constexpr,        # query row width, n_qh * HD
    WK: tl.constexpr,        # key row width, n_kh * HD
    CST: tl.constexpr,       # cos/sin token stride
    CSTEP: tl.constexpr,     # cos/sin plane step
    HD: tl.constexpr,        # head size
    RD: tl.constexpr,        # rotary dim
    SEC0: tl.constexpr,      # mrope_section[0]
    SEC1: tl.constexpr,      # mrope_section[1]
    BQ: tl.constexpr,        # query elements per program, whole heads
    NTQ: tl.constexpr,       # query tiles per token
):
    tok = tl.program_id(0)
    tile = tl.program_id(1)

    # The frequency axis spans half a head. Since rotary_dim never exceeds
    # head_size, that is wide enough for any angle vector the cache can hold,
    # and the live mask below trims it back to the rotary prefix.
    PF: tl.constexpr = HD // 2
    # A tile is meant to span whole heads, so the tile width is normally an
    # exact multiple of the head size. Rounded up, a tile narrower than one
    # head still covers a head rather than nothing at all.
    HPB: tl.constexpr = (BQ + HD - 1) // HD
    NHQ: tl.constexpr = WQ // HD
    NHK: tl.constexpr = WK // HD
    KNT: tl.constexpr = (NHK + HPB - 1) // HPB

    _rope_stream(
        q_ptr, oq_ptr, cos_ptr, sin_ptr, tok,
        WQ, CST, CSTEP, HD, RD, SEC0, SEC1, PF, HPB, NHQ, tile * HPB,
    )

    # Tile 0 of a token owns the rest of the row's work. The key row is a head
    # or two wide, so it rides along here instead of costing a second dispatch.
    # The sweep after it is a coverage guard: NTQ * HPB >= NHQ holds for any
    # tile width, since ceil(WQ / BQ) * ceil(BQ / HD) >= WQ / HD, so it folds
    # away today and only matters if the host heuristic ever changes.
    if tile == 0:
        for kb in tl.static_range(0, KNT):
            _rope_stream(
                k_ptr, ok_ptr, cos_ptr, sin_ptr, tok,
                WK, CST, CSTEP, HD, RD, SEC0, SEC1, PF, HPB, NHK,
                kb * HPB,
            )
        for hb in tl.static_range(NTQ * HPB, NHQ):
            _rope_stream(
                q_ptr, oq_ptr, cos_ptr, sin_ptr, tok,
                WQ, CST, CSTEP, HD, RD, SEC0, SEC1, PF, 1, NHQ, hb,
            )


def _pow2(n):
    return 1 if n <= 1 else int(triton.next_power_of_2(n))


def _tiles(width, bq):
    return (width + bq - 1) // bq


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    cos = inputs["cos"]
    sin = inputs["sin"]

    n_tokens = int(q.shape[0])
    width_q = int(q.shape[1])
    width_k = int(k.shape[1])
    # The cache is [3, n_tokens, rotary_dim // 2] with a unit stride along the
    # frequency axis, so its trailing dim doubles as the token stride.
    cache_stride = int(cos.shape[-1])

    # The row arithmetic assumes a dense row-major layout. A reordered view is
    # the only case that has to pay for a copy, and testing the strides keeps
    # that copy, and its device work, out of the common path entirely.
    if not q.is_contiguous():
        q = q.contiguous()
    if not k.is_contiguous():
        k = k.contiguous()
    if not cos.is_contiguous():
        cos = cos.contiguous()
    if not sin.is_contiguous():
        sin = sin.contiguous()

    section = inputs["mrope_section"]
    head_size = inputs["head_size"]
    rotary_dim = inputs["rotary_dim"]

    out_q = torch.empty_like(q)
    out_k = torch.empty_like(k)

    # Tile width in elements. A tile spans whole heads, because rotate_half
    # pairs frequency i with i + rd/2 and a head cut in half cannot be rotated,
    # so the row width is where the split starts. Walking down towards 128
    # kicks in when the row is long and the batch thin, which is what lets a
    # single-token row still reach every core.
    bq = min(512, _pow2(width_q))
    while bq > 128 and n_tokens * _tiles(width_q, bq) < 128:
        bq = bq // 2
    ntq = _tiles(width_q, bq)

    # One or two warps. A block is at most 512 elements, and every extra warp
    # costs a split of the block across vector units plus the buffer handoff
    # around it, which a tile this narrow cannot repay.
    nw = 1 if bq <= 128 else 2

    _mrope_forward[(n_tokens, ntq)](
        q,
        k,
        out_q,
        out_k,
        cos,
        sin,
        WQ=width_q,
        WK=width_k,
        CST=cache_stride,
        CSTEP=cache_stride * n_tokens,
        HD=head_size,
        RD=rotary_dim,
        SEC0=section[0],
        SEC1=section[1],
        BQ=bq,
        NTQ=ntq,
        num_warps=nw,
    )

    return {"q": out_q, "k": out_k}
