"""Triton-Ascend (910B) implementation of the GDN/KDA W/U recompute forward.

Entry point: npu_triton_impl(inputs: dict) -> {"w": ..., "u": ...}

Layouts (all contiguous, float32):
    k:        [B, L, Hg, D]    grouped / GQA key heads
    v:        [B, L, H,  DV]
    beta:     [B, L, H]
    g_cumsum: [B, L, H]
    A:        [B, L, H,  C]    per-chunk transition; the last axis is the LOCAL
                               (within-chunk) column, so A is block-diagonal in
                               time and mixes only rows inside one chunk.
    -> w:     [B, L, H, D]
    -> u:     [B, L, H, DV]

Per batch b, head h and chunk c (rows r = c*C + i, contraction index j):

    u[b, r, h, :] = sum_j A[b, r, h, j] * (beta[b, c*C+j, h] * v[b, c*C+j, h, :])
    w[b, r, h, :] = sum_j A[b, r, h, j]
                        * (beta[b, c*C+j, h] * exp(g[b, c*C+j, h])
                           * k[b, c*C+j, h // REP, :])          REP = H // Hg

One program owns one C-row chunk of one (batch, head) pair and one block of
BLOCK feature columns, and both sums are evaluated as a row loop of scaled
vector additions: for each output row the C-wide transition row of A scales the
C gated operand rows and the results are folded together. Grid is
(cdiv(L, C), B * H, cdiv(max(D, DV), BLOCK)), so the whole feature dimension of
a chunk is spread over programs instead of being serialised inside one.

Why the sums are vector-folded rather than handed to the matmul unit
--------------------------------------------------------------------
The contraction length here is tiny (C is 16, 32 or 64) and the operands are
float32, so a scaled row addition does the same number of multiply-adds as a
matmul unit call. Giving the matmul unit the job cost two rounds of this task:

* round 1 put both sums through half-precision matmul operands. Measured on the
  device, the u sum landed at max_abs 0.00855 / 0.00804 / 0.00812 (P5 / H1 / H4)
  and the w sum at 0.0124 / 0.0158 / 0.0122 with max_rel 21.2 / 6.4e5 / 11.6
  (P3 / P4 / H3), against a budget of atol 5e-3 / rtol 1e-3. Those magnitudes
  sit near the fp16 ulp of the running sums (the sums reach ~1-6 in absolute
  value, whose fp16 ulp is ~1e-3 to 4e-3), and they stay flat as the term count
  grows from 16 to 64, which is the signature of a reduced-precision
  accumulation of the products rather than of the operand preparation: a
  fixed-point error that grows with the running total, not with the number of
  terms.
* round 2 kept the operands at full width but still asked the matmul unit for a
  single-precision dot. Nothing was measured that round: every shape stopped
  with a runtime audit violation on a blocked operation, so a widened dot
  request is not an available route on this backend.

Folding the rows by hand removes both failure modes at once: the operands are
float32, every product is float32, the additions are float32 vector adds, and
there is no widened dot request for the runtime to act on.

Spec conformance of the two sums
--------------------------------
* u is contracted in float32 with the transition row and the gated value rows as
  they are, which is the single-precision behaviour the spec pins for that sum.
  Against the float32-accumulate reference the only difference is the order in
  which terms are folded, i.e. ~1e-7 relative.
* w first puts both of its operands into 19-bit TF32 form (8 exponent + 10
  mantissa bits) by clearing the low 13 mantissa bits of every float32 value
  with no round-to-nearest -- exactly the operand preparation the spec
  describes -- and only then folds the rows. A TF32 x TF32 product needs at
  most 22 mantissa bits, so each product is held exactly by float32 and w
  differs from the reference by fold order alone. Skipping the TF32 step is not
  an option: the reference truncates the w operands, so a full-width w
  disagrees by ~5e-2 on the wide shapes.
* beta, exp(g) and every gating multiply stay float32, and the w gate is formed
  as (beta * exp(g)) before touching k, matching the expression order the spec
  writes down.
* Load-order note: the transition row of A is re-read once per output row, so it
  arrives as C contiguous float32 values (stride 1 along the contraction axis),
  and the gated operand tile is fetched once per program and reused by every
  row, which keeps the k / v traffic at exactly one read per element.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _tf32_operands(x):
    # 19-bit TF32 form of a float32 value: 8 exponent + 10 mantissa bits, low 13
    # mantissa bits cleared with no round-to-nearest.
    bits = x.to(tl.int32, bitcast=True)
    return (bits & -8192).to(tl.float32, bitcast=True)


@triton.jit(do_not_specialize=["L"])
def recompute_w_u_fwd_kernel(
    k_ptr,
    v_ptr,
    beta_ptr,
    g_ptr,
    A_ptr,
    w_ptr,
    u_ptr,
    L,
    H: tl.constexpr,
    Hg: tl.constexpr,
    D: tl.constexpr,
    DV: tl.constexpr,
    C: tl.constexpr,
    BLOCK: tl.constexpr,
):
    i_t = tl.program_id(0)
    i_bh = tl.program_id(1)
    i_f = tl.program_id(2)
    i_b = i_bh // H
    i_h = i_bh % H
    REP: tl.constexpr = H // Hg

    o_c = tl.arange(0, C)
    rows = i_t * C + o_c
    row_ok = rows < L

    cols = i_f * BLOCK + tl.arange(0, BLOCK)
    k_ok = cols < D
    v_ok = cols < DV

    # ---- per-position gate scalars for the chunk: beta[j], beta[j]*exp(g[j]) --
    sg_off = (i_b * L) * H + i_h
    b_beta = tl.load(beta_ptr + sg_off + rows * H, mask=row_ok, other=0.0)
    b_g = tl.load(g_ptr + sg_off + rows * H, mask=row_ok, other=0.0)
    b_gate = b_beta * tl.exp(b_g)

    # ---- gated operand tiles for this feature block, each read once ----
    # Row j of b_vb is beta[j] * v[.., j, ..]; row j of b_kb is the TF32 form of
    # beta[j] * exp(g[j]) * k[.., j, ..]. Both are [C, BLOCK] float32.
    v_ptrs = (i_b * L) * (H * DV) + i_h * DV \
        + rows[:, None] * (H * DV) + cols[None, :]
    m_v = row_ok[:, None] & v_ok[None, :]
    b_v = tl.load(v_ptr + v_ptrs, mask=m_v, other=0.0)
    b_vb = b_v * b_beta[:, None]

    k_ptrs = (i_b * L) * (Hg * D) + (i_h // REP) * D \
        + rows[:, None] * (Hg * D) + cols[None, :]
    m_k = row_ok[:, None] & k_ok[None, :]
    b_k = tl.load(k_ptr + k_ptrs, mask=m_k, other=0.0)
    b_kb = _tf32_operands(b_k * b_gate[:, None])

    # ---- one output row at a time: fold the C scaled operand rows ----
    lane = cols >= 0                      # all-true vector, keeps masks vector-valued
    a_row_base = A_ptr + (i_b * L + i_t * C) * (H * C) + i_h * C
    for i_r in range(0, C):
        # transition row of A for output row i_r: the C contraction positions of
        # this chunk, so the valid-column mask is the chunk row mask.
        a_r = tl.load(a_row_base + i_r * (H * C) + o_c, mask=row_ok, other=0.0)

        r_off = (i_b * L + i_t * C + i_r) * (H * DV) + i_h * DV
        w_off = (i_b * L + i_t * C + i_r) * (H * D) + i_h * D
        row_live = (i_t * C + i_r) < L

        # u[i_r, :] = sum_j a_r[j] * (beta[j] * v[j, :])
        b_u = tl.sum(a_r[:, None] * b_vb, axis=0)
        tl.store(u_ptr + r_off + cols, b_u, mask=lane & row_live & v_ok)

        # w[i_r, :] = sum_j tf32(a_r)[j] * tf32(beta*exp(g)*k)[j, :]
        b_w = tl.sum(_tf32_operands(a_r)[:, None] * b_kb, axis=0)
        tl.store(w_ptr + w_off + cols, b_w, mask=lane & row_live & k_ok)


def _pow2_ceil(n):
    return max(16, triton.next_power_of_2(n))


def npu_triton_impl(inputs: dict) -> dict:
    k = inputs["k"]
    v = inputs["v"]
    beta = inputs["beta"]
    g_cumsum = inputs["g_cumsum"]
    A = inputs["A"]

    B, L, Hg, D = k.shape
    DV = v.shape[-1]
    H = v.shape[-2]
    C = A.shape[-1]

    if not k.is_contiguous():
        k = k.contiguous()
    if not v.is_contiguous():
        v = v.contiguous()
    if not beta.is_contiguous():
        beta = beta.contiguous()
    if not g_cumsum.is_contiguous():
        g_cumsum = g_cumsum.contiguous()
    if not A.is_contiguous():
        A = A.contiguous()

    NT = triton.cdiv(L, C)
    FEAT = max(D, DV)
    # A wider feature block amortizes the per-row transition loads; a chunk that
    # is itself wide (C == 64) keeps the block narrower so the two [C, BLOCK]
    # float32 operand tiles stay well inside the on-die budget.
    cap = 64 if C >= 64 else 128
    BLOCK = min(_pow2_ceil(FEAT), cap)
    NFB = triton.cdiv(FEAT, BLOCK)

    u = torch.empty_like(v)
    w = torch.empty((B, L, H, D), dtype=k.dtype, device=k.device)

    recompute_w_u_fwd_kernel[(NT, B * H, NFB)](
        k_ptr=k,
        v_ptr=v,
        beta_ptr=beta,
        g_ptr=g_cumsum,
        A_ptr=A,
        w_ptr=w,
        u_ptr=u,
        L=L,
        H=H,
        Hg=Hg,
        D=D,
        DV=DV,
        C=C,
        BLOCK=BLOCK,
        num_warps=4,
    )
    return {"w": w, "u": u}
