"""Round 4 candidate for L3_29_recompute_w_u_fwd (GDN/KDA W/U recompute).

Faithful port of the frozen upstream ``recompute_w_u_fwd_kernel`` (vLLM
``fla/ops/wy_fast.py``, commit 18f6bf5a) rewritten to satisfy the
Triton-Ascend static-call allowlist and the backend's dot precision set:

* ``tl.make_block_ptr`` is not on the Layer C allowlist, so all loads and
  stores use explicit pointer arithmetic with ``tl.load`` / ``tl.store``.
* ``triton.autotune`` is dropped (its config table needs comprehensions,
  which the static checker rejects); a fixed launch configuration is used.
* Both dots pin ``input_precision="ieee"``. That is the precision model
  the frozen oracle expects on this hardware, whose dot only supports
  ("ieee", "hf32"):
  - ``u`` dot: full-fp32 contraction (upstream pins ``allow_tf32=False``).
  - ``w`` dot: upstream leaves the dot unpinned, so on the CUDA daemon both
    operands are truncated to TF32 before multiplying. We emulate that
    truncation with an integer bit-mask (clear the low 13 mantissa bits),
    then run an IEEE dot -- bit-identical to the oracle's ``_to_tf32``.

Semantics (non-varlen path only, the sole path the oracle models):

    u[b, r, h, :] = sum_j A[b, r, h, j] * (beta[b, r_j, h] * v[b, r_j, h, :])
    w[b, r, h, :] = sum_j A[b, r, h, j]
                        * (beta[b, r_j, h] * exp(g[b, r_j, h])
                           * k[b, r_j, h // (H // Hg), :])

where ``r_j = i_t*BT + j`` enumerates the rows of chunk ``i_t`` and ``j``
is the local within-chunk column index. Every contract shape satisfies
``T % BT == 0`` and ``K % BK == V % BV == 0`` (block sizes follow the
extents), so all tiles are fully in-bounds and no boundary masking is
needed.
"""

import torch

import triton
import triton.language as tl


@triton.jit
def _to_tf32(x):
    """Truncate an fp32 tensor to TF32 the way the hardware dot would.

    Mirrors the oracle's ``_to_tf32``: clear the 13 low mantissa bits of
    the float32 encoding (leaving sign, exponent, and 10 mantissa bits)
    and bitcast back to fp32.
    """
    bits = x.to(tl.int32, bitcast=True)
    masked = bits & -8192  # 0xFFFFE000 in two's-complement int32
    return masked.to(tl.float32, bitcast=True)


@triton.jit(do_not_specialize=["T"])
def recompute_w_u_fwd_kernel(
    k,
    v,
    beta,
    w,
    u,
    A,
    g,
    T,
    H: tl.constexpr,
    Hg: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BT: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
):
    i_t = tl.program_id(0)
    i_bh = tl.program_id(1)
    i_b = i_bh // H
    i_h = i_bh % H

    offs_r = tl.arange(0, BT)

    # beta / g: [B, T, H], time stride H
    p_sc = (i_b * T + i_t * BT) * H + i_h
    b_beta = tl.load(beta + p_sc + offs_r * H)
    b_g = tl.exp(tl.load(g + p_sc + offs_r * H))

    # A: [B, T, H, BT], contiguous along the local column axis
    p_A = (i_b * T + i_t * BT) * H * BT + i_h * BT
    b_A = tl.load(A + p_A + offs_r[:, None] * (H * BT) + tl.arange(0, BT)[None, :])

    b_Au = b_A
    b_Aw = _to_tf32(b_A)

    # u loop over V blocks: u_tile = A @ (beta * v)
    p_vu = (i_b * T + i_t * BT) * H * V + i_h * V
    for i_v in range(tl.cdiv(V, BV)):
        offs_c = i_v * BV + tl.arange(0, BV)
        ptr = p_vu + offs_r[:, None] * (H * V) + offs_c[None, :]
        b_v = tl.load(v + ptr)
        b_vb = b_v * b_beta[:, None]
        b_u = tl.dot(b_Au, b_vb, input_precision="ieee")
        tl.store(u + ptr, b_u)

    # w loop over K blocks; value head h reads key head h // (H // Hg)
    i_hg = i_h // (H // Hg)
    p_k = (i_b * T + i_t * BT) * Hg * K + i_hg * K
    p_w = (i_b * T + i_t * BT) * H * K + i_h * K
    for i_k in range(tl.cdiv(K, BK)):
        offs_c = i_k * BK + tl.arange(0, BK)
        b_k = tl.load(k + p_k + offs_r[:, None] * (Hg * K) + offs_c[None, :])
        b_kb = b_k * b_beta[:, None] * b_g[:, None]
        b_w = tl.dot(b_Aw, _to_tf32(b_kb), input_precision="ieee")
        tl.store(w + p_w + offs_r[:, None] * (H * K) + offs_c[None, :], b_w)


def npu_triton_impl(inputs: dict) -> dict:
    """Non-varlen launcher mirroring the upstream ``recompute_w_u_fwd``."""
    k = inputs["k"]
    v = inputs["v"]
    beta = inputs["beta"]
    g_cumsum = inputs["g_cumsum"]
    A = inputs["A"]

    B, T, Hg, K = k.shape
    V = v.shape[-1]
    H = v.shape[-2]
    BT = A.shape[-1]

    # Block sizes follow the extents: 64 where divisible, else the extent
    # itself (e.g. K = V = 16 for the tiny shape), so every tile is fully
    # in-bounds and the kernel needs no boundary masks.
    BK = 64 if K % 64 == 0 else triton.next_power_of_2(K)
    BV = 64 if V % 64 == 0 else triton.next_power_of_2(V)

    u = torch.empty_like(v)
    w = k.new_empty(B, T, H, K)

    NT = triton.cdiv(T, BT)

    recompute_w_u_fwd_kernel[(NT, B * H)](
        k=k,
        v=v,
        beta=beta,
        w=w,
        u=u,
        A=A,
        g=g_cumsum,
        T=T,
        H=H,
        Hg=Hg,
        K=K,
        V=V,
        BT=BT,
        BK=BK,
        BV=BV,
        num_warps=1,
        num_stages=1,
    )
    return {"w": w, "u": u}
