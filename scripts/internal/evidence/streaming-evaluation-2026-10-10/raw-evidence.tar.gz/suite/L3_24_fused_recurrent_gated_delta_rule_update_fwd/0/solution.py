"""L3_24 fused_recurrent_gated_delta_rule_update_fwd_kernel -- Triton-Ascend port.

Gated DeltaNet recurrent forward with a per-sequence state carry-in and a
final-state write-back.  One program owns a stripe of value rows of a single
(batch, value head) state matrix and walks the token sequence in order, so
the recurrence is token exact and the state itself never leaves the tile.

Per token t, with the state S laid out [V, K] (rows = value channels,
columns = key channels, the reference memory layout):

    a_t  = exp(g_t)                                    scalar per head
    kS_t = sum_k (a_t * S_{t-1})[v, k] * k_t[k]        decayed contraction
    d_t  = (v_t - kS_t) * beta_t                       delta correction
    S_t  = a_t * S_{t-1} + outer(d_t, k_t)             rank-1 update
    o_t  = sum_k S_t[v, k] * (scale * q_t[k])          read the updated state

Because a_t is a per-head scalar, contracting the already-decayed state is
equal to scaling the contraction of the carried state, so the decay is folded
into the two places where the tile is touched (the kS reduction and the fused
decay-plus-rank-1 update) instead of being materialised as a third pass over
the whole tile.  The update still reads the decayed state and the output still
reads the updated one, i.e. the reference's load-bearing order is preserved;
what changes is one fp32 rounding on a single product rather than the
recurrence itself.  Everything after a load is fp32, and only the per-token
output narrows to the bf16 output dtype at the store.

Key channels are never split across programs: both K-contractions need whole
rows of S, and the reference asserts a single key tile as well.
"""

import torch
import triton
import triton.language as tl


@triton.jit(do_not_specialize=['T'])
def fused_recurrent_gated_delta_rule_update_fwd_kernel(
    q,
    k,
    v,
    g,
    beta,
    o,
    h0_source,
    h0_indices,
    cu_seqlens,
    scale,
    intermediate_states_buffer,
    intermediate_state_indices,
    cache_steps,
    retrieve_parent_token_ptr,
    stride_retrieve_parent_token_seq: tl.constexpr,
    stride_retrieve_parent_token_token: tl.constexpr,
    T,
    NP2_T: tl.constexpr,
    B: tl.constexpr,
    H: tl.constexpr,
    HV: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
    IS_BETA_HEADWISE: tl.constexpr,
    USE_QK_L2NORM_IN_KERNEL: tl.constexpr,
    IS_VARLEN: tl.constexpr,
    DISABLE_STATE_UPDATE: tl.constexpr,
    DISABLE_OUTPUT_CALCULATION: tl.constexpr,
    CACHE_INTERMEDIATE_STATES: tl.constexpr,
    HAS_EAGLE_TREE_CUSTOM_ATTN_MASK: tl.constexpr,
):
    i_v = tl.program_id(0)
    i_nh = tl.program_id(1)
    i_n = i_nh // HV
    i_hv = i_nh % HV
    i_h = i_hv // (HV // H)

    if IS_VARLEN:
        bos = tl.load(cu_seqlens + i_n).to(tl.int64)
        eos = tl.load(cu_seqlens + i_n + 1).to(tl.int64)
        T = eos - bos
    else:
        bos = i_n * T

    o_k = tl.arange(0, BK)
    o_v = i_v * BV + tl.arange(0, BV)

    p_q = q + (bos * H + i_h) * K + o_k
    p_k = k + (bos * H + i_h) * K + o_k
    p_v = v + (bos * HV + i_hv) * V + o_v
    if IS_BETA_HEADWISE:
        p_beta = beta + (bos * HV + i_hv) * V + o_v
    else:
        p_beta = beta + bos * HV + i_hv
    p_g = g + bos * HV + i_hv
    p_o = o + (bos * HV + i_hv) * V + o_v

    mask_k = o_k < K
    mask_v = o_v < V
    mask_h = mask_v[:, None] & mask_k[None, :]

    b_h = tl.zeros([BV, BK], dtype=tl.float32)
    cache_idx = -1
    if USE_INITIAL_STATE:
        # The pool-slot predicate rides on the load/store mask instead of a
        # runtime branch, so no control-flow join has to carry the [BV, BK]
        # tile around.
        slot = tl.load(h0_indices + i_n)
        live = slot >= 0
        safe = tl.where(live, slot, 0)
        p_h0 = (
            h0_source
            + safe.to(tl.int64) * (HV * K * V)
            + i_hv * (K * V)
            + o_v[:, None] * K
            + o_k[None, :]
        )
        b_h += tl.load(p_h0, mask=mask_h & live, other=0).to(tl.float32)
    if CACHE_INTERMEDIATE_STATES:
        cache_idx = tl.load(intermediate_state_indices + i_n)

    if HAS_EAGLE_TREE_CUSTOM_ATTN_MASK:
        token_indices = tl.arange(0, NP2_T)
        parent_idx_tokens = tl.load(
            retrieve_parent_token_ptr
            + i_n * stride_retrieve_parent_token_seq
            + token_indices * stride_retrieve_parent_token_token,
            mask=token_indices < T,
            other=0,
        )

    step_idx = 0
    for _ in range(0, T):
        if HAS_EAGLE_TREE_CUSTOM_ATTN_MASK:
            if step_idx != 0:
                parent_step_idx = tl.sum(
                    tl.where(token_indices == step_idx, parent_idx_tokens, 0)
                )
                if cache_idx >= 0:
                    b_h = tl.load(
                        intermediate_states_buffer
                        + cache_idx.to(tl.int64) * (cache_steps * HV * K * V)
                        + parent_step_idx * (HV * K * V)
                        + i_hv * (K * V)
                        + o_v[:, None] * K
                        + o_k[None, :],
                        mask=mask_h,
                        other=0,
                    ).to(tl.float32)

        b_q = tl.load(p_q, mask=mask_k, other=0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0).to(tl.float32)
        b_g = tl.load(p_g).to(tl.float32)
        if USE_QK_L2NORM_IN_KERNEL:
            b_q = b_q / tl.sqrt(tl.sum(b_q * b_q) + 1e-06)
            b_k = b_k / tl.sqrt(tl.sum(b_k * b_k) + 1e-06)
        b_q = b_q * scale

        b_a = tl.exp(b_g)
        # Contraction of the carried state rescaled by the decay, which is the
        # same value as contracting the decayed state.
        b_v -= b_a * tl.sum(b_h * b_k[None, :], 1)
        if IS_BETA_HEADWISE:
            b_beta = tl.load(p_beta, mask=mask_v, other=0).to(tl.float32)
        else:
            b_beta = tl.load(p_beta).to(tl.float32)
        b_v *= b_beta

        # Decay and rank-1 update fused into a single sweep of the tile.
        b_h = b_h * b_a + b_v[:, None] * b_k[None, :]

        if not DISABLE_OUTPUT_CALCULATION:
            b_o = tl.sum(b_h * b_q[None, :], 1)
            tl.store(p_o, b_o.to(p_o.dtype.element_ty), mask=mask_v)
        if CACHE_INTERMEDIATE_STATES:
            if cache_idx >= 0:
                tl.store(
                    intermediate_states_buffer
                    + cache_idx.to(tl.int64) * (cache_steps * HV * K * V)
                    + step_idx * (HV * K * V)
                    + i_hv * (K * V)
                    + o_v[:, None] * K
                    + o_k[None, :],
                    b_h.to(intermediate_states_buffer.dtype.element_ty),
                    mask=mask_h,
                )

        step_idx += 1
        p_q += H * K
        p_k += H * K
        p_o += HV * V
        p_v += HV * V
        p_g += HV
        p_beta += HV * (V if IS_BETA_HEADWISE else 1)

    if not DISABLE_STATE_UPDATE:
        slot = tl.load(h0_indices + i_n)
        live = slot >= 0
        safe = tl.where(live, slot, 0)
        p_h0 = (
            h0_source
            + safe.to(tl.int64) * (HV * K * V)
            + i_hv * (K * V)
            + o_v[:, None] * K
            + o_k[None, :]
        )
        tl.store(p_h0, b_h.to(p_h0.dtype.element_ty), mask=mask_h & live)


def _pow2(n: int) -> int:
    p = 1
    while p < n:
        p = p * 2
    return p


def _cdiv(a: int, b: int) -> int:
    return -(-a // b)


# The state stripe stays resident for the whole token walk, so its fp32 lane
# count is capped at 4096 (16 KB).  With num_stages=3 the loop keeps the tile
# and a couple of broadcast temporaries live at once, and the reference's own
# narrowest tiling never exceeds this footprint either.  Rows are widened while
# the launch is short of programs (a 256-program target keeps the cores fed) and
# narrowed again once there are enough, and both tile edges stay >= 8 lanes so
# no vector op runs on a sliver.
_LANE_CAP = 4096
_ROW_FLOOR = 8
_ROW_SLACK = 64
_PROGRAM_TARGET = 256


def _pick_blocks(dim_k: int, dim_v: int, seq_heads: int):
    bk = _pow2(dim_k)
    if bk < _ROW_FLOOR:
        bk = _ROW_FLOOR
    # Widest row count that still fits the lane budget.
    limit = _LANE_CAP // bk
    if limit < 1:
        limit = 1
    if limit > _ROW_SLACK:
        limit = _ROW_SLACK
    wanted = _cdiv(_PROGRAM_TARGET, seq_heads if seq_heads > 0 else 1)
    if wanted < 1:
        wanted = 1
    bv = _pow2(_cdiv(dim_v, wanted))
    if bv > limit:
        bv = limit
    if bv < _ROW_FLOOR and limit >= _ROW_FLOOR:
        bv = _ROW_FLOOR
    return bk, bv


def _pick_warps(lanes: int) -> int:
    if lanes <= 1024:
        return 1
    if lanes <= 2048:
        return 2
    return 4


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    g = inputs["g"]
    beta = inputs["beta"]
    initial_state = inputs["initial_state"]
    scale = inputs["scale"]

    B, T, H, K = k.shape
    V = v.shape[-1]
    HV = v.shape[2]

    # The update step writes the final state back into the slot it read from,
    # so it works on a private fp32 copy: the caller's tensor is never mutated
    # and a repeated call sees the same carry-in.
    state = initial_state.contiguous().to(torch.float32).clone()
    h0_indices = torch.arange(B, device=initial_state.device)

    o = torch.empty((B, T, HV, V), dtype=q.dtype, device=q.device)

    BK, BV = _pick_blocks(K, V, B * HV)
    NV = _cdiv(V, BV)
    lanes = BK * BV

    fused_recurrent_gated_delta_rule_update_fwd_kernel[(NV, B * HV)](
        q.contiguous(),
        k.contiguous(),
        v.contiguous(),
        g.contiguous(),
        beta.contiguous(),
        o,
        state,
        h0_indices,
        q,
        scale,
        q,
        q,
        1,
        q,
        1,
        1,
        T,
        NP2_T=_pow2(T),
        B=B,
        H=H,
        HV=HV,
        K=K,
        V=V,
        BK=BK,
        BV=BV,
        USE_INITIAL_STATE=True,
        IS_BETA_HEADWISE=beta.ndim == v.ndim,
        USE_QK_L2NORM_IN_KERNEL=False,
        IS_VARLEN=False,
        DISABLE_STATE_UPDATE=False,
        DISABLE_OUTPUT_CALCULATION=False,
        CACHE_INTERMEDIATE_STATES=False,
        HAS_EAGLE_TREE_CUSTOM_ATTN_MASK=False,
        num_warps=_pick_warps(lanes),
        num_stages=3,
    )

    return {"output": o, "final_state": state}
