"""L3_24 fused gated-delta-rule recurrent UPDATE forward, Triton-Ascend port.

Token-by-token recurrence (state kept as a V-major tile b_h == [BV, BK]):

    S_t = exp(g_t) * S_{t-1}                    # decay BEFORE any contraction
    kS  = sum_k S_t[v, k] * k_t[k]              # uses the ALREADY-decayed S
    u_t = (v_t - kS) * beta_t                   # scalar beta per (token, head)
    S_t = S_t + u_t[:, None] * k_t[None, :]     # rank-1 update
    o_t = sum_k S_t[v, k] * (scale * q_t[k])    # reads the UPDATED state

The update order above is load-bearing: decay-then-contract is not the same as
contract-then-decay on real inputs.

Parallelisation: one program owns one (sequence, value-head) state slot and one
BV-wide slice of the V axis, keeps that [BV, BK] fp32 state in registers for the
whole token loop, and writes it back once at the end (the pool slot the update
kernel reads is the same slot it overwrites).  All reduction/elementwise math is
float32; loads cast up from the storage dtype and stores cast down, so the
accumulation dtype and cast order match the reference bit-for-bit in structure.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit(do_not_specialize=['T'])
def _gated_delta_rule_update_fwd_kernel(
    q_ptr,                          # [B, T, H, K]   bf16
    k_ptr,                          # [B, T, H, K]   bf16 (l2-normalised rows)
    v_ptr,                          # [B, T, HV, V]  bf16
    g_ptr,                          # [B, T, HV]     fp32 log-decrement
    beta_ptr,                       # [B, T, HV]     bf16 scalar beta
    o_ptr,                          # [B, T, HV, V]  out, same dtype as v
    state_in_ptr,                   # [B, HV, V, K]  initial state (V-major)
    state_out_ptr,                  # [B, HV, V, K]  final state (V-major)
    scale,
    T,
    B: tl.constexpr,
    H: tl.constexpr,
    HV: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
):
    i_v = tl.program_id(0)
    i_nh = tl.program_id(1)
    i_n = i_nh // HV
    i_hv = i_nh % HV
    i_h = i_hv // (HV // H)

    bos = i_n * T
    o_k = tl.arange(0, BK)
    o_v = i_v * BV + tl.arange(0, BV)

    mask_k = o_k < K
    mask_v = o_v < V
    mask_h = mask_v[:, None] & mask_k[None, :]

    # V-major state addressing: element (v, k) of slot (n, hv) sits at
    # ((n * HV + hv) * V + v) * K + k
    p_s_in = (state_in_ptr + (i_n * HV + i_hv) * K * V
              + o_v[:, None] * K + o_k[None, :])
    p_s_out = (state_out_ptr + (i_n * HV + i_hv) * K * V
               + o_v[:, None] * K + o_k[None, :])

    p_q = q_ptr + (bos * H + i_h) * K + o_k
    p_k = k_ptr + (bos * H + i_h) * K + o_k
    p_v = v_ptr + (bos * HV + i_hv) * V + o_v
    p_g = g_ptr + bos * HV + i_hv
    p_beta = beta_ptr + bos * HV + i_hv
    p_o = o_ptr + (bos * HV + i_hv) * V + o_v

    b_h = tl.load(p_s_in, mask=mask_h, other=0.0).to(tl.float32)

    for _ in range(0, T):
        b_q = tl.load(p_q, mask=mask_k, other=0.0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0.0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0.0).to(tl.float32)
        b_g = tl.load(p_g).to(tl.float32)
        b_beta = tl.load(p_beta).to(tl.float32)

        # scale folds into q before the read; decay lands on the state first
        b_q = b_q * scale
        b_h = b_h * tl.exp(b_g)

        # kS on the decayed state, then the gated rank-1 correction
        b_v = b_v - tl.sum(b_h * b_k[None, :], 1)
        b_v = b_v * b_beta
        b_h = b_h + b_v[:, None] * b_k[None, :]

        b_o = tl.sum(b_h * b_q[None, :], 1)
        tl.store(p_o, b_o.to(o_ptr.dtype.element_ty), mask=mask_v)

        p_q += H * K
        p_k += H * K
        p_v += HV * V
        p_g += HV
        p_beta += HV
        p_o += HV * V

    tl.store(p_s_out, b_h.to(state_out_ptr.dtype.element_ty), mask=mask_h)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    g = inputs["g"]
    beta = inputs["beta"]
    h0 = inputs["initial_state"]
    scale = inputs["scale"]

    q = q.contiguous()
    k = k.contiguous()
    v = v.contiguous()
    g = g.contiguous()
    beta = beta.contiguous()
    h0 = h0.contiguous()

    B, T, H, K = q.shape
    HV = v.shape[2]
    V = v.shape[3]

    # BK covers the whole contraction axis (splitting K across programs cannot
    # express a single-program recurrence); BV slices V so small shapes keep
    # enough programs in flight to fill the device.
    BK = triton.next_power_of_2(K)
    BV = min(triton.next_power_of_2(V), 8)
    NV = triton.cdiv(V, BV)

    o = torch.empty(B, T, HV, V, dtype=v.dtype, device=v.device)
    final_state = torch.empty(B, HV, V, K, dtype=h0.dtype, device=h0.device)

    _gated_delta_rule_update_fwd_kernel[(NV, B * HV)](
        q, k, v, g, beta, o, h0, final_state,
        scale, T,
        B=B, H=H, HV=HV, K=K, V=V, BK=BK, BV=BV,
        num_warps=1, num_stages=1,
    )

    return {"output": o, "final_state": final_state}
