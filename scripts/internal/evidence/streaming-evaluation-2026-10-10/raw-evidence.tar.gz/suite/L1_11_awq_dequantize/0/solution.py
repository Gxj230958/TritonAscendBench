"""Triton-Ascend candidate for the AWQ lane-expansion task (level L1), round 5.

Operation
---------
Expand an AWQ-packed int32 weight matrix into a half-precision matrix, one
4-bit lane per output element, and apply the per-group zero point and scale:

    out[r, c * 8 + l] = (lane(qweight[r, c], l) - lane(zeros[g, c], l))
                        * scales[g, c * 8 + l]      with g = r // group_size

and group_size = rows // scales_rows, exactly like the reference entrypoint.

Tensor shapes:

    qweight : [R, C]        int32    (8 packed lanes per int32)
    scales  : [R // G, C*8] float16
    zeros   : [R // G, C]   int32
    output  : [R, C*8]      float16

Lane order inside a packed word follows the AWQ "reverse" permutation
[0, 4, 1, 5, 2, 6, 3, 7], so logical lane l sits at bit offset

    4 * ((l // 2) + 4 * (l % 2))   ->  [0, 16, 4, 20, 8, 24, 12, 28]

which is the closed form of the three nested interleave steps in the reference
source. The reference widens the unpacked lanes to float32, subtracts and
multiplies there, and narrows the product to float16 only at the end, so both
bodies below keep the same cast order.

What this round changes
-----------------------
Round 4 was correct on 49 of 49 shapes and left about 1.3-1.4x of device time on
the table next to round 3, because round 3 -- the same arithmetic, the same
rank-3 tile, minus the predicates -- ran 30-45% faster on every shape where both
rounds were measured. Round 4 had bought those predicates with the only
correctness evidence available at the time. This round spends them where they
are actually needed and drops them where they are not.

The need is now pinned down exactly. Round 3 passed 13 shapes and failed 36. For
every entry in the task's shape list I replayed round 3's own tile choice and
asked one question about it: does one program's store land on a SINGLE
contiguous run of output memory? That holds when the tile spans a whole row, so
successive tile rows are adjacent, or when it spans a single row, so there is
nothing to stride across. That one test reproduces round 3's pass set with no
exceptions, 13 passed and 36 failed, and it is sharper than round 4's reading,
which had to fall back on "single band or height one" and then explain H6
separately. So the rule is not that a predicate is missing. The rule is that
this back end places an unmasked store correctly when its addresses form one
run, and mis-places it when they form a strided block -- scattering
correctly-valued lanes over the wrong rows, which is precisely the max_abs 15
with max_rel 1.5e13 signature on all 36 round-3 failures.

Given that, the predicate and the contiguity are two separate properties, and
only contiguity is load-bearing. So there are two kernel bodies:

  * awq_expand_row_kernel -- no predicate anywhere. Reached when the host can
    give the tile the whole packed row, i.e. BLOCK_X == packed width, which
    makes grid_x one and turns every store into one contiguous run of
    BLOCK_Y * packed_width * 8 halfs. It requires a packed width that is a
    power of two up to 256, which covers 21 of the 49 shapes. Every address in
    it is in range by construction: BLOCK_X is the row width, and BLOCK_Y
    divides both the row count and the scale group.
  * awq_expand_scale_kernel -- round 4's predicated body, unchanged, for the
    other 28. Widths 3, 12, 48, 96 and 192 are three times a power of two, so no
    power-of-two BLOCK_X can span them; their stores really are strided blocks
    and really do need the guarded transfer.

The launch keeps two axes in both paths, as in round 4, with the x axis simply
one on the fast path -- so this round's delta against round 4 is the predicate,
on a geometry the same family round 4 already ran. Neither body changes the
arithmetic, the rank-3 tile, the fp32 widening, the single narrowing cast at the
store, the scalar group index, or the one-kernel-per-call count.

Two things confine the fast path to ground that has already been measured on
the device. Twelve of its 21 shapes (P1, P2, P3, P5, P12, P13, P15, P16, H2,
H3, H4, H5) land on the identical BLOCK_X, BLOCK_Y that round 3 ran unmasked and
passed, so those are a straight replay of a tile that already has a passing
receipt -- 144 to 273 us there, against 144 to 381 us for round 4's masked run of
the same tile. The other nine (P4, P7, P8, P36, P37, P39, P41, H7, H8) take a
wider BLOCK_X and a correspondingly shorter tile, and the chooser holds their
product to 2048 output lanes per program, which is H3's proven volume: H3 ran
that unmasked, correctly, storing a single 2048-half run. So no fast-path tile
is bigger than one that already ran on this device, and no contiguous run it
stores is longer either. What changes on those nine is the shape of a volume
that is already covered -- one 2048-half run instead of 2, 4, 8, 16 or 32
strided runs of 128 halfs. Contiguity, not tile size, is what round 3 shows
governs whether an unmasked store lands, so widening BLOCK_X takes the speed
without moving the condition that carries correctness.

Expected effect, from the two rounds' own medians. The twelve replays are a
known quantity: round 3's time there is round 4's time divided by a mask tax
whose median over those twelve is 0.909, so they recover about 9% each, which by
itself moves the geomean from 0.398 ms to roughly 0.384 ms. The nine widenings
have no passing round-3 number to aim at -- round 3 failed them -- so they are
scored here only on the argument above, that a contiguous run cannot cost more
than the strided block it replaces. Taken at face value that adds a few percent
more, to roughly 0.377 ms; if a wide tile turns out to cost as much as the mask
it saves, they land back at the 0.384 ms the replays guarantee. The 28
predicated shapes are byte-identical to round 4 in source and in tile choice, so
they are the control, and they are also the reason nothing else can regress.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def awq_expand_row_kernel(
    qw_ptr,
    sc_ptr,
    zr_ptr,
    out_ptr,
    group_size,
    group_rows,
    qw_row_stride,
    sc_row_stride,
    zr_row_stride,
    out_row_stride,
    BLOCK_Y: tl.constexpr,
    BLOCK_X: tl.constexpr,
    BLOCK_L: tl.constexpr,
):
    """Whole-row tile with no predicates.

    BLOCK_X is the entire packed width and grid_x is one, so a program's store
    is one contiguous run of BLOCK_Y * BLOCK_X * BLOCK_L halfs -- the property
    that round 3 showed an unmasked store needs -- and every address is in
    range by construction, so there is nothing for a mask to protect.
    """
    pid_x = tl.program_id(axis=0)
    pid_y = tl.program_id(axis=1)

    offs_y = pid_y * BLOCK_Y + tl.arange(0, BLOCK_Y)
    offs_x = pid_x * BLOCK_X + tl.arange(0, BLOCK_X)
    lane = tl.arange(0, BLOCK_L)

    # Bit offset of logical lane l under the AWQ reverse order.
    shifts = ((lane >> 1) + 4 * (lane & 1)) * 4

    # Output column of (word x, lane l). With the full row in hand this is
    # 0 .. cols - 1, so the scale row is read whole and contiguously.
    out_col = offs_x[:, None] * BLOCK_L + lane[None, :]

    # BLOCK_Y divides group_size and every tile starts on a multiple of
    # BLOCK_Y, so the whole tile shares one group: the group index is a scalar
    # and the zero / scale rows are fetched once per program. The clamp is
    # inert for every shape in the task's list and keeps a ragged row count
    # from addressing past the last group row.
    group = (pid_y * BLOCK_Y) // group_size
    group = tl.minimum(group, group_rows - 1)

    word = tl.load(qw_ptr + offs_y[:, None] * qw_row_stride + offs_x[None, :])
    zword = tl.load(zr_ptr + group * zr_row_stride + offs_x)
    scale = tl.load(sc_ptr + group * sc_row_stride + out_col)

    vals = (word[:, :, None] >> shifts[None, None, :]) & 15
    base = (zword[:, None] >> shifts[None, :]) & 15
    diff = vals - base[None, :, :]

    # Widening to float32 before the multiply reproduces the reference
    # arithmetic; the store narrows the product once, to the output dtype.
    product = diff.to(tl.float32) * scale.to(tl.float32)[None, :, :]

    tl.store(out_ptr + offs_y[:, None, None] * out_row_stride
             + out_col[None, :, :], product)


@triton.jit
def awq_expand_scale_kernel(
    qw_ptr,
    sc_ptr,
    zr_ptr,
    out_ptr,
    rows,
    cols,
    group_size,
    group_rows,
    qw_row_stride,
    sc_row_stride,
    zr_row_stride,
    out_row_stride,
    BLOCK_Y: tl.constexpr,
    BLOCK_X: tl.constexpr,
    BLOCK_L: tl.constexpr,
):
    """Round 4's predicated body, for a packed width that no power of two can
    span (3, 12, 48, 96, 192): the tile covers several column bands, its store
    is a strided block, and that is the case round 3 showed needs the guarded
    transfer."""
    pid_x = tl.program_id(axis=0)
    pid_y = tl.program_id(axis=1)

    offs_y = pid_y * BLOCK_Y + tl.arange(0, BLOCK_Y)
    offs_x = pid_x * BLOCK_X + tl.arange(0, BLOCK_X)
    lane = tl.arange(0, BLOCK_L)

    # Bit offset of logical lane l under the AWQ reverse order.
    shifts = ((lane >> 1) + 4 * (lane & 1)) * 4

    # Output column of (word x, lane l). Affine in both tile indices, so the
    # scale fetch and the fp16 store share one contiguous run of halfs.
    out_col = offs_x[:, None] * BLOCK_L + lane[None, :]

    masks_y = offs_y < rows
    masks_x = offs_x < (cols // BLOCK_L)
    valid_col = out_col < cols
    mask_2d = masks_y[:, None] & masks_x[None, :]

    group = (pid_y * BLOCK_Y) // group_size
    group = tl.minimum(group, group_rows - 1)

    word = tl.load(qw_ptr + offs_y[:, None] * qw_row_stride + offs_x[None, :],
                   mask_2d, 0)
    zword = tl.load(zr_ptr + group * zr_row_stride + offs_x, masks_x, 0)
    scale = tl.load(sc_ptr + group * sc_row_stride + out_col, valid_col, 0.0)

    vals = (word[:, :, None] >> shifts[None, None, :]) & 15
    base = (zword[:, None] >> shifts[None, :]) & 15
    diff = vals - base[None, :, :]

    product = diff.to(tl.float32) * scale.to(tl.float32)[None, :, :]

    mask_3d = masks_y[:, None, None] & valid_col[None, :, :]
    tl.store(out_ptr + offs_y[:, None, None] * out_row_stride
             + out_col[None, :, :], product, mask_3d)


_ROW_CONFIG: dict = {}
_CONFIG: dict = {}

# Tile widths, largest first. BLOCK_X counts packed words (8 lanes each);
# BLOCK_Y counts rows and must also divide the scale group.
_X_CANDIDATES = (16, 8, 4, 2, 1)
_Y_CANDIDATES = (32, 16, 8, 4, 2, 1)

# Output lanes per program. 2048 is the tile round 3 ran correctly and fastest
# on H3, so no whole-row program is bigger than something already measured on
# the device, and the contiguous run it stores is at most 2048 halfs.
_LANE_BUDGET = 2048
# Widest packed row the whole-row tile spans: 256 words is 2048 halfs, which is
# the whole budget in one row, so such a tile has height 1.
_MAX_ROW_WORDS = 256
# Launch-depth floor, shared with the predicated path.
_MIN_PROGRAMS = 128
# Ceiling on one launch axis. The whole-row path puts the entire row count on
# the y axis, so a deep enough matrix would run past it; at that depth the
# predicated body is used instead. Inert for every shape in the task's list --
# the deepest fast-path launch here is H8 at 32768 programs.
_MAX_AXIS = 65535


def _is_pow2(n: int) -> bool:
    return n > 0 and (n & (n - 1)) == 0


def _row_tile(rows: int, packed_cols: int, group_size: int):
    """Geometry for the predicate-free body, or None when no power-of-two tile
    can span a whole packed row. BLOCK_X == packed_cols is what makes grid_x
    one and the store one contiguous run."""
    key = (rows, packed_cols, group_size)
    if key in _ROW_CONFIG:
        return _ROW_CONFIG[key]

    cfg = None
    if _is_pow2(packed_cols) and packed_cols <= _MAX_ROW_WORDS:
        lanes_row = packed_cols * 8
        block_y = 1
        while block_y * 2 * lanes_row <= _LANE_BUDGET:
            nxt = block_y * 2
            if group_size % nxt != 0 or rows % nxt != 0:
                break
            block_y = nxt
        # Grow the launch back up when that budget leaves too few programs to
        # cover the device; the halved height is still an exact divisor, so the
        # store stays one contiguous run either way.
        while block_y > 1 and rows // block_y < _MIN_PROGRAMS:
            half = block_y // 2
            if group_size % half != 0 or rows % half != 0:
                break
            block_y = half

        cfg = (packed_cols, block_y)
        if rows // block_y > _MAX_AXIS:
            cfg = None

    _ROW_CONFIG[key] = cfg
    return cfg


def _tile(rows: int, packed_cols: int, group_size: int):
    """Exact tiling for the predicated body: BLOCK_X divides packed_cols,
    BLOCK_Y divides both group_size and rows. Cached so the search runs once
    per shape."""
    key = (rows, packed_cols, group_size)
    if key in _CONFIG:
        return _CONFIG[key]

    block_x = 1
    for cand in _X_CANDIDATES:
        if packed_cols % cand == 0:
            block_x = cand
            break
    block_y = 1
    for cand in _Y_CANDIDATES:
        if group_size % cand == 0 and rows % cand == 0:
            block_y = cand
            break

    grid_x = packed_cols // block_x
    grid_y = rows // block_y
    # Shrink the tile height when the exact fit leaves the launch too shallow
    # to cover the device; the halved height is still an exact divisor.
    while block_y > 1 and grid_x * grid_y < 128:
        half = block_y // 2
        if group_size % half != 0 or rows % half != 0:
            break
        block_y = half
        grid_y = rows // block_y

    cfg = (block_x, block_y, grid_x, grid_y)
    _CONFIG[key] = cfg
    return cfg


def npu_triton_impl(inputs: dict) -> dict:
    qweight = inputs["qweight"]
    scales = inputs["scales"]
    zeros = inputs["zeros"]

    rows = int(qweight.shape[0])
    packed_cols = int(qweight.shape[1])
    scale_rows = int(scales.shape[0])
    cols = packed_cols * 8
    group_size = rows // scale_rows if scale_rows > 0 else 0

    result = torch.empty((rows, cols), dtype=scales.dtype,
                         device=qweight.device)
    if rows <= 0 or packed_cols <= 0 or group_size <= 0:
        return {"output": result}

    qw_stride = int(qweight.stride(0))
    sc_stride = int(scales.stride(0))
    zr_stride = int(zeros.stride(0))
    out_stride = int(result.stride(0))

    row_tile = _row_tile(rows, packed_cols, group_size)
    if row_tile is not None:
        block_x, block_y = row_tile
        awq_expand_row_kernel[(1, rows // block_y)](
            qweight,
            scales,
            zeros,
            result,
            group_size,
            scale_rows,
            qw_stride,
            sc_stride,
            zr_stride,
            out_stride,
            BLOCK_Y=block_y,
            BLOCK_X=block_x,
            BLOCK_L=8,
        )
        return {"output": result}

    block_x, block_y, grid_x, grid_y = _tile(rows, packed_cols, group_size)

    awq_expand_scale_kernel[(grid_x, grid_y)](
        qweight,
        scales,
        zeros,
        result,
        rows,
        cols,
        group_size,
        scale_rows,
        qw_stride,
        sc_stride,
        zr_stride,
        out_stride,
        BLOCK_Y=block_y,
        BLOCK_X=block_x,
        BLOCK_L=8,
    )
    return {"output": result}


run = npu_triton_impl
