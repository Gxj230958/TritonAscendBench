"""Triton-Ascend implementation for L3_12_selective_state_update.

Mamba2-style selective-state single-step decode update. Per batch b and head h
(group g = h // (H // G)):

    dt    = softplus(dt + dt_bias)                # [dim]
    dA    = exp(A * dt[:, None])                  # [dim, dstate]
    dB    = B[g][None, :] * dt[:, None]           # [dim, dstate]
    state = state * dA + dB * x[:, None]          # [dim, dstate] (in place)
    out   = sum(state * C[g][None, :], dstate)    # [dim]
    out  += x * D                                 # D skip connection
    out  *= z * sigmoid(z)                        # SiLU z-gate

Only the base decode path is supported, matching the contract: DT_SOFTPLUS,
HAS_D, HAS_Z and HAS_DT_BIAS are all true; no state batch indices, no
speculative decoding, no varlen, no stochastic rounding.

Dtype policy mirrors the reference: every input is loaded and upcast to
fp32 before any arithmetic (bf16 activations x/dt/z/B/C, fp32 parameters
A/D/dt_bias), the recurrence runs fully in fp32, the state write-back stays
fp32 (in place) and the ssm output is fp32.

Entry point: npu_triton_impl(inputs: dict) -> dict returning {"out": ...}
and mutating inputs["state"] in place.
"""

import torch
import torch_npu  # noqa: F401  (registers the npu device with torch)
import triton
import triton.language as tl


@triton.jit
def _softplus(dt):
    # Numerically guarded softplus: log(exp(dt) + 1) for dt <= 20, else dt.
    dt = tl.where(dt <= 20.0, tl.log(tl.exp(dt) + 1.0), dt)
    return dt


@triton.jit
def _selective_scan_update_kernel_npu(
    state_ptr,
    x_ptr,
    dt_ptr,
    dt_bias_ptr,
    A_ptr,
    B_ptr,
    C_ptr,
    D_ptr,
    z_ptr,
    out_ptr,
    dim,
    dstate,
    nheads_ngroups_ratio,
    stride_state_batch,
    stride_state_head,
    stride_state_dim,
    stride_state_dstate,
    stride_x_batch,
    stride_x_head,
    stride_x_dim,
    stride_dt_batch,
    stride_dt_head,
    stride_dt_dim,
    stride_dt_bias_head,
    stride_dt_bias_dim,
    stride_A_head,
    stride_A_dim,
    stride_A_dstate,
    stride_B_batch,
    stride_B_group,
    stride_B_dstate,
    stride_C_batch,
    stride_C_group,
    stride_C_dstate,
    stride_D_head,
    stride_D_dim,
    stride_z_batch,
    stride_z_head,
    stride_z_dim,
    stride_out_batch,
    stride_out_head,
    stride_out_dim,
    # Meta-parameters
    DT_SOFTPLUS: tl.constexpr,
    HAS_DT_BIAS: tl.constexpr,
    HAS_D: tl.constexpr,
    HAS_Z: tl.constexpr,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_DSTATE: tl.constexpr,
):
    pid_m = tl.program_id(axis=0)
    pid_b = tl.program_id(axis=1)
    pid_h = tl.program_id(axis=2)

    # Base decode path: single token per batch element, state batch index is
    # the batch id itself, so source and destination state coincide.
    state_ptr += pid_b * stride_state_batch + pid_h * stride_state_head

    x_ptr += pid_b * stride_x_batch + pid_h * stride_x_head
    dt_ptr += pid_b * stride_dt_batch + pid_h * stride_dt_head
    dt_bias_ptr += pid_h * stride_dt_bias_head
    A_ptr += pid_h * stride_A_head
    B_ptr += pid_b * stride_B_batch + (pid_h // nheads_ngroups_ratio) * stride_B_group
    C_ptr += pid_b * stride_C_batch + (pid_h // nheads_ngroups_ratio) * stride_C_group
    D_ptr += pid_h * stride_D_head
    z_ptr += pid_b * stride_z_batch + pid_h * stride_z_head
    out_ptr += pid_b * stride_out_batch + pid_h * stride_out_head

    offs_m = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_n = tl.arange(0, BLOCK_SIZE_DSTATE)

    state_ptrs = state_ptr + (
        offs_m[:, None] * stride_state_dim + offs_n[None, :] * stride_state_dstate
    )
    mask = (offs_m[:, None] < dim) & (offs_n[None, :] < dstate)
    state = tl.load(state_ptrs, mask=mask, other=0.0).to(tl.float32)

    dt_bias_ptrs = dt_bias_ptr + offs_m * stride_dt_bias_dim
    D_ptrs = D_ptr + offs_m * stride_D_dim
    A_ptrs = A_ptr + offs_m[:, None] * stride_A_dim + offs_n[None, :] * stride_A_dstate

    x_ptrs = x_ptr + offs_m * stride_x_dim
    dt_ptrs = dt_ptr + offs_m * stride_dt_dim
    B_ptrs = B_ptr + offs_n * stride_B_dstate
    C_ptrs = C_ptr + offs_n * stride_C_dstate
    z_ptrs = z_ptr + offs_m * stride_z_dim
    out_ptrs = out_ptr + offs_m * stride_out_dim

    x = tl.load(x_ptrs, mask=offs_m < dim, other=0.0).to(tl.float32)
    dt = tl.load(dt_ptrs, mask=offs_m < dim, other=0.0).to(tl.float32)
    if HAS_DT_BIAS:
        dt += tl.load(dt_bias_ptrs, mask=offs_m < dim, other=0.0).to(tl.float32)
    if DT_SOFTPLUS:
        dt = _softplus(dt)
    A = tl.load(A_ptrs, mask=mask, other=0.0).to(tl.float32)
    dA = tl.exp(A * dt[:, None])

    B = tl.load(B_ptrs, mask=offs_n < dstate, other=0.0).to(tl.float32)
    C = tl.load(C_ptrs, mask=offs_n < dstate, other=0.0).to(tl.float32)
    D = tl.load(D_ptrs, mask=offs_m < dim, other=0.0).to(tl.float32)
    z = tl.load(z_ptrs, mask=offs_m < dim, other=0.0).to(tl.float32)

    dB = B[None, :] * dt[:, None]
    state = state * dA + dB * x[:, None]

    # In-place write-back of the updated recurrent state (fp32).
    tl.store(state_ptrs, state, mask=mask)

    out = tl.sum(state * C[None, :], axis=1)
    if HAS_D:
        out += x * D
    if HAS_Z:
        out *= z * tl.sigmoid(z)
    tl.store(out_ptrs, out, mask=offs_m < dim)


def _next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


def npu_triton_impl(inputs: dict) -> dict:
    state = inputs["state"]      # [B, H, dim, dstate] fp32
    x = inputs["x"]              # [B, H, dim] bf16
    dt = inputs["dt"]            # [B, H, dim] bf16
    A = inputs["A"]              # [H, dim, dstate] fp32
    B = inputs["B"]              # [B, G, dstate] bf16
    C = inputs["C"]              # [B, G, dstate] bf16
    D = inputs["D"]              # [H, dim] fp32
    z = inputs["z"]              # [B, H, dim] bf16
    dt_bias = inputs["dt_bias"]  # [H, dim] fp32

    batch, nheads, dim, dstate = state.shape
    ngroups = B.shape[1]

    # ssm output buffer, fp32, candidate-allocated.
    out = torch.empty(x.shape, dtype=torch.float32, device=x.device)

    block_dstate = _next_pow2(dstate)
    # Round-2 geometry: round-1 measurements scale as a fixed floor plus a
    # roughly constant per-program cost (~0.16 us per AI-core task, fitted
    # across 15+ graded shapes), nearly independent of the tiny 512-element
    # tile size. Enlarge BLOCK_SIZE_M so each program owns a
    # <= 4096-element (16 KB fp32) state tile, cutting the program count
    # 4-8x on the large shapes while staying well inside the on-chip buffer.
    if block_dstate <= 64:
        block_m, num_warps = 64, 4
    else:
        block_m, num_warps = 32, 4

    grid = (triton.cdiv(dim, block_m), batch, nheads)

    _selective_scan_update_kernel_npu[grid](
        state,
        x,
        dt,
        dt_bias,
        A,
        B,
        C,
        D,
        z,
        out,
        dim,
        dstate,
        nheads // ngroups,
        state.stride(0), state.stride(1), state.stride(2), state.stride(3),
        x.stride(0), x.stride(1), x.stride(2),
        dt.stride(0), dt.stride(1), dt.stride(2),
        dt_bias.stride(0), dt_bias.stride(1),
        A.stride(0), A.stride(1), A.stride(2),
        B.stride(0), B.stride(1), B.stride(2),
        C.stride(0), C.stride(1), C.stride(2),
        D.stride(0), D.stride(1),
        z.stride(0), z.stride(1), z.stride(2),
        out.stride(0), out.stride(1), out.stride(2),
        True,           # DT_SOFTPLUS
        True,           # HAS_DT_BIAS
        True,           # HAS_D
        True,           # HAS_Z
        BLOCK_SIZE_M=block_m,
        BLOCK_SIZE_DSTATE=block_dstate,
        num_warps=num_warps,
    )

    return {"out": out}
