"""Chunked LoRA expand (segmented SGMV-B) for Triton-Ascend.

Entry point: ``npu_triton_impl(inputs) -> {"output": ...}``.

Semantics (contract.md).  ``x`` packs ``NUM_SLICES`` rank projections side by
side and each slice owns one band of the output columns, given by
``slice_offsets``.  For every segment -- the contiguous row range of ``x``
described by ``seg_indptr``, with adapter ``weight_indices[seg]`` -- and every
slice, the kernel evaluates the skinny reduction

    out[rows, c0:c1] += scaling[ad] * (x[rows, sl*r:(sl+1)*r]
                                       @ weights[ad, c0:c1, :r]^T)

with ``r = min(MAX_RANK, lora_ranks[ad])``.  Two details carry the result: each
slice strides ``x`` by the *effective* rank ``r`` rather than by ``MAX_RANK``,
and only the first ``r`` columns of a weight band take part.

Products and the reduction stay in fp32; the tile is multiplied by the
per-adapter scaling in fp32, cast to the element type of ``x``, and only then
added to whatever the output slot already holds (zero, or the base projection
when one is supplied).  That ordering is the one the source implementation
uses, and it is load-bearing for the reported tolerance.  When no base is
supplied the slot provably holds zero, so the add is folded away by the
``LOAD_BASE`` switch and the read of the output tile disappears with it; the
value written is the same either way, bit for bit.

What this round is about: every shape here is bound by per-program latency, not
by arithmetic.  A working program spends on the order of 3 to 12 microseconds on
a tile whose reduction is sixteen thousand multiply-accumulates, which is a few
hundred nanoseconds of cube work, and the measured cost tracks the number of
programs rather than the flops.  The prologue is where the rest goes.  The
previous version read one scalar, branched on it, read the next, branched again,
so six independent global loads -- the adapter id, that adapter's rank, both
segment bounds, both band bounds and the scaling -- were strung into a serial
chain, each link paying a full round trip before the next one could even be
issued.  Here all six are issued together, with no branch between them, and the
emptiness tests that used to return early became the loop bounds themselves: a
rank of zero leaves the reduction trip count at zero, a zero-length segment
leaves the row loop at zero tiles, an empty band leaves the column walk at zero
tiles.  Coverage is unchanged, the arithmetic is untouched, and the critical
path through the prologue drops from six dependent loads to the two that are
genuinely dependent, the adapter id feeding its rank.

The host reads nothing back from the device: the grid is ``(num_slices,
num_segs, col_tiles)``, all plain Python integers derived from input shapes, and
every length that lives in a device tensor (segment bounds, band bounds, rank) is
loaded inside the kernel.  Row blocks stay an inner loop, so the launch is dense
and no program is created for a segment it cannot serve.

Tile sizes come from the mean segment length and the mean band width, clamped
to a power of two inside ``[16, 64]``.  The 64 ceiling on the band dimension is
load-bearing: it is the widest column tile the device accepts for this kernel,
so a band of 1024 columns is walked as sixteen 64-wide tiles.  Those tiles are
handed to sixteen different programs by the third grid axis instead of being
chained through one program's inner loop, which keeps the work any single
program performs bounded by one tile step.  Coverage does not depend on the
split being exact: a program owns tiles ``z, z + col_tiles, ...`` of its own
band, so an unevenly cut band simply costs one program a second step while no
column is ever dropped or computed twice.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


def _pow2_clamp(value: int, low: int, high: int) -> int:
    """Round a Python int up to a power of two inside [low, high]."""
    size = low
    while size < value and size < high:
        size *= 2
    return max(low, min(size, high))


# Tile ceilings.  64 is the widest column tile this kernel has been observed to
# run on the device: settings above it are refused by the runtime audit before a
# single element is written, so a wide band is walked as several 64-wide column
# tiles rather than one fat tile.  With both ceilings at 64 the fp32 accumulator
# tops out at 4096 elements (16 KB, a quarter of the unified-buffer budget), and
# every shape whose mean row count and mean band width already fit 64 keeps
# exactly the geometry that ran clean in earlier rounds.
BLOCK_N_CAP = 64
BLOCK_M_CAP = 64
# Accumulator ceiling in fp32 elements.  A guard, not a binding limit here.
ACC_BUDGET = 4096


@triton.jit(
    do_not_specialize=[
        "num_segs",
        "col_tiles",
        "output_stride_0",
        "output_stride_1",
    ]
)
def _chunked_lora_expand_kernel(
    # Packed rank projections, the LoRA-B slabs, and the result.
    x,
    weights,
    output,
    # The result may be a band written into a wider base projection, so its
    # strides can differ from (OUTPUT_DIM, 1).
    output_stride_0,
    output_stride_1,
    # Segment boundaries, adapter id per segment, rank per adapter.
    seg_indptr,
    weight_indices,
    lora_ranks,
    num_segs,
    # Per-adapter multiplier, folded into the epilogue.
    scalings,
    # Boundaries of every slice band along the output dimension.
    slice_offsets,
    # Row stride of x (NUM_SLICES * MAX_RANK for a packed, contiguous x).
    x_stride_0,
    # How many column tiles were handed out, and which one this program starts
    # at.  Tiles are taken with this stride, so the stride must be at least one.
    col_tiles,
    # Meta parameters.
    NUM_SLICES: tl.constexpr,
    OUTPUT_DIM: tl.constexpr,
    MAX_RANK: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    # Whether the output slot already holds something to accumulate onto.  It
    # is a compile-time switch, so the read of the output tile is gone from the
    # generated program rather than guarded by a branch inside it.
    LOAD_BASE: tl.constexpr,
):
    slice_id = tl.program_id(axis=0)
    pid_s = tl.program_id(axis=1)
    pid_c = tl.program_id(axis=2)

    # All six metadata loads, issued back to back.  Only one of them depends on
    # another -- the rank is read through the adapter id -- so the rest of this
    # program's setup can sit in flight at the same time.  The grid covers
    # exactly num_segs segments and num_slices bands, so every index here is in
    # range and no bound has to be checked before reading.
    w_index = tl.load(weight_indices + pid_s)
    raw_rank = tl.load(lora_ranks + w_index)
    seg_start = tl.load(seg_indptr + pid_s)
    seg_end = tl.load(seg_indptr + pid_s + 1)
    slice_start = tl.load(slice_offsets + slice_id)
    slice_end = tl.load(slice_offsets + slice_id + 1)
    scaling = tl.load(scalings + w_index)

    # The emptiness tests that used to be early returns become trip counts.  A
    # rank-0 adapter reduces the k loop to zero steps, a zero-length segment
    # reduces the row loop to zero tiles and an empty band reduces the column
    # walk to zero tiles, so a program that owns nothing still writes nothing.
    cur_rank = tl.maximum(tl.minimum(MAX_RANK, raw_rank), 0)
    seg_len = tl.maximum(seg_end - seg_start, 0)
    band_len = tl.maximum(slice_end - slice_start, 0)

    k_offset = tl.arange(0, BLOCK_K)
    m_offset = tl.arange(0, BLOCK_M)
    n_local = tl.arange(0, BLOCK_N)

    # weights[ad, n, k] and x[row, slice_id * r + k] both keep k innermost.
    w_slab = weights + w_index * (OUTPUT_DIM * MAX_RANK)
    x_col0 = slice_id * cur_rank

    # A band of band_len columns needs this many BLOCK_N tiles; this program
    # serves tile pid_c, pid_c + col_tiles, ... so the tiles of one band are
    # shared out and no band is ever left uncovered, however it was cut.
    band_tiles = tl.maximum(tl.cdiv(band_len, BLOCK_N) - pid_c, 0)
    my_tiles = tl.cdiv(band_tiles, col_tiles)
    row_tiles = tl.cdiv(seg_len, BLOCK_M)

    for m_blk in range(0, row_tiles):
        rows = seg_start + m_blk * BLOCK_M + m_offset
        row_ok = rows < seg_end
        x_ptrs = x + rows[:, None] * x_stride_0 + x_col0 + k_offset[None, :]

        for step in range(0, my_tiles):
            n_blk = pid_c + step * col_tiles
            cols = slice_start + n_blk * BLOCK_N + n_local
            col_ok = cols < slice_end
            w_ptrs = w_slab + cols[None, :] * MAX_RANK + k_offset[:, None]

            acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
            for k_blk in range(0, tl.cdiv(cur_rank, BLOCK_K)):
                k_left = cur_rank - k_blk * BLOCK_K
                k_ok = k_offset < k_left
                x_tile = tl.load(
                    x_ptrs + k_blk * BLOCK_K,
                    mask=row_ok[:, None] & k_ok[None, :],
                    other=0.0,
                )
                w_tile = tl.load(
                    w_ptrs + k_blk * BLOCK_K,
                    mask=k_ok[:, None] & col_ok[None, :],
                    other=0.0,
                )
                acc += tl.dot(x_tile, w_tile)

            acc *= scaling
            acc = acc.to(x.dtype.element_ty)

            out_ptrs = (
                output
                + rows[:, None] * output_stride_0
                + cols[None, :] * output_stride_1
            )
            out_mask = row_ok[:, None] & col_ok[None, :]
            if LOAD_BASE:
                acc += tl.load(out_ptrs, mask=out_mask, other=0.0)
            tl.store(out_ptrs, acc, mask=out_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"].contiguous()
    weights = inputs["weights"].contiguous()
    seg_indptr = inputs["seg_indptr"].contiguous()
    weight_indices = inputs["weight_indices"].contiguous()
    lora_ranks = inputs["lora_ranks"].contiguous()
    scalings = inputs["scalings"].contiguous()
    slice_offsets = inputs["slice_offsets"].contiguous()

    # Everything the launch needs is a Python integer taken from a shape, so no
    # device value is ever read back on the host.
    num_tokens = x.shape[0]
    output_dim = weights.shape[1]
    max_rank = weights.shape[2]
    num_segs = seg_indptr.shape[0] - 1
    num_slices = slice_offsets.shape[0] - 1

    # The flag is set from which branch of the lookup was taken, never from the
    # tensor itself: no value that could be a tensor is tested or subscripted on
    # the host.
    load_base = False
    try:
        output = inputs["base_output"].to(x.dtype).contiguous().clone()
        load_base = True
    except (KeyError, AttributeError):
        output = torch.zeros(
            (num_tokens, output_dim), device=x.device, dtype=x.dtype
        )

    launch = (
        num_tokens > 0
        and num_segs > 0
        and num_slices > 0
        and max_rank > 0
        and output_dim > 0
    )

    if launch:
        # Segments tile the rows and bands tile the columns, so the mean
        # segment length and mean band width bound the useful tile size without
        # inspecting the offset tensors themselves.
        mean_seg_len = (num_tokens + num_segs - 1) // num_segs
        mean_band_len = (output_dim + num_slices - 1) // num_slices
        block_m = _pow2_clamp(mean_seg_len, 16, BLOCK_M_CAP)
        block_n = _pow2_clamp(mean_band_len, 16, BLOCK_N_CAP)
        # A k tile at least as wide as MAX_RANK collapses the reduction to a
        # single step for every shape whose rank sits within the cap.
        block_k = _pow2_clamp(max_rank, 16, 64)
        # Keep the fp32 accumulator inside the unified-buffer budget in case a
        # future shape widens rows and band at the same time.
        while block_n > 16 and block_m * block_n > ACC_BUDGET:
            block_n //= 2

        # One column tile per program for the tiles a mean-width band needs, so
        # that the whole output width costs ceil(OUTPUT_DIM / BLOCK_N) programs
        # spread over the slice axis.  Clamped to at least one, and a band wider
        # than this share keeps walking tiles inside its own program.
        col_tiles = (
            output_dim + block_n * num_slices - 1
        ) // (block_n * num_slices)
        if col_tiles < 1:
            col_tiles = 1

        _chunked_lora_expand_kernel[(num_slices, num_segs, col_tiles)](
            x=x,
            weights=weights,
            output=output,
            output_stride_0=output.stride(0),
            output_stride_1=output.stride(1),
            seg_indptr=seg_indptr,
            weight_indices=weight_indices,
            lora_ranks=lora_ranks,
            num_segs=num_segs,
            scalings=scalings,
            slice_offsets=slice_offsets,
            x_stride_0=x.stride(0),
            col_tiles=col_tiles,
            NUM_SLICES=num_slices,
            OUTPUT_DIM=output_dim,
            MAX_RANK=max_rank,
            BLOCK_M=block_m,
            BLOCK_N=block_n,
            BLOCK_K=block_k,
            LOAD_BASE=load_base,
        )

    return {"output": output}


run = npu_triton_impl
