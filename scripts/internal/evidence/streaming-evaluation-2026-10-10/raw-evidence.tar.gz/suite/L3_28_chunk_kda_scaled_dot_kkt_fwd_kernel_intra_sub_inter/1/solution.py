"""NPU (Triton-Ascend) implementation of
chunk_kda_scaled_dot_kkt_fwd_kernel_intra_sub_inter.

Dense layout, per-dimension gate consumed as-is (the cumulative transform lives
upstream, so nothing here integrates it):
  q, k, gk : [B, T, H, K]
  beta     : [B, T, H]
  A, Aqk   : [B, T, H, BT] with BT = 64 and the last axis LOCAL to the chunk

Chunk geometry: BT = 64, sub-chunk width BC = 16, NC = BT / BC = 4. Only the
strictly off-diagonal sub-chunk blocks of every time chunk are produced by this
kernel: row sub-chunk i_i against column sub-chunk i_j < i_i. The diagonal
sub-blocks and the sub-blocks above them belong to a separately named kernel,
so for THIS task they must read as zero.

For row r of sub-chunk i_i and in-chunk column c of sub-chunk i_j, with the
anchor gate gn read from the FIRST row of sub-chunk i_i:

  A[r, c]   = beta_r * sum_d (k_rd exp(g_rd - gn_d)) (k_cd exp(gn_d - g_cd))
  Aqk[r, c] =          sum_d (q_rd exp(g_rd - gn_d) scale) (k_cd exp(gn_d - g_cd))

The anchor stays folded into both operands instead of cancelling against
itself: exp(g_r - gn) * exp(gn - g_c) is algebraically exp(g_r - g_c), but the
reference builds the two split operands and reduces those, so anchor placement
decides what each product is rounded through. Likewise beta multiplies the
accumulated result (never an operand) and scale enters the left operand of its
own dot before truncation.

Operand precision: the reference reduction multiplies operands carrying an
11-bit significand and accumulates in fp32. Each fp32 operand here is chopped
to that width in a register, which makes it exactly representable in half
precision, so the half-precision reduction reproduces the reference operands
bit for bit while the accumulator stays fp32. Summation order over the feature
axis is then the only remaining difference, and that is what the tolerance band
covers.

What changed against the round-3 candidate (one thing, and only that)
--------------------------------------------------------------------
The zero fill of the untouched sub-blocks moved INSIDE the kernel, so the two
device-side fill launches that used to precede it are gone and the outputs are
allocated uninitialized.

Why that is the lever. Two hardware receipts bracket the cost of everything
else in this kernel. Round 1 -> round 3 cut loaded tile elements by 30% (30
tile passes per time chunk and feature slice -> 21) at unchanged dot count,
unchanged products and unchanged per-output arithmetic, and bought 3.5% of
device time (geomean 2.153 -> 2.094 ms); the two-point difference is inside the
run-to-run spread on the noisier shapes. So tile traffic is close to free on
this backend. Round 3's own cross-shape fit puts a floor of roughly 0.2-0.45 ms
under every single measurement: the smallest shape in the grid (H2, 4 live
programs, 8 reduction calls, 64 KB of output) still costs 223 us, and P1 (24
live programs, 96 reduction calls, 256 KB of output) costs 481 us. That floor is over half of the measured time on the
~20 shapes where the arithmetic is negligible, which makes it the largest
remaining term in the objective.

The floor cannot be the arithmetic and it cannot be the kernel body either,
because both are tiny on exactly those shapes. What is left is the per-invocation
dispatch of device operations. Every call used to issue three of them: two fp32
memsets (one per output, each covering the WHOLE [B, T, H, BT] tensor) followed
by the kernel. Those memsets are also redundant traffic: they write all 16
sub-blocks of every chunk, after which the kernel writes 6 of them a second
time.

This candidate issues ONE device operation. A program now owns a full row
sub-chunk of the output -- all BT columns -- and writes it completely: the
i_i sub-chunks strictly below the diagonal hold the reduction, and the
NC - i_i sub-chunks from the diagonal up are stored as zero. Row sub-chunk 0
carries no data block at all and becomes a pure fill program, so the grid's
second axis widens from NC - 1 to NC and coverage stays exact. Total bytes
written per chunk drop from 16 blocks of memset + 6 blocks of result to 16
blocks of result, i.e. 44 block-writes -> 32, and two launches disappear.

The arithmetic is untouched by construction. The data path is the round-3
kernel statement for statement -- same three flat row-sub-chunk paths, same
[BC, BK] x [BK, BC] dot shapes, same hoisted row-side preparation, same
anchors, same truncation, same accumulation order -- so every written result
element is bit-identical to the hardware-verified candidate. The zero blocks
were 0.0f before and are 0.0f now. Verified on the CPU interpreter: the output
of this kernel equals round 3's to the last bit on every shape in shapes.yaml
plus off-grid T and K, and a pre-poisoned NaN buffer comes back with no NaN
left anywhere, which is the coverage proof for the uninitialized allocation.

Coverage argument for writing every element exactly once. Fix (i_t, i_i) with
row0 = i_t * BT + i_i * BC < T; the program owns rows [row0, row0 + BC) (clipped
to T) and writes columns [0, i_i * BC) from the reduction and columns
[i_i * BC, BT) as zero, so all BT columns of each owned row are written. Owned
row sub-chunks partition the T rows of the chunk. Column time indices used by
the data path are i_t * BT + i_j * BC + b with i_j < i_i, hence strictly below
row0 < T, so no data element can refer to a column outside the tensor and the
zero region picks up nothing that the data region wanted. Programs whose row0
reaches T own no tensor rows and their absence is harmless.
"""
import torch
import triton
import triton.language as tl

# Frozen chunk geometry, not tuning knobs.
_BT = 64
_BC = 16


@triton.jit
def _chop_significand(x):
    """Chop the low mantissa bits of an fp32 tensor (truncate, not round)."""
    bits = x.to(tl.int32, bitcast=True)
    bits = bits & -8192
    return bits.to(tl.float32, bitcast=True)


@triton.jit
def _kda_intra_sub_inter_npu(
    q_ptr,
    k_ptr,
    g_ptr,
    beta_ptr,
    A_ptr,
    Aqk_ptr,
    scale,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    BC: tl.constexpr,
    BK: tl.constexpr,
    NC: tl.constexpr,
    NK: tl.constexpr,
):
    i_t = tl.program_id(0)
    # Row sub-chunk 0 owns no data block; it exists to fill its rows.
    i_i = tl.program_id(1)
    i_bh = tl.program_id(2)
    i_b = i_bh // H
    i_h = i_bh % H

    chunk0 = i_t * BT
    row0 = chunk0 + i_i * BC
    if row0 >= T:
        return

    o_r = row0 + tl.arange(0, BC)            # global rows owned by this program
    m_r = o_r < T

    beta_base = i_b * T * H + i_h
    src_base = (i_b * T * H + i_h) * K
    out_base = (i_b * T * H + i_h) * BT
    anchor = src_base + row0 * (H * K)       # gate row 0 of sub-chunk i_i

    o_k0 = tl.arange(0, BK)
    o_cl = tl.arange(0, BC)                  # LOCAL in-chunk column of a block
    b_beta = tl.load(beta_ptr + beta_base + o_r * H, mask=m_r, other=0.0)
    p_out = out_base + o_r[:, None] * (H * BT)

    if i_i == 0:
        # ---- no data block here: this program exists to fill its rows ----
        b_zero = tl.zeros([BC, BC], dtype=tl.float32)
        m_fill = m_r[:, None] & (o_cl[None, :] < BT)
        for i_j in range(NC):
            o_cz = i_j * BC + o_cl
            tl.store(A_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)
            tl.store(Aqk_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)
        return

    if i_i == 1:
        # ---- one column sub-chunk: nothing shared beyond the row side ----
        o_c = chunk0 + tl.arange(0, BC)
        m_c = o_c < T
        acc_a = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q = tl.zeros([BC, BC], dtype=tl.float32)
        for i_k in range(NK):
            o_k = i_k * BK + o_k0
            m_k = o_k < K
            m_row = m_r[:, None] & m_k[None, :]
            p_row = o_r[:, None] * (H * K) + o_k[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r).to(tl.float16)
            lhs_q = _chop_significand(b_q * ek_r * scale).to(tl.float16)

            p_col = o_k[:, None] + o_c[None, :] * (H * K)
            m_col = m_k[:, None] & m_c[None, :]
            b_gc = tl.load(g_ptr + src_base + p_col, mask=m_col, other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_col, mask=m_col, other=0.0)
            rhs = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)

            acc_a += tl.dot(lhs_k, rhs)
            acc_q += tl.dot(lhs_q, rhs)

        m_store = m_r[:, None] & m_c[None, :]
        tl.store(A_ptr + p_out + o_cl[None, :], acc_a * b_beta[:, None], mask=m_store)
        tl.store(Aqk_ptr + p_out + o_cl[None, :], acc_q, mask=m_store)

        # Diagonal and upper sub-blocks: written here, not by a fill launch.
        b_zero = tl.zeros([BC, BC], dtype=tl.float32)
        m_fill = m_r[:, None] & (o_cl[None, :] < BT)
        for i_j in range(1, NC):
            o_cz = i_j * BC + o_cl
            tl.store(A_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)
            tl.store(Aqk_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)

    elif i_i == 2:
        # ---- two column sub-chunks sharing one row preparation ----
        o_c1 = chunk0 + tl.arange(0, BC)
        o_c2 = chunk0 + BC + tl.arange(0, BC)
        m_c1 = o_c1 < T
        m_c2 = o_c2 < T
        acc_a1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_a2 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q2 = tl.zeros([BC, BC], dtype=tl.float32)
        for i_k in range(NK):
            o_k = i_k * BK + o_k0
            m_k = o_k < K
            m_row = m_r[:, None] & m_k[None, :]
            p_row = o_r[:, None] * (H * K) + o_k[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r).to(tl.float16)
            lhs_q = _chop_significand(b_q * ek_r * scale).to(tl.float16)

            m_kc = m_k[:, None]
            p_c1 = o_k[:, None] + o_c1[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            rhs1 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a1 += tl.dot(lhs_k, rhs1)
            acc_q1 += tl.dot(lhs_q, rhs1)

            p_c2 = o_k[:, None] + o_c2[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            rhs2 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a2 += tl.dot(lhs_k, rhs2)
            acc_q2 += tl.dot(lhs_q, rhs2)

        m_s1 = m_r[:, None] & m_c1[None, :]
        tl.store(A_ptr + p_out + o_cl[None, :], acc_a1 * b_beta[:, None], mask=m_s1)
        tl.store(Aqk_ptr + p_out + o_cl[None, :], acc_q1, mask=m_s1)
        m_s2 = m_r[:, None] & m_c2[None, :]
        o_cl2 = BC + o_cl
        tl.store(A_ptr + p_out + o_cl2[None, :], acc_a2 * b_beta[:, None], mask=m_s2)
        tl.store(Aqk_ptr + p_out + o_cl2[None, :], acc_q2, mask=m_s2)

        # Diagonal and upper sub-blocks: written here, not by a fill launch.
        b_zero = tl.zeros([BC, BC], dtype=tl.float32)
        m_fill = m_r[:, None] & (o_cl[None, :] < BT)
        for i_j in range(2, NC):
            o_cz = i_j * BC + o_cl
            tl.store(A_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)
            tl.store(Aqk_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)

    elif i_i == 3:
        # ---- three column sub-chunks sharing one row preparation ----
        o_c1 = chunk0 + tl.arange(0, BC)
        o_c2 = chunk0 + BC + tl.arange(0, BC)
        o_c3 = chunk0 + 2 * BC + tl.arange(0, BC)
        m_c1 = o_c1 < T
        m_c2 = o_c2 < T
        m_c3 = o_c3 < T
        acc_a1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_a2 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q2 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_a3 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q3 = tl.zeros([BC, BC], dtype=tl.float32)
        for i_k in range(NK):
            o_k = i_k * BK + o_k0
            m_k = o_k < K
            m_row = m_r[:, None] & m_k[None, :]
            p_row = o_r[:, None] * (H * K) + o_k[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r).to(tl.float16)
            lhs_q = _chop_significand(b_q * ek_r * scale).to(tl.float16)

            m_kc = m_k[:, None]
            p_c1 = o_k[:, None] + o_c1[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            rhs1 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a1 += tl.dot(lhs_k, rhs1)
            acc_q1 += tl.dot(lhs_q, rhs1)

            p_c2 = o_k[:, None] + o_c2[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            rhs2 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a2 += tl.dot(lhs_k, rhs2)
            acc_q2 += tl.dot(lhs_q, rhs2)

            p_c3 = o_k[:, None] + o_c3[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c3, mask=m_kc & m_c3[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c3, mask=m_kc & m_c3[None, :], other=0.0)
            rhs3 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a3 += tl.dot(lhs_k, rhs3)
            acc_q3 += tl.dot(lhs_q, rhs3)

        m_s1 = m_r[:, None] & m_c1[None, :]
        tl.store(A_ptr + p_out + o_cl[None, :], acc_a1 * b_beta[:, None], mask=m_s1)
        tl.store(Aqk_ptr + p_out + o_cl[None, :], acc_q1, mask=m_s1)
        m_s2 = m_r[:, None] & m_c2[None, :]
        o_cl2 = BC + o_cl
        tl.store(A_ptr + p_out + o_cl2[None, :], acc_a2 * b_beta[:, None], mask=m_s2)
        tl.store(Aqk_ptr + p_out + o_cl2[None, :], acc_q2, mask=m_s2)
        m_s3 = m_r[:, None] & m_c3[None, :]
        o_cl3 = 2 * BC + o_cl
        tl.store(A_ptr + p_out + o_cl3[None, :], acc_a3 * b_beta[:, None], mask=m_s3)
        tl.store(Aqk_ptr + p_out + o_cl3[None, :], acc_q3, mask=m_s3)

        # Sub-block above the diagonal: written here, not by a fill launch.
        b_zero = tl.zeros([BC, BC], dtype=tl.float32)
        m_fill = m_r[:, None] & (o_cl[None, :] < BT)
        for i_j in range(3, NC):
            o_cz = i_j * BC + o_cl
            tl.store(A_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)
            tl.store(Aqk_ptr + p_out + o_cz[None, :], b_zero, mask=m_fill)


def _feature_tile(K):
    """Largest power-of-two divisor of K in [16, 64]; defaults to 16."""
    BK = 16
    while BK < 64 and K % (2 * BK) == 0:
        BK = 2 * BK
    return BK


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    gk = inputs["gk"]
    beta = inputs["beta"]
    scale = inputs["scale"]

    B, T, H, K = k.shape
    K = int(K)
    T = int(T)

    BT = _BT
    BC = min(_BC, BT)
    NC = (BT + BC - 1) // BC
    NT = (T + BT - 1) // BT

    # Feature tiling: one pass when the feature axis fits a single tile, else a
    # fp32-accumulated loop over BK-wide slices.
    BK = _feature_tile(K)
    NK = (K + BK - 1) // BK

    # Uninitialized: every element of both outputs is written by the kernel.
    A = torch.empty(B, T, H, BT, device=k.device, dtype=torch.float32)
    Aqk = torch.empty(B, T, H, BT, device=k.device, dtype=torch.float32)

    grid = (NT, NC, B * H)
    _kda_intra_sub_inter_npu[grid](
        q,
        k,
        gk,
        beta,
        A,
        Aqk,
        scale,
        T,
        H=H,
        K=K,
        BT=BT,
        BC=BC,
        BK=BK,
        NC=NC,
        NK=NK,
        num_warps=4,
    )
    return {"A": A, "Aqk": Aqk}
