"""NPU (Triton-Ascend) implementation of
chunk_kda_scaled_dot_kkt_fwd_kernel_intra_sub_inter.

Dense layout, per-dimension gate consumed as-is (the cumulative transform lives
upstream, so nothing here integrates it):
  q, k, gk : [B, T, H, K]
  beta     : [B, T, H]
  A, Aqk   : [B, T, H, BT] with BT = 64 and the last axis LOCAL to the chunk

Chunk geometry: BT = 64, sub-chunk width BC = 16, NC = BT / BC = 4. Only the
strictly off-diagonal sub-chunk blocks of every time chunk are produced here:
row sub-chunk i_i against column sub-chunk i_j < i_i. The diagonal sub-blocks
and the upper triangle belong to a separately named kernel and stay zero, so
the outputs are allocated at zero and left untouched there.

For row r of sub-chunk i_i and in-chunk column c of sub-chunk i_j, with the
anchor gate gn read from the FIRST row of sub-chunk i_i:

  A[r, c]   = beta_r * sum_d (k_rd exp(g_rd - gn_d)) (k_cd exp(gn_d - g_cd))
  Aqk[r, c] =          sum_d (q_rd exp(g_rd - gn_d) scale) (k_cd exp(gn_d - g_cd))

The anchor is kept folded into both operands instead of being cancelled against
itself. exp(g_r - gn) * exp(gn - g_c) is algebraically exp(g_r - g_c), but the
reference builds the two split operands and reduces those, so the anchor
placement is load-bearing: it decides what each product is rounded through.
Likewise beta multiplies the accumulated result (never the operand) and scale
enters the left operand of its own dot.

Program layout: one program owns (time chunk, row sub-chunk, batch-head) and
walks its lower column sub-chunks in an inner loop. That shares the row-side
tile and the anchor across all column sub-chunks of the row sub-chunk, and
covers exactly the blocks that are written -- no empty program is launched and
no wasted block is computed. Column sub-chunk i_j spans in-chunk columns
[i_j * BC, i_j * BC + BC), so the store offset follows directly from it.

Operand precision: the reference reduction multiplies operands carrying an
11-bit significand and accumulates in fp32. Each fp32 operand here is chopped
to that width in a register, which makes it exactly representable in half
precision, so the half-precision dot reproduces the reference operands bit for
bit while the accumulator stays fp32. Summation order over the feature axis is
then the only remaining difference, and the fp32 partials are summed in the
chunked order the reference uses.
"""

import torch
import triton
import triton.language as tl

# Frozen chunk geometry, not tuning knobs.
_BT = 64
_BC = 16


@triton.jit
def _chop_significand(x):
    """Chop the low mantissa bits of an fp32 tensor (truncate, not round)."""
    bits = x.to(tl.int32, bitcast=True)
    bits = bits & -8192
    return bits.to(tl.float32, bitcast=True)


@triton.jit
def _kda_intra_sub_inter_npu(
    q_ptr,
    k_ptr,
    g_ptr,
    beta_ptr,
    A_ptr,
    Aqk_ptr,
    scale,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    BC: tl.constexpr,
    BK: tl.constexpr,
    NK: tl.constexpr,
):
    i_t = tl.program_id(0)
    # Row sub-chunks 1..NC-1 are the only ones with a lower neighbour.
    i_i = tl.program_id(1) + 1
    i_bh = tl.program_id(2)
    i_b = i_bh // H
    i_h = i_bh % H

    row0 = i_t * BT + i_i * BC
    if row0 >= T:
        return

    o_r = row0 + tl.arange(0, BC)            # global rows owned by this program
    m_r = o_r < T

    beta_base = i_b * T * H + i_h
    src_base = (i_b * T * H + i_h) * K
    out_base = (i_b * T * H + i_h) * BT
    anchor = src_base + row0 * (H * K)       # gate row 0 of sub-chunk i_i

    b_beta = tl.load(beta_ptr + beta_base + o_r * H, mask=m_r, other=0.0)

    for i_j in range(i_i):                   # strictly below the diagonal block
        o_c = i_t * BT + i_j * BC + tl.arange(0, BC)
        m_c = o_c < T
        b_A = tl.zeros([BC, BC], dtype=tl.float32)
        b_Aqk = tl.zeros([BC, BC], dtype=tl.float32)

        for i_k in range(NK):
            o_k = i_k * BK + tl.arange(0, BK)
            m_k = o_k < K
            # Row-side tiles [BC, BK]: feature axis contiguous.
            p_row = o_r[:, None] * (H * K) + o_k[None, :]
            m_row = m_r[:, None] & m_k[None, :]
            # Column-side tiles [BK, BC]: reduction axis contiguous, so the
            # cube unit sees the transposed operand without a shuffle.
            p_col = o_k[:, None] + o_c[None, :] * (H * K)
            m_col = m_k[:, None] & m_c[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_gc = tl.load(g_ptr + src_base + p_col, mask=m_col, other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_col, mask=m_col, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r)
            lhs_q = _chop_significand(b_q * ek_r * scale)
            rhs = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc))

            b_A += tl.dot(lhs_k.to(tl.float16), rhs.to(tl.float16))
            b_Aqk += tl.dot(lhs_q.to(tl.float16), rhs.to(tl.float16))

        b_A = b_A * b_beta[:, None]          # beta applied after the reduction
        o_c_local = i_j * BC + tl.arange(0, BC)
        p_out = o_r[:, None] * (H * BT) + o_c_local[None, :]
        tl.store(A_ptr + out_base + p_out, b_A, mask=m_r[:, None] & m_c[None, :])
        tl.store(Aqk_ptr + out_base + p_out, b_Aqk, mask=m_r[:, None] & m_c[None, :])


def _feature_tile(K):
    """Largest power-of-two divisor of K in [16, 64]; defaults to 16."""
    BK = 16
    while BK < 64 and K % (2 * BK) == 0:
        BK = 2 * BK
    return BK


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    gk = inputs["gk"]
    beta = inputs["beta"]
    scale = inputs["scale"]

    B, T, H, K = k.shape
    K = int(K)

    BT = _BT
    BC = min(_BC, BT)
    NC = (BT + BC - 1) // BC
    NT = (T + BT - 1) // BT

    # Feature tiling: one pass when the feature axis fits a single tile, else a
    # fp32-accumulated loop over BK-wide slices.
    BK = _feature_tile(K)
    NK = (K + BK - 1) // BK

    A = torch.zeros(B, T, H, BT, device=k.device, dtype=torch.float32)
    Aqk = torch.zeros(B, T, H, BT, device=k.device, dtype=torch.float32)

    grid = (NT, NC - 1, B * H)
    _kda_intra_sub_inter_npu[grid](
        q,
        k,
        gk,
        beta,
        A,
        Aqk,
        scale,
        T,
        H=H,
        K=K,
        BT=BT,
        BC=BC,
        BK=BK,
        NK=NK,
        num_warps=4,
    )
    return {"A": A, "Aqk": Aqk}
