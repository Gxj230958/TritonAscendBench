"""NPU (Triton-Ascend) implementation of
chunk_kda_scaled_dot_kkt_fwd_kernel_intra_sub_inter.

Dense layout, per-dimension gate consumed as-is (the cumulative transform lives
upstream, so nothing here integrates it):
  q, k, gk : [B, T, H, K]
  beta     : [B, T, H]
  A, Aqk   : [B, T, H, BT] with BT = 64 and the last axis LOCAL to the chunk

Chunk geometry: BT = 64, sub-chunk width BC = 16, NC = BT / BC = 4. Only the
strictly off-diagonal sub-chunk blocks of every time chunk are produced here:
row sub-chunk i_i against column sub-chunk i_j < i_i. The diagonal sub-blocks
and the upper triangle belong to a separately named kernel and stay zero, so
the outputs are allocated at zero and left untouched there.

For row r of sub-chunk i_i and in-chunk column c of sub-chunk i_j, with the
anchor gate gn read from the FIRST row of sub-chunk i_i:

  A[r, c]   = beta_r * sum_d (k_rd exp(g_rd - gn_d)) (k_cd exp(gn_d - g_cd))
  Aqk[r, c] =          sum_d (q_rd exp(g_rd - gn_d) scale) (k_cd exp(gn_d - g_cd))

The anchor is kept folded into both operands instead of being cancelled against
itself: exp(g_r - gn) * exp(gn - g_c) is algebraically exp(g_r - g_c), but the
reference builds those two split operands and reduces them, so anchor placement
decides what each product is rounded through. Likewise beta multiplies the
accumulated result (never an operand) and scale enters the left operand of its
own dot before truncation.

Operand precision: the reference reduction multiplies operands carrying an
11-bit significand and accumulates in fp32. Each fp32 operand here is chopped
to that width in a register, which makes it exactly representable in half
precision, so the half-precision dot reproduces the reference operands bit for
bit while the accumulator stays fp32. Summation order over the feature axis is
then the only remaining difference, and that is what the tolerance band covers.

What changed against the round-1 candidate (one thing, and only that)
--------------------------------------------------------------------
The feature loop moved OUTSIDE the column walk, so the row-side operands of a
sub-chunk are prepared once per program instead of once per (row, column) pair.

A row belongs to exactly one row sub-chunk, so for a fixed feature slice the
three row tiles (g, k, q), their gate exponential and their two truncations are
IDENTICAL for every column sub-chunk below the diagonal. Round 1 rebuilt them
i_i times: walking i_j in the outer loop forced the k-reduction of each pair to
finish before the next pair started, which pinned the whole row-side
preparation inside the pair loop. Round 1 therefore paid, per time chunk and
batch-head and feature slice:

    6 pairs x (3 row tiles + 2 column tiles) = 30 tile passes

This version hoists the row side above the column walk and keeps one fp32
accumulator per owned column sub-chunk, so the same work becomes

    3 row tiles + (1 + 2 + 3) pairs x 2 column tiles = 21 tile passes

That is 70% of the element traffic, and element traffic is what this kernel is
made of: on the round-1 receipt, measured device time across all 47 shapes is a
single straight line in loaded tile elements (R^2 = 0.995, max residual 4.8%,
~0.76 ns per element plus a fixed floor), i.e. the reduction and the stores are
not what costs anything here.

Nothing else moves. Same grid (NT, NC-1, B*H) so no empty program is launched
and no wasted block is computed; same [BC, BK] x [BK, BC] dot shapes, which are
the shapes the round-1 candidate ran successfully on this backend; same
masked loads, same masked stores, same torch.zeros allocation for the untouched
diagonal and upper sub-blocks, same num_warps. The round-2 candidate attacked
the same duplication with wide [BC, 32] / [BC, 48] slab dots, a jit helper
called with runtime tensor arguments, compile-time dispatch of differently
shaped tiles, and a fused masked zero store replacing the output fill; it
faulted on the device on all 47 shapes (ACL stream synchronize failed, 507015),
so none of those four constructs is repeated here. The only new structure is
the row-sub-chunk specialization needed to hold 1, 2 and 3 accumulators, and
each of its three paths is a straight copy of the round-1 inner nest.

The three paths are written out flat rather than expressed as an array of
accumulators because Triton tensors cannot be indexed by a loop variable; the
branches are scalar and uniform per program, so a program executes exactly one
of them and the shared row preparation is paid exactly once per program.
"""

import torch
import triton
import triton.language as tl

# Frozen chunk geometry, not tuning knobs.
_BT = 64
_BC = 16


@triton.jit
def _chop_significand(x):
    """Chop the low mantissa bits of an fp32 tensor (truncate, not round)."""
    bits = x.to(tl.int32, bitcast=True)
    bits = bits & -8192
    return bits.to(tl.float32, bitcast=True)


@triton.jit
def _kda_intra_sub_inter_npu(
    q_ptr,
    k_ptr,
    g_ptr,
    beta_ptr,
    A_ptr,
    Aqk_ptr,
    scale,
    T,
    H: tl.constexpr,
    K: tl.constexpr,
    BT: tl.constexpr,
    BC: tl.constexpr,
    BK: tl.constexpr,
    NK: tl.constexpr,
):
    i_t = tl.program_id(0)
    # Row sub-chunks 1..NC-1 are the only ones with a lower neighbour.
    i_i = tl.program_id(1) + 1
    i_bh = tl.program_id(2)
    i_b = i_bh // H
    i_h = i_bh % H

    chunk0 = i_t * BT
    row0 = chunk0 + i_i * BC
    if row0 >= T:
        return

    o_r = row0 + tl.arange(0, BC)            # global rows owned by this program
    m_r = o_r < T

    beta_base = i_b * T * H + i_h
    src_base = (i_b * T * H + i_h) * K
    out_base = (i_b * T * H + i_h) * BT
    anchor = src_base + row0 * (H * K)       # gate row 0 of sub-chunk i_i

    # Row tile addresses are the same for every path and every column
    # sub-chunk: one row sub-chunk per program.
    o_k0 = tl.arange(0, BK)
    o_cl = tl.arange(0, BC)                  # LOCAL in-chunk column of a block
    p_out = out_base + o_r[:, None] * (H * BT)

    b_beta = tl.load(beta_ptr + beta_base + o_r * H, mask=m_r, other=0.0)

    if i_i == 1:
        # ---- one column sub-chunk, nothing shared beyond the row side ----
        o_c = chunk0 + tl.arange(0, BC)
        m_c = o_c < T
        acc_a = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q = tl.zeros([BC, BC], dtype=tl.float32)
        for i_k in range(NK):
            o_k = i_k * BK + o_k0
            m_k = o_k < K
            m_row = m_r[:, None] & m_k[None, :]
            p_row = o_r[:, None] * (H * K) + o_k[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r).to(tl.float16)
            lhs_q = _chop_significand(b_q * ek_r * scale).to(tl.float16)

            p_col = o_k[:, None] + o_c[None, :] * (H * K)
            m_col = m_k[:, None] & m_c[None, :]
            b_gc = tl.load(g_ptr + src_base + p_col, mask=m_col, other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_col, mask=m_col, other=0.0)
            rhs = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)

            acc_a += tl.dot(lhs_k, rhs)
            acc_q += tl.dot(lhs_q, rhs)

        m_store = m_r[:, None] & m_c[None, :]
        tl.store(A_ptr + p_out + o_cl[None, :], acc_a * b_beta[:, None], mask=m_store)
        tl.store(Aqk_ptr + p_out + o_cl[None, :], acc_q, mask=m_store)

    elif i_i == 2:
        # ---- two column sub-chunks sharing one row preparation ----
        o_c1 = chunk0 + tl.arange(0, BC)
        o_c2 = chunk0 + BC + tl.arange(0, BC)
        m_c1 = o_c1 < T
        m_c2 = o_c2 < T
        acc_a1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_a2 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q2 = tl.zeros([BC, BC], dtype=tl.float32)
        for i_k in range(NK):
            o_k = i_k * BK + o_k0
            m_k = o_k < K
            m_row = m_r[:, None] & m_k[None, :]
            p_row = o_r[:, None] * (H * K) + o_k[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r).to(tl.float16)
            lhs_q = _chop_significand(b_q * ek_r * scale).to(tl.float16)

            m_kc = m_k[:, None]
            p_c1 = o_k[:, None] + o_c1[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            rhs1 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a1 += tl.dot(lhs_k, rhs1)
            acc_q1 += tl.dot(lhs_q, rhs1)

            p_c2 = o_k[:, None] + o_c2[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            rhs2 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a2 += tl.dot(lhs_k, rhs2)
            acc_q2 += tl.dot(lhs_q, rhs2)

        m_s1 = m_r[:, None] & m_c1[None, :]
        tl.store(A_ptr + p_out + o_cl[None, :], acc_a1 * b_beta[:, None], mask=m_s1)
        tl.store(Aqk_ptr + p_out + o_cl[None, :], acc_q1, mask=m_s1)
        m_s2 = m_r[:, None] & m_c2[None, :]
        o_cl2 = BC + o_cl
        tl.store(A_ptr + p_out + o_cl2[None, :], acc_a2 * b_beta[:, None], mask=m_s2)
        tl.store(Aqk_ptr + p_out + o_cl2[None, :], acc_q2, mask=m_s2)

    else:
        # ---- three column sub-chunks sharing one row preparation ----
        o_c1 = chunk0 + tl.arange(0, BC)
        o_c2 = chunk0 + BC + tl.arange(0, BC)
        o_c3 = chunk0 + 2 * BC + tl.arange(0, BC)
        m_c1 = o_c1 < T
        m_c2 = o_c2 < T
        m_c3 = o_c3 < T
        acc_a1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q1 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_a2 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q2 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_a3 = tl.zeros([BC, BC], dtype=tl.float32)
        acc_q3 = tl.zeros([BC, BC], dtype=tl.float32)
        for i_k in range(NK):
            o_k = i_k * BK + o_k0
            m_k = o_k < K
            m_row = m_r[:, None] & m_k[None, :]
            p_row = o_r[:, None] * (H * K) + o_k[None, :]

            b_gn = tl.load(g_ptr + anchor + o_k, mask=m_k, other=0.0)
            b_g = tl.load(g_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_k = tl.load(k_ptr + src_base + p_row, mask=m_row, other=0.0)
            b_q = tl.load(q_ptr + src_base + p_row, mask=m_row, other=0.0)

            ek_r = tl.exp(b_g - b_gn[None, :])
            lhs_k = _chop_significand(b_k * ek_r).to(tl.float16)
            lhs_q = _chop_significand(b_q * ek_r * scale).to(tl.float16)

            m_kc = m_k[:, None]
            p_c1 = o_k[:, None] + o_c1[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c1, mask=m_kc & m_c1[None, :], other=0.0)
            rhs1 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a1 += tl.dot(lhs_k, rhs1)
            acc_q1 += tl.dot(lhs_q, rhs1)

            p_c2 = o_k[:, None] + o_c2[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c2, mask=m_kc & m_c2[None, :], other=0.0)
            rhs2 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a2 += tl.dot(lhs_k, rhs2)
            acc_q2 += tl.dot(lhs_q, rhs2)

            p_c3 = o_k[:, None] + o_c3[None, :] * (H * K)
            b_gc = tl.load(g_ptr + src_base + p_c3, mask=m_kc & m_c3[None, :], other=0.0)
            b_kc = tl.load(k_ptr + src_base + p_c3, mask=m_kc & m_c3[None, :], other=0.0)
            rhs3 = _chop_significand(b_kc * tl.exp(b_gn[:, None] - b_gc)).to(tl.float16)
            acc_a3 += tl.dot(lhs_k, rhs3)
            acc_q3 += tl.dot(lhs_q, rhs3)

        m_s1 = m_r[:, None] & m_c1[None, :]
        tl.store(A_ptr + p_out + o_cl[None, :], acc_a1 * b_beta[:, None], mask=m_s1)
        tl.store(Aqk_ptr + p_out + o_cl[None, :], acc_q1, mask=m_s1)
        m_s2 = m_r[:, None] & m_c2[None, :]
        o_cl2 = BC + o_cl
        tl.store(A_ptr + p_out + o_cl2[None, :], acc_a2 * b_beta[:, None], mask=m_s2)
        tl.store(Aqk_ptr + p_out + o_cl2[None, :], acc_q2, mask=m_s2)
        m_s3 = m_r[:, None] & m_c3[None, :]
        o_cl3 = 2 * BC + o_cl
        tl.store(A_ptr + p_out + o_cl3[None, :], acc_a3 * b_beta[:, None], mask=m_s3)
        tl.store(Aqk_ptr + p_out + o_cl3[None, :], acc_q3, mask=m_s3)


def _feature_tile(K):
    """Largest power-of-two divisor of K in [16, 64]; defaults to 16."""
    BK = 16
    while BK < 64 and K % (2 * BK) == 0:
        BK = 2 * BK
    return BK


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    gk = inputs["gk"]
    beta = inputs["beta"]
    scale = inputs["scale"]

    B, T, H, K = k.shape
    K = int(K)
    T = int(T)

    BT = _BT
    BC = min(_BC, BT)
    NC = (BT + BC - 1) // BC
    NT = (T + BT - 1) // BT

    # Feature tiling: one pass when the feature axis fits a single tile, else a
    # fp32-accumulated loop over BK-wide slices.
    BK = _feature_tile(K)
    NK = (K + BK - 1) // BK

    A = torch.zeros(B, T, H, BT, device=k.device, dtype=torch.float32)
    Aqk = torch.zeros(B, T, H, BT, device=k.device, dtype=torch.float32)

    grid = (NT, NC - 1, B * H)
    _kda_intra_sub_inter_npu[grid](
        q,
        k,
        gk,
        beta,
        A,
        Aqk,
        scale,
        T,
        H=H,
        K=K,
        BT=BT,
        BC=BC,
        BK=BK,
        NK=NK,
        num_warps=4,
    )
    return {"A": A, "Aqk": Aqk}
