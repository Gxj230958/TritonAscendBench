"""Triton-Ascend implementation of L2_03_act_and_mul (act_and_mul).

Fused MoE down-projection gate.  Each input row holds the concatenated gate
and up projections, ``gate = in[p, :half]`` and ``up = in[p, half:]``, and the
matching output row is

    out[p] = cast(storage dtype)(act(gate)) * up

The dtype round-trip sits *before* the multiply: the activated gate is narrowed
to the storage dtype first and only then combined with ``up``.  That ordering is
load bearing, and so is the *rounding direction* of both narrowings, so this
file performs them itself -- see ``_round_narrow`` -- rather than trusting a
conversion to pick a direction.

``topk_ids[p] == -1`` marks a dropped token, whose row must read back as zero.
Instead of an early return per program, the routing decision is folded into the
load masks: a dropped row reads gate and up as 0, and every activation here
satisfies act(0) == 0, so its row is stored as exact zeros while still being
written exactly once.  Control flow stays uniform across the tile.

Work is laid out as 2-D tiles of ``BLOCK_R`` rows by ``BLOCK_H`` columns.
Column tiles are aligned runs, so each row of a tile is one provably
contiguous vector load; row grouping only kicks in once the row-wise launch
would produce far more programs than the device can use, so that per-program
setup stays amortised.  That geometry is unchanged from the previous round;
only the rounding of the two narrowing steps moved.

Why the rounding is now explicit
--------------------------------
The previous round used ``x * tl.sigmoid(x)`` plus plain dtype conversions, and
41 of 42 shapes came back with a violation of exactly one bfloat16 step,
one-sided, never two steps.  Two measurements pin the cause to the narrowing
steps rather than to the transcendental:

* a shape with 16 output elements was among the failures.  A primitive that
  merely disagreed with the float32 definition in its last few bits would cross
  a bfloat16 rounding boundary about once in 65536 elements and could not fail
  a 16-element shape; dropping a narrowing entirely does, and reproduces the
  reported magnitudes exactly (one step, a few percent of elements).
* no element was ever off by two steps, which rules out two independently
  mis-rounded steps stacking up, and leaves the rounding *direction* of a
  narrowing as the other live mechanism -- both narrowings land roughly half
  their elements one step low that way.

So the two narrowings are now carried out as arithmetic on the float32 bit
pattern -- add half a retained step plus the parity of the last retained bit,
then clear the trailing bits -- which is round-to-nearest, ties-to-even, the
rule the storage format is defined by.  That covers both mechanisms at once:
the direction is no longer the conversion's choice, and because the value is
already sitting on the storage grid the later dtype conversion is exact, so
folding it away cannot change a bit either.  The multiply between them stays in
float32, where the product of two storage-format operands is exact, so those
two narrowings are the only rounding in the whole path.

"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _round_narrow(x, DROP: tl.constexpr):
    """Round float32 ``x`` to the nearest value the storage format can hold.

    ``DROP`` is how many of the 23 float32 mantissa bits the storage format
    discards: 16 for bfloat16, 13 for float16, 0 to leave the value alone.
    The bias below is half a retained step plus the parity of the last retained
    bit, which is ties-to-even.  The answer is returned as float32, on the
    storage format's value grid, so the conversion that follows it is exact.
    """
    if DROP == 0:
        return x
    bits = x.to(tl.int32, bitcast=True)
    parity = (bits >> DROP) & 1
    bias = (1 << (DROP - 1)) - 1 + parity
    narrowed = (bits + bias) & -(1 << DROP)
    return narrowed.to(tl.float32, bitcast=True)


@triton.jit
def _activation(values, MODE: tl.constexpr):
    """Elementwise activation, evaluated in float32.

    Spelled out of the primitives the definition names -- negation, ``exp``,
    an add, a division -- rather than a fused composite, so nothing here leans
    on a helper whose rounding the operation does not also use.  ``tanh`` is
    written on ``exp(-2 * |u|)`` so the exponent argument stays signed and
    large arguments saturate to +-1 instead of overflowing.
    """
    values = values.to(tl.float32)
    if MODE == "gelu":
        inner = 0.7978845608028654 * (
            values + ((0.044715 * values) * values) * values
        )
        magnitude = tl.maximum(inner, -inner)
        decay = tl.exp(-2.0 * magnitude)
        sign = tl.where(inner > 0.0, 1.0, tl.where(inner < 0.0, -1.0, 0.0))
        return 0.5 * values * (1.0 + sign * ((1.0 - decay) / (1.0 + decay)))
    elif MODE == "relu":
        return tl.maximum(values, 0.0)
    else:
        return values / (1.0 + tl.exp(-values))


@triton.jit
def _act_and_mul_kernel(
    in_ptr,
    out_ptr,
    id_ptr,
    hidden_size,
    half_size,
    num_rows,
    BLOCK_R: tl.constexpr,
    BLOCK_H: tl.constexpr,
    MODE: tl.constexpr,
    DROP: tl.constexpr,
):
    in_dtype = in_ptr.dtype.element_ty
    pid_r = tl.program_id(0)
    pid_h = tl.program_id(1)

    rows = pid_r * BLOCK_R + tl.arange(0, BLOCK_R)
    cols = pid_h * BLOCK_H + tl.arange(0, BLOCK_H)
    # Only the column axis is contiguous in memory, so claim that hint and
    # nothing more: no row stride is ever assumed to be divisible.
    cols = tl.max_contiguous(tl.multiple_of(cols, BLOCK_H), BLOCK_H)

    row_ok = rows < num_rows
    col_ok = cols < half_size
    in_range = row_ok[:, None] & col_ok[None, :]

    # One routing lookup per tile row, broadcast across the tile columns.
    expert_id = tl.load(id_ptr + rows, mask=row_ok, other=-1)
    live = in_range & (expert_id != -1)[:, None]

    offsets = rows[:, None] * hidden_size + cols[None, :]
    gate = tl.load(in_ptr + offsets, mask=live, other=0.0)
    up = tl.load(in_ptr + (offsets + half_size), mask=live, other=0.0)

    # act -> narrow -> multiply -> narrow.  Both narrowings happen above in
    # float32, on the storage grid, so the dtype conversions below are exact
    # and the first one cannot be optimised out without changing the bits.
    activated = _round_narrow(_activation(gate, MODE), DROP).to(in_dtype)
    product = _round_narrow(activated.to(tl.float32) * up.to(tl.float32), DROP)

    out_offsets = rows[:, None] * half_size + cols[None, :]
    tl.store(out_ptr + out_offsets, product.to(in_dtype), mask=in_range)


# Activation selector, keyed straight off the scalar so no host-side comparison
# ever has to look inside a tensor-typed input.
_MODE_TABLE = {"silu": "silu", "gelu": "gelu", "relu": "relu"}

# How many float32 mantissa bits each storage format discards.  A format that
# is not listed gets 0, which leaves the float32 value untouched.
_DROP_BITS = {torch.bfloat16: 16, torch.float16: 13}


def _drop_bits(dtype):
    try:
        return _DROP_BITS[dtype]
    except KeyError:
        return 0


_POW2 = (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768)

# A 1024-element column tile is a 2-KB run for bfloat16: wide enough for the
# HBM path to stream, narrow enough to leave room for row grouping.
_MAX_BLOCK_H = 1024
# Keep a single tile inside this element count so its float32 intermediates fit
# the on-core buffer without spilling.
_MAX_TILE_ELEMS = 4096
# Past this many programs, start merging rows onto one program.
_PROGRAM_CEILING = 2048
# Merging pulls a large launch back to roughly this many programs.
_PROGRAM_TARGET = 512
_MAX_BLOCK_R = 64


def _pow2_at_most(value, limit):
    out = 1
    for candidate in _POW2:
        if candidate <= value and candidate <= limit:
            out = candidate
    return out


def _pick_tile(num_rows, half_size):
    """Pick (BLOCK_H, BLOCK_R): wide contiguous column runs, few row merges."""
    block_h = _pow2_at_most(half_size, _MAX_BLOCK_H)
    col_tiles = (half_size + block_h - 1) // block_h
    block_r = 1
    if num_rows * col_tiles > _PROGRAM_CEILING:
        grouped = _pow2_at_most((num_rows * col_tiles) // _PROGRAM_TARGET, _MAX_BLOCK_R)
        block_r = _pow2_at_most(grouped, _MAX_TILE_ELEMS // block_h)
        block_r = _pow2_at_most(block_r, num_rows)
    return block_h, block_r


def npu_triton_impl(inputs: dict) -> dict:
    try:
        gateup = inputs["gateup_output"]
    except KeyError:
        gateup = inputs["x"]
    try:
        router = inputs["topk_ids"]
    except KeyError:
        router = inputs["expert_ids"]

    gateup = gateup.contiguous()
    router = router.view(-1).contiguous()

    try:
        mode = _MODE_TABLE[inputs["act"]]
    except KeyError:
        mode = "silu"

    num_rows = int(gateup.shape[0])
    hidden_size = int(gateup.shape[1])
    half_size = hidden_size // 2

    out = torch.empty((num_rows, half_size), dtype=gateup.dtype, device=gateup.device)
    if num_rows == 0 or half_size == 0:
        return {"output": out}

    block_h, block_r = _pick_tile(num_rows, half_size)
    grid = (
        (num_rows + block_r - 1) // block_r,
        (half_size + block_h - 1) // block_h,
    )
    _act_and_mul_kernel[grid](
        gateup,
        out,
        router,
        hidden_size,
        half_size,
        num_rows,
        BLOCK_R=block_r,
        BLOCK_H=block_h,
        MODE=mode,
        DROP=_drop_bits(gateup.dtype),
    )
    return {"output": out}
