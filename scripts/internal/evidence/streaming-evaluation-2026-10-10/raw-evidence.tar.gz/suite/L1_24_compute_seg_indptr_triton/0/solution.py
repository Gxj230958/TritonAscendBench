"""Triton-Ascend implementation of `compute_seg_indptr_triton_kernel`.

Contract semantics: with `E = num_local_experts`, the ids flattened into one
1-D stream of length `n`, and `k = E + 1` thresholds,

    seg_indptr[e] = #{ i : topk_ids_flat[i] < e }    for e in [0, E]

The result holds `k` int64 entries. Both ends of the range follow from the same
formula: no id is below 0 and every id is below `E`, so column 0 is 0 and
column `E` is `n`, and neither needs a special case in any kernel here.

Shape of the work
----------------
`k` threshold counts taken over one id stream. The formula needs no scan, no
atomic and no lock-step, so every device construct in this file is load /
compare / `tl.where` / `tl.sum` / store, and the only open question is how to
lay the sweep out over the program grid. Three layouts, all built out of those
same constructs:

* `_seg_bound_kernel` -- one program, and the id stream is never read. When
  `E == 1` the ids can only be 0, so both columns of the answer are the
  definition itself: `seg_indptr = [0, n]`.
* `_seg_sweep_kernel` -- one launch. One program per threshold chunk walks the
  whole stream and writes its chunk of the answer straight out as int64.
  Parallelism comes from the threshold axis alone.
* `_seg_count_kernel` + `_seg_sum_kernel` -- two launches. The stream is
  striped over programs, each program sweeps every threshold chunk for its own
  stripe into a `[rows, k]` int32 stage tile, and a second launch folds that
  tile column by column. Two launches, but the ids are only touched once.

Why this round changes the choice between them
---------------------------------------------
Round 4 gated layouts 2 and 3 on device work alone, on the reasoning that
nothing it measured could separate "one launch costs 96.5 us" from "193 us
however many launches you pay for". Round 4 then measured that floor directly,
and it does separate them:

    H5  round 3, two launches, no device work   198.9 us
    H5  round 4, one  launch, no device work    132.6 us
    P33 round 3, two launches, ~14 us of work   211.8 us
    P33 round 4, one  launch, ~0 us of work     137.2 us
    H8  round 3, two launches, 1.06 ms of work  1255.1 us
    H8  round 4, one  launch, ~0 us of work      161.1 us

Two shapes moved to a single launch with no device work left in them and lost
66 us and 75 us; the third lost the 1.06 ms it was spending on rows of
duplicated analytic columns. So a launch is worth about 65 us, round 4's floor
for one launch is about 133 us, and its floor for two is about 195 us -- and
comparing two layouts while leaving a 65 us term out of the comparison was
comparing them with the wrong sign on every shape whose device work is under
about 130 us. This round's gate is

    one launch wins when   133 + sweep_work  <  195 + striped_work - margin

which is round 4's rule with the missing launch term put back, plus two things
the receipts ask for. First, the sweep estimate is scaled by 1.4: read against
these floors, round 4's own sweep numbers price that layout's device work at
1.24x (P12, H7), 1.37x (P5) and 1.9x (P6) its model, so the model is trusted
for the *ranking* but not for the size of the gap, and a term that is only ever
measured to be too small gets padded before it is allowed to win a shape.
Second, the winner has to lead by 15 us, which is a fifth of the launch credit
and comfortably above the 9-27 us coefficient of variation these floor shapes
carry; a shape only moves when the model says the move is worth more than the
instrument.

Six shapes move, and every one of them is a shape whose device work the other
layout already does in under 60 us, i.e. a shape that is paying two launch
floors to do almost nothing:

    to one launch   P1  (n=512,  E=4)  198.7 -> ~148 us   (gate lead 51 us)
                    P13 (n=1024)       194.8 -> ~157 us   (gate lead 38 us)
                    P14 (n=1536)       193.2 -> ~174 us   (gate lead 19 us)
                    P24 (n=768)        196.5 -> ~149 us   (gate lead 48 us)
                    P25 (n=1536)       197.6 -> ~178 us   (gate lead 19 us)
    to two launches P5  (n=4096,E=128) 493.5 -> ~454 us   (gate lead 39 us), and
                    round 3's striped run of the same shape measured 439.3 us

The column on the right anchors the prediction on the shape's own round 4
measurement and applies the modelled difference between the two layouts to it,
because the model's absolute level is off by 10-15% on this end (it puts P14's
striped total at 210 us against 193.2 measured). P14 and P25 are the two
marginal cases: 19 us of predicted lead against a shape measured twice at
193.2/197.6 us with a 10-12% coefficient of variation, so they can land on
either side of where they are now and that is not evidence about the rule.

Of the shapes round 4 already handed to the sweep
only P5 moves, and it is the one place where the launch term and the padding
together flip the ranking: the two layouts price its device work within 5 us of
each other, so charging the striped layout a launch it does not have to pay is
the whole difference, and round 3's striped run of P5 (439.3 us against round
4's sweep 493.5 us) says the gate is right to move it back. P6, P12, P20-P23,
H2, H6 and H7 all still lead striped by 19 us or more and stay put, which is
what the receipts show for that group: H7 1601.9 -> 619.2, P6 537.5 -> 273.8,
P12 198.0 -> 153.4, H2 193.7 -> 153.1. Every shape with real device work --
P7, P8, P11, P4, P41 and the rest -- keeps round 4's striped geometry launch
for launch and tile for tile. The `_SWEEP_N_MAX` cap goes away
because the padded gate now rejects the sweep at large `n` on its own (P8
prices 2.26 ms against 1.64 ms, P7 1.1 ms against 0.79 ms), and a cap that the
gate makes redundant is one more number that can be wrong.

Numerics
--------
Tallies are literal `1`s reduced with `tl.sum`, so every intermediate is an
exact integer count bounded by `n` (the largest stream in the shape set is
8388608, comfortably inside int32). Only the stored result is widened, so no
int64 lane arithmetic happens inside any loop. The output is deterministic and
bit-exact regardless of how programs are scheduled. Id lanes past the end of
the stream load as 0, which every threshold above 0 would count, so the live
lanes are ANDed into the match tile instead of relying on the load default.
Lanes that fall outside the threshold range are clamped to a legal column and
suppressed by the store mask, so no program can write outside the result.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

# Comparison lanes one program holds for one threshold chunk. The band is set
# by what this task has measured building: 512 lanes at the narrow end, 4096 at
# the wide end.
_TILE_LANES = 4096
_TILE_LANES_MIN = 512
_BLOCK_N_MAX = 256
_BLOCK_N_MIN = 32
_BLOCK_E_MAX = 16
_BLOCK_E_MIN = 2

# Programs needed to keep the grid busy on a short id stream (striped layout).
_MIN_PROGRAMS = 32

# Fold geometry, as measured in the first round.
_FOLD_BLOCK_K = 8
_FOLD_BLOCK_R = 128

# Each threshold chunk ends in a cross-lane reduction and a masked store, so a
# narrow chunk that splits the sweep into many chunks is not free even when it
# pads no more. Price of one extra chunk, in units of one padded comparison
# lane per element.
_CHUNK_PRICE = 0.05

# ---------------------------------------------------------------------------
# Cost model, in integer nanoseconds, fitted against round 3's 49 timings (it
# reproduces them to about 1.4% in geomean) and re-anchored on the launch
# floors round 4 measured. Unlike round 4 this file keeps the floors, because
# the gate below compares two candidates whose launch counts differ.
# ---------------------------------------------------------------------------
_AGG_NUM = 327            # per-lane ns at a saturated grid, times 1000
_AGG_DEN = 1000
_SER = 16                 # per-lane ns for a program that runs alone
_CORES = 48               # resident programs per core, in tile lanes
_PROG_NS = 130            # per program, from the first round's timing fit
_BYTES_NUM = 1            # ns for a byte count at 1500 bytes per ns
_BYTES_DEN = 1500

# Measured cost of getting to the device at all. One launch: H5 132.6 us and
# P33 137.2 us, both with the id stream untouched. Two launches: the round 4
# floor group (P13, P14, P24, P25, P34, P35 at 193-207 us with at most 30 us of
# modelled device work between them).
_FLOOR_ONE = 133_000
_FLOOR_TWO = 195_000

# The sweep layout has only ever been measured 3 to 129 programs deep, and
# against these floors its device work reads 1.24x-1.9x under its model
# (P12 1.24, H7 1.24, P5 1.37, P6 1.90). Pad the estimate by the middle of
# that range so it has to clear the launch credit rather than just match it.
_SWEEP_PAD_NUM = 14
_SWEEP_PAD_DEN = 10

# The winner has to lead by this much. The instrument carries a 9-27%
# coefficient of variation on the floor shapes and the receipts repeat them to
# plus or minus 10 us, so a predicted lead smaller than this is not a lead.
_MIN_GAIN = 15_000


@triton.jit
def _seg_bound_kernel(
    out_ptr,   # int64 [k]
    n,
    k,
):
    # `E == 1`: every id is 0, so the definition fixes both columns and the id
    # stream does not have to be read at all. Column 0 counts ids below 0,
    # column 1 counts ids below 1, which is the entire stream.
    cols = tl.arange(0, 2)
    vals = tl.where(cols == 0, 0, n)
    tl.store(out_ptr + cols, vals.to(tl.int64), mask=cols < k)


@triton.jit
def _seg_sweep_kernel(
    ids_ptr,   # int64 [n] flattened expert ids
    out_ptr,   # int64 [k] final result
    n,
    k,
    iters,
    BLOCK_N: tl.constexpr,
    BLOCK_E: tl.constexpr,
):
    pid = tl.program_id(0)
    thresholds = pid * BLOCK_E + tl.arange(0, BLOCK_E)
    emask = thresholds < k
    # Keep addresses inside the result when a chunk runs past the range; emask
    # suppresses the duplicated lanes.
    cols = tl.minimum(thresholds, k - 1)
    offs_n = tl.arange(0, BLOCK_N)

    acc = tl.zeros([BLOCK_E], tl.int32)
    for s in range(0, iters):
        offs = s * BLOCK_N + offs_n
        live = offs < n
        # A block past the end of the stream loads as all 0, which every
        # threshold above 0 would count, so the live lanes are cleared out of
        # the match tile explicitly. The trip count needs no second guard.
        ids = tl.load(ids_ptr + offs, mask=live, other=0).to(tl.int32)
        hit = (ids[None, :] < thresholds[:, None]) & live[None, :]
        acc += tl.sum(tl.where(hit, 1, 0), axis=1)

    # One fold for the whole stream walk, then straight out as int64. The two
    # boundary columns need no special case: no id is below 0 and every id is
    # below E, so the sweep already returns 0 and n there.
    tl.store(out_ptr + cols, acc.to(tl.int64), mask=emask)


@triton.jit
def _seg_count_kernel(
    ids_ptr,     # int64 [n] flattened expert ids
    stage_ptr,   # int32 [rows, k] partial tallies, k = E + 1 thresholds
    n,
    k,
    stride_s,
    BLOCK_N: tl.constexpr,
    BLOCK_E: tl.constexpr,
):
    pid = tl.program_id(0)
    offs_n = pid * BLOCK_N + tl.arange(0, BLOCK_N)
    live = offs_n < n
    ids = tl.load(ids_ptr + offs_n, mask=live, other=0).to(tl.int32)

    e_last = k - 1
    offs_e = tl.arange(0, BLOCK_E)
    last_inner = e_last - 1
    # Interior thresholds only: 1 .. E - 1. The two boundary columns are written
    # below, so with E = 1 this loop never runs at all.
    for t0 in range(1, e_last, BLOCK_E):
        thresholds = t0 + offs_e
        emask = thresholds < e_last
        # Keep the addresses inside the tile; emask suppresses wrapped lanes.
        cols = tl.minimum(thresholds, last_inner)
        hit = (ids[None, :] < thresholds[:, None]) & live[None, :]
        tally = tl.sum(tl.where(hit, 1, 0), axis=1)
        tl.store(stage_ptr + pid * stride_s + cols, tally, mask=emask)

    # The two analytic columns, in the same chunk-vector / masked-store form as
    # the sweep above: this block contributes 0 to the lower boundary and its
    # own element count to the upper one, and those counts add up to n across
    # the grid. The block's count is plain index arithmetic, so with E = 1 --
    # where the sweep above does not run -- nothing here reads the ids at all.
    owned = tl.minimum(tl.maximum(n - pid * BLOCK_N, 0), BLOCK_N)
    ends = (offs_e == 0) | (offs_e == 1)
    tl.store(stage_ptr + pid * stride_s + tl.where(offs_e == 0, 0, e_last),
             tl.where(offs_e == 0, 0, owned), mask=ends)


@triton.jit
def _seg_sum_kernel(
    stage_ptr,   # int32 [rows, k]
    out_ptr,     # int64 [k]
    rows,
    k,
    stride_s,
    BLOCK_K: tl.constexpr,
    BLOCK_R: tl.constexpr,
):
    pid = tl.program_id(0)
    cols = pid * BLOCK_K + tl.arange(0, BLOCK_K)
    emask = cols < k
    offs_r = tl.arange(0, BLOCK_R)
    # int32 stays exact: a folded tally never exceeds the element count.
    acc = tl.zeros([BLOCK_K], tl.int32)

    for r0 in range(0, rows, BLOCK_R):
        rmask = offs_r < rows - r0
        tile = tl.load(
            stage_ptr + (r0 + offs_r)[:, None] * stride_s + cols[None, :],
            mask=rmask[:, None] & emask[None, :],
            other=0,
        )
        acc += tl.sum(tile, axis=0)

    # Only the stored result is widened, so no int64 lane arithmetic happens
    # inside the loop.
    tl.store(out_ptr + cols, acc.to(tl.int64), mask=emask)


def _ceil_div(a: int, b: int) -> int:
    return (a + b - 1) // b


def _pick_block_n(n_elems: int) -> int:
    """Widest id block that still leaves the stream split across programs."""
    block_n = _BLOCK_N_MAX
    while block_n > _BLOCK_N_MIN:
        if _ceil_div(n_elems, block_n) >= _MIN_PROGRAMS:
            break
        block_n = block_n // 2
    return block_n


def _pick_block_e(span: int, block_n: int) -> int:
    """Cheapest threshold chunk width for `span` interior columns."""
    cap = _TILE_LANES // block_n
    if cap > _BLOCK_E_MAX:
        cap = _BLOCK_E_MAX
    # Smallest chunk that still fills the narrow end of the proven tile band.
    floor = _TILE_LANES_MIN // block_n
    if floor < _BLOCK_E_MIN:
        floor = _BLOCK_E_MIN
    if floor > cap:
        floor = cap

    best_block = floor
    best_score = None
    block_e = floor
    while block_e <= cap:
        chunks = _ceil_div(span, block_e)
        if chunks < 1:
            chunks = 1
        score = chunks * block_e * (1.0 + _CHUNK_PRICE * (chunks - 1))
        if best_score is None or score < best_score:
            best_score = score
            best_block = block_e
        block_e = block_e * 2
    return best_block


def _striped_plan(n_elems: int, k_out: int):
    """Round 3's geometry: stripe the ids, sweep every chunk per program."""
    block_n = _pick_block_n(n_elems)
    block_e = _pick_block_e(k_out - 2, block_n)
    rows = _ceil_div(n_elems, block_n)
    if rows < 1:
        rows = 1
    chunks = _ceil_div(k_out - 2, block_e)
    if chunks < 1:
        chunks = 1
    return block_e, block_n, rows, chunks


def _work_striped(n_elems: int, k_out: int) -> int:
    """Device nanoseconds of the two-launch striped layout, floor excluded."""
    block_e, block_n, rows, chunks = _striped_plan(n_elems, k_out)
    lanes = rows * chunks * block_e * block_n
    count = lanes * _AGG_NUM // _AGG_DEN
    # Programs run in waves across the cores; a wave costs its serial length.
    count_wave = _ceil_div(rows, _CORES) * chunks * block_e * block_n * _SER
    if count_wave > count:
        count = count_wave

    fold_cols = _ceil_div(k_out, _FOLD_BLOCK_K)
    fold_lanes = rows * fold_cols * _FOLD_BLOCK_K
    fold = fold_lanes * _AGG_NUM // _AGG_DEN
    fold_wave = _ceil_div(fold_cols, _CORES) * rows * _FOLD_BLOCK_K * _SER
    if fold_wave > fold:
        fold = fold_wave
    # Stage tile: one int32 write in the count kernel, one read in the fold.
    stage = rows * k_out * 4 * 2 * _BYTES_NUM // _BYTES_DEN
    programs = rows + fold_cols
    return count + fold + stage + programs * _PROG_NS


def _work_sweep(n_elems: int, k_out: int):
    """Device nanoseconds of the one-launch layout, plus the geometry that
    achieves it. Returns None when no tile in the proven band fits."""
    best_cost = None
    best_block_e = _BLOCK_E_MIN
    best_block_n = _BLOCK_N_MAX
    block_e = _BLOCK_E_MIN
    while block_e <= _BLOCK_E_MAX:
        block_n = _BLOCK_N_MIN
        while block_n <= _BLOCK_N_MAX:
            if _TILE_LANES_MIN <= block_e * block_n <= _TILE_LANES:
                chunks = _ceil_div(k_out, block_e)
                iters = _ceil_div(n_elems, block_n)
                if iters < 1:
                    iters = 1
                lanes = chunks * iters * block_e * block_n
                dev = lanes * _AGG_NUM // _AGG_DEN
                wave = _ceil_div(chunks, _CORES) * iters * block_e * block_n * _SER
                if wave > dev:
                    dev = wave
                # Every chunk walks the stream, so the ids are re-read once per
                # chunk.
                reread = chunks * n_elems * 8 * _BYTES_NUM // _BYTES_DEN
                cost = dev + reread + chunks * _PROG_NS
                if best_cost is None or cost < best_cost:
                    best_cost = cost
                    best_block_e = block_e
                    best_block_n = block_n
            block_n = block_n * 2
        block_e = block_e * 2
    if best_cost is None:
        return None
    return best_cost, best_block_e, best_block_n


def npu_triton_impl(inputs: dict) -> dict:
    topk_ids = inputs["topk_ids"]
    ids = topk_ids.reshape(-1)
    device = ids.device
    n_elems = ids.shape[0]

    # Allocated straight from the knob, then read back: the width of the
    # threshold range is what every size below is derived from.
    probe = torch.empty((inputs["num_local_experts"],), dtype=torch.int8,
                        device=device)
    k_out = probe.shape[0] + 1
    seg_indptr = torch.empty((k_out,), dtype=torch.int64, device=device)

    if k_out <= 2:
        # A single expert: the definition fixes both columns, so one program
        # writes them and the id stream is never read.
        _seg_bound_kernel[(1,)](seg_indptr, n_elems, k_out)
        return {"seg_indptr": seg_indptr}

    striped = _work_striped(n_elems, k_out) + _FLOOR_TWO
    found = _work_sweep(n_elems, k_out)

    if found is not None:
        # Round 4 charged this comparison on device work alone; the floors are
        # the term it was missing, and the sweep estimate carries the padding
        # its own measurements asked for.
        sweep = _FLOOR_ONE + (found[0] * _SWEEP_PAD_NUM) // _SWEEP_PAD_DEN
        if sweep + _MIN_GAIN < striped:
            block_e = found[1]
            block_n = found[2]
            iters = _ceil_div(n_elems, block_n)
            if iters < 1:
                iters = 1
            _seg_sweep_kernel[(_ceil_div(k_out, block_e),)](
                ids,
                seg_indptr,
                n_elems,
                k_out,
                iters,
                BLOCK_N=block_n,
                BLOCK_E=block_e,
            )
            return {"seg_indptr": seg_indptr}

    block_e, block_n, rows, _chunks = _striped_plan(n_elems, k_out)

    # The count kernel covers every column of every stage row, interior and
    # boundary, so the tile needs no pre-clearing pass.
    stage = torch.empty((rows, k_out), dtype=torch.int32, device=device)
    stride_s = stage.shape[1]

    _seg_count_kernel[(rows,)](
        ids,
        stage,
        n_elems,
        k_out,
        stride_s,
        BLOCK_N=block_n,
        BLOCK_E=block_e,
    )
    _seg_sum_kernel[(_ceil_div(k_out, _FOLD_BLOCK_K),)](
        stage,
        seg_indptr,
        rows,
        k_out,
        stride_s,
        BLOCK_K=_FOLD_BLOCK_K,
        BLOCK_R=_FOLD_BLOCK_R,
    )

    return {"seg_indptr": seg_indptr}
