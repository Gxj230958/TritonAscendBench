"""triton-ascend migration of L2_06_topk_log_softmax.

Gathers log_softmax(logits) at the given token ids, one program per row.
Accumulation (max, exp sum, final subtract) is done in fp32 to match the
load-bearing dtype ordering of the reference: bf16 inputs are up-cast
before exp/log, and the output is stored fp32.

Round 2 change (vs round 1): the gather tile width BLOCK_K was
min(1024, next_power_of_2(D)), which degenerates to a 1-lane tile for the
D=1 shapes. Those are exactly the two round-1 failures (P18: B=48, D=1 and
H8: B=2048, D=1), while the only other D=1 shape (H5: B=1) passed, and all
D>=2 shapes passed. A 1-lane gather tile is a degenerate vector width for
the triton-ascend lowering, so the width is floored at 32; the existing
k_mask already zeros out-of-range lanes, so the floored tile is numerically
identical.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _topk_log_softmax_kernel(
    output_ptr,
    logits_ptr,
    logits_stride,
    topk_ids_ptr,
    topk,
    vocab_size,
    BLOCK_SIZE: tl.constexpr,
    BLOCK_K: tl.constexpr,
):
    req_idx = tl.program_id(0)
    row_ptr = logits_ptr + req_idx * logits_stride

    # Pass 1: row max, accumulated in fp32 after up-casting the bf16 tile.
    max_val = float("-inf")
    for i in range(0, vocab_size, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        m = block < vocab_size
        logits = tl.load(row_ptr + block, mask=m, other=float("-inf"))
        max_val = tl.max(tl.maximum(logits.to(tl.float32), max_val))

    # Pass 2: sum of exps in fp32.
    se = 0.0
    for i in range(0, vocab_size, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        m = block < vocab_size
        logits = tl.load(row_ptr + block, mask=m, other=0.0).to(tl.float32)
        e = tl.exp(logits - max_val)
        e = tl.where(m, e, 0.0)
        se += tl.sum(e)
    lse = tl.log(se)

    # Pass 3: gather log-probs at the requested ids, in chunks.
    for i in range(0, topk, BLOCK_K):
        k_off = i + tl.arange(0, BLOCK_K)
        k_mask = k_off < topk
        ids = tl.load(topk_ids_ptr + req_idx * topk + k_off, mask=k_mask, other=0)
        vals = tl.load(row_ptr + ids, mask=k_mask, other=0.0).to(tl.float32)
        o = vals - max_val - lse
        tl.store(output_ptr + req_idx * topk + k_off, o, mask=k_mask)


def npu_triton_impl(inputs: dict) -> dict:
    logits = inputs["logits"]
    token_ids = inputs["token_ids"].to(torch.int64)
    batch_size, vocab_size = logits.shape
    num_ids = token_ids.shape[1]

    logprobs = torch.empty(
        (batch_size, num_ids), dtype=torch.float32, device=logits.device
    )

    BLOCK_SIZE = 1024
    # Gather tile: chunk at 1024 for huge D (keeps the register tile bounded
    # for D=8192..32768), but never below 32 lanes (a 1-lane tile is a
    # degenerate vector width for the triton-ascend lowering).
    BLOCK_K = min(1024, max(32, triton.next_power_of_2(num_ids)))
    if num_ids > 0:
        _topk_log_softmax_kernel[(batch_size,)](
            logprobs,
            logits,
            logits.stride(0),
            token_ids,
            num_ids,
            vocab_size,
            BLOCK_SIZE=BLOCK_SIZE,
            BLOCK_K=BLOCK_K,
            num_warps=8,
        )

    return {"logprobs": logprobs}
