"""Triton-Ascend implementation of the single-pass gated LayerNorm forward.

Migration of the upstream 1-pass layer-norm forward kernel in the mode this
task's configuration drives: affine weights/biases plus the SiLU gate applied
*after* normalisation (non-RMS, ``norm_before_gate=True``).

Design notes
------------
* One program owns one row; the last axis of ``x`` is the reduction axis.
* Statistics and normalisation live in a single device launch, so the whole
  operation is one kernel (no extra reduction launches).
* Accumulation dtype is fp32 everywhere: every load is widened with
  ``.to(tl.float32)`` before it enters a sum, mean/variance/rstd stay fp32,
  and the narrowing back to the storage dtype happens only at the store.
  ``x`` is reused in registers for both the statistics and the normalisation
  pass, so the deviation is measured against the same widened values that
  feed the sums.
* Rows up to ``_ONESHOT_MAX`` columns are held in one on-chip tile, exactly
  like the source kernel.  Wider rows use a chunked variant so the per-tile
  uniform-buffer footprint stays bounded; the chunked variant keeps the same
  arithmetic order (mean, then masked sum of squared deviations, then
  normalise/affine/gate) so both paths agree.
* The gate uses ``z / (1 + exp(-z))`` rather than a fused sigmoid, which is
  overflow-stable at both ends of the SiLU range.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

# Widest row that is processed as a single on-chip tile.
_ONESHOT_MAX = 4096
# Chunk width used by the streaming variant for wider rows.
_STREAM_BLOCK = 1024
# Smallest tile width: keeps degenerate rows (D = 2, 4, ...) tidy and masked.
_MIN_BLOCK = 16


@triton.jit
def _silu_gate(z):
    return z / (1.0 + tl.exp(-z))


@triton.jit
def _ln_fwd_1pass_oneshot(
    X,  # pointer to the input rows
    Y,  # pointer to the output rows
    W,  # pointer to the scale weights
    B,  # pointer to the biases
    Z,  # pointer to the gating branch
    Mean,  # pointer to the per-row mean (fp32)
    Rstd,  # pointer to the per-row 1/std (fp32)
    stride_x,
    stride_y,
    stride_z,
    N,
    eps,
    BLOCK_N: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    HAS_Z: tl.constexpr,
    NORM_BEFORE_GATE: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK_N)
    mask = cols < N

    x = tl.load(X + row * stride_x + cols, mask=mask, other=0.0).to(tl.float32)
    if HAS_Z and not NORM_BEFORE_GATE:
        x = x * _silu_gate(tl.load(Z + row * stride_z + cols, mask=mask, other=0.0).to(tl.float32))

    if IS_RMS_NORM:
        mean = 0.0
    else:
        mean = tl.sum(x, axis=0) / N
    xbar = tl.where(mask, x - mean, 0.0)
    var = tl.sum(xbar * xbar, axis=0) / N
    rstd = 1.0 / tl.sqrt(var + eps)
    if not IS_RMS_NORM:
        tl.store(Mean + row, mean)
    tl.store(Rstd + row, rstd)

    w = tl.load(W + cols, mask=mask).to(tl.float32)
    y = (x - mean) * rstd * w
    if HAS_BIAS:
        b = tl.load(B + cols, mask=mask).to(tl.float32)
        y = y + b
    if HAS_Z and NORM_BEFORE_GATE:
        y = y * _silu_gate(tl.load(Z + row * stride_z + cols, mask=mask, other=0.0).to(tl.float32))

    tl.store(Y + row * stride_y + cols, y, mask=mask)


@triton.jit
def _ln_fwd_1pass_stream(
    X,
    Y,
    W,
    B,
    Z,
    Mean,
    Rstd,
    stride_x,
    stride_y,
    stride_z,
    N,
    eps,
    BLOCK_N: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    HAS_Z: tl.constexpr,
    NORM_BEFORE_GATE: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
):
    row = tl.program_id(0)
    x_base = row * stride_x
    y_base = row * stride_y
    z_base = row * stride_z
    lane = tl.arange(0, BLOCK_N)

    # Pass 1: row mean (fp32 accumulation over chunks).
    acc = tl.zeros([BLOCK_N], dtype=tl.float32)
    for start in range(0, N, BLOCK_N):
        cols = start + lane
        m = cols < N
        chunk = tl.load(X + x_base + cols, mask=m, other=0.0).to(tl.float32)
        if HAS_Z and not NORM_BEFORE_GATE:
            z = tl.load(Z + z_base + cols, mask=m, other=0.0).to(tl.float32)
            chunk = chunk * _silu_gate(z)
        acc += chunk
    if IS_RMS_NORM:
        mean = 0.0
    else:
        mean = tl.sum(acc, axis=0) / N

    # Pass 2: masked sum of squared deviations -> variance -> 1/std.
    acc2 = tl.zeros([BLOCK_N], dtype=tl.float32)
    for start in range(0, N, BLOCK_N):
        cols = start + lane
        m = cols < N
        chunk = tl.load(X + x_base + cols, mask=m, other=0.0).to(tl.float32)
        if HAS_Z and not NORM_BEFORE_GATE:
            z = tl.load(Z + z_base + cols, mask=m, other=0.0).to(tl.float32)
            chunk = chunk * _silu_gate(z)
        xbar = tl.where(m, chunk - mean, 0.0)
        acc2 += xbar * xbar
    var = tl.sum(acc2, axis=0) / N
    rstd = 1.0 / tl.sqrt(var + eps)
    if not IS_RMS_NORM:
        tl.store(Mean + row, mean)
    tl.store(Rstd + row, rstd)

    # Pass 3: normalise, affine, gate, store.
    for start in range(0, N, BLOCK_N):
        cols = start + lane
        m = cols < N
        chunk = tl.load(X + x_base + cols, mask=m, other=0.0).to(tl.float32)
        if HAS_Z and not NORM_BEFORE_GATE:
            z = tl.load(Z + z_base + cols, mask=m, other=0.0).to(tl.float32)
            chunk = chunk * _silu_gate(z)
        w = tl.load(W + cols, mask=m).to(tl.float32)
        y = (chunk - mean) * rstd * w
        if HAS_BIAS:
            b = tl.load(B + cols, mask=m).to(tl.float32)
            y = y + b
        if HAS_Z and NORM_BEFORE_GATE:
            z = tl.load(Z + z_base + cols, mask=m, other=0.0).to(tl.float32)
            y = y * _silu_gate(z)
        tl.store(Y + y_base + cols, y, mask=m)


def _warps_for(block_n: int) -> int:
    # Mirrors the source heuristic, capped for the Ascend vector cores.
    return min(max(block_n // 256, 1), 4)


def npu_triton_impl(inputs: dict) -> dict:
    """Run the migrated layer-norm forward over ``inputs``.

    ``output`` holds the normalised tensor with the shape and storage dtype of
    ``x``. The per-row ``mean``/``rstd`` side outputs the source kernel writes
    are allocated and stored as well, but only ``output`` is returned, since
    that is the key this contract compares.
    """
    x = inputs["x"]
    weight = inputs["weight"]
    # Presence is decided from the key set, never by comparing tensors.
    has_bias = "bias" in inputs
    has_z = "z" in inputs
    eps = inputs["eps"] if "eps" in inputs else 1e-5

    out_shape = x.shape
    n_cols = int(out_shape[-1])
    # A row-major copy guarantees dense rows; cheap no-op for built inputs.
    x2 = x.contiguous().view(-1, n_cols)
    rows = int(x2.shape[0])

    out = torch.empty((rows, n_cols), dtype=x2.dtype, device=x2.device)
    mean = torch.empty((rows,), dtype=torch.float32, device=x2.device)
    rstd = torch.empty((rows,), dtype=torch.float32, device=x2.device)

    # Guarded pointer arguments still need a real tensor of a sane element
    # type; the corresponding loads are pruned when the flag is off.
    b_ptr = inputs["bias"] if has_bias else weight
    zt = inputs["z"] if has_z else x2
    z2 = zt.contiguous().view(-1, n_cols)
    stride_z = int(z2.stride(0))

    if n_cols <= _ONESHOT_MAX:
        block_n = max(_MIN_BLOCK, triton.next_power_of_2(n_cols))
        kernel = _ln_fwd_1pass_oneshot
    else:
        block_n = _STREAM_BLOCK
        kernel = _ln_fwd_1pass_stream

    kernel[(rows,)](
        x2,
        out,
        weight,
        b_ptr,
        z2,
        mean,
        rstd,
        int(x2.stride(0)),
        int(out.stride(0)),
        stride_z,
        n_cols,
        eps,
        BLOCK_N=block_n,
        HAS_BIAS=has_bias,
        HAS_Z=has_z,
        NORM_BEFORE_GATE=True,
        IS_RMS_NORM=False,
        num_warps=_warps_for(block_n),
    )

    # The compared result is the normalised tensor; mean/rstd stay
    # internal so the returned key set matches the task contract.
    return {"output": out.view(out_shape)}
