"""Triton-Ascend implementation of a single-pass gated LayerNorm forward.

Semantics (fp32 intermediate math, result rounded to the input dtype):
    mean = x.mean(-1)
    var  = ((x - mean) ** 2).mean(-1)          # biased
    y    = (x - mean) * rsqrt(var + eps) * w + b
    y    = y * silu(z)                          # gate AFTER normalisation
    return y.to(x.dtype)

Two real Triton kernels are provided:
  * `_ln_fwd_tile`   -- one program per row, whole row in a single block.
  * `_ln_fwd_rowscan` -- one program per row, row walked in BLOCK_N chunks.
                        Statistics come from an online (Welford) merge of the
                        per-chunk partial sums, so no cancellation-prone
                        E[x^2] - mean^2 shortcut is used and the row is read
                        exactly twice.

Entry point: `npu_triton_impl(inputs: dict) -> dict`.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

# Rows at or below this width are handled by the single-block kernel; wider
# rows go through the chunked kernel, so no on-chip fp32 tile is larger than
# _SCAN_BLOCK * 4 bytes.
_TILE_MAX = 2048
# Chunk width for the chunked kernel.
_SCAN_BLOCK = 1024
# Smallest block any kernel is launched with.
_MIN_BLOCK = 16


@triton.jit
def _ln_fwd_tile(
    X,  # input rows, row-major, last dim contiguous
    Y,  # output rows
    W,  # scale, length N
    BS,  # shift, length N
    Z,  # gate, same layout as X (unused when HAS_Z is False)
    stride_x,
    stride_y,
    stride_z,
    N,
    eps,
    BLOCK_N: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    HAS_Z: tl.constexpr,
):
    row = tl.program_id(0)
    cols = tl.arange(0, BLOCK_N)
    mask = cols < N

    x = tl.load(X + row * stride_x + cols, mask=mask, other=0.0).to(tl.float32)
    mean = tl.sum(x, axis=0) / N
    xbar = tl.where(mask, x - mean, 0.0)
    var = tl.sum(xbar * xbar, axis=0) / N
    rstd = 1.0 / tl.sqrt(var + eps)

    w = tl.load(W + cols, mask=mask, other=0.0).to(tl.float32)
    y = (x - mean) * rstd * w
    if HAS_BIAS:
        b = tl.load(BS + cols, mask=mask, other=0.0).to(tl.float32)
        y = y + b
    if HAS_Z:
        z = tl.load(Z + row * stride_z + cols, mask=mask, other=0.0).to(tl.float32)
        y = y * (z / (1.0 + tl.exp(-z)))
    tl.store(Y + row * stride_y + cols, y, mask=mask)


@triton.jit
def _ln_fwd_rowscan(
    X,
    Y,
    W,
    BS,
    Z,
    stride_x,
    stride_y,
    stride_z,
    N,
    eps,
    BLOCK_N: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    HAS_Z: tl.constexpr,
):
    row = tl.program_id(0)
    base_x = X + row * stride_x
    base_y = Y + row * stride_y
    base_z = Z + row * stride_z

    # Pass 1: running mean and running centred second moment, merged chunk by
    # chunk (Welford-style).  Only four fp32 scalars are carried between
    # iterations, and the row is traversed once.
    mean = 0.0
    m2 = 0.0
    seen = 0.0
    for start in range(0, N, BLOCK_N):
        cols = start + tl.arange(0, BLOCK_N)
        mask = cols < N
        x = tl.load(base_x + cols, mask=mask, other=0.0).to(tl.float32)
        n_chunk = tl.minimum(N - start, BLOCK_N).to(tl.float32)
        n_new = seen + n_chunk
        mean_chunk = tl.sum(x, axis=0) / n_chunk
        xbar = tl.where(mask, x - mean_chunk, 0.0)
        m2_chunk = tl.sum(xbar * xbar, axis=0)

        delta = mean_chunk - mean
        mean = mean + delta * (n_chunk / n_new)
        m2 = m2 + m2_chunk + delta * delta * (seen * n_chunk / n_new)
        seen = n_new

    var = m2 / seen
    rstd = 1.0 / tl.sqrt(var + eps)

    # Pass 2: normalise, apply affine and gate, write out.
    for start in range(0, N, BLOCK_N):
        cols = start + tl.arange(0, BLOCK_N)
        mask = cols < N
        x = tl.load(base_x + cols, mask=mask, other=0.0).to(tl.float32)
        w = tl.load(W + cols, mask=mask, other=0.0).to(tl.float32)
        y = (x - mean) * rstd * w
        if HAS_BIAS:
            b = tl.load(BS + cols, mask=mask, other=0.0).to(tl.float32)
            y = y + b
        if HAS_Z:
            z = tl.load(base_z + cols, mask=mask, other=0.0).to(tl.float32)
            y = y * (z / (1.0 + tl.exp(-z)))
        tl.store(base_y + cols, y, mask=mask)


def _row_major(t, n_cols):
    """Return `t` as a 2-D, last-dim-contiguous view of shape (rows, n_cols)."""
    if t.dim() != 2:
        t = t.reshape(-1, n_cols)
    if t.stride(-1) != 1:
        t = t.contiguous()
    return t


def _flat(t):
    """Return `t` as a 1-D, contiguous view (per-feature operands)."""
    if t.dim() != 1:
        t = t.reshape(-1)
    if t.stride(-1) != 1:
        t = t.contiguous()
    return t


def npu_triton_impl(inputs: dict) -> dict:
    x_in = inputs["x"]
    out_shape = x_in.shape
    n_cols = out_shape[-1]
    x2 = _row_major(x_in, n_cols)
    w = _flat(inputs["weight"])

    # Presence is decided from the dict keys only.  An absent operand reuses
    # an already-live tensor, because the kernel never dereferences a pointer
    # whose feature flag is off.
    has_bias = "bias" in inputs
    has_z = "z" in inputs
    b = _flat(inputs["bias"]) if has_bias else w
    z2 = _row_major(inputs["z"], n_cols) if has_z else x2
    eps = inputs["eps"] if "eps" in inputs else 1e-5

    n_rows = x2.shape[0]
    out = torch.empty(x2.shape, dtype=x2.dtype, device=x2.device)
    if n_rows == 0:
        return {"output": out.reshape(out_shape)}

    pow2 = triton.next_power_of_2(n_cols)
    if pow2 <= _TILE_MAX:
        # Padding the block past the row length is numerically neutral: the
        # padded lanes load as zero, are zeroed again before the variance
        # reduction, and are dropped by the store mask.
        block_n = max(pow2, _MIN_BLOCK)
        launch = _ln_fwd_tile
    else:
        block_n = min(_SCAN_BLOCK, pow2)
        launch = _ln_fwd_rowscan

    launch[(n_rows,)](
        x2,
        out,
        w,
        b,
        z2,
        x2.stride(0),
        out.stride(0),
        z2.stride(0),
        n_cols,
        eps,
        BLOCK_N=block_n,
        HAS_BIAS=has_bias,
        HAS_Z=has_z,
    )
    return {"output": out.reshape(out_shape)}
