"""triton-ascend migration of the QKV LoRA-B expand (segmented SGMV) kernel.

Round-2 revision of the round-1 candidate.

Round 1 passed 49/49 correctness comparisons but the verified run was
flagged with an unverified-NPU / non-triton-execution marker and every
shape measured in the hundreds of microseconds to milliseconds range
(e.g. H5 moves 60 B of traffic yet measured ~213 us, P8 does 6.3 MFLOP
yet measured ~4.4 ms). That pattern is the signature of the Triton
program not actually being converted/executed by the triton-ascend
backend and the engine serving output through its reference path. The
most likely conversion-breaking construct in the round-1 device code is
the K-reduction loop whose trip count `tl.cdiv(K, BLOCK_K)` is a runtime
value (K comes from loaded int64 scalars). The triton-ascend 3.2.0.dev
converter handles statically bounded loops reliably; runtime-bounded
loops are the known fragile case.

The single change this round: the K loop becomes statically bounded via
a `K_LOOP: tl.constexpr` parameter set on the host from the shape
(K_LOOP = cdiv(r, BLOCK_K)). All fixture shapes have r <= 16 = BLOCK_K,
so the loop is a single fully-unrolled iteration; larger r would simply
yield more unrolled iterations (one re-conversion per distinct r, which
the benchmark's warmup absorbs).

Secondary simplifications that remove device-side constructs with no
numeric effect:
- The n_offs 1-D scalar table is dropped; the slice window is derived in
  device code as n_start = qkv_id * max_qkv_out_dim, n_size =
  max_qkv_out_dim (equal Q/K/V windows, matching the fixture layout
  output_dim == 3 * per_slice exactly).
- The host no longer allocates the n_offs device tensor.

Everything load-bearing from round 1 is unchanged:
- grid (cdiv(s, BLOCK_S) * cdiv(per_slice, BLOCK_N), 3, num_segments),
  BLOCK_S=16 / BLOCK_N=64 / BLOCK_K=16 (same constexpr values as the
  upstream launcher: BLOCK_S / BLOCK_OUT / BLOCK_R);
- identity row mapping (contiguous tokens, SORTED_BY_ADAPTER=False);
- K = min(rank, r) clamp, x slice read at columns [qkv_id*K : qkv_id*K+K];
- rank-0 / empty-segment no-ops (fresh zero buffer keeps their cells at
  0, base copied through when a base is present);
- fp32 accumulation in tl.dot, scaling applied in fp32, base added in
  fp32, exactly ONE cast to the output dtype right before the store.
Every output cell is written by exactly one program (disjoint segment
rows x disjoint slice windows), so no atomics are needed.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _qkv_lora_b_ascend_kernel(
    # Pointers
    x,
    weights,
    output,
    base,
    # Sizes
    K_full,  # r = qkv_lora_b.shape[-1]
    max_qkv_out_dim,  # per-slice output size (== output_dim // 3)
    # Strides
    x_stride_0,
    x_stride_1,
    w_stride_0,
    w_stride_1,
    w_stride_2,
    o_stride_0,
    o_stride_1,
    # Segment metadata
    seg_indptr,
    weight_indices,
    lora_ranks,
    scalings,
    # Meta parameters
    SORTED_BY_ADAPTER: tl.constexpr,
    BLOCK_S: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    K_LOOP: tl.constexpr,
    HAS_BASE: tl.constexpr,
):
    batch_id = tl.program_id(axis=2)
    qkv_id = tl.program_id(axis=1)
    pid = tl.program_id(axis=0)

    w_index = tl.load(weight_indices + batch_id)
    rank = tl.load(lora_ranks + w_index)

    seg_start = tl.load(seg_indptr + batch_id)
    seg_end = tl.load(seg_indptr + batch_id + 1)
    seg_len = seg_end - seg_start
    if seg_len == 0:
        return

    n_start = qkv_id * max_qkv_out_dim
    n_size = max_qkv_out_dim
    scaling = tl.load(scalings + w_index)

    num_pid_n = tl.cdiv(max_qkv_out_dim, BLOCK_N)
    pid_s = pid // num_pid_n
    pid_n = pid % num_pid_n
    if pid_s * BLOCK_S >= seg_len:
        return

    s_offset = tl.arange(0, BLOCK_S) + pid_s * BLOCK_S
    n_offset = tl.arange(0, BLOCK_N) + pid_n * BLOCK_N
    k_offset = tl.arange(0, BLOCK_K)

    # Tokens are contiguous (SORTED_BY_ADAPTER is False for this task), so the
    # physical row is simply seg_start + s_offset. The parameter is accepted to
    # mirror the upstream signature but the mapping is the identity here.
    s_physical = seg_start + s_offset

    out_mask = (s_offset[:, None] < seg_len) & (n_offset[None, :] < n_size)
    out_ptr = (
        output
        + n_start * o_stride_1
        + (s_physical[:, None] * o_stride_0 + n_offset[None, :] * o_stride_1)
    )

    # Rank-0 (or larger than r) adapters make the product term zero.
    if rank == 0:
        if HAS_BASE:
            base_tile = tl.load(
                base
                + n_start * o_stride_1
                + (s_physical[:, None] * o_stride_0 + n_offset[None, :] * o_stride_1),
                mask=out_mask,
                other=0.0,
            )
            tl.store(out_ptr, base_tile.to(output.dtype.element_ty), mask=out_mask)
        return

    # Clamp the reduction extent to this adapter's rank.
    K = tl.minimum(K_full, rank)

    x_ptrs = (
        x
        + (qkv_id * K) * x_stride_1
        + (s_physical[:, None] * x_stride_0 + k_offset[None, :] * x_stride_1)
    )
    w_ptrs = (weights + w_index * w_stride_0 + n_start * w_stride_1) + (
        k_offset[:, None] * w_stride_2 + n_offset[None, :] * w_stride_1
    )

    partial_sum = tl.zeros((BLOCK_S, BLOCK_N), dtype=tl.float32)
    for k in range(0, K_LOOP):
        x_tile = tl.load(
            x_ptrs,
            mask=(s_offset[:, None] < seg_len) & (k_offset[None, :] < K - k * BLOCK_K),
            other=0.0,
        )
        w_tile = tl.load(
            w_ptrs,
            mask=(k_offset[:, None] < K - k * BLOCK_K) & (n_offset[None, :] < n_size),
            other=0.0,
        )
        partial_sum += tl.dot(x_tile, w_tile)
        x_ptrs += BLOCK_K * x_stride_1
        w_ptrs += BLOCK_K * w_stride_2

    # Apply the scaling in fp32 and add the base tile in fp32 (when present);
    # only then cast once to the input dtype, mirroring the eager reference's
    # single final cast.
    partial_sum = partial_sum * scaling
    if HAS_BASE:
        base_tile = tl.load(
            base
            + n_start * o_stride_1
            + (s_physical[:, None] * o_stride_0 + n_offset[None, :] * o_stride_1),
            mask=out_mask,
            other=0.0,
        )
        partial_sum = partial_sum + base_tile.to(tl.float32)

    partial_sum = partial_sum.to(output.dtype.element_ty)
    tl.store(out_ptr, partial_sum, mask=out_mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    qkv_lora_b = inputs["qkv_lora_b"]
    seg_indptr = inputs["seg_indptr"].to(torch.int64)
    weight_indices = inputs["weight_indices"].to(torch.int64)
    lora_ranks = inputs["lora_ranks"].to(torch.int64)
    scalings = inputs["scalings"].to(torch.float32)

    s = x.shape[0]
    r = qkv_lora_b.shape[-1]
    output_dim = qkv_lora_b.shape[-2]
    n_slices = 3
    per_slice = output_dim // n_slices
    num_segments = int(seg_indptr.numel() - 1)

    # base_output is optional and absent from the fixtures; detect presence
    # via a plain dict membership test (no host-side tensor comparison).
    has_base = "base_output" in inputs

    output = torch.zeros((s, output_dim), device=x.device, dtype=x.dtype)

    BLOCK_S = 16
    BLOCK_N = 64
    BLOCK_K = 16
    # Static trip count for the K reduction: cdiv(r, BLOCK_K) iterations,
    # fully unrolled by the triton-ascend converter (r <= BLOCK_K on all
    # fixture shapes, so exactly one iteration).
    K_LOOP = triton.cdiv(r, BLOCK_K)

    base_ptr = output
    if has_base:
        base_ptr = inputs["base_output"]

    if s > 0 and num_segments > 0:
        grid = (
            triton.cdiv(s, BLOCK_S) * triton.cdiv(per_slice, BLOCK_N),
            n_slices,
            num_segments,
        )
        _qkv_lora_b_ascend_kernel[grid](
            x,
            qkv_lora_b,
            output,
            base_ptr,
            r,
            per_slice,
            x.stride(0),
            x.stride(1),
            qkv_lora_b.stride(0),
            qkv_lora_b.stride(1),
            qkv_lora_b.stride(2),
            output.stride(0),
            output.stride(1),
            seg_indptr,
            weight_indices,
            lora_ranks,
            scalings,
            False,  # SORTED_BY_ADAPTER: tokens are contiguous
            BLOCK_S,
            BLOCK_N,
            BLOCK_K,
            K_LOOP,
            has_base,
        )

    return {"output": output}
