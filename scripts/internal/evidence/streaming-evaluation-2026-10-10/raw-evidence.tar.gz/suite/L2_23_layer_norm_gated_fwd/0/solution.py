"""NPU triton-ascend migration of L2_23_layer_norm_gated_fwd.

Operation (contract / upstream semantics, RMS branch, gated SiLU path):
    xf  = x + residual                      (float32 accumulation)
    var = sum(xf^2, dim=D) / D
    rstd = 1 / sqrt(var + eps)
    xhat = xf * rstd
    y    = (xhat * w + b) * silu(g)         (float32, cast to bf16 on store)
where silu(t) = t / (1 + exp(-t)).

Single fused kernel, one program per row of the (B, D) tensor.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _ln_gated_fwd_kernel(
    x, g, y, w, bias, residual, rstd,
    eps, D,
    BD: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
):
    i_t = tl.program_id(0)
    o_d = tl.arange(0, BD)
    m_d = o_d < D

    # Load row, accumulate residual in fp32 (load-bearing: bf16 inputs,
    # all math in fp32, single cast at store).
    b_x = tl.load(x + i_t * D + o_d, mask=m_d, other=0.0).to(tl.float32)
    b_res = tl.load(residual + i_t * D + o_d, mask=m_d, other=0.0).to(tl.float32)
    b_x = b_x + b_res

    if not IS_RMS_NORM:
        b_mean = tl.sum(b_x, axis=0) / D
        b_xbar = tl.where(m_d, b_x - b_mean, 0.0)
        b_var = tl.sum(b_xbar * b_xbar, axis=0) / D
    else:
        b_xbar = tl.where(m_d, b_x, 0.0)
        b_var = tl.sum(b_xbar * b_xbar, axis=0) / D

    b_rstd = 1.0 / tl.sqrt(b_var + eps)
    tl.store(rstd + i_t, b_rstd)

    b_w = tl.load(w + o_d, mask=m_d, other=0.0).to(tl.float32)
    b_b = tl.load(bias + o_d, mask=m_d, other=0.0).to(tl.float32)

    if not IS_RMS_NORM:
        b_x_hat = (b_x - b_mean) * b_rstd
    else:
        b_x_hat = b_x * b_rstd

    b_y = b_x_hat * b_w + b_b

    # Gate: silu spelled from its definition x/(1+exp(-x)) to match the
    # reference bit-for-bit in fp32.
    b_g = tl.load(g + i_t * D + o_d, mask=m_d, other=0.0).to(tl.float32)
    b_y = b_y * (b_g / (1.0 + tl.exp(-b_g)))

    tl.store(y + i_t * D + o_d, b_y.to(y.dtype.element_ty), mask=m_d)


def _next_power_of_2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    g = inputs["g"]
    w = inputs["w"] if "w" in inputs else inputs["weight"]
    bias = inputs["b"] if "b" in inputs else inputs["bias"]
    residual = inputs["residual"]
    eps = inputs["eps"]
    is_rms_norm = inputs["is_rms_norm"]

    T, D = x.shape
    y = torch.empty_like(x)
    rstd = torch.empty((T,), dtype=torch.float32, device=x.device)

    # bf16 inputs: 65536 // 2 = 32768 max block elements.
    BD = min(32768, _next_power_of_2(D))

    _ln_gated_fwd_kernel[(T,)](
        x=x, g=g, y=y, w=w, bias=bias, residual=residual, rstd=rstd,
        eps=eps, D=D,
        BD=BD,
        IS_RMS_NORM=is_rms_norm,
        num_warps=4,
    )
    return {"output": y}
