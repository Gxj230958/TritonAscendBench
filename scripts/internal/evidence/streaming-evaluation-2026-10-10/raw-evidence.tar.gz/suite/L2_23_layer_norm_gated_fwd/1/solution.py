"""Triton-Ascend migration of L2_23_layer_norm_gated_fwd (gated norm forward).

Per-row semantics, held in float32 from the load until the store:

    v      = x.float() + residual.float()
    mean   = sum(v) / D                     (layer-norm mode; 0.0 in RMS mode)
    var    = sum((v - mean)^2) / D
    rstd   = 1 / sqrt(var + eps)
    x_hat  = (v - mean) * rstd
    y      = (x_hat * w.float() + b.float()) * g * sigmoid(g)
    out    = y.to(x.dtype)                  (the single bf16 narrowing, at the store)

Two device programs share that arithmetic:
  * layer_norm_gated_fwd_kernel  : whole rows stay resident on-chip (D <= 1024).
  * layer_norm_gated_fwd_kernel1 : column-chunked for wide rows (D > 1024),
                                   statistics pass first then the write pass, so
                                   the live block stays inside the 910B UB budget.
"""

import torch
import triton
import triton.language as tl


_TILE_ELEMS = 2048
_MAX_ROWS_PER_PROGRAM = 32
_TARGET_PROGRAMS = 32
_MIN_COLS = 16
_FUSED_MAX_COLS = 1024
_CHUNK_COLS = 1024


@triton.jit
def layer_norm_gated_fwd_kernel(
    x,
    g,
    y,
    w,
    b,
    residual,
    eps,
    T,
    D: tl.constexpr,
    BT: tl.constexpr,
    BD: tl.constexpr,
    ACTIVATION: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
    HAS_RESIDUAL: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    HAS_BIAS: tl.constexpr,
):
    """BT full rows per program; one BD-wide block spans a whole row."""
    i_t = tl.program_id(0)
    o_t = i_t * BT + tl.arange(0, BT)
    o_d = tl.arange(0, BD)
    m_d = o_d < D
    keep = (o_t < T)[:, None] & m_d[None, :]
    offs = o_t[:, None] * D + o_d[None, :]

    b_x = tl.load(x + offs, mask=keep, other=0.0).to(tl.float32)
    if HAS_RESIDUAL:
        b_x += tl.load(residual + offs, mask=keep, other=0.0).to(tl.float32)

    if IS_RMS_NORM:
        # RMS branch: no mean subtraction. An explicit zero mean lets both
        # branches share one (v - mean) expression, which is bit-identical to v.
        b_mean = tl.zeros([BT], dtype=tl.float32)
    else:
        b_mean = tl.sum(b_x, axis=1) / D

    b_xbar = tl.where(keep, b_x - b_mean[:, None], 0.0)
    b_var = tl.sum(b_xbar * b_xbar, axis=1) / D
    b_rstd = 1.0 / tl.sqrt(b_var + eps)

    b_y = b_xbar * b_rstd[:, None]
    if HAS_WEIGHT:
        b_w = tl.load(w + o_d, mask=m_d, other=0.0).to(tl.float32)
        b_y = b_y * b_w[None, :]
    if HAS_BIAS:
        b_b = tl.load(b + o_d, mask=m_d, other=0.0).to(tl.float32)
        b_y = b_y + b_b[None, :]

    b_g = tl.load(g + offs, mask=keep, other=0.0).to(tl.float32)
    if ACTIVATION == "swish" or ACTIVATION == "silu":
        # Output gate written from its definition: g * sigmoid(g).
        b_y = b_y * b_g * tl.sigmoid(b_g)
    elif ACTIVATION == "sigmoid":
        b_y = b_y * tl.sigmoid(b_g)

    tl.store(y + offs, b_y.to(y.dtype.element_ty), mask=keep)


@triton.jit
def layer_norm_gated_fwd_kernel1(
    x,
    g,
    y,
    w,
    b,
    residual,
    eps,
    T,
    D: tl.constexpr,
    BT: tl.constexpr,
    BD: tl.constexpr,
    N_CHUNKS: tl.constexpr,
    ACTIVATION: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
    HAS_RESIDUAL: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    HAS_BIAS: tl.constexpr,
):
    """Wide rows: walk the columns in BD-sized chunks, statistics first, then write."""
    i_t = tl.program_id(0)
    o_t = i_t * BT + tl.arange(0, BT)
    m_t = o_t < T

    b_mean = tl.zeros([BT], dtype=tl.float32)
    if not IS_RMS_NORM:
        acc_mean = tl.zeros([BT], dtype=tl.float32)
        for k in tl.static_range(N_CHUNKS):
            o_d = k * BD + tl.arange(0, BD)
            m_d = o_d < D
            keep = m_t[:, None] & m_d[None, :]
            offs = o_t[:, None] * D + o_d[None, :]
            b_v = tl.load(x + offs, mask=keep, other=0.0).to(tl.float32)
            if HAS_RESIDUAL:
                b_v += tl.load(residual + offs, mask=keep, other=0.0).to(tl.float32)
            acc_mean += tl.sum(b_v, axis=1)
        b_mean = acc_mean / D

    acc_var = tl.zeros([BT], dtype=tl.float32)
    for k in tl.static_range(N_CHUNKS):
        o_d = k * BD + tl.arange(0, BD)
        m_d = o_d < D
        keep = m_t[:, None] & m_d[None, :]
        offs = o_t[:, None] * D + o_d[None, :]
        b_v = tl.load(x + offs, mask=keep, other=0.0).to(tl.float32)
        if HAS_RESIDUAL:
            b_v += tl.load(residual + offs, mask=keep, other=0.0).to(tl.float32)
        b_xbar = tl.where(keep, b_v - b_mean[:, None], 0.0)
        acc_var += tl.sum(b_xbar * b_xbar, axis=1)

    b_rstd = 1.0 / tl.sqrt(acc_var / D + eps)

    for k in tl.static_range(N_CHUNKS):
        o_d = k * BD + tl.arange(0, BD)
        m_d = o_d < D
        keep = m_t[:, None] & m_d[None, :]
        offs = o_t[:, None] * D + o_d[None, :]
        b_v = tl.load(x + offs, mask=keep, other=0.0).to(tl.float32)
        if HAS_RESIDUAL:
            b_v += tl.load(residual + offs, mask=keep, other=0.0).to(tl.float32)
        b_y = (b_v - b_mean[:, None]) * b_rstd[:, None]
        if HAS_WEIGHT:
            b_w = tl.load(w + o_d, mask=m_d, other=0.0).to(tl.float32)
            b_y = b_y * b_w[None, :]
        if HAS_BIAS:
            b_b = tl.load(b + o_d, mask=m_d, other=0.0).to(tl.float32)
            b_y = b_y + b_b[None, :]
        b_g = tl.load(g + offs, mask=keep, other=0.0).to(tl.float32)
        if ACTIVATION == "swish" or ACTIVATION == "silu":
            b_y = b_y * b_g * tl.sigmoid(b_g)
        elif ACTIVATION == "sigmoid":
            b_y = b_y * tl.sigmoid(b_g)
        tl.store(y + offs, b_y.to(y.dtype.element_ty), mask=keep)


def _rows_per_program(block_cols, total_rows):
    """Cap the resident tile, then trade tile height for more live programs."""
    bt = _TILE_ELEMS // block_cols
    if bt < 1:
        bt = 1
    if bt > _MAX_ROWS_PER_PROGRAM:
        bt = _MAX_ROWS_PER_PROGRAM
    while bt > 1 and -(-total_rows // bt) < _TARGET_PROGRAMS:
        bt = bt // 2
    return bt


def _select_tensor(inputs, primary, alias):
    """Pick a tensor by its task key, honouring the weight->w / bias->b alias map."""
    if primary in inputs:
        return inputs[primary], True
    if alias in inputs:
        return inputs[alias], True
    return None, False


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    g = inputs["g"]
    eps = inputs["eps"]
    is_rms_norm = inputs["is_rms_norm"]

    weight, has_weight = _select_tensor(inputs, "weight", "w")
    bias, has_bias = _select_tensor(inputs, "bias", "b")
    residual, has_residual = _select_tensor(inputs, "residual", "residual")

    # Every optional pointer stays a real tensor so the launch never dereferences
    # a null address; the HAS_* constexprs keep the unused ones out of the kernel.
    safe_weight = weight
    if not has_weight:
        safe_weight = x
    safe_bias = bias
    if not has_bias:
        safe_bias = x
    safe_residual = residual
    if not has_residual:
        safe_residual = x

    # Flat row-major indexing assumes a dense layout; callers that hand over a
    # permuted or sliced view are normalised here at zero cost when already dense.
    x = x.contiguous()
    g = g.contiguous()
    safe_residual = safe_residual.contiguous()
    safe_weight = safe_weight.contiguous()
    safe_bias = safe_bias.contiguous()

    T = x.shape[0]
    D = x.shape[1]
    y = torch.empty_like(x)

    BD = triton.next_power_of_2(D)
    if BD < _MIN_COLS:
        BD = _MIN_COLS

    if BD <= _FUSED_MAX_COLS:
        BT = _rows_per_program(BD, T)
        layer_norm_gated_fwd_kernel[(triton.cdiv(T, BT),)](
            x=x,
            g=g,
            y=y,
            w=safe_weight,
            b=safe_bias,
            residual=safe_residual,
            eps=eps,
            T=T,
            D=D,
            BT=BT,
            BD=BD,
            ACTIVATION="swish",
            IS_RMS_NORM=is_rms_norm,
            HAS_RESIDUAL=has_residual,
            HAS_WEIGHT=has_weight,
            HAS_BIAS=has_bias,
            num_warps=4,
        )
    else:
        BT = _rows_per_program(_CHUNK_COLS, T)
        layer_norm_gated_fwd_kernel1[(triton.cdiv(T, BT),)](
            x=x,
            g=g,
            y=y,
            w=safe_weight,
            b=safe_bias,
            residual=safe_residual,
            eps=eps,
            T=T,
            D=D,
            BT=BT,
            BD=_CHUNK_COLS,
            N_CHUNKS=triton.cdiv(D, _CHUNK_COLS),
            ACTIVATION="swish",
            IS_RMS_NORM=is_rms_norm,
            HAS_RESIDUAL=has_residual,
            HAS_WEIGHT=has_weight,
            HAS_BIAS=has_bias,
            num_warps=4,
        )

    return {"output": y}
