"""NPU (Triton-Ascend) implementation for L2_23_layer_norm_gated_fwd.

Row-tiled gated normalization forward over a [T, D] view of the inputs:

    xr  = x + residual                      (fp32 accumulation)
    var = sum(xr * xr, axis=-1) / D         (IS_RMS_NORM: no mean removal)
    xh  = xr * rsqrt(var + eps)
    yn  = (xh * w) + b                      (fp32)
    out = yn * g * sigmoid(g)               (swish gate) -> input dtype

Numerics that are load-bearing and kept exactly as upstream:
  * every operand is widened to fp32 before any add, mul or reduction;
  * the residual add happens BEFORE the reduction;
  * the reduction divisor is the true D (pad lanes contribute 0);
  * rstd is formed as 1 / tl.sqrt(var + eps), not a reciprocal-square-root
    intrinsic, so the rounding sequence matches the reference;
  * the reduction is a plain tl.sum over the fp32 squares;
  * the single narrowing cast to the tensor dtype happens last.

Rows whose feature width does not fit one block are handled by a bounded
column loop; the sum of squares stays in an fp32 accumulator across chunks
and the tile is re-read (it is smaller than the round trip) for the apply
pass.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


def _npo(n):
    """Smallest power of two that is >= n, for n >= 1."""
    p = 1
    while p < n:
        p = p + p
    return p


@triton.jit
def layer_norm_gated_fwd_kernel(
    x,
    g,
    y,
    w,
    b,
    residual,
    residual_out,
    mean,
    rstd,
    eps,
    T,
    D,
    stride_xt,
    stride_yt,
    stride_gt,
    stride_rt,
    NCHUNK: tl.constexpr,
    BT: tl.constexpr,
    BD: tl.constexpr,
    D_FULL: tl.constexpr,
    ACTIVATION: tl.constexpr,
    IS_RMS_NORM: tl.constexpr,
    STORE_RESIDUAL_OUT: tl.constexpr,
    HAS_RESIDUAL: tl.constexpr,
    HAS_WEIGHT: tl.constexpr,
    HAS_BIAS: tl.constexpr,
):
    i_t = tl.program_id(0)
    o_t = i_t * BT + tl.arange(0, BT)
    m_t = o_t < T
    o_d = tl.arange(0, BD)

    # ------------------------------------------------------------------
    # Narrow rows: the whole feature axis fits one block, so the
    # normalized tile stays live and nothing is read twice.
    # ------------------------------------------------------------------
    if D_FULL:
        m_x = m_t[:, None] & (o_d[None, :] < D)
        p_x = x + o_t[:, None] * stride_xt + o_d[None, :]
        b_x = tl.load(p_x, mask=m_x, other=0.0).to(tl.float32)
        if HAS_RESIDUAL:
            b_x += tl.load(residual + o_t[:, None] * stride_rt + o_d[None, :],
                           mask=m_x, other=0.0).to(tl.float32)
        if STORE_RESIDUAL_OUT:
            tl.store(residual_out + o_t[:, None] * stride_rt + o_d[None, :],
                     b_x.to(residual_out.dtype.element_ty), mask=m_x)

        b_xbar = tl.where(m_x, b_x, 0.0)
        if IS_RMS_NORM:
            b_var = tl.sum(b_xbar * b_xbar, axis=1) / D
        else:
            b_mean = tl.sum(b_x, axis=1) / D
            tl.store(mean + o_t, b_mean, mask=m_t)
            b_xbar = tl.where(m_x, b_x - b_mean[:, None], 0.0)
            b_var = tl.sum(b_xbar * b_xbar, axis=1) / D

        b_rstd = 1.0 / tl.sqrt(b_var + eps)
        tl.store(rstd + o_t, b_rstd, mask=m_t)

        if IS_RMS_NORM:
            b_xh = b_x * b_rstd[:, None]
        else:
            b_xh = (b_x - b_mean[:, None]) * b_rstd[:, None]

        if HAS_WEIGHT:
            b_w = tl.load(w + o_d, mask=o_d < D, other=0.0).to(tl.float32)
            b_xh = b_xh * b_w[None, :]
        if HAS_BIAS:
            b_bb = tl.load(b + o_d, mask=o_d < D, other=0.0).to(tl.float32)
            b_xh = b_xh + b_bb[None, :]

        b_g = tl.load(g + o_t[:, None] * stride_gt + o_d[None, :],
                      mask=m_x, other=0.0).to(tl.float32)
        b_y = b_xh * b_g * tl.sigmoid(b_g)
        tl.store(y + o_t[:, None] * stride_yt + o_d[None, :],
                 b_y.to(y.dtype.element_ty), mask=m_x)

    # ------------------------------------------------------------------
    # Wide rows: bounded column loops, fp32 accumulators across chunks.
    # The mean pass disappears at build time for the RMS variant, and the
    # variance keeps the upstream two-pass centered form.
    # ------------------------------------------------------------------
    else:
        b_mean = tl.zeros([BT], dtype=tl.float32)
        if not IS_RMS_NORM:
            for i_c in tl.static_range(NCHUNK):
                o_c = i_c * BD + o_d
                m_c = m_t[:, None] & (o_c[None, :] < D)
                b_xc = tl.load(x + o_t[:, None] * stride_xt + o_c[None, :],
                               mask=m_c, other=0.0).to(tl.float32)
                if HAS_RESIDUAL:
                    b_xc += tl.load(residual + o_t[:, None] * stride_rt + o_c[None, :],
                                    mask=m_c, other=0.0).to(tl.float32)
                b_mean += tl.sum(tl.where(m_c, b_xc, 0.0), axis=1)
            b_mean = b_mean / D
            tl.store(mean + o_t, b_mean, mask=m_t)

        b_var = tl.zeros([BT], dtype=tl.float32)
        for i_c in tl.static_range(NCHUNK):
            o_c = i_c * BD + o_d
            m_c = m_t[:, None] & (o_c[None, :] < D)
            b_xc = tl.load(x + o_t[:, None] * stride_xt + o_c[None, :],
                           mask=m_c, other=0.0).to(tl.float32)
            if HAS_RESIDUAL:
                b_xc += tl.load(residual + o_t[:, None] * stride_rt + o_c[None, :],
                                mask=m_c, other=0.0).to(tl.float32)
            if IS_RMS_NORM:
                b_qc = tl.where(m_c, b_xc, 0.0)
            else:
                b_qc = tl.where(m_c, b_xc - b_mean[:, None], 0.0)
            b_var += tl.sum(b_qc * b_qc, axis=1)

        b_rstd = 1.0 / tl.sqrt(b_var / D + eps)
        tl.store(rstd + o_t, b_rstd, mask=m_t)

        for i_c in tl.static_range(NCHUNK):
            o_c = i_c * BD + o_d
            m_c = m_t[:, None] & (o_c[None, :] < D)
            b_x = tl.load(x + o_t[:, None] * stride_xt + o_c[None, :],
                          mask=m_c, other=0.0).to(tl.float32)
            if HAS_RESIDUAL:
                b_x += tl.load(residual + o_t[:, None] * stride_rt + o_c[None, :],
                               mask=m_c, other=0.0).to(tl.float32)
            if STORE_RESIDUAL_OUT:
                tl.store(residual_out + o_t[:, None] * stride_rt + o_c[None, :],
                         b_x.to(residual_out.dtype.element_ty), mask=m_c)
            if IS_RMS_NORM:
                b_xh = b_x * b_rstd[:, None]
            else:
                b_xh = (b_x - b_mean[:, None]) * b_rstd[:, None]
            if HAS_WEIGHT:
                b_w = tl.load(w + o_c, mask=o_c < D, other=0.0).to(tl.float32)
                b_xh = b_xh * b_w[None, :]
            if HAS_BIAS:
                b_bb = tl.load(b + o_c, mask=o_c < D, other=0.0).to(tl.float32)
                b_xh = b_xh + b_bb[None, :]
            b_g = tl.load(g + o_t[:, None] * stride_gt + o_c[None, :],
                          mask=m_c, other=0.0).to(tl.float32)
            tl.store(y + o_t[:, None] * stride_yt + o_c[None, :],
                     (b_xh * b_g * tl.sigmoid(b_g)).to(y.dtype.element_ty),
                     mask=m_c)


_TILE_ELEMS = 4096
_MAX_BD = 1024
_MIN_GRID = 32


def _pick_block(t, d):
    """(BD, NCHUNK, D_FULL, BT) under a fixed per-program element budget."""
    bd_full = _npo(d)
    bd = min(bd_full, _MAX_BD)
    nchunk = (d + bd - 1) // bd
    d_full = nchunk == 1
    bt = max(1, min(32, _TILE_ELEMS // bd))
    while bt > 1 and (t + bt - 1) // bt < _MIN_GRID:
        bt //= 2
    return bd, nchunk, d_full, bt


def npu_triton_impl(inputs: dict) -> dict:
    """Gated RMS/Layer normalization forward with residual add and swish gate."""
    x = inputs["x"]
    g = inputs["g"]

    has_w = "w" in inputs
    if not has_w:
        has_w = "weight" in inputs
    w = x
    if "w" in inputs:
        w = inputs["w"]
    if "weight" in inputs:
        w = inputs["weight"]

    has_b = "b" in inputs
    if not has_b:
        has_b = "bias" in inputs
    b = x
    if "b" in inputs:
        b = inputs["b"]
    if "bias" in inputs:
        b = inputs["bias"]

    has_residual = "residual" in inputs
    r2 = x
    if has_residual:
        r2 = inputs["residual"]

    eps = 1e-5
    if "eps" in inputs:
        eps = inputs["eps"]
    is_rms_norm = True
    if "is_rms_norm" in inputs:
        is_rms_norm = inputs["is_rms_norm"]

    out_shape = x.shape
    d = int(out_shape[-1])
    x2 = x.reshape((-1, d))
    g2 = g.reshape((-1, d))
    if has_residual:
        r2 = r2.reshape((-1, d))
    if x2.stride(1) != 1:
        x2 = x2.contiguous()
    if g2.stride(1) != 1:
        g2 = g2.contiguous()
    if has_residual and r2.stride(1) != 1:
        r2 = r2.contiguous()

    t = int(x2.shape[0])
    y = torch.empty((t, d), dtype=x2.dtype, device=x2.device)
    rstd = torch.empty((t,), dtype=torch.float32, device=x2.device)
    mean = torch.empty((t,), dtype=torch.float32, device=x2.device)

    stride_rt = 0
    if has_residual:
        stride_rt = int(r2.stride(0))

    bd, nchunk, d_full, bt = _pick_block(t, d)
    elems = bd * bt
    num_warps = 4
    if elems < 2048:
        num_warps = 1
    if 2048 <= elems < 4096:
        num_warps = 2
    layer_norm_gated_fwd_kernel[((t + bt - 1) // bt,)](
        x2,
        g2,
        y,
        w,
        b,
        r2,
        y,
        mean,
        rstd,
        eps,
        t,
        d,
        int(x2.stride(0)),
        int(y.stride(0)),
        int(g2.stride(0)),
        stride_rt,
        NCHUNK=nchunk,
        BT=bt,
        BD=bd,
        D_FULL=d_full,
        ACTIVATION="swish",
        IS_RMS_NORM=is_rms_norm,
        STORE_RESIDUAL_OUT=False,
        HAS_RESIDUAL=has_residual,
        HAS_WEIGHT=has_w,
        HAS_BIAS=has_b,
        num_warps=num_warps,
    )

    return {"output": y.reshape(out_shape)}
