"""Round 1 — triton-ascend port of the gated-delta-rule single-step update.

Per (b, h), with q,k,v in [D], state in [D, D] (fp32):

    sp   = softplus(a + dt_bias, softplus_beta, softplus_threshold)   (scalar)
    g    = exp(-exp(A_log) * sp)                                      (scalar)
    kS   = sum_k k[k] * state[k, v]     -> [D]    (row-vector matvec)
    qS   = sum_k q[k] * state[k, v]     -> [D]
    qk   = sum_k q[k] * k[k]            -> scalar
    d[v] = beta[v] * (v[v] - g * kS[v])
    S'[k, v] = g * state[k, v] + k[k] * d[v]
    out[v]   = sum_k q[k] * S'[k, v]
             = g * qS[v] + qk * d[v]              (rank-1 expansion)

The rank-1 expansion is algebraically identical to the reference
contraction, so the output is computed without ever reading S'.

All math runs in fp32; the bfloat16 q/k/v are upcast on load.  D ranges
from 1 to 1024 and is not always a power of two, so the [D, D] state is
processed with a chunked loop (BK rows per step); one program owns
(b, h, v-block) and loops over the k-chunks internally, which also keeps
the number of launches at exactly two (within the allowed 1..4).

Launches:
  kernel 1 (grid = B*H, D/BV): writes kS, qS scratch and the scalar qk.
  kernel 2 (grid = B*H, D/BV): re-gates/decays the state in place into
                               new_state and writes the bfloat16 output.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _gate_scalar(A_log, a, dt_bias, i_b, i_h, H: tl.constexpr,
                 softplus_beta, softplus_threshold):
    A = tl.load(A_log + i_b * H + i_h).to(tl.float32)
    av = tl.load(a + i_b * H + i_h).to(tl.float32)
    db = tl.load(dt_bias + i_h).to(tl.float32)
    x = av + db
    z = softplus_beta * x
    # sp = log(1 + exp(z)) / beta, evaluated directly: the linear branch
    # (z > threshold) is taken first, and for z <= threshold (<= 20) the
    # fp32 exp cannot overflow.
    sp = tl.log(1.0 + tl.exp(z)) / softplus_beta
    sp = tl.where(z > softplus_threshold, x, sp)
    return tl.exp(-tl.exp(A) * sp)


@triton.jit
def _matvec_kernel(
    q, k, v, state, kS, qS, qk,
    A_log, a, dt_bias, beta,
    H: tl.constexpr, D: tl.constexpr,
    BK: tl.constexpr, BV: tl.constexpr, NK: tl.constexpr,
):
    i_bh = tl.program_id(0)
    i_vb = tl.program_id(1)
    i_b = i_bh // H
    i_h = i_bh % H

    o_v = i_vb * BV + tl.arange(0, BV)
    mask_v = o_v < D

    acc_ks = tl.zeros([BV], dtype=tl.float32)
    acc_qs = tl.zeros([BV], dtype=tl.float32)
    acc_qk = tl.zeros([], dtype=tl.float32)

    for kc in range(0, NK):
        o_k = kc * BK + tl.arange(0, BK)
        mask_k = o_k < D
        mask_h = mask_k[:, None] & mask_v[None, :]
        base = i_bh * D
        kb = tl.load(k + base + o_k, mask=mask_k, other=0.0).to(tl.float32)
        qb = tl.load(q + base + o_k, mask=mask_k, other=0.0).to(tl.float32)
        S = tl.load(state + base * D + o_k[:, None] * D + o_v[None, :],
                    mask=mask_h, other=0.0)
        acc_ks += tl.sum(kb[:, None] * S, 0)
        acc_qs += tl.sum(qb[:, None] * S, 0)
        acc_qk += tl.sum(qb * kb)

    # v is not needed here; keep the store masks identical for kS and qS.
    tl.store(kS + i_bh * D + o_v, acc_ks, mask=mask_v)
    tl.store(qS + i_bh * D + o_v, acc_qs, mask=mask_v)
    if i_vb == 0:
        tl.store(qk + i_bh, acc_qk)


@triton.jit
def _update_kernel(
    q, k, v, state, out, new_state, kS, qS, qk,
    A_log, a, dt_bias, beta,
    softplus_beta, softplus_threshold,
    H: tl.constexpr, D: tl.constexpr,
    BK: tl.constexpr, BV: tl.constexpr, NK: tl.constexpr,
):
    i_bh = tl.program_id(0)
    i_vb = tl.program_id(1)
    i_b = i_bh // H
    i_h = i_bh % H

    o_v = i_vb * BV + tl.arange(0, BV)
    mask_v = o_v < D

    g = _gate_scalar(A_log, a, dt_bias, i_b, i_h, H,
                     softplus_beta, softplus_threshold)
    qkv = tl.load(qk + i_bh)

    ks = tl.load(kS + i_bh * D + o_v, mask=mask_v, other=0.0)
    qs = tl.load(qS + i_bh * D + o_v, mask=mask_v, other=0.0)
    vt = tl.load(v + i_bh * D + o_v, mask=mask_v, other=0.0).to(tl.float32)
    bt = tl.load(beta + i_bh * D + o_v, mask=mask_v, other=0.0).to(tl.float32)

    d = bt * (vt - g * ks)
    o = g * qs + qkv * d
    tl.store(out + i_bh * D + o_v, o.to(out.dtype.element_ty), mask=mask_v)

    base = i_bh * D
    for kc in range(0, NK):
        o_k = kc * BK + tl.arange(0, BK)
        mask_k = o_k < D
        mask_h = mask_k[:, None] & mask_v[None, :]
        kb = tl.load(k + base + o_k, mask=mask_k, other=0.0).to(tl.float32)
        S = tl.load(state + base * D + o_k[:, None] * D + o_v[None, :],
                    mask=mask_h, other=0.0)
        Sn = g * S + kb[:, None] * d[None, :]
        tl.store(new_state + base * D + o_k[:, None] * D + o_v[None, :],
                 Sn, mask=mask_h)


def npu_triton_impl(inputs: dict) -> dict:
    A_log = inputs["A_log"]
    a = inputs["a"]
    dt_bias = inputs["dt_bias"]
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    beta = inputs["beta"]
    state = inputs["state"]
    softplus_beta = inputs["softplus_beta"]
    softplus_beta = softplus_beta.item() if torch.is_tensor(softplus_beta) else softplus_beta
    softplus_threshold = inputs["softplus_threshold"]
    softplus_threshold = softplus_threshold.item() if torch.is_tensor(softplus_threshold) else softplus_threshold

    B, H, D = q.shape
    BH = B * H
    dev = q.device

    q = q.contiguous()
    k = k.contiguous()
    v = v.contiguous()
    A_log = A_log.contiguous()
    a = a.contiguous()
    dt_bias = dt_bias.contiguous()
    beta = beta.contiguous()
    state = state.contiguous()

    out = torch.empty(B, H, D, dtype=q.dtype, device=dev)
    new_state = torch.empty(B, H, D, D, dtype=state.dtype, device=dev)
    kS = torch.empty(BH, D, dtype=torch.float32, device=dev)
    qS = torch.empty(BH, D, dtype=torch.float32, device=dev)
    qk = torch.empty(BH, dtype=torch.float32, device=dev)

    BK = 64
    BV = 64
    NK = triton.cdiv(D, BK)
    NV = triton.cdiv(D, BV)

    _matvec_kernel[(BH, NV)](
        q, k, v, state, kS, qS, qk,
        A_log, a, dt_bias, beta,
        H=H, D=D, BK=BK, BV=BV, NK=NK,
        num_warps=4,
    )
    _update_kernel[(BH, NV)](
        q, k, v, state, out, new_state, kS, qS, qk,
        A_log, a, dt_bias, beta,
        softplus_beta, softplus_threshold,
        H=H, D=D, BK=BK, BV=BV, NK=NK,
        num_warps=4,
    )
    return {"output": out, "state": new_state}
