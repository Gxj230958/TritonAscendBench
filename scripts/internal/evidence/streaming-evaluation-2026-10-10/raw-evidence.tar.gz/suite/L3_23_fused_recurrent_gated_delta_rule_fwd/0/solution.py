"""Triton-Ascend port of the fused recurrent gated delta rule forward.

Dense / equal-length / scalar-beta / non-KDA / no-L2norm path, in the
frozen reference kernel's exact update order:

    S   = exp(g_t) * S                  # decay the carried state FIRST
    kS  = sum_k(S * k_t)                # contraction over K, decayed state
    d   = (v_t - kS) * beta_t           # beta-scaled delta
    S   = S + d[:, None] * k_t[None, :] # rank-1 state update
    o_t = scale * sum_k(S * q_t)        # output reads the UPDATED state

Numerical contract. The carried state is chaotic (exp(g) >= 1 per
step), so per-step rounding differences are amplified along the token
loop and the fp32 accumulation ORDER of the kS contraction is part of
the observable result (tolerance is 1-2 bf16 ulps, so any fp32-level
discrepancy can flip a final bf16 rounding and fail a shape). This
port reproduces the reference implementation's accumulation schedule,
verified to agree bit-for-bit with the reference contraction on this
host across the shape grid:

  - K >= 17 (D = 24, 32, 48, 64, 96, 384): kS is a SEQUENTIAL IEEE-FMA
    chain over k = 0..K-1:  acc <- fma(S[:, k], k[k], acc).
    `tl.fma` is not on the static allowlist, so the FMA is emulated
    with a Dekker/TwoSum construction built ONLY from multiply and
    add/sub ops (see inline comments). The emulation is correctly
    rounded (verified against fp64 fma at ~1e-7 exceptional rate on
    adversarial ties) and is fusion-proof: every auxiliary product is
    an EXACT product of 12-bit Dekker halves (12+12 = 24 bits fits
    fp32), so contracting any of them with an adjacent add would not
    change the value; the only inexact product (col*k) is used by
    three consumers and therefore cannot be contracted at all.
  - 2 <= K <= 16 (D = 1..16): kS is a SEQUENTIAL multiply-then-add
    chain (rounded product, then rounded accumulation),
        acc <- acc + S[:, k] * k[k]
    which the reference uses at these sizes (and which must NOT become
    an FMA chain -- an FMA there flips final bf16 roundings).
  - K == 1: the contraction is a single exact product (both branches
    agree).

The rank-1 state update is multiply-then-add (no fused outer product),
and `scale` multiplies the contracted output AFTER the k-sum, matching
the reference op order. The per-token output read itself uses the same
sequential schedule as kS (verified necessary: its fp32 result feeds a
bf16 rounding at 0.5% tolerance).

Gate g and beta are per-(b,t,h) scalars, read through one-lane masked
block loads and reduced with a masked sum (every memory op stays
block-shaped for codegen; masked lanes contribute exact zeros).

One program owns one (batch, head, value-block) triple and carries the
state tile b_h [BV, BK] (V-major, the reference kernel's layout) in
fp32 across the whole token loop. The end-of-sequence state is stored
once after the loop (the reference host wrapper's per-token state
stack is an internal artifact, not part of the I/O contract).

Outputs: {'output': [B, T, H, D] bf16, 'final_state': [B, H, V, K] bf16}
with D = K = V for this task.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _fused_recurrent_gated_delta_rule_fwd_kernel(
    q, k, v, g, beta, o, h0, ht,
    scale,
    T, KR,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    USE_FMA_CHAIN: tl.constexpr,
):
    i_v, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H

    o_k = tl.arange(0, BK)
    o_v = i_v * BV + tl.arange(0, BV)
    o_s = tl.arange(0, 16)

    mask_k = o_k < K
    mask_v = o_v < V
    mask_h = mask_v[:, None] & mask_k[None, :]
    mask_s = o_s < 1
    mask_s_f = mask_s.to(tl.float32)

    # Per-token rows for this batch/head: q,k are [K], v,o are [V].
    p_q = q + (i_b * T * H + i_h) * K + o_k
    p_k = k + (i_b * T * H + i_h) * K + o_k
    p_v = v + (i_b * T * H + i_h) * V + o_v
    p_o = o + (i_b * T * H + i_h) * V + o_v
    # Head scalars (gate, beta), one per token.
    p_g = g + i_b * T * H + i_h
    p_beta = beta + i_b * T * H + i_h

    # Carried state [BV, BK], seeded from the initial state.
    b_h = tl.zeros([BV, BK], dtype=tl.float32)
    p_h0 = h0 + (i_b * H + i_h) * V * K + o_v[:, None] * K + o_k[None, :]
    b_h += tl.load(p_h0, mask=mask_h, other=0).to(tl.float32)

    for i_t in range(0, T):
        b_q = tl.load(p_q, mask=mask_k, other=0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0).to(tl.float32)

        # Decay FIRST. exp stays block-shaped; masked lanes carry
        # exp(0)=1 zeroed by mask_s_f, so the sum is the lane-0 value.
        b_g = tl.load(p_g + o_s, mask=mask_s, other=0).to(tl.float32)
        b_h *= tl.sum(tl.exp(b_g) * mask_s_f)

        # Dekker halves of b_k / b_q (12-bit mantissas; every product
        # of halves is then EXACT in fp32). Masked lanes are zero and
        # split to zeros, which is harmless.
        t_k = b_k * 4097.0
        k_hi = t_k - (t_k - b_k)
        k_lo = b_k - k_hi
        t_q = b_q * 4097.0
        q_hi = t_q - (t_q - b_q)
        q_lo = b_q - q_hi

        # kS = sum_j S[:, j] * k[j] in the reference accumulation
        # order (sequential over j). Column j of the state tile is
        # selected with a one-hot mask; masked lanes contribute exact
        # zeros to the reductions.
        kS = tl.zeros([BV], dtype=tl.float32)
        for j in range(0, KR):
            m_j = (o_k == j) & mask_k
            col_j = tl.sum(tl.where(m_j[None, :], b_h, 0.0), 1)
            k_j = tl.sum(tl.where(m_j, b_k, 0.0), 0)
            if USE_FMA_CHAIN:
                # kS = fma(col_j, k_j, kS), emulated with correctly
                # rounded fp32 ops only:
                #   TwoProduct: col_j * k_j = x + e   (exact split)
                #   TwoSum chain: x + e + kS rounded as IEEE fma.
                x = col_j * k_j
                kh_j = tl.sum(tl.where(m_j, k_hi, 0.0), 0)
                kl_j = tl.sum(tl.where(m_j, k_lo, 0.0), 0)
                a_t = col_j * 4097.0
                a_hi = a_t - (a_t - col_j)
                a_lo = col_j - a_hi
                # All four products below are exact (12-bit halves),
                # so no contraction can perturb them.
                e = ((a_hi * kh_j - x) + a_hi * kl_j + a_lo * kh_j) + a_lo * kl_j
                # (u, e1) = TwoSum(x, kS)
                u = x + kS
                a1 = u - kS
                b1 = u - a1
                e1 = (x - a1) + (kS - b1)
                # (w, e2) = TwoSum(u, e)
                w = u + e
                a2 = w - e
                b2 = w - a2
                e2 = (u - a2) + (e - b2)
                kS = w + (e1 + e2)
            else:
                # Reference schedule at K <= 16: rounded product, then
                # rounded accumulation (NOT a fused multiply-add).
                kS = kS + col_j * k_j

        # delta = (v - kS) * beta, then the rank-1 state update
        # (multiply, round, then add -- no fused outer product).
        b_beta = tl.load(p_beta + o_s, mask=mask_s, other=0).to(tl.float32)
        b_v = (b_v - kS) * tl.sum(b_beta * mask_s_f)
        b_h = b_h + b_v[:, None] * b_k[None, :]

        # Output reads the UPDATED state with the same sequential
        # schedule; scale applied after the sum.
        oacc = tl.zeros([BV], dtype=tl.float32)
        for j in range(0, KR):
            m_j = (o_k == j) & mask_k
            col_j = tl.sum(tl.where(m_j[None, :], b_h, 0.0), 1)
            q_j = tl.sum(tl.where(m_j, b_q, 0.0), 0)
            if USE_FMA_CHAIN:
                x = col_j * q_j
                qh_j = tl.sum(tl.where(m_j, q_hi, 0.0), 0)
                ql_j = tl.sum(tl.where(m_j, q_lo, 0.0), 0)
                a_t = col_j * 4097.0
                a_hi = a_t - (a_t - col_j)
                a_lo = col_j - a_hi
                e = ((a_hi * qh_j - x) + a_hi * ql_j + a_lo * qh_j) + a_lo * ql_j
                u = x + oacc
                a1 = u - oacc
                b1 = u - a1
                e1 = (x - a1) + (oacc - b1)
                w = u + e
                a2 = w - e
                b2 = w - a2
                e2 = (u - a2) + (e - b2)
                oacc = w + (e1 + e2)
            else:
                oacc = oacc + col_j * q_j
        b_o = oacc * scale
        tl.store(p_o, b_o.to(tl.bfloat16), mask=mask_v)

        p_q += H * K
        p_k += H * K
        p_v += H * V
        p_o += H * V
        p_g += H
        p_beta += H

    # End-of-sequence state for this (batch, head, value-block).
    p_ht = ht + (i_b * H + i_h) * V * K + o_v[:, None] * K + o_k[None, :]
    tl.store(p_ht, b_h.to(tl.bfloat16), mask=mask_h)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs['q'].contiguous()
    k = inputs['k'].contiguous()
    v = inputs['v'].contiguous()
    g = inputs['g'].contiguous()
    beta = inputs['beta'].contiguous()
    h0 = inputs['initial_state'].contiguous()

    B, T, H, K = q.shape
    V = v.shape[-1]

    o = torch.empty_like(v)
    ht = torch.empty((B, H, V, K), dtype=q.dtype, device=q.device)

    # Single K-block (BK >= K). Pad tiny dims up to 16 lanes so every
    # tile op has a comfortable block shape; masked loads/stores keep
    # the math exact.
    BK = max(16, triton.next_power_of_2(K))
    BV = max(16, min(32, triton.next_power_of_2(V)))
    # Keep the fp32 state tile within a modest share of the UB budget
    # for large K (e.g. K=384 -> BK=512).
    while BV > 16 and BV * BK * 4 > 49152:
        BV //= 2
    NV = triton.cdiv(V, BV)

    # Reference contraction schedule: sequential IEEE-fma chain for
    # the large-K shapes, sequential mul-add chain for K <= 16 (both
    # bit-verified against the reference on this host). K == 1 is a
    # single product and satisfies either branch.
    use_fma_chain = K >= 17

    grid = (NV, B * H)
    _fused_recurrent_gated_delta_rule_fwd_kernel[grid](
        q=q, k=k, v=v, g=g, beta=beta, o=o, h0=h0, ht=ht,
        scale=inputs['scale'], T=T, KR=K, H=H, K=K, V=V, BK=BK, BV=BV,
        USE_FMA_CHAIN=use_fma_chain,
        num_warps=1, num_stages=1,
    )
    return {'output': o, 'final_state': ht}
