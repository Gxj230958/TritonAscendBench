"""Gated DeltaNet recurrent forward, Triton-Ascend implementation.

Entry point: npu_triton_impl(inputs: dict) -> dict with keys
  "output"      [B, T, H, Dv]  (input dtype)
  "final_state" [B, H, Dv, K]  (input dtype)

The carried state lives in on-chip storage as a float32 [BV, BK] tile per
program, and the token loop reproduces the specified update order exactly:

    S     = exp(g_t) * S                # decay the carried state first
    kS    = sum_k (S * k_t)             # contraction over the decayed state
    delta = (v_t - kS) * beta_t
    S     = S + delta (outer) k_t       # rank-1 update
    o_t   = scale * sum_k (S * q_t)     # read the updated state

Scope: dense, equal-length batches, per-head scalar beta and per-head scalar
gate, no in-kernel normalization, HV == H. The K axis is never split, because
both contractions reduce over K inside the serial recurrence; the V axis is
tiled across programs instead.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def fused_recurrent_gated_delta_rule_fwd_kernel(
    q_ptr, k_ptr, v_ptr, g_ptr, beta_ptr, o_ptr, h0_ptr, ht_ptr, scale_ptr,
    T,
    stride_qb, stride_qt, stride_qh,
    stride_kb, stride_kt, stride_kh,
    stride_vb, stride_vt, stride_vh,
    stride_gb, stride_gt,
    stride_bb, stride_bt,
    stride_ob, stride_ot, stride_oh,
    stride_h0b, stride_h0h,
    stride_htb, stride_hth,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
    USE_INITIAL_STATE: tl.constexpr,
):
    i_v = tl.program_id(0)
    i_bh = tl.program_id(1)
    i_n = i_bh // H
    i_h = i_bh % H

    o_v = i_v * BV + tl.arange(0, BV)
    o_k = tl.arange(0, BK)
    mask_v = o_v < V
    mask_k = o_k < K
    mask_h = mask_v[:, None] & mask_k[None, :]

    p_q = q_ptr + i_n * stride_qb + i_h * stride_qh + o_k
    p_k = k_ptr + i_n * stride_kb + i_h * stride_kh + o_k
    p_v = v_ptr + i_n * stride_vb + i_h * stride_vh + o_v
    p_g = g_ptr + i_n * stride_gb + i_h
    p_beta = beta_ptr + i_n * stride_bb + i_h
    p_o = o_ptr + i_n * stride_ob + i_h * stride_oh + o_v

    b_scale = tl.load(scale_ptr).to(tl.float32)

    # fp32 accumulator tile for the carried state, V-major addressing.
    b_h = tl.zeros([BV, BK], dtype=tl.float32)
    if USE_INITIAL_STATE:
        p_h0 = h0_ptr + i_n * stride_h0b + i_h * stride_h0h
        p_h0 = p_h0 + o_v[:, None] * K + o_k[None, :]
        b_h += tl.load(p_h0, mask=mask_h, other=0.0).to(tl.float32)

    for i_t in range(0, T):
        b_q = tl.load(p_q, mask=mask_k, other=0.0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0.0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0.0).to(tl.float32)
        b_g = tl.load(p_g).to(tl.float32)
        b_beta = tl.load(p_beta).to(tl.float32)

        # decay first, so both the read-out and the correction see exp(g) * S
        b_h = b_h * tl.exp(b_g)
        b_kS = tl.sum(b_h * b_k[None, :], 1)
        b_delta = (b_v - b_kS) * b_beta
        b_h = b_h + b_delta[:, None] * b_k[None, :]

        b_o = tl.sum(b_h * b_q[None, :], 1) * b_scale
        tl.store(p_o, b_o.to(p_o.dtype.element_ty), mask=mask_v)

        p_q += stride_qt
        p_k += stride_kt
        p_v += stride_vt
        p_g += stride_gt
        p_beta += stride_bt
        p_o += stride_ot

    # the recurrence ends on the sequence-level state; one store covers it
    p_ht = ht_ptr + i_n * stride_htb + i_h * stride_hth
    p_ht = p_ht + o_v[:, None] * K + o_k[None, :]
    tl.store(p_ht, b_h.to(p_ht.dtype.element_ty), mask=mask_h)


def _pick_blocks(K: int, V: int, n_bh: int):
    """Whole-K block (the recurrence reduces over K) x V tiles.

    Both axes are rounded up to a power-of-two block and carried by masks, so
    padded lanes multiply by zero and never reach a store. Blocks are floored
    at 16 lanes: a tiny head (D=1) still gets a well-formed vector block.

    Big tiles are cheaper per step: every V tile re-reads the full q/k/g/beta
    vectors of each token, so splitting V only pays off when the batch*head
    axis alone cannot fill the device. The float32 state tile is capped at
    4096 elements (16 KB), well inside the per-core on-chip budget.
    """
    BK = max(16, triton.next_power_of_2(K))
    BV = min(32, max(16, triton.next_power_of_2(V)))
    while BV > 16 and BK * BV > 4096:
        BV //= 2
    # raise the program count towards the device core count when starved
    while BV > 16 and BK * (BV // 2) >= 512 and -(-V // BV) * n_bh < 32:
        BV //= 2
    return BK, BV


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"].contiguous()
    k = inputs["k"].contiguous()
    v = inputs["v"].contiguous()
    g = inputs["g"].contiguous()
    beta = inputs["beta"].contiguous()
    initial_state = inputs["initial_state"].contiguous()

    B, T, H, K = q.shape
    Dv = v.shape[-1]
    HV = v.shape[2]
    if HV != H:
        raise ValueError("grouped value heads are not supported")
    if beta.shape != g.shape:
        raise ValueError("vector beta is not supported")

    # scale arrives as a python scalar or a device tensor; either way it is
    # resolved to a one-element float32 tensor and read inside the kernel.
    scale_t = torch.as_tensor(inputs["scale"], dtype=torch.float32)
    scale_t = scale_t.reshape(1).to(q.device)

    # the contract returns both tensors in the input element type
    o = torch.empty((B, T, HV, Dv), dtype=q.dtype, device=q.device)
    final_state = torch.empty((B, HV, Dv, K), dtype=q.dtype, device=q.device)

    BK, BV = _pick_blocks(K, Dv, B * HV)
    NV = triton.cdiv(Dv, BV)
    tile = BK * BV
    num_warps = 1 if tile <= 2048 else (2 if tile <= 8192 else 4)

    fused_recurrent_gated_delta_rule_fwd_kernel[(NV, B * HV)](
        q_ptr=q, k_ptr=k, v_ptr=v, g_ptr=g, beta_ptr=beta,
        o_ptr=o, h0_ptr=initial_state, ht_ptr=final_state,
        scale_ptr=scale_t,
        T=T,
        stride_qb=q.stride(0), stride_qt=q.stride(1), stride_qh=q.stride(2),
        stride_kb=k.stride(0), stride_kt=k.stride(1), stride_kh=k.stride(2),
        stride_vb=v.stride(0), stride_vt=v.stride(1), stride_vh=v.stride(2),
        stride_gb=g.stride(0), stride_gt=g.stride(1),
        stride_bb=beta.stride(0), stride_bt=beta.stride(1),
        stride_ob=o.stride(0), stride_ot=o.stride(1), stride_oh=o.stride(2),
        stride_h0b=initial_state.stride(0), stride_h0h=initial_state.stride(1),
        stride_htb=final_state.stride(0), stride_hth=final_state.stride(1),
        H=H, K=K, V=Dv, BK=BK, BV=BV,
        USE_INITIAL_STATE=True,
        num_warps=num_warps,
        num_stages=1,
    )

    return {"output": o, "final_state": final_state}
