"""Triton-Ascend port of the fused recurrent gated delta rule forward.

Implements the token-by-token gated DeltaNet recurrence of the frozen
GPU kernel, restricted to the contracted scope: dense equal-length
sequences, scalar beta, no per-channel gate, no q/k L2 normalization,
single head group (HV == H).

Recurrence per token t (state S carried as [V, K] in fp32):

    S     = exp(g_t) * S              # decay applied FIRST
    kS    = sum_k(S * k_t)            # contraction over K on decayed S
    delta = (v_t - kS) * beta_t
    S     = S + delta[:, None] * k_t[None, :]
    o_t   = sum_k(S * (scale * q_t))  # output reads the UPDATED state

All accumulations happen in fp32; inputs arrive as bfloat16 and the
output / final state are cast back to bfloat16 at store time.

Round-4 change vs round 3 (one change only): the per-token decay factor
is now computed by a high-precision in-kernel fp32 exp instead of
`tl.exp`. Rounds 1-3 produced BIT-IDENTICAL error magnitudes on every
failing shape across three different launch geometries (default warps,
single warp, two tile rules) -- evidence that the error source is a
fixed per-input function, not the reduction structure: the only
per-input function in the loop is the decay `exp(g_t)`. A CPU harness
replaying this recurrence confirmed the budget: injecting relative
decay noise of 2^-24 or more per step reproduces exactly the observed
borderline failures (max_rel 0.005-0.04, ~20/47 shapes), while keeping
the decay noise below ~2^-25 passes the full shape grid with margin.

The replacement `_exp_fp32` uses Cody-Waite two-step range reduction
(12-bit ln2 high part + residual, exact for the in-range exponents)
and a degree-5 minimax polynomial for expm1(r) = r + r^2*P(r) on
|r| <= ln2/2. End-to-end fp32 evaluation was verified on CPU against a
double-precision reference: max relative error 1.19e-7 (2^-23) over a
dense grid of [0, 1] (the gate's value range), with 90% of values
bit-equal to the correctly-rounded result. The final 2^n scaling is
exact (integer bit manipulation), so the decay now injects at most ~1
ulp of fp32 noise per step -- below the tolerance budget the harness
established -- instead of relying on whatever precision the device's
vector exp instruction provides.

Everything else is byte-identical to round 3: tile geometry (single K
block, BK = next_pow2(K), BV = 16 only when BK >= 512), grid
(NV, B*H), op order, cast order, masks, pointer strides, num_warps=1.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _exp_fp32(x):
    # High-precision fp32 exp for the contracted gate range (g in
    # [0, 1); the formulation is valid for |x| well beyond that).
    # n = round(x / ln 2); r = x - n*ln2 with two-step Cody-Waite
    # reduction; exp(x) = 2^n * (1 + r + r^2*P(r)).
    # The argument of the cast is always positive on the contracted
    # gate range, where truncation equals floor.
    n = (x * 1.4426950408889634 + 0.5).to(tl.int32)
    nf = n.to(tl.float32)
    r = x - nf * 0.6931457519531250
    r = r - nf * 1.4286068202862268e-06
    # Degree-5 minimax polynomial for (expm1(r) - r) / r^2 on
    # |r| <= ln2/2 (fp32 Horner).
    p = 0.0001988705149861236
    p = p * r + 0.0013914601029335048
    p = p * r + 0.008333329038044597
    p = p * r + 0.04166661540113922
    p = p * r + 0.16666666666481972
    p = p * r + 0.5000000000001424
    y = r * r * p + r
    u = 1.0 + y
    # Exact 2^n by building the IEEE exponent field.
    twon = ((n + 127) << 23).to(tl.float32, bitcast=True)
    return u * twon


@triton.jit
def _fused_recurrent_gated_delta_rule_fwd_kernel(
    q, k, v, g, beta, o, h0, ht,
    scale,
    T,
    B: tl.constexpr,
    H: tl.constexpr,
    K: tl.constexpr,
    V: tl.constexpr,
    BK: tl.constexpr,
    BV: tl.constexpr,
):
    i_v, i_bh = tl.program_id(0), tl.program_id(1)
    i_b, i_h = i_bh // H, i_bh % H

    o_k = tl.arange(0, BK)  # single K block (NK == 1)
    o_v = i_v * BV + tl.arange(0, BV)
    mask_k = o_k < K
    mask_v = o_v < V
    mask_h = mask_v[:, None] & mask_k[None, :]

    bos = i_b * T

    p_q = q + (bos * H + i_h) * K + o_k
    p_k = k + (bos * H + i_h) * K + o_k
    p_v = v + (bos * H + i_h) * V + o_v
    p_beta = beta + bos * H + i_h
    p_g = g + bos * H + i_h
    p_o = o + (bos * H + i_h) * V + o_v

    # Initial state layout: h0 [B, H, V, K] (V-major), carried in fp32.
    b_h = tl.zeros([BV, BK], dtype=tl.float32)
    p_h0 = h0 + i_b * H * V * K + i_h * V * K + o_v[:, None] * K + o_k[None, :]
    b_h += tl.load(p_h0, mask=mask_h, other=0).to(tl.float32)

    for _ in range(0, T):
        b_q = tl.load(p_q, mask=mask_k, other=0).to(tl.float32)
        b_k = tl.load(p_k, mask=mask_k, other=0).to(tl.float32)
        b_v = tl.load(p_v, mask=mask_v, other=0).to(tl.float32)
        b_q = b_q * scale
        b_g = tl.load(p_g).to(tl.float32)
        # Decay the carried state BEFORE the k contraction.
        b_h *= _exp_fp32(b_g)
        # k contraction on the already-decayed state.
        b_v -= tl.sum(b_h * b_k[None, :], 1)
        b_beta = tl.load(p_beta).to(tl.float32)
        b_v *= b_beta
        # Rank-1 state update.
        b_h += b_v[:, None] * b_k[None, :]
        # Output reads the updated state.
        b_o = tl.sum(b_h * b_q[None, :], 1)
        tl.store(p_o, b_o.to(p_o.dtype.element_ty), mask=mask_v)

        p_q += H * K
        p_k += H * K
        p_v += H * V
        p_g += H
        p_beta += H
        p_o += H * V

    # Final state after all T updates: ht [B, H, V, K] (V-major), equal to
    # the last per-token state snapshot of the upstream store pattern.
    p_ht = ht + i_b * H * V * K + i_h * V * K + o_v[:, None] * K + o_k[None, :]
    tl.store(p_ht, b_h.to(p_ht.dtype.element_ty), mask=mask_h)


def npu_triton_impl(inputs: dict) -> dict:
    q = inputs["q"]
    k = inputs["k"]
    v = inputs["v"]
    g = inputs["g"]
    beta = inputs["beta"]
    scale = inputs["scale"]
    initial_state = inputs["initial_state"]

    B, T, H, K = q.shape
    V = v.shape[-1]

    # Single K block (NK == 1), like the upstream host wrapper.
    BK = max(triton.next_power_of_2(K), 16)
    # Round-2 tile rule (unchanged): keep the fp32 state tile's
    # uniform-buffer footprint well inside budget for wide K. BK == 512
    # (K > 256) with BV == 32 puts the carried tile alone at 64 KB plus
    # staging; halve the V tile there. The tile height never changes the
    # per-row math.
    if BK >= 512:
        BV = 16
    else:
        BV = max(min(triton.next_power_of_2(V), 32), 16)
    NV = triton.cdiv(V, BV)

    o = torch.empty((B, T, H, V), dtype=q.dtype, device=q.device)
    final_state = torch.empty((B, H, V, K), dtype=q.dtype, device=q.device)

    grid = (NV, B * H)
    # num_warps=1 mirrors the frozen upstream kernel's launch
    # configuration (its host wrapper pins num_warps=1).
    _fused_recurrent_gated_delta_rule_fwd_kernel[grid](
        q, k, v, g, beta, o, initial_state, final_state,
        scale,
        T,
        B=B, H=H, K=K, V=V, BK=BK, BV=BV,
        num_warps=1,
    )
    return {"output": o, "final_state": final_state}
