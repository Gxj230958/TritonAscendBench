"""Triton-Ascend port of the Mamba2 inter-chunk state-passing recurrence.

Round 3: same fused-tile kernel as round 2, with the per-sequence chunk
loop unrolled by two. Each iteration advances the recurrence by two
chunks:

    mid = exp(dA_c)     * run + states_c       (stored at chunk c)
    run = exp(dA_{c+1}) * mid + states_{c+1}   (stored at chunk c+1)

These are exactly the round 2 per-step expressions in the same order,
so float32 rounding is bit-identical to the sequential loop; the only
effects are halved loop-control overhead and issuing both chunk loads
before the dependent compute. This targets the serial-loop-bound
shapes (H7: one sequence, 512 chunk iterations) and the two-iteration
shapes (P4, P6, P8, H3, ...). An odd trailing chunk is handled by one
scalar-guarded final step.

Entry point: npu_triton_impl(inputs: dict) -> dict, returning
{"output": out} with out shaped [nchunks, nheads, dim].

Semantics (matches contract.md):
  states:             [nchunks, nheads, dim], float32
  dA_cumsum:          [nheads, nchunks, chunk_size], float32. Only the
                      chunk-final value dA_cumsum[h, c, chunk_size-1]
                      is used as the inter-chunk decay exponent.
  last_chunk_indices: [batch], int64, inclusive end-chunk index per
                      sequence. Sequence b spans chunks
                      (last_chunk_indices[b-1]+1 .. last_chunk_indices[b]),
                      with the value before index 0 treated as -1.

Per head h, within each sequence's chunk span:
  S_c = exp(dA_cumsum[h, c, -1]) * S_{c-1} + states[c, h]
All loads are widened to float32 and the recurrence accumulates in
float32; the result is stored in the dtype of `states`.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _state_passing_fwd_kernel_npu(
    states_ptr,
    out_ptr,
    dA_cs_ptr,
    last_chunk_indices_ptr,
    # Dimensions
    nheads: tl.constexpr,
    dim: tl.constexpr,
    chunk_size: tl.constexpr,
    # Strides
    stride_states_chunk: tl.int64,
    stride_states_head: tl.int64,
    stride_states_dim: tl.constexpr,
    stride_out_chunk: tl.int64,
    stride_out_head: tl.int64,
    stride_out_dim: tl.constexpr,
    stride_dA_cs_head: tl.int64,
    stride_dA_cs_chunk: tl.int64,
    stride_dA_cs_csize: tl.constexpr,
    # Meta-parameters
    BLOCK_H: tl.constexpr,
    BLOCK_D: tl.constexpr,
):
    pid_d = tl.program_id(axis=0)
    pid_b = tl.program_id(axis=1)
    pid_h = tl.program_id(axis=2)

    # Derive this sequence's chunk range from last_chunk_indices.
    chunk_end = tl.load(last_chunk_indices_ptr + pid_b) + 1
    chunk_start = (
        tl.load(last_chunk_indices_ptr + pid_b - 1, mask=pid_b > 0, other=-1) + 1
    )

    # Offset pointers to this sequence's first chunk. The dA pointer is
    # positioned on the chunk-final element of the first chunk.
    states_ptr += chunk_start * stride_states_chunk
    dA_cs_ptr += (
        chunk_start * stride_dA_cs_chunk
        + (chunk_size - 1) * stride_dA_cs_csize
    )
    out_ptr += chunk_start * stride_out_chunk

    offs_h = pid_h * BLOCK_H + tl.arange(0, BLOCK_H)
    offs_d = pid_d * BLOCK_D + tl.arange(0, BLOCK_D)
    mask_h = offs_h < nheads
    mask_d = offs_d < dim
    tile_mask = mask_h[:, None] & mask_d[None, :]

    states_ptrs = (
        states_ptr
        + offs_h[:, None] * stride_states_head
        + offs_d[None, :] * stride_states_dim
    )
    out_ptrs = (
        out_ptr
        + offs_h[:, None] * stride_out_head
        + offs_d[None, :] * stride_out_dim
    )
    # Per-head chunk-final decay pointers (one scalar per fused head).
    dA_ptrs = dA_cs_ptr + offs_h * stride_dA_cs_head

    # Recurrence state for this sequence starts at zero.
    run = tl.zeros((BLOCK_H, BLOCK_D), dtype=tl.float32)

    # Two-step unroll over this sequence's chunks (dynamic count).
    nchunks_this_seq = chunk_end - chunk_start
    n_pairs = nchunks_this_seq // 2
    for _ in range(n_pairs):
        s0 = tl.load(states_ptrs, mask=tile_mask, other=0.0).to(tl.float32)
        d0 = tl.load(dA_ptrs, mask=mask_h, other=0.0).to(tl.float32)
        s1 = tl.load(
            states_ptrs + stride_states_chunk, mask=tile_mask, other=0.0
        ).to(tl.float32)
        d1 = tl.load(
            dA_ptrs + stride_dA_cs_chunk, mask=mask_h, other=0.0
        ).to(tl.float32)

        # Same per-step expressions (and order) as the sequential loop.
        mid = tl.exp(d0)[:, None] * run + s0
        run = tl.exp(d1)[:, None] * mid + s1
        tl.store(out_ptrs, mid, mask=tile_mask)
        tl.store(out_ptrs + stride_out_chunk, run, mask=tile_mask)

        states_ptrs += 2 * stride_states_chunk
        dA_ptrs += 2 * stride_dA_cs_chunk
        out_ptrs += 2 * stride_out_chunk

    # Odd remainder: one final single-chunk step.
    if nchunks_this_seq % 2 == 1:
        new_states = tl.load(states_ptrs, mask=tile_mask, other=0.0).to(tl.float32)
        dA_cs = tl.load(dA_ptrs, mask=mask_h, other=0.0).to(tl.float32)
        run = tl.exp(dA_cs)[:, None] * run + new_states
        tl.store(out_ptrs, run, mask=tile_mask)


def npu_triton_impl(inputs: dict) -> dict:
    states = inputs["states"]
    dA_cumsum = inputs["dA_cumsum"]
    last_chunk_indices = inputs["last_chunk_indices"]

    nchunks, nheads, dim = states.shape
    chunk_size = dA_cumsum.shape[-1]
    batch = last_chunk_indices.shape[0]

    out = torch.empty_like(states)

    BLOCK_D = max(16, min(triton.next_power_of_2(dim), 2048))

    # Head fusion is only worth it when the serial chunk loop is short:
    # then program-count overhead dominates and the wider tile amortizes.
    # With long loops (many chunks per sequence) keep one head per
    # program to preserve parallelism along the grid.
    avg_chunks = (nchunks + batch - 1) // batch
    if avg_chunks <= 4:
        BLOCK_H = min(triton.next_power_of_2(nheads), 8)
    else:
        BLOCK_H = 1

    grid = (
        triton.cdiv(dim, BLOCK_D),
        batch,
        triton.cdiv(nheads, BLOCK_H),
    )

    _state_passing_fwd_kernel_npu[grid](
        states_ptr=states,
        out_ptr=out,
        dA_cs_ptr=dA_cumsum,
        last_chunk_indices_ptr=last_chunk_indices,
        nheads=nheads,
        dim=dim,
        chunk_size=chunk_size,
        stride_states_chunk=states.stride(0),
        stride_states_head=states.stride(1),
        stride_states_dim=states.stride(2),
        stride_out_chunk=out.stride(0),
        stride_out_head=out.stride(1),
        stride_out_dim=out.stride(2),
        stride_dA_cs_head=dA_cumsum.stride(0),
        stride_dA_cs_chunk=dA_cumsum.stride(1),
        stride_dA_cs_csize=dA_cumsum.stride(2),
        BLOCK_H=BLOCK_H,
        BLOCK_D=BLOCK_D,
    )
    return {"output": out}
