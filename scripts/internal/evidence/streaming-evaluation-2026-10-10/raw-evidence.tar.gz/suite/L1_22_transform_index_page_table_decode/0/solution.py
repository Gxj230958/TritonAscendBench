"""Round 2 candidate — triton-ascend migration of the upstream GPU kernel
`transform_index_page_table_decode_kernel` (L1_22_transform_index_page_table_decode).

Semantics (page_size == 1 for every shape in this task):
    result[i, j] = page_table[i, t]      if t = topk_indices[i, j] >= 0
                 = -1                     if t < 0  (padding)
Output dtype: int32.

Round-1 change: the kernel body is numerically identical to the upstream
@triton.jit (one row of 2048 lanes, masked int64 gather, int32 store), but
the per-row work is split across NB programs per request row (2D grid
(B, NB)). Each program handles a contiguous 1024-lane slice, which

  * halves the int64 lanes (topk gather, page-table gather, int32 store)
    that each Ascend vector unit processes,
  * doubles the resident-program count for the large-B shapes so more AIC
    cores are kept busy (B is as high as 256; 2048 int64 lanes per program
    is near the per-program vector-register limit and was the bottleneck
    for H8 ~1.1 ms and P37 ~1.0 ms),
  * merges the two mask-complement stores into a single tl.where store.

The masked-lane pointer arithmetic in the gather stays
suppressed by the load mask (same structure as round 1 and the
upstream kernel body).
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _transform_index_page_table_decode_kernel(
    page_table_ptr,
    topk_indices_ptr,
    result_ptr,
    max_seqlen_k,
    NB: tl.constexpr,
):
    TOPK: tl.constexpr = 2048
    BLOCK: tl.constexpr = TOPK // NB
    req_id = tl.program_id(0)
    blk = tl.program_id(1)
    base = blk * BLOCK
    pt_row = page_table_ptr + req_id.to(tl.int64) * max_seqlen_k
    ti_row = topk_indices_ptr + req_id * TOPK + base
    out_row = result_ptr + req_id * TOPK + base

    lane = tl.arange(0, BLOCK)
    loaded_topk_indices = tl.load(ti_row + lane)
    mask = loaded_topk_indices >= 0
    # Gather one int64 page-table entry per selected token (masked lanes
    # are suppressed exactly as in the upstream kernel body).
    loaded_kv_indices = tl.load(pt_row + loaded_topk_indices, mask=mask)
    # Cast on the way out, mirroring the reference cast order.
    values = tl.where(mask, loaded_kv_indices.to(tl.int32), -1)
    tl.store(out_row + lane, values)


def npu_triton_impl(inputs: dict) -> dict:
    page_table = inputs["page_table"]          # [B, D], int64
    topk_indices = inputs["topk_indices"]      # [B, 2048], int64

    qo_len = topk_indices.shape[0]
    max_seqlen_k = page_table.shape[1]

    device = topk_indices.device
    result = torch.empty_like(topk_indices, dtype=torch.int32, device=device)

    grid = (qo_len, 2)
    _transform_index_page_table_decode_kernel[grid](
        page_table,
        topk_indices,
        result,
        max_seqlen_k,
        NB=2,
    )
    return {"result": result}
