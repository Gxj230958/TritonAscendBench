# triton-ascend migration of L1_29 fused GDN gating kernel (round 5).
#
# Reference semantics (from kernel.py):
#   A_log, dt_bias: [D]  (per-head, broadcast over batch)
#   a, b:           [B, D]  (bfloat16)
#   g          = -exp(A_log) * softplus(a + dt_bias)   (float32, shape [1, B, D])
#                softplus(x) = where(beta*x <= threshold, (1/beta)*log(1+exp(beta*x)), x)
#   beta_output = sigmoid(b)                            (dtype of b, shape [1, B, D])
#
# Kernel body is byte-identical to the round-1 candidate, which executed
# successfully on the NPU and passed 49/50 shapes (upstream-faithful 3-D
# grid (B, 1, cdiv(D, BLK)), BLK_HEADS=8, num_warps=1, float32 arithmetic,
# same cast order).  Round 1's only failure was H9 (B=256, D=2048):
# its total program count is exactly 65536 and the triton-ascend backend
# requires the total grid size to be STRICTLY less than 65536.
#
# Round 5 change vs round 1 (single, minimal, host-side only):
#   For every shape, total programs with BLK=8 are < 65536 EXCEPT H9,
#   so BLK stays 8 (identical launch to the proven round-1 geometry).
#   Only when B * cdiv(D, 8) >= 65536 (i.e. exactly H9) the head block
#   doubles to 16, giving 32768 programs.  Masked lanes
#   (head_off < NUM_HEADS) keep per-element arithmetic identical for
#   any block size, so H9's results are unchanged semantically.
#
# Rationale for NOT reusing the round-4 launcher: round 4 used a
# 1-D flattened grid with i_b = i_prog // blk_per_batch and
# i_d = i_prog % blk_per_batch, and it failed with ACL error 507035
# on ALL 50 shapes (including shapes that launched fine in round 1).
# Round 4's kernel body also dropped the upstream 'seq_len' parameter.
# The flattened-index kernel has never executed successfully on this
# backend, so this round returns to the exact round-1 kernel and
# 3-D grid and changes nothing except the H9 block size.

import torch
import triton
import triton.language as tl


@triton.jit
def fused_gdn_gating_kernel(
    g,
    beta_output,
    A_log,
    a,
    b,
    dt_bias,
    seq_len,
    NUM_HEADS: tl.constexpr,
    beta: tl.constexpr,
    threshold: tl.constexpr,
    BLK_HEADS: tl.constexpr,
):
    i_b, i_s, i_d = tl.program_id(0), tl.program_id(1), tl.program_id(2)
    head_off = i_d * BLK_HEADS + tl.arange(0, BLK_HEADS)
    off = i_b * seq_len * NUM_HEADS + i_s * NUM_HEADS + head_off
    mask = head_off < NUM_HEADS
    blk_A_log = tl.load(A_log + head_off, mask=mask)
    blk_a = tl.load(a + off, mask=mask)
    blk_b = tl.load(b + off, mask=mask)
    blk_bias = tl.load(dt_bias + head_off, mask=mask)
    # float32 accumulation (load-bearing cast order, mirrors upstream)
    x = blk_a.to(tl.float32) + blk_bias.to(tl.float32)
    bx = beta * x
    softplus_x = tl.where(
        bx <= threshold, (1 / beta) * tl.log(1 + tl.exp(bx)), x
    )
    blk_g = -tl.exp(blk_A_log.to(tl.float32)) * softplus_x
    tl.store(g + off, blk_g.to(g.dtype.element_ty), mask=mask)
    # beta_output = sigmoid(b), b cast to float32 first
    blk_beta_output = tl.sigmoid(blk_b.to(tl.float32))
    tl.store(
        beta_output + off, blk_beta_output.to(beta_output.dtype.element_ty), mask=mask
    )


# Backend limit: total program count must be strictly less than this.
_GRID_LIMIT = 65536


def _pick_block(num_heads: int, batch: int) -> int:
    """BLK_HEADS=8 (upstream) unless the 3-D grid
    (batch, 1, cdiv(num_heads, 8)) reaches _GRID_LIMIT, in which case
    double the head block once until it is strictly below the limit."""
    blk = 8
    while batch * triton.cdiv(num_heads, blk) >= _GRID_LIMIT:
        blk *= 2
    return blk


def npu_triton_impl(inputs: dict) -> dict:
    A_log = inputs["A_log"]
    a = inputs["a"]
    b = inputs["b"]
    dt_bias = inputs["dt_bias"]
    beta = inputs["beta"]
    threshold = inputs["threshold"]

    batch, num_heads = a.shape
    seq_len = 1
    BLK_HEADS = _pick_block(num_heads, batch)
    g = torch.empty(1, batch, num_heads, dtype=torch.float32, device=a.device)
    beta_output = torch.empty(1, batch, num_heads, dtype=b.dtype, device=b.device)
    grid = (batch, seq_len, triton.cdiv(num_heads, BLK_HEADS))
    fused_gdn_gating_kernel[grid](
        g,
        beta_output,
        A_log,
        a,
        b,
        dt_bias,
        seq_len,
        num_heads,
        beta,
        threshold,
        BLK_HEADS,
        num_warps=1,
    )
    return {"g": g, "beta_output": beta_output}
