"""Triton-Ascend implementation of the grouped MoE w4a16 expert GEMM.

Entry point: npu_triton_impl(inputs: dict) -> dict with key "output".

Per sorted-token block of ``block_size`` rows:
  1. take the block's expert ``e = expert_ids[pid_m]``
  2. gather the activation rows named by ``sorted_token_ids`` (top_k == 1, so
     the activation row index is the token id itself)
  3. unpack the 4-bit weights of expert ``e``:
       b      [E, N, K//2] int32 -- two nibbles along the contraction axis,
              even k -> low nibble, odd k -> high nibble (shift (k % 2) * 4)
       b_zp   [E, N//2, K//GS] int32 -- two nibbles along the output axis,
              column n -> nibble (n % 2) of row n // 2 (shift (n % 2) * 4)
       b_scale[E, N, K//GS] fp32, group index g = k // group_size
     giving w[n, k] = (q[n, k] - zp[n, g]) * scale[n, g]
  4. accumulate acc += dot(a_tile, w_tile) in fp32, the weight operand rounded
     to bf16 first, matching the 16-bit operand the cube unit consumes
  5. optionally scale each row by topk_weights[token]
  6. scatter-store to output row == token id; slots holding the padding
     sentinel (token id >= n_tokens) are masked out, so unrouted rows stay 0.

Ascend adaptations versus the accelerator original:
  * block_size is 4, below the 16-row minimum of the cube unit, so every
    program widens its M tile to BLOCK_M >= 16 and masks the extra lanes. The
    padding lanes read zero activations and never store, leaving the four real
    rows arithmetically untouched.
  * BLOCK_N is at least 16 as well; when N < 16 the column index wraps with
    ``% N`` (in range) and the extra lanes are dropped by the store mask.
  * index math stays 32-bit and every gathered row / expert / group index is
    clamped, so no lane forms an out-of-range address even when its whole tile
    is padding.
  * the fixture's scalars are consumed as metadata instead of host-side
    conversions: block_size = sorted_ids_len // expert_ids_len (the launcher
    asserts expert_ids has exactly one entry per block), and group_size =
    K // b_scale.shape[-1] (b_scale is [E, N, K // group_size]).
  * when a K tile is coarser than the group resolution the scale/zero-point
    tiles are loaded per (k, n); when one group covers the whole tile they are
    loaded as 1-D vectors.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _moe_w4a16_kernel(
    a_ptr,
    b_ptr,
    c_ptr,
    b_scale_ptr,
    b_zp_ptr,
    topk_weights_ptr,
    weight_flag_ptr,
    sorted_ids_ptr,
    expert_ids_ptr,
    N,
    K,
    num_slots,
    num_expert_blocks,
    num_valid_tokens,
    num_pid_n,
    stride_am,
    stride_ak,
    stride_be,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_bse,
    stride_bsk,
    stride_bsn,
    stride_bze,
    stride_bzk,
    stride_bzn,
    stride_twm,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_M: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_K: tl.constexpr,
    GROUP_SIZE: tl.constexpr,
    TOP_K: tl.constexpr,
    GROUP_UNIFORM: tl.constexpr,
    K_DIVISIBLE: tl.constexpr,
):
    pid = tl.program_id(0)
    pid_m = pid // num_pid_n
    pid_n = pid % num_pid_n

    # One program owns one sorted-token block (BLOCK_SIZE_M rows) crossed with
    # one tile of the output-feature axis.
    if pid_m >= num_expert_blocks:
        return

    expert = tl.load(expert_ids_ptr + pid_m).to(tl.int32)
    # The -1 entry marks a block with no expert; its rows stay at the zero the
    # output buffer was initialised with.
    if expert < 0:
        return

    row = tl.arange(0, BLOCK_M)
    real_row = row < BLOCK_SIZE_M
    # Lanes past BLOCK_SIZE_M repeat slot 0 of this block only to keep their
    # addresses in range; their mask bit is false so they compute nothing and
    # store nothing.
    slot = pid_m * BLOCK_SIZE_M + tl.where(real_row, row, 0)
    slot_ok = real_row & (slot < num_slots)
    token_id = tl.load(sorted_ids_ptr + slot, mask=slot_ok, other=0).to(tl.int32)
    token_ok = slot_ok & (token_id < num_valid_tokens)

    # Activation row (top_k == 1 -> row == token id); clamped so masked lanes
    # still address a valid row.
    tok_row = token_id // TOP_K
    tok_row = tl.where(token_ok, tok_row, 0)

    offs_bn = (pid_n * BLOCK_N + tl.arange(0, BLOCK_N)) % N
    offs_k = tl.arange(0, BLOCK_K)

    a_ptrs = a_ptr + (tok_row[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = (
        b_ptr
        + expert * stride_be
        + (offs_k[:, None] // 2) * stride_bk
        + offs_bn[None, :] * stride_bn
    )
    b_shifter = (offs_k[:, None] % 2) * 4

    # 1-D bases serve a whole K tile inside one group, 2-D bases serve the
    # per-element group index.
    scale_base_1 = b_scale_ptr + expert * stride_bse + offs_bn * stride_bsn
    zp_base_1 = b_zp_ptr + expert * stride_bze + (offs_bn // 2) * stride_bzn
    scale_base_2 = b_scale_ptr + expert * stride_bse + offs_bn[None, :] * stride_bsn
    zp_base_2 = b_zp_ptr + expert * stride_bze + (offs_bn[None, :] // 2) * stride_bzn
    zp_shifter_col = (offs_bn % 2) * 4
    zp_shifter_tile = (offs_bn[None, :] % 2) * 4

    acc = tl.zeros((BLOCK_M, BLOCK_N), dtype=tl.float32)
    n_ks = tl.cdiv(K, BLOCK_K)

    for k_iter in range(0, n_ks):
        k_start = k_iter * BLOCK_K
        k_global = k_start + offs_k

        if K_DIVISIBLE:
            a_tile = tl.load(a_ptrs + k_start * stride_ak, mask=token_ok[:, None], other=0.0)
            b_raw = tl.load(b_ptrs + (k_start // 2) * stride_bk)
        else:
            k_ok = k_global < K
            a_tile = tl.load(
                a_ptrs + k_start * stride_ak,
                mask=k_ok[None, :] & token_ok[:, None],
                other=0.0,
            )
            b_raw = tl.load(b_ptrs + (k_start // 2) * stride_bk, mask=k_ok[:, None], other=0)

        q = (b_raw >> b_shifter) & 15

        if GROUP_UNIFORM:
            group = k_start // GROUP_SIZE
            scale = tl.load(scale_base_1 + group * stride_bsk).to(tl.float32)
            zp_raw = tl.load(zp_base_1 + group * stride_bzk)
            zp = ((zp_raw >> zp_shifter_col) & 15).to(tl.float32)
            w = (q.to(tl.float32) - zp[None, :]) * scale[None, :]
        else:
            group = k_global // GROUP_SIZE
            if K_DIVISIBLE:
                scale = tl.load(scale_base_2 + group[:, None] * stride_bsk).to(tl.float32)
                zp_raw = tl.load(zp_base_2 + group[:, None] * stride_bzk)
            else:
                g_ok = (k_global < K)[:, None]
                scale = tl.load(
                    scale_base_2 + group[:, None] * stride_bsk,
                    mask=g_ok,
                    other=0.0,
                ).to(tl.float32)
                zp_raw = tl.load(
                    zp_base_2 + group[:, None] * stride_bzk,
                    mask=g_ok,
                    other=0,
                )
            zp = ((zp_raw >> zp_shifter_tile) & 15).to(tl.float32)
            w = (q.to(tl.float32) - zp) * scale

        # Both dot operands are 16-bit; the activation is already that width,
        # the cast is a no-op kept for shape robustness.
        acc = tl.dot(a_tile.to(tl.bfloat16), w.to(tl.bfloat16), acc=acc)

    # Routing weight: the 0/1 flag blends the gathered weight towards exactly
    # 1.0, so a disabled flag leaves the accumulator bit-identical.
    flag = tl.load(weight_flag_ptr)
    moe_weight = tl.load(topk_weights_ptr + tok_row * stride_twm, mask=token_ok, other=0.0)
    moe_weight = moe_weight * flag + (1.0 - flag)
    acc = acc * moe_weight[:, None]

    offs_cn = pid_n * BLOCK_N + tl.arange(0, BLOCK_N)
    c_ptrs = c_ptr + stride_cm * tok_row[:, None] + stride_cn * offs_cn[None, :]
    c_mask = token_ok[:, None] & (offs_cn[None, :] < N)
    tl.store(c_ptrs, acc, mask=c_mask)


def _largest_tile(value: int, candidates) -> int:
    for tile in candidates:
        if value % tile == 0:
            return tile
    return candidates[-1]


def _rows_per_block(num_slots: int, num_blocks: int) -> int:
    if num_blocks > 0 and num_slots % num_blocks == 0:
        rows = num_slots // num_blocks
        if rows > 0:
            return rows
    return 4


def _pad_pow2(value: int, minimum: int) -> int:
    out = minimum
    while out < value:
        out *= 2
    return out


def npu_triton_impl(inputs: dict) -> dict:
    a = inputs["a"].contiguous()
    b = inputs["b"].contiguous()
    b_scale = inputs["b_scale"].contiguous()
    b_zp = inputs["b_zp"].contiguous()
    topk_weights = inputs["topk_weights"].contiguous()
    sorted_token_ids = inputs["sorted_token_ids"].to(torch.int64).reshape(-1)
    expert_ids = inputs["expert_ids"].to(torch.int64).reshape(-1)
    weight_flag = torch.as_tensor(inputs["apply_weight"], dtype=torch.float32, device=a.device).reshape(1)

    n_tokens, K = a.shape
    E, N, _ = b.shape
    num_slots = sorted_token_ids.shape[0]
    num_expert_blocks = expert_ids.shape[0]
    num_valid_tokens = n_tokens  # top_k == 1

    block_size = _rows_per_block(num_slots, num_expert_blocks)
    groups_per_expert = b_scale.shape[2]
    group_size = max(1, K // groups_per_expert)

    BLOCK_N = _largest_tile(N, (64, 32, 16))
    BLOCK_K = _largest_tile(K, (64, 32, 16))
    BLOCK_M = _pad_pow2(block_size, 16)
    GROUP_UNIFORM = group_size % BLOCK_K == 0
    K_DIVISIBLE = K % BLOCK_K == 0

    c = torch.zeros((n_tokens, N), device=a.device, dtype=torch.float32)

    num_pid_m = -(-num_slots // block_size)
    num_pid_n = -(-N // BLOCK_N)
    grid = (num_pid_m * num_pid_n,)

    _moe_w4a16_kernel[grid](
        a,
        b,
        c,
        b_scale,
        b_zp,
        topk_weights,
        weight_flag,
        sorted_token_ids,
        expert_ids,
        N,
        K,
        num_slots,
        min(num_pid_m, num_expert_blocks),
        num_valid_tokens,
        num_pid_n,
        a.stride(0),
        a.stride(1),
        b.stride(0),
        b.stride(2),
        b.stride(1),
        c.stride(0),
        c.stride(1),
        b_scale.stride(0),
        b_scale.stride(2),
        b_scale.stride(1),
        b_zp.stride(0),
        b_zp.stride(2),
        b_zp.stride(1),
        topk_weights.stride(0),
        BLOCK_SIZE_M=block_size,
        BLOCK_M=BLOCK_M,
        BLOCK_N=BLOCK_N,
        BLOCK_K=BLOCK_K,
        GROUP_SIZE=group_size,
        TOP_K=1,
        GROUP_UNIFORM=GROUP_UNIFORM,
        K_DIVISIBLE=K_DIVISIBLE,
        num_warps=4,
        num_stages=2,
    )

    return {"output": c}
