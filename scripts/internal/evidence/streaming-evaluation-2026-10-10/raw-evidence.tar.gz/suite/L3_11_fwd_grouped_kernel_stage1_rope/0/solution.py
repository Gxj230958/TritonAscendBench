"""Triton-Ascend port of the MLA decode stage1 grouped kernel with fused RoPE.

Per (batch b, query head h) the kernel computes grouped attention over the
batch's paged KV range (single KV split spans the whole sequence) and writes

    att_out[b, h, 0, :C] = sum_n softmax(score)[n] * v_latent[n]   # context
    att_out[b, h, 0,  C] = max_n score[n] + log(sum_n exp(...))    # log-sum-exp

with, for kv token n in the batch's page,

    score[n] = sm_scale * (q_pe_roped . k_pe[n] + q_nope . kv_latent[n])

Q = [q_nope(C) ; q_pe(R)], K_Buffer row = [kv_latent(C) ; k_pe(R)], and the
V buffer is the aliased latent slice K_Buffer[:, 0, :C]. RoPE (neox style)
rotates q_pe by positions[b]; the cached k_pe is already roped for every
token EXCEPT the last one in the page, which this kernel ropes on the fly
with the same (cos, sin).

Mixed precision follows the upstream kernel exactly: the cos/sin table is
bf16, so the rope multiplies stay bf16 (result rounded to bf16), every
tl.dot is bf16 x bf16 with fp32 accumulation, the softmax probabilities are
rounded to bf16 for the context dot while e_sum stays fp32.

Round-5 structure (latency pass on top of the round-4 candidate, which
passed all 33 graded shapes; round-4 code is kept verbatim for every shape
it already serves well):

- kv_lora_rank a power of two, <= 256: the byte-identical round-4 fused
  single-tile kernel (one latent tile of next_pow2(C) columns, BLOCK_N=32).

- kv_lora_rank = 512: the byte-identical round-4 wide kernel (one program,
  four 128-column chunks, BLOCK_N=16; the structure that finally built for
  the three C=512 shapes that failed rounds 1-3).

- kv_lora_rank even but not a power of two (C = 192 and C = 96 in this
  manifest, 20 of the 33 graded shapes): a NEW two-chunk kernel that is the
  round-4 wide structure with two chunks instead of four. The latent is cut
  into [BLOCK_C ; BLOCK_C1] = [128 ; 64] for C = 192 and [64 ; 32] for
  C = 96. Both chunks are exact power-of-two widths that tile the rank with
  zero padding, whereas the round-4 fused tile pads C = 192 up to 256
  columns (33% dead lanes) and C = 96 up to 128 (25% dead lanes). The
  widest tile in either configuration is 128 columns -- exactly the tile
  width the proven round-4 wide kernel already builds with for C = 512, so
  the footprint is no larger than a known-good program (the C=192
  configuration is smaller: one 128-wide and one 64-wide accumulator
  instead of four 128-wide).

Measured round-4 device latency scales almost exactly linearly in the
per-tile latent width -- P16 (C=64): 1.411 ms, P17 (C=96 padded to 128):
2.137 ms, P18 (C=128): 2.124 ms, P6 (C=192 padded to 256): 2.091 ms --
about 11.2 us per padded column across all batch units, so the padded
columns are what those shapes pay for. Expected savings at the same
correctness: C=192 shapes (20 of 33, including H6 = B64) drop from a
256-wide tile to 192 live columns (~25% of per-batch-unit kernel time),
P17 from 128 to 96 live columns.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def tanh(x):
    # Tanh via the exp-stable form: 2/(1 + exp(-2x)) - 1
    return 2.0 / (1.0 + tl.exp(-2.0 * x)) - 1.0


@triton.jit
def _fwd_grouped_kernel_stage1_rope_wide(
    Q,  # Holds [Q_NOPE; Q_PE], b x h x (c+r)
    K_Buffer,  # Holds [KV; K_PE], b*s x (c+r)
    V_buffer,  # Holds [KV], b*s x c
    cos_sin_cache,  # max_seq_len x rotary_dim
    positions,  # sequence positions
    sm_scale,
    kv_indptr,
    kv_indices,
    Att_Out,  # b x h x NUM_KV_SPLITS x (kv_lora_rank + 1)
    k_pe_t_out,
    stride_qb,
    stride_qh,
    stride_buf_kbs,
    stride_buf_vbs,
    stride_mid_ob,
    stride_mid_oh,
    stride_mid_os,
    stride_kpe_tokens_out_b,
    stride_cos_sin_cache_s,
    stride_positions_b,
    kv_lora_rank,
    rotary_dim,
    qk_rope_head_dim: tl.constexpr,
    kv_group_num: tl.constexpr,
    q_head_num: tl.constexpr,
    BLOCK_C: tl.constexpr,
    BLOCK_R: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_H: tl.constexpr,
    NUM_KV_SPLITS: tl.constexpr,
    LOGIT_CAP: tl.constexpr,
    USE_ROPE: tl.constexpr,
    IS_NEOX_STYLE: tl.constexpr,
):
    """Single-program kernel for the wide latent (kv_lora_rank = 512).

    The latent is cut into four BLOCK_C=128 column chunks and BLOCK_N=16, so
    every tl.dot operand and every fp32 accumulator is at most 128 columns /
    16 rows wide. Score partials of the four chunks are summed in fp32 into
    the same qk tile before the (single-tile) online softmax, which is the
    exact algebraic split of one wide dot along its reduction axis. Same
    online softmax, same bf16 p rounding, same LSE as the fused kernel.
    """
    cur_batch = tl.program_id(0)
    cur_head_id = tl.program_id(1)
    split_kv_id = tl.program_id(2)

    if BLOCK_H < kv_group_num:
        VALID_BLOCK_H: tl.constexpr = BLOCK_H
    else:
        VALID_BLOCK_H: tl.constexpr = kv_group_num
    cur_head = cur_head_id * VALID_BLOCK_H + tl.arange(0, BLOCK_H)
    mask_h = cur_head < (cur_head_id + 1) * VALID_BLOCK_H
    mask_h = mask_h & (cur_head < q_head_num)

    offs_qk_r = kv_lora_rank + tl.arange(0, BLOCK_R)  # to get the k_pe

    off_q_pe = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_qk_r[None, :]
    )

    mask_qk_r = offs_qk_r < (kv_lora_rank + qk_rope_head_dim)

    cur_batch_kv_start_idx = tl.load(kv_indptr + cur_batch)
    cur_batch_seq_len = tl.load(kv_indptr + cur_batch + 1) - cur_batch_kv_start_idx

    q_pe = tl.load(
        Q + off_q_pe, mask=(mask_h[:, None]) & (mask_qk_r[None, :]), other=0.0
    )

    kv_len_per_split = tl.cdiv(cur_batch_seq_len, NUM_KV_SPLITS)
    split_kv_start = kv_len_per_split * split_kv_id
    split_kv_end = tl.minimum(split_kv_start + kv_len_per_split, cur_batch_seq_len)

    # With NUM_KV_SPLITS == 1 the single split always ends at the sequence end,
    # so the on-the-fly rope of the page's last token always applies here.
    k_pe_last_token = tl.zeros([BLOCK_R], dtype=q_pe.dtype)

    if USE_ROPE:
        if IS_NEOX_STYLE:
            # neox-style index setup:
            # [r/2, r/2+1, ..., r-1, 0, 1, ..., r/2-1]
            offs_qk_rot_r = kv_lora_rank + (
                (tl.arange(0, BLOCK_R) + (rotary_dim // 2)) % rotary_dim
            )
            # Which elements to flip
            mask_rotate = tl.arange(0, BLOCK_R) < (rotary_dim // 2)
            # [0, 1, ..., r/2-1, 0, 1, ..., r/2-1]
            offs_rotary = tl.arange(0, BLOCK_R) % (rotary_dim // 2)
        else:
            # interleaved style: [1, 0, 3, 2, 5, 4, ...]
            offs_qk_rot_r = (
                kv_lora_rank
                + (((tl.arange(0, BLOCK_R) + 1) % 2) * 2)
                - 1
                + tl.arange(0, BLOCK_R)
            )
            mask_rotate = tl.arange(0, BLOCK_R) % 2 < 1
            # [0, 0, 1, 1, ..., r/2-1, r/2-1]
            offs_rotary = tl.arange(0, BLOCK_R) // 2

        if qk_rope_head_dim > rotary_dim:
            offs_qk_rot_r = tl.where(
                tl.arange(0, BLOCK_R) < rotary_dim, offs_qk_rot_r, tl.arange(0, BLOCK_R)
            )
            offs_rotary = tl.where(
                tl.arange(0, BLOCK_R) < rotary_dim, offs_rotary, tl.arange(0, BLOCK_R)
            )

        mask_rotary = tl.arange(0, BLOCK_R) < rotary_dim

        pos = tl.load(positions + cur_batch * stride_positions_b)
        cos = tl.load(
            cos_sin_cache + pos * stride_cos_sin_cache_s + offs_rotary,
            mask=mask_rotary,
            other=1.0,
        )
        sin = tl.load(
            cos_sin_cache
            + pos * stride_cos_sin_cache_s
            + offs_rotary
            + rotary_dim // 2,
            mask_rotary,
            other=0.0,
        )

        off_q_pe_rot = (
            cur_batch * stride_qb
            + cur_head[:, None] * stride_qh
            + offs_qk_rot_r[None, :]
        )
        mask_qk_rot_r = offs_qk_rot_r < (kv_lora_rank + qk_rope_head_dim)

        q_pe_rot = tl.load(
            Q + off_q_pe_rot,
            mask=(mask_h[:, None]) & (mask_qk_rot_r[None, :]),
            other=0.0,
        )
        q_pe_rot = tl.where(mask_rotate[None, :], -q_pe_rot, q_pe_rot)

        # bf16 * bf16 -> bf16: rope result stays in the storage dtype
        q_pe = q_pe * cos + q_pe_rot * sin

        # Rope only the last token of the page on the fly; all earlier tokens
        # are already roped in the cache.
        kv_loc_last = tl.load(
            kv_indices + cur_batch_kv_start_idx + cur_batch_seq_len - 1
        )
        offs_buf_k_pe_last_token = kv_loc_last * stride_buf_kbs + offs_qk_r
        offs_buf_k_pe_rot_last_token = kv_loc_last * stride_buf_kbs + offs_qk_rot_r
        k_pe_last_token = tl.load(K_Buffer + offs_buf_k_pe_last_token)

        k_pe_rot_last_token = tl.load(K_Buffer + offs_buf_k_pe_rot_last_token)
        k_pe_rot_last_token = tl.where(
            mask_rotate, -k_pe_rot_last_token, k_pe_rot_last_token
        )

        k_pe_last_token = k_pe_last_token * cos + k_pe_rot_last_token * sin

    e_max = tl.zeros([BLOCK_H], dtype=tl.float32) - float("inf")
    e_sum = tl.zeros([BLOCK_H], dtype=tl.float32)

    # Four 128-column latent chunks. Their score partials sum (in fp32, before
    # scaling and softmax) to the full nope dot; each keeps its own fp32
    # context accumulator, rescaled together per tile.
    offs_c0 = tl.arange(0, BLOCK_C)
    mask_c0 = offs_c0 < kv_lora_rank
    offs_c1 = BLOCK_C + tl.arange(0, BLOCK_C)
    mask_c1 = offs_c1 < kv_lora_rank
    offs_c2 = 2 * BLOCK_C + tl.arange(0, BLOCK_C)
    mask_c2 = offs_c2 < kv_lora_rank
    offs_c3 = 3 * BLOCK_C + tl.arange(0, BLOCK_C)
    mask_c3 = offs_c3 < kv_lora_rank

    offs_q0 = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c0[None, :]
    )
    q0 = tl.load(Q + offs_q0, mask=(mask_h[:, None]) & (mask_c0[None, :]), other=0.0)
    offs_q1 = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c1[None, :]
    )
    q1 = tl.load(Q + offs_q1, mask=(mask_h[:, None]) & (mask_c1[None, :]), other=0.0)
    offs_q2 = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c2[None, :]
    )
    q2 = tl.load(Q + offs_q2, mask=(mask_h[:, None]) & (mask_c2[None, :]), other=0.0)
    offs_q3 = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c3[None, :]
    )
    q3 = tl.load(Q + offs_q3, mask=(mask_h[:, None]) & (mask_c3[None, :]), other=0.0)

    acc0 = tl.zeros([BLOCK_H, BLOCK_C], dtype=tl.float32)
    acc1 = tl.zeros([BLOCK_H, BLOCK_C], dtype=tl.float32)
    acc2 = tl.zeros([BLOCK_H, BLOCK_C], dtype=tl.float32)
    acc3 = tl.zeros([BLOCK_H, BLOCK_C], dtype=tl.float32)

    if split_kv_end > split_kv_start:
        for start_n in range(split_kv_start, split_kv_end, BLOCK_N):
            offs_n = start_n + tl.arange(0, BLOCK_N)
            kv_loc = tl.load(
                kv_indices + cur_batch_kv_start_idx + offs_n,
                mask=offs_n < split_kv_end,
                other=0,
            )

            offs_buf_k_pe = kv_loc[None, :] * stride_buf_kbs + offs_qk_r[:, None]

            k_pe = tl.load(
                K_Buffer + offs_buf_k_pe,
                mask=(offs_n[None, :] < split_kv_end) & (mask_qk_r[:, None]),
                other=0.0,
            )  # positional embedding part of keys

            # Swap in the freshly roped last token. The selector only
            # matches in the tile that actually contains the final token,
            # so this is safe to run on every tile.
            if USE_ROPE:
                k_pe = tl.where(
                    offs_n[None, :] != (split_kv_end - 1),
                    k_pe,
                    k_pe_last_token[:, None],
                )

            # dot product of rope parts
            qk = tl.dot(q_pe, k_pe.to(q_pe.dtype))

            # nope dot split along the reduction axis into four 128-wide
            # partials, summed in fp32 into the same score tile
            offs_buf_kv0 = kv_loc[None, :] * stride_buf_kbs + offs_c0[:, None]
            kv0 = tl.load(
                K_Buffer + offs_buf_kv0,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c0[:, None]),
                other=0.0,
            )
            qk += tl.dot(q0, kv0)

            offs_buf_kv1 = kv_loc[None, :] * stride_buf_kbs + offs_c1[:, None]
            kv1 = tl.load(
                K_Buffer + offs_buf_kv1,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c1[:, None]),
                other=0.0,
            )
            qk += tl.dot(q1, kv1)

            offs_buf_kv2 = kv_loc[None, :] * stride_buf_kbs + offs_c2[:, None]
            kv2 = tl.load(
                K_Buffer + offs_buf_kv2,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c2[:, None]),
                other=0.0,
            )
            qk += tl.dot(q2, kv2)

            offs_buf_kv3 = kv_loc[None, :] * stride_buf_kbs + offs_c3[:, None]
            kv3 = tl.load(
                K_Buffer + offs_buf_kv3,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c3[:, None]),
                other=0.0,
            )
            qk += tl.dot(q3, kv3)

            qk *= sm_scale

            if LOGIT_CAP > 0:
                qk = LOGIT_CAP * tanh(qk / LOGIT_CAP)

            qk = tl.where(
                mask_h[:, None] & (offs_n[None, :] < split_kv_end),
                qk,
                float("-inf"),
            )

            n_e_max = tl.maximum(tl.max(qk, 1), e_max)
            re_scale = tl.exp(e_max - n_e_max)
            p = tl.exp(qk - n_e_max[:, None])

            acc0 *= re_scale[:, None]
            acc1 *= re_scale[:, None]
            acc2 *= re_scale[:, None]
            acc3 *= re_scale[:, None]

            # probabilities round to the storage dtype for the context dots
            p_b = p.to(q_pe.dtype)

            offs_buf_v0 = kv_loc[:, None] * stride_buf_vbs + offs_c0[None, :]
            v0 = tl.load(
                V_buffer + offs_buf_v0,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c0[None, :]),
                other=0.0,
            )
            acc0 += tl.dot(p_b.to(v0.dtype), v0)

            offs_buf_v1 = kv_loc[:, None] * stride_buf_vbs + offs_c1[None, :]
            v1 = tl.load(
                V_buffer + offs_buf_v1,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c1[None, :]),
                other=0.0,
            )
            acc1 += tl.dot(p_b.to(v1.dtype), v1)

            offs_buf_v2 = kv_loc[:, None] * stride_buf_vbs + offs_c2[None, :]
            v2 = tl.load(
                V_buffer + offs_buf_v2,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c2[None, :]),
                other=0.0,
            )
            acc2 += tl.dot(p_b.to(v2.dtype), v2)

            offs_buf_v3 = kv_loc[:, None] * stride_buf_vbs + offs_c3[None, :]
            v3 = tl.load(
                V_buffer + offs_buf_v3,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c3[None, :]),
                other=0.0,
            )
            acc3 += tl.dot(p_b.to(v3.dtype), v3)

            e_sum = e_sum * re_scale + tl.sum(p, 1)
            e_max = n_e_max

        if USE_ROPE:
            k_pe_last_token_ptrs = (
                k_pe_t_out
                + cur_batch * stride_kpe_tokens_out_b
                + tl.arange(0, BLOCK_R)
            )
            tl.store(k_pe_last_token_ptrs, k_pe_last_token, mask=mask_qk_r)

        offs_mid_o0 = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c0[None, :]
        )
        tl.store(
            Att_Out + offs_mid_o0,
            acc0 / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c0[None, :]),
        )

        offs_mid_o1 = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c1[None, :]
        )
        tl.store(
            Att_Out + offs_mid_o1,
            acc1 / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c1[None, :]),
        )

        offs_mid_o2 = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c2[None, :]
        )
        tl.store(
            Att_Out + offs_mid_o2,
            acc2 / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c2[None, :]),
        )

        offs_mid_o3 = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c3[None, :]
        )
        tl.store(
            Att_Out + offs_mid_o3,
            acc3 / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c3[None, :]),
        )

        offs_mid_o_1 = (
            cur_batch * stride_mid_ob
            + cur_head * stride_mid_oh
            + split_kv_id * stride_mid_os
            + kv_lora_rank
        )

        tl.store(
            Att_Out + offs_mid_o_1,
            e_max + tl.log(e_sum),
            mask=mask_h,
        )
@triton.jit
def _fwd_grouped_kernel_stage1_rope(
    Q,  # Holds [Q_NOPE; Q_PE], b x h x (c+r)
    K_Buffer,  # Holds [KV; K_PE], b*s x (c+r)
    V_buffer,  # Holds [KV], b*s x c
    cos_sin_cache,  # max_seq_len x rotary_dim
    positions,  # sequence positions
    sm_scale,
    kv_indptr,
    kv_indices,
    Att_Out,  # b x h x NUM_KV_SPLITS x (kv_lora_rank + 1)
    k_pe_t_out,
    stride_qb,
    stride_qh,
    stride_buf_kbs,
    stride_buf_vbs,
    stride_mid_ob,
    stride_mid_oh,
    stride_mid_os,
    stride_kpe_tokens_out_b,
    stride_cos_sin_cache_s,
    stride_positions_b,
    kv_lora_rank,
    rotary_dim,
    qk_rope_head_dim: tl.constexpr,
    kv_group_num: tl.constexpr,
    q_head_num: tl.constexpr,
    BLOCK_C: tl.constexpr,
    BLOCK_R: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_H: tl.constexpr,
    NUM_KV_SPLITS: tl.constexpr,
    LOGIT_CAP: tl.constexpr,
    USE_ROPE: tl.constexpr,
    IS_NEOX_STYLE: tl.constexpr,
):
    """Fused single-latent-tile kernel (kv_lora_rank <= 256)."""
    cur_batch = tl.program_id(0)
    cur_head_id = tl.program_id(1)
    split_kv_id = tl.program_id(2)

    if BLOCK_H < kv_group_num:
        VALID_BLOCK_H: tl.constexpr = BLOCK_H
    else:
        VALID_BLOCK_H: tl.constexpr = kv_group_num
    cur_head = cur_head_id * VALID_BLOCK_H + tl.arange(0, BLOCK_H)
    mask_h = cur_head < (cur_head_id + 1) * VALID_BLOCK_H
    mask_h = mask_h & (cur_head < q_head_num)

    offs_qk_r = kv_lora_rank + tl.arange(0, BLOCK_R)  # to get the k_pe

    off_q_pe = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_qk_r[None, :]
    )

    mask_qk_r = offs_qk_r < (kv_lora_rank + qk_rope_head_dim)

    cur_batch_kv_start_idx = tl.load(kv_indptr + cur_batch)
    cur_batch_seq_len = tl.load(kv_indptr + cur_batch + 1) - cur_batch_kv_start_idx

    q_pe = tl.load(
        Q + off_q_pe, mask=(mask_h[:, None]) & (mask_qk_r[None, :]), other=0.0
    )

    kv_len_per_split = tl.cdiv(cur_batch_seq_len, NUM_KV_SPLITS)
    split_kv_start = kv_len_per_split * split_kv_id
    split_kv_end = tl.minimum(split_kv_start + kv_len_per_split, cur_batch_seq_len)

    # With NUM_KV_SPLITS == 1 the single split always ends at the sequence end,
    # so the on-the-fly rope of the page's last token always applies here.
    k_pe_last_token = tl.zeros([BLOCK_R], dtype=q_pe.dtype)

    if USE_ROPE:
        if IS_NEOX_STYLE:
            # neox-style index setup:
            # [r/2, r/2+1, ..., r-1, 0, 1, ..., r/2-1]
            offs_qk_rot_r = kv_lora_rank + (
                (tl.arange(0, BLOCK_R) + (rotary_dim // 2)) % rotary_dim
            )
            # Which elements to flip
            mask_rotate = tl.arange(0, BLOCK_R) < (rotary_dim // 2)
            # [0, 1, ..., r/2-1, 0, 1, ..., r/2-1]
            offs_rotary = tl.arange(0, BLOCK_R) % (rotary_dim // 2)
        else:
            # interleaved style: [1, 0, 3, 2, 5, 4, ...]
            offs_qk_rot_r = (
                kv_lora_rank
                + (((tl.arange(0, BLOCK_R) + 1) % 2) * 2)
                - 1
                + tl.arange(0, BLOCK_R)
            )
            mask_rotate = tl.arange(0, BLOCK_R) % 2 < 1
            # [0, 0, 1, 1, ..., r/2-1, r/2-1]
            offs_rotary = tl.arange(0, BLOCK_R) // 2

        if qk_rope_head_dim > rotary_dim:
            offs_qk_rot_r = tl.where(
                tl.arange(0, BLOCK_R) < rotary_dim, offs_qk_rot_r, tl.arange(0, BLOCK_R)
            )
            offs_rotary = tl.where(
                tl.arange(0, BLOCK_R) < rotary_dim, offs_rotary, tl.arange(0, BLOCK_R)
            )

        mask_rotary = tl.arange(0, BLOCK_R) < rotary_dim

        pos = tl.load(positions + cur_batch * stride_positions_b)
        cos = tl.load(
            cos_sin_cache + pos * stride_cos_sin_cache_s + offs_rotary,
            mask=mask_rotary,
            other=1.0,
        )
        sin = tl.load(
            cos_sin_cache
            + pos * stride_cos_sin_cache_s
            + offs_rotary
            + rotary_dim // 2,
            mask_rotary,
            other=0.0,
        )

        off_q_pe_rot = (
            cur_batch * stride_qb
            + cur_head[:, None] * stride_qh
            + offs_qk_rot_r[None, :]
        )
        mask_qk_rot_r = offs_qk_rot_r < (kv_lora_rank + qk_rope_head_dim)

        q_pe_rot = tl.load(
            Q + off_q_pe_rot,
            mask=(mask_h[:, None]) & (mask_qk_rot_r[None, :]),
            other=0.0,
        )
        q_pe_rot = tl.where(mask_rotate[None, :], -q_pe_rot, q_pe_rot)

        # bf16 * bf16 -> bf16: rope result stays in the storage dtype
        q_pe = q_pe * cos + q_pe_rot * sin

        # Rope only the last token of the page on the fly; all earlier tokens
        # are already roped in the cache.
        kv_loc_last = tl.load(
            kv_indices + cur_batch_kv_start_idx + cur_batch_seq_len - 1
        )
        offs_buf_k_pe_last_token = kv_loc_last * stride_buf_kbs + offs_qk_r
        offs_buf_k_pe_rot_last_token = kv_loc_last * stride_buf_kbs + offs_qk_rot_r
        k_pe_last_token = tl.load(K_Buffer + offs_buf_k_pe_last_token)

        k_pe_rot_last_token = tl.load(K_Buffer + offs_buf_k_pe_rot_last_token)
        k_pe_rot_last_token = tl.where(
            mask_rotate, -k_pe_rot_last_token, k_pe_rot_last_token
        )

        k_pe_last_token = k_pe_last_token * cos + k_pe_rot_last_token * sin

    e_max = tl.zeros([BLOCK_H], dtype=tl.float32) - float("inf")
    e_sum = tl.zeros([BLOCK_H], dtype=tl.float32)

    offs_c = tl.arange(0, BLOCK_C)
    mask_c = offs_c < kv_lora_rank
    offs_q = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c[None, :]
    )
    q = tl.load(Q + offs_q, mask=(mask_h[:, None]) & (mask_c[None, :]), other=0.0)
    acc = tl.zeros([BLOCK_H, BLOCK_C], dtype=tl.float32)

    if split_kv_end > split_kv_start:
        for start_n in range(split_kv_start, split_kv_end, BLOCK_N):
            offs_n = start_n + tl.arange(0, BLOCK_N)
            kv_loc = tl.load(
                kv_indices + cur_batch_kv_start_idx + offs_n,
                mask=offs_n < split_kv_end,
                other=0,
            )

            offs_buf_kv = kv_loc[None, :] * stride_buf_kbs + offs_c[:, None]
            offs_buf_k_pe = kv_loc[None, :] * stride_buf_kbs + offs_qk_r[:, None]

            k_pe = tl.load(
                K_Buffer + offs_buf_k_pe,
                mask=(offs_n[None, :] < split_kv_end) & (mask_qk_r[:, None]),
                other=0.0,
            )  # positional embedding part of keys

            # Swap in the freshly roped last token. The selector only
            # matches in the tile that actually contains the final token,
            # so this is safe to run on every tile.
            if USE_ROPE:
                k_pe = tl.where(
                    offs_n[None, :] != (split_kv_end - 1),
                    k_pe,
                    k_pe_last_token[:, None],
                )

            # dot product of rope parts
            qk = tl.dot(q_pe, k_pe.to(q_pe.dtype))

            kv = tl.load(
                K_Buffer + offs_buf_kv,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c[:, None]),
                other=0.0,
            )  # the shared latent tensor for keys and values

            # dot product of nope parts
            qk += tl.dot(q, kv)

            qk *= sm_scale

            if LOGIT_CAP > 0:
                qk = LOGIT_CAP * tanh(qk / LOGIT_CAP)

            qk = tl.where(
                mask_h[:, None] & (offs_n[None, :] < split_kv_end),
                qk,
                float("-inf"),
            )

            offs_buf_v = kv_loc[:, None] * stride_buf_vbs + offs_c[None, :]
            v = tl.load(
                V_buffer + offs_buf_v,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c[None, :]),
                other=0.0,
            )

            n_e_max = tl.maximum(tl.max(qk, 1), e_max)
            re_scale = tl.exp(e_max - n_e_max)
            p = tl.exp(qk - n_e_max[:, None])
            acc *= re_scale[:, None]
            # probabilities round to the storage dtype for the context dot
            acc += tl.dot(p.to(v.dtype), v)

            e_sum = e_sum * re_scale + tl.sum(p, 1)
            e_max = n_e_max

        offs_mid_o = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c[None, :]
        )

        if USE_ROPE:
            k_pe_last_token_ptrs = (
                k_pe_t_out
                + cur_batch * stride_kpe_tokens_out_b
                + tl.arange(0, BLOCK_R)
            )
            tl.store(k_pe_last_token_ptrs, k_pe_last_token, mask=mask_qk_r)

        tl.store(
            Att_Out + offs_mid_o,
            acc / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c[None, :]),
        )

        offs_mid_o_1 = (
            cur_batch * stride_mid_ob
            + cur_head * stride_mid_oh
            + split_kv_id * stride_mid_os
            + kv_lora_rank
        )

        tl.store(
            Att_Out + offs_mid_o_1,
            e_max + tl.log(e_sum),
            mask=mask_h,
        )



@triton.jit
def _fwd_grouped_kernel_stage1_rope_chunked2(
    Q,  # Holds [Q_NOPE; Q_PE], b x h x (c+r)
    K_Buffer,  # Holds [KV; K_PE], b*s x (c+r)
    V_buffer,  # Holds [KV], b*s x c
    cos_sin_cache,  # max_seq_len x rotary_dim
    positions,  # sequence positions
    sm_scale,
    kv_indptr,
    kv_indices,
    Att_Out,  # b x h x NUM_KV_SPLITS x (kv_lora_rank + 1)
    k_pe_t_out,
    stride_qb,
    stride_qh,
    stride_buf_kbs,
    stride_buf_vbs,
    stride_mid_ob,
    stride_mid_oh,
    stride_mid_os,
    stride_kpe_tokens_out_b,
    stride_cos_sin_cache_s,
    stride_positions_b,
    kv_lora_rank,
    rotary_dim,
    qk_rope_head_dim: tl.constexpr,
    kv_group_num: tl.constexpr,
    q_head_num: tl.constexpr,
    BLOCK_C: tl.constexpr,
    BLOCK_C1: tl.constexpr,
    BLOCK_R: tl.constexpr,
    BLOCK_N: tl.constexpr,
    BLOCK_H: tl.constexpr,
    NUM_KV_SPLITS: tl.constexpr,
    LOGIT_CAP: tl.constexpr,
    USE_ROPE: tl.constexpr,
    IS_NEOX_STYLE: tl.constexpr,
):
    """Two-chunk kernel for even latent ranks that are not powers of two.

    The latent is cut into [BLOCK_C ; BLOCK_C1] columns (192 = 128 + 64,
    96 = 64 + 32), so every tile lane holds a live latent value instead of
    the zero padding a next-power-of-two tile would carry. The nope score is
    the exact algebraic split of one wide dot along its reduction axis,
    summed in fp32 before scaling and softmax; same online softmax, same
    bf16 p rounding, same LSE as the fused kernel.
    """
    cur_batch = tl.program_id(0)
    cur_head_id = tl.program_id(1)
    split_kv_id = tl.program_id(2)

    if BLOCK_H < kv_group_num:
        VALID_BLOCK_H: tl.constexpr = BLOCK_H
    else:
        VALID_BLOCK_H: tl.constexpr = kv_group_num
    cur_head = cur_head_id * VALID_BLOCK_H + tl.arange(0, BLOCK_H)
    mask_h = cur_head < (cur_head_id + 1) * VALID_BLOCK_H
    mask_h = mask_h & (cur_head < q_head_num)

    offs_qk_r = kv_lora_rank + tl.arange(0, BLOCK_R)  # to get the k_pe

    off_q_pe = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_qk_r[None, :]
    )

    mask_qk_r = offs_qk_r < (kv_lora_rank + qk_rope_head_dim)

    cur_batch_kv_start_idx = tl.load(kv_indptr + cur_batch)
    cur_batch_seq_len = tl.load(kv_indptr + cur_batch + 1) - cur_batch_kv_start_idx

    q_pe = tl.load(
        Q + off_q_pe, mask=(mask_h[:, None]) & (mask_qk_r[None, :]), other=0.0
    )

    kv_len_per_split = tl.cdiv(cur_batch_seq_len, NUM_KV_SPLITS)
    split_kv_start = kv_len_per_split * split_kv_id
    split_kv_end = tl.minimum(split_kv_start + kv_len_per_split, cur_batch_seq_len)

    # With NUM_KV_SPLITS == 1 the single split always ends at the sequence end,
    # so the on-the-fly rope of the page's last token always applies here.
    k_pe_last_token = tl.zeros([BLOCK_R], dtype=q_pe.dtype)

    if USE_ROPE:
        if IS_NEOX_STYLE:
            # neox-style index setup:
            # [r/2, r/2+1, ..., r-1, 0, 1, ..., r/2-1]
            offs_qk_rot_r = kv_lora_rank + (
                (tl.arange(0, BLOCK_R) + (rotary_dim // 2)) % rotary_dim
            )
            # Which elements to flip
            mask_rotate = tl.arange(0, BLOCK_R) < (rotary_dim // 2)
            # [0, 1, ..., r/2-1, 0, 1, ..., r/2-1]
            offs_rotary = tl.arange(0, BLOCK_R) % (rotary_dim // 2)
        else:
            # interleaved style: [1, 0, 3, 2, 5, 4, ...]
            offs_qk_rot_r = (
                kv_lora_rank
                + (((tl.arange(0, BLOCK_R) + 1) % 2) * 2)
                - 1
                + tl.arange(0, BLOCK_R)
            )
            mask_rotate = tl.arange(0, BLOCK_R) % 2 < 1
            # [0, 0, 1, 1, ..., r/2-1, r/2-1]
            offs_rotary = tl.arange(0, BLOCK_R) // 2

        if qk_rope_head_dim > rotary_dim:
            offs_qk_rot_r = tl.where(
                tl.arange(0, BLOCK_R) < rotary_dim, offs_qk_rot_r, tl.arange(0, BLOCK_R)
            )
            offs_rotary = tl.where(
                tl.arange(0, BLOCK_R) < rotary_dim, offs_rotary, tl.arange(0, BLOCK_R)
            )

        mask_rotary = tl.arange(0, BLOCK_R) < rotary_dim

        pos = tl.load(positions + cur_batch * stride_positions_b)
        cos = tl.load(
            cos_sin_cache + pos * stride_cos_sin_cache_s + offs_rotary,
            mask=mask_rotary,
            other=1.0,
        )
        sin = tl.load(
            cos_sin_cache
            + pos * stride_cos_sin_cache_s
            + offs_rotary
            + rotary_dim // 2,
            mask_rotary,
            other=0.0,
        )

        off_q_pe_rot = (
            cur_batch * stride_qb
            + cur_head[:, None] * stride_qh
            + offs_qk_rot_r[None, :]
        )
        mask_qk_rot_r = offs_qk_rot_r < (kv_lora_rank + qk_rope_head_dim)

        q_pe_rot = tl.load(
            Q + off_q_pe_rot,
            mask=(mask_h[:, None]) & (mask_qk_rot_r[None, :]),
            other=0.0,
        )
        q_pe_rot = tl.where(mask_rotate[None, :], -q_pe_rot, q_pe_rot)

        # bf16 * bf16 -> bf16: rope result stays in the storage dtype
        q_pe = q_pe * cos + q_pe_rot * sin

        # Rope only the last token of the page on the fly; all earlier tokens
        # are already roped in the cache.
        kv_loc_last = tl.load(
            kv_indices + cur_batch_kv_start_idx + cur_batch_seq_len - 1
        )
        offs_buf_k_pe_last_token = kv_loc_last * stride_buf_kbs + offs_qk_r
        offs_buf_k_pe_rot_last_token = kv_loc_last * stride_buf_kbs + offs_qk_rot_r
        k_pe_last_token = tl.load(K_Buffer + offs_buf_k_pe_last_token)

        k_pe_rot_last_token = tl.load(K_Buffer + offs_buf_k_pe_rot_last_token)
        k_pe_rot_last_token = tl.where(
            mask_rotate, -k_pe_rot_last_token, k_pe_rot_last_token
        )

        k_pe_last_token = k_pe_last_token * cos + k_pe_rot_last_token * sin

    e_max = tl.zeros([BLOCK_H], dtype=tl.float32) - float("inf")
    e_sum = tl.zeros([BLOCK_H], dtype=tl.float32)

    # Two power-of-two latent chunks covering the rank exactly (128 + 64 for
    # C = 192, 64 + 32 for C = 96). Their score partials sum in fp32 into
    # the same qk tile before scaling and softmax; each keeps its own fp32
    # context accumulator, rescaled together per tile.
    offs_c0 = tl.arange(0, BLOCK_C)
    mask_c0 = offs_c0 < kv_lora_rank
    offs_c1 = BLOCK_C + tl.arange(0, BLOCK_C1)
    mask_c1 = offs_c1 < kv_lora_rank

    offs_q0 = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c0[None, :]
    )
    q0 = tl.load(Q + offs_q0, mask=(mask_h[:, None]) & (mask_c0[None, :]), other=0.0)
    offs_q1 = (
        cur_batch * stride_qb + cur_head[:, None] * stride_qh + offs_c1[None, :]
    )
    q1 = tl.load(Q + offs_q1, mask=(mask_h[:, None]) & (mask_c1[None, :]), other=0.0)

    acc0 = tl.zeros([BLOCK_H, BLOCK_C], dtype=tl.float32)
    acc1 = tl.zeros([BLOCK_H, BLOCK_C1], dtype=tl.float32)

    if split_kv_end > split_kv_start:
        for start_n in range(split_kv_start, split_kv_end, BLOCK_N):
            offs_n = start_n + tl.arange(0, BLOCK_N)
            kv_loc = tl.load(
                kv_indices + cur_batch_kv_start_idx + offs_n,
                mask=offs_n < split_kv_end,
                other=0,
            )

            offs_buf_k_pe = kv_loc[None, :] * stride_buf_kbs + offs_qk_r[:, None]

            k_pe = tl.load(
                K_Buffer + offs_buf_k_pe,
                mask=(offs_n[None, :] < split_kv_end) & (mask_qk_r[:, None]),
                other=0.0,
            )  # positional embedding part of keys

            # Swap in the freshly roped last token. The selector only
            # matches in the tile that actually contains the final token,
            # so this is safe to run on every tile.
            if USE_ROPE:
                k_pe = tl.where(
                    offs_n[None, :] != (split_kv_end - 1),
                    k_pe,
                    k_pe_last_token[:, None],
                )

            # dot product of rope parts
            qk = tl.dot(q_pe, k_pe.to(q_pe.dtype))

            # nope dot split along the reduction axis into the two chunks,
            # summed in fp32 into the same score tile
            offs_buf_kv0 = kv_loc[None, :] * stride_buf_kbs + offs_c0[:, None]
            kv0 = tl.load(
                K_Buffer + offs_buf_kv0,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c0[:, None]),
                other=0.0,
            )
            qk += tl.dot(q0, kv0)

            offs_buf_kv1 = kv_loc[None, :] * stride_buf_kbs + offs_c1[:, None]
            kv1 = tl.load(
                K_Buffer + offs_buf_kv1,
                mask=(offs_n[None, :] < split_kv_end) & (mask_c1[:, None]),
                other=0.0,
            )
            qk += tl.dot(q1, kv1)

            qk *= sm_scale

            if LOGIT_CAP > 0:
                qk = LOGIT_CAP * tanh(qk / LOGIT_CAP)

            qk = tl.where(
                mask_h[:, None] & (offs_n[None, :] < split_kv_end),
                qk,
                float("-inf"),
            )

            n_e_max = tl.maximum(tl.max(qk, 1), e_max)
            re_scale = tl.exp(e_max - n_e_max)
            p = tl.exp(qk - n_e_max[:, None])

            acc0 *= re_scale[:, None]
            acc1 *= re_scale[:, None]

            # probabilities round to the storage dtype for the context dots
            p_b = p.to(q_pe.dtype)

            offs_buf_v0 = kv_loc[:, None] * stride_buf_vbs + offs_c0[None, :]
            v0 = tl.load(
                V_buffer + offs_buf_v0,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c0[None, :]),
                other=0.0,
            )
            acc0 += tl.dot(p_b.to(v0.dtype), v0)

            offs_buf_v1 = kv_loc[:, None] * stride_buf_vbs + offs_c1[None, :]
            v1 = tl.load(
                V_buffer + offs_buf_v1,
                mask=(offs_n[:, None] < split_kv_end) & (mask_c1[None, :]),
                other=0.0,
            )
            acc1 += tl.dot(p_b.to(v1.dtype), v1)

            e_sum = e_sum * re_scale + tl.sum(p, 1)
            e_max = n_e_max

        if USE_ROPE:
            k_pe_last_token_ptrs = (
                k_pe_t_out
                + cur_batch * stride_kpe_tokens_out_b
                + tl.arange(0, BLOCK_R)
            )
            tl.store(k_pe_last_token_ptrs, k_pe_last_token, mask=mask_qk_r)

        offs_mid_o0 = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c0[None, :]
        )
        tl.store(
            Att_Out + offs_mid_o0,
            acc0 / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c0[None, :]),
        )

        offs_mid_o1 = (
            cur_batch * stride_mid_ob
            + cur_head[:, None] * stride_mid_oh
            + split_kv_id * stride_mid_os
            + offs_c1[None, :]
        )
        tl.store(
            Att_Out + offs_mid_o1,
            acc1 / e_sum[:, None],
            mask=(mask_h[:, None]) & (mask_c1[None, :]),
        )

        offs_mid_o_1 = (
            cur_batch * stride_mid_ob
            + cur_head * stride_mid_oh
            + split_kv_id * stride_mid_os
            + kv_lora_rank
        )

        tl.store(
            Att_Out + offs_mid_o_1,
            e_max + tl.log(e_sum),
            mask=mask_h,
        )



def npu_triton_impl(inputs: dict) -> dict:
    """Launch the stage1 kernel on NPU and return {"att_out": ...}.

    Mirrors the upstream host wrapper's grid/stride/BLOCK setup: BLOCK_H=16,
    one program row per (batch, head group of min(16, kv_group_num), split).
    Kernel selection by latent rank C = kv_lora_rank:

    - C a power of two and C <= 256: the round-4 fused single-tile kernel,
      BLOCK_C = next_pow2(C) = C, BLOCK_N = 32 (byte-identical code path).
    - C even, not a power of two, C <= 256 (C = 192 and C = 96 in this
      manifest): the round-5 two-chunk kernel, which tiles the latent as
      128 + 64 (C = 192) or 64 + 32 (C = 96) -- exact power-of-two chunks
      with no padded lanes -- at BLOCK_N = 32.
    - otherwise (C = 512): the round-4 wide kernel, four 128-column chunks,
      BLOCK_N = 16 (byte-identical code path).

    BLOCK_R is the next power of two of the rope dim. k_buffer is
    [total_kv, 1, kv_lora_rank + qk_rope_head_dim], so every query head
    shares the single latent KV head, and V aliases the latent slice
    k_buffer[:, 0, :kv_lora_rank].

    All host-side sizes are derived from tensor shapes; the scalar knobs
    (sm_scale, logit_cap, use_rope, is_neox_style) are passed straight
    through to the kernel launch without host-side coercion.
    """
    q = inputs["q"]
    k_buffer = inputs["k_buffer"]
    kv_indptr = inputs["kv_indptr"].to(torch.int32)
    kv_indices = inputs["kv_indices"].to(torch.int64)
    cos_sin_cache = inputs["cos_sin_cache"]
    positions = inputs["positions"]

    # q row = [q_nope(C); q_pe(R)], k_buffer row = [kv_latent(C); k_pe(R)], and
    # cos_sin_cache has exactly R columns. So R and C are shape-derived ints.
    rotary_dim = cos_sin_cache.shape[-1]
    kv_lora_rank = q.shape[-1] - rotary_dim
    qk_rope_head_dim = k_buffer.shape[-1] - kv_lora_rank
    batch = kv_indptr.shape[0] - 1
    head_num = q.shape[1]
    kv_group_num = head_num // k_buffer.shape[1]
    v_buffer = k_buffer[:, 0, :kv_lora_rank]

    # Stage1 mid-output (attn_logits): fp32. Zero-initialized so that a batch
    # with an empty KV range (guarded inside the kernel) stays at zero.
    att_out = torch.zeros(
        (batch, head_num, 1, kv_lora_rank + 1),
        dtype=torch.float32,
        device=q.device,
    )
    # Fused RoPE writes the roped last k_pe token here (not graded).
    k_pe_tokens_out = torch.empty(
        (batch, qk_rope_head_dim), dtype=q.dtype, device=q.device
    )

    BLOCK_H = 16
    grid = (
        batch,
        triton.cdiv(head_num, min(BLOCK_H, kv_group_num)),
        1,
    )

    is_pow2 = (kv_lora_rank & (kv_lora_rank - 1)) == 0
    chunk_c0 = triton.next_power_of_2(kv_lora_rank // 2)
    chunk_c1 = kv_lora_rank - chunk_c0
    chunk_c1_pow2 = chunk_c1 > 0 and (chunk_c1 & (chunk_c1 - 1)) == 0
    # Two-chunk path only when both chunks are power-of-two cube widths
    # (>= 16 columns each); any other rank keeps the proven fused tile.
    use_chunked2 = (
        kv_lora_rank <= 256
        and not is_pow2
        and chunk_c1_pow2
        and chunk_c0 >= 16
        and chunk_c1 >= 16
    )

    if kv_lora_rank <= 256 and not use_chunked2:
        # Proven fused geometry (rounds 1-4): one latent tile of
        # BLOCK_C = next_pow2(C) <= 256 columns, BLOCK_N = 32.
        BLOCK_C = triton.next_power_of_2(kv_lora_rank)
        BLOCK_N = 32
        _fwd_grouped_kernel_stage1_rope[grid](
            q,
            k_buffer,
            v_buffer,
            cos_sin_cache,
            positions,
            inputs["sm_scale"],
            kv_indptr,
            kv_indices,
            att_out,
            k_pe_tokens_out,
            q.stride(0),
            q.stride(1),
            k_buffer.stride(0),
            v_buffer.stride(0),
            att_out.stride(0),
            att_out.stride(1),
            att_out.stride(2),
            k_pe_tokens_out.stride(0),
            cos_sin_cache.stride(0),
            positions.stride(0),
            kv_lora_rank,
            rotary_dim,
            qk_rope_head_dim,
            kv_group_num=kv_group_num,
            q_head_num=head_num,
            BLOCK_C=BLOCK_C,
            BLOCK_R=triton.next_power_of_2(qk_rope_head_dim),
            BLOCK_N=BLOCK_N,
            BLOCK_H=BLOCK_H,
            NUM_KV_SPLITS=1,
            LOGIT_CAP=inputs["logit_cap"],
            USE_ROPE=inputs["use_rope"],
            IS_NEOX_STYLE=inputs["is_neox_style"],
            num_warps=4,
            num_stages=1,
        )
    elif use_chunked2:
        # Round-5 two-chunk geometry for even non-power-of-two ranks
        # (192 = 128 + 64, 96 = 64 + 32): every tile lane is a live latent
        # value, no next-pow2 padding, BLOCK_N = 32.
        BLOCK_C = chunk_c0
        BLOCK_C1 = chunk_c1
        BLOCK_N = 32
        _fwd_grouped_kernel_stage1_rope_chunked2[grid](
            q,
            k_buffer,
            v_buffer,
            cos_sin_cache,
            positions,
            inputs["sm_scale"],
            kv_indptr,
            kv_indices,
            att_out,
            k_pe_tokens_out,
            q.stride(0),
            q.stride(1),
            k_buffer.stride(0),
            v_buffer.stride(0),
            att_out.stride(0),
            att_out.stride(1),
            att_out.stride(2),
            k_pe_tokens_out.stride(0),
            cos_sin_cache.stride(0),
            positions.stride(0),
            kv_lora_rank,
            rotary_dim,
            qk_rope_head_dim,
            kv_group_num=kv_group_num,
            q_head_num=head_num,
            BLOCK_C=BLOCK_C,
            BLOCK_C1=BLOCK_C1,
            BLOCK_R=triton.next_power_of_2(qk_rope_head_dim),
            BLOCK_N=BLOCK_N,
            BLOCK_H=BLOCK_H,
            NUM_KV_SPLITS=1,
            LOGIT_CAP=inputs["logit_cap"],
            USE_ROPE=inputs["use_rope"],
            IS_NEOX_STYLE=inputs["is_neox_style"],
            num_warps=4,
            num_stages=1,
        )
    else:
        # Wide-latent geometry (kv_lora_rank = 512): one program, four
        # 128-column latent chunks, BLOCK_N = 16.
        BLOCK_C = triton.next_power_of_2(triton.cdiv(kv_lora_rank, 4))
        BLOCK_N = 16
        _fwd_grouped_kernel_stage1_rope_wide[grid](
            q,
            k_buffer,
            v_buffer,
            cos_sin_cache,
            positions,
            inputs["sm_scale"],
            kv_indptr,
            kv_indices,
            att_out,
            k_pe_tokens_out,
            q.stride(0),
            q.stride(1),
            k_buffer.stride(0),
            v_buffer.stride(0),
            att_out.stride(0),
            att_out.stride(1),
            att_out.stride(2),
            k_pe_tokens_out.stride(0),
            cos_sin_cache.stride(0),
            positions.stride(0),
            kv_lora_rank,
            rotary_dim,
            qk_rope_head_dim,
            kv_group_num=kv_group_num,
            q_head_num=head_num,
            BLOCK_C=BLOCK_C,
            BLOCK_R=triton.next_power_of_2(qk_rope_head_dim),
            BLOCK_N=BLOCK_N,
            BLOCK_H=BLOCK_H,
            NUM_KV_SPLITS=1,
            LOGIT_CAP=inputs["logit_cap"],
            USE_ROPE=inputs["use_rope"],
            IS_NEOX_STYLE=inputs["is_neox_style"],
            num_warps=4,
            num_stages=1,
        )

    return {"att_out": att_out}
