"""Round 1 solution for L2_17_w8a8_block_int8_matmul (triton-ascend / 910B).

Block-wise W8A8 INT8 GEMM: A (int8, per-token x k-group scale As) @
B^T (int8, per-(n-block, k-group) scale Bs) -> C in the requested output
dtype.  The inner GEMM tile is computed with tl.dot on INT8 (mapped to the
910B cube), the per-k-block scales are applied on the vector path, and the
accumulator is fp32, cast to the output dtype only at the final store.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _w8a8_block_int8_matmul_kernel(
    A,
    B,
    C,
    As,
    Bs,
    M,
    N,
    K,
    group_n,
    group_k,
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_As_m,
    stride_As_k,
    stride_Bs_k,
    stride_Bs_n,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    num_pid_in_group = GROUP_SIZE_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_SIZE_M
    group_size_m = min(num_pid_m - first_pid_m, GROUP_SIZE_M)
    pid_m = first_pid_m + (pid % group_size_m)
    pid_n = (pid % num_pid_in_group) // group_size_m

    # Row/column indices are wrapped with % M / % N so that OOB lanes of
    # the input tiles stay in-bounds while loading (the store is masked
    # separately at the end).
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    # B is contiguous [N, K]; the wrapper passes stride_bk=B.stride(1) and
    # stride_bn=B.stride(0), i.e. the K x N tile is read transposed-in-place.
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    As_ptrs = As + offs_am * stride_As_m
    offs_bsn = offs_bn // group_n
    Bs_ptrs = Bs + offs_bsn * stride_Bs_n

    # fp32 accumulation, as required by the contract.
    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        a = tl.load(a_ptrs, mask=offs_k[None, :] < K - k * BLOCK_SIZE_K, other=0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < K - k * BLOCK_SIZE_K, other=0)

        offs_ks = (k * BLOCK_SIZE_K) // group_k
        a_s = tl.load(As_ptrs + offs_ks * stride_As_k)
        b_s = tl.load(Bs_ptrs + offs_ks * stride_Bs_k)

        accumulator += tl.dot(a, b).to(tl.float32) * a_s[:, None] * b_s[None, :]
        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    # Single cast to the output dtype, only here.
    if C.dtype.element_ty == tl.bfloat16:
        c = accumulator.to(tl.bfloat16)
    elif C.dtype.element_ty == tl.float16:
        c = accumulator.to(tl.float16)
    else:
        c = accumulator.to(tl.float32)

    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)


def w8a8_block_int8_matmul(
    A: torch.Tensor,
    B: torch.Tensor,
    As: torch.Tensor,
    Bs: torch.Tensor,
    block_size,
    output_dtype: torch.dtype = torch.float16,
) -> torch.Tensor:
    """Host wrapper. block_size = [block_n, block_k]."""
    # block_size is a plain Python scalar_seq [block_n, block_k].
    block_n = block_size[0]
    block_k = block_size[1]
    K = B.shape[-1]
    M = A.numel() // K
    N = B.shape[0]

    C_shape = A.shape[:-1] + (N,)
    C = torch.empty(C_shape, dtype=output_dtype, device=A.device)

    # Static tile choice for 910B: 64 x 32 int8 tile is a well-supported
    # cube shape; BLOCK_SIZE_N (32) is a multiple of the n-block (8) so the
    # weight-scale lookup stays uniform inside the tile, and BLOCK_SIZE_K
    # equals the k-group (32) so one dot covers exactly one scale step.
    BLOCK_SIZE_M = 64
    BLOCK_SIZE_N = 32
    BLOCK_SIZE_K = block_k
    GROUP_SIZE_M = 8
    num_warps = 4
    num_stages = 3

    def grid(META):
        return (
            triton.cdiv(M, META["BLOCK_SIZE_M"]) * triton.cdiv(N, META["BLOCK_SIZE_N"]),
        )

    _w8a8_block_int8_matmul_kernel[grid](
        A,
        B,
        C,
        As,
        Bs,
        M,
        N,
        K,
        block_n,
        block_k,
        A.stride(-2),
        A.stride(-1),
        B.stride(1),
        B.stride(0),
        C.stride(-2),
        C.stride(-1),
        As.stride(-2),
        As.stride(-1),
        Bs.stride(1),
        Bs.stride(0),
        BLOCK_SIZE_M=BLOCK_SIZE_M,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
        BLOCK_SIZE_K=BLOCK_SIZE_K,
        GROUP_SIZE_M=GROUP_SIZE_M,
        num_warps=num_warps,
        num_stages=num_stages,
    )
    return C


def npu_triton_impl(inputs: dict) -> dict:
    result = w8a8_block_int8_matmul(
        inputs["A"],
        inputs["B"],
        inputs["As"],
        inputs["Bs"],
        inputs["block_size"],
    )
    return {"C": result}
