"""Block-scaled INT8 matmul (task L2_17) migrated to Triton-Ascend.

Semantics kept from the contract:

    A_fp[m, k] = A[m, k] * As[m, k // group_k]
    B_fp[n, k] = B[n, k] * Bs[n // group_n, k // group_k]
    C[m, n]    = (A_fp @ B_fp.T) cast once, at the final store

Load-bearing details preserved here:
  * every inner block product goes through ``tl.dot`` (cube units);
  * the accumulator stays ``tl.float32`` for the whole k loop;
  * ``As`` / ``Bs`` are applied per k-group *after* the block product is
    widened to fp32, never folded into the int8 operands;
  * the single narrowing cast happens in the epilogue and follows the
    element type of ``C``;
  * row/column indices wrap with ``% M`` / ``% N`` rather than being
    masked on load, so out-of-range lanes read in-range garbage and the
    store mask alone decides what lands in ``C``;
  * ``stride_bk`` / ``stride_bn`` are ``B.stride(1)`` / ``B.stride(0)``,
    i.e. the B tile is reached through the transposed view.

``BLOCK_SIZE_K`` is 32, exactly one k-scale group, so a k tile never
straddles two groups and the scalar group index ``k_start // group_k``
stays valid.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _w8a8_block_int8_matmul_npu(
    A,
    B,
    C,
    As,
    Bs,
    M,
    N,
    K,
    group_n,
    group_k,
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_As_m,
    stride_As_k,
    stride_Bs_k,
    stride_Bs_n,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
    DOT_MODE: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    num_pid_in_group = GROUP_SIZE_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_SIZE_M
    group_size_m = min(num_pid_m - first_pid_m, GROUP_SIZE_M)
    pid_m = first_pid_m + (pid % group_size_m)
    pid_n = (pid % num_pid_in_group) // group_size_m

    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    As_ptrs = As + offs_am * stride_As_m
    offs_bsn = offs_bn // group_n
    Bs_ptrs = Bs + offs_bsn * stride_Bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        k_rem = K - k * BLOCK_SIZE_K
        a = tl.load(a_ptrs, mask=offs_k[None, :] < k_rem, other=0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < k_rem, other=0)

        offs_ks = (k * BLOCK_SIZE_K) // group_k
        # a_s has BLOCK_SIZE_M entries, b_s has BLOCK_SIZE_N entries: one
        # scale per row / column of the tile, picked by the wrapped indices.
        a_s = tl.load(As_ptrs + offs_ks * stride_As_k)
        b_s = tl.load(Bs_ptrs + offs_ks * stride_Bs_k)

        if DOT_MODE == 0:
            # Preferred path: int8 x int8 -> int32 on the cube. The block
            # sum cannot overflow int32 and int32 -> fp32 is exact.
            accumulator += tl.dot(a, b).to(tl.float32) * a_s[:, None] * b_s[None, :]
        elif DOT_MODE == 1:
            # Alternate operand type: fp16 represents every int8 value
            # and every |int8 * int8| product exactly, and the dot still
            # accumulates in fp32, so the block product is bit-identical.
            accumulator += tl.dot(
                a.to(tl.float16), b.to(tl.float16), out_dtype=tl.float32
            ) * a_s[:, None] * b_s[None, :]
        else:
            accumulator += tl.dot(
                a.to(tl.float32), b.to(tl.float32), out_dtype=tl.float32
            ) * a_s[:, None] * b_s[None, :]

        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    if C.dtype.element_ty == tl.bfloat16:
        c = accumulator.to(tl.bfloat16)
    elif C.dtype.element_ty == tl.float16:
        c = accumulator.to(tl.float16)
    else:
        c = accumulator.to(tl.float32)

    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)


# A 910B die exposes a couple of dozen cube cores, so a grid much below
# this leaves compute idle.
_TARGET_PROGRAMS = 48

# Depth of one k tile. It equals one k-scale group, so it can never be
# widened past ``group_k`` without breaking the per-group scale handling.
_BLOCK_SIZE_K = 32

# Launch attempts, most preferred first: (BLOCK_SIZE_M, BLOCK_SIZE_N,
# DOT_MODE, num_warps, num_stages). The first entries all take the int8
# operand path at progressively safer cube shapes; the tail entries keep
# the best tiles but feed the cube through fp16 / fp32 operands instead.
# Every entry is a genuine ``tl.dot`` GEMM with an fp32 accumulator and
# produces the same values.
def _attempts(block_size_m, block_size_n):
    narrow_m = 32 if block_size_m > 32 else 16
    return (
        (block_size_m, block_size_n, 0, 4, 3),
        (block_size_m, block_size_n, 0, 4, 1),
        (narrow_m, 64, 0, 4, 3),
        (64, 64, 0, 4, 3),
        (block_size_m, block_size_n, 1, 4, 3),
        (block_size_m, block_size_n, 1, 4, 1),
        (block_size_m, block_size_n, 2, 4, 1),
    )


def npu_triton_impl(inputs: dict) -> dict:
    """Block-scaled INT8 matmul on Ascend. Keys follow contract.md."""
    A = inputs["A"]
    B = inputs["B"]
    As = inputs["As"]
    Bs = inputs["Bs"]
    block_size = inputs["block_size"]
    group_n = block_size[0]
    group_k = block_size[1]

    try:
        output_dtype = inputs["output_dtype"]
    except KeyError:
        output_dtype = torch.float16

    K = A.shape[-1]
    M = A.numel() // K
    N = B.shape[0]

    A_2d = A.reshape(M, K)
    As_2d = As.reshape(M, As.shape[-1])
    C = A.new_empty(A.shape[:-1] + (N,), dtype=output_dtype)
    C_2d = C.reshape(M, N)

    GROUP_SIZE_M = 32
    BLOCK_SIZE_K = min(_BLOCK_SIZE_K, max(16, triton.next_power_of_2(K)))

    BLOCK_SIZE_M = min(64, max(16, triton.next_power_of_2(M)))
    num_pid_m = triton.cdiv(M, BLOCK_SIZE_M)

    # Widest n tile that still keeps enough programs in flight; the narrowest
    # tile is kept when the problem is too small to saturate the cores.
    block_size_n_cap = min(128, max(16, triton.next_power_of_2(N)))
    block_size_n = 16
    for candidate_n in (16, 32, 64, 128):
        if candidate_n > block_size_n_cap:
            break
        if num_pid_m * triton.cdiv(N, candidate_n) >= _TARGET_PROGRAMS:
            block_size_n = candidate_n
    BLOCK_SIZE_N = block_size_n

    args = (
        A_2d,
        B,
        C_2d,
        As_2d,
        Bs,
        M,
        N,
        K,
        group_n,
        group_k,
        A_2d.stride(0),
        A_2d.stride(1),
        B.stride(1),
        B.stride(0),
        C_2d.stride(0),
        C_2d.stride(1),
        As_2d.stride(0),
        As_2d.stride(1),
        Bs.stride(1),
        Bs.stride(0),
    )

    last_error = None
    for block_m, block_n, dot_mode, num_warps, num_stages in _attempts(
        BLOCK_SIZE_M, BLOCK_SIZE_N
    ):
        num_progs = triton.cdiv(M, block_m) * triton.cdiv(N, block_n)
        try:
            _w8a8_block_int8_matmul_npu[(num_progs,)](
                *args,
                BLOCK_SIZE_M=block_m,
                BLOCK_SIZE_N=block_n,
                BLOCK_SIZE_K=BLOCK_SIZE_K,
                GROUP_SIZE_M=GROUP_SIZE_M,
                DOT_MODE=dot_mode,
                num_warps=num_warps,
                num_stages=num_stages,
            )
            return {"C": C}
        except Exception as err:  # noqa: BLE001 - last error is re-raised
            last_error = err

    raise last_error
