"""Triton-Ascend (910B) implementation of block-wise W8A8 INT8 matmul.

Entry point: npu_triton_impl(inputs: dict) -> dict, returning {"C": ...}.

Semantics (contract.md):
    A_fp[m, k] = A_int8[m, k] * As[m, k // block_k]
    B_fp[n, k] = B_int8[n, k] * Bs[n // block_n, k // block_k]
    C[m, n]    = (A_fp @ B_fp.T).to(output_dtype)

The inner product runs on the cube unit via ``tl.dot`` over int8 operands
(int32 result, matching the 910B INT8 cube path). Each k-block is de-scaled
into an fp32 accumulator and the narrowing to the output dtype happens
exactly once, in the final store.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _w8a8_block_int8_matmul_npu(
    A,
    B,
    C,
    As,
    Bs,
    M,
    N,
    K,
    group_n,
    group_k,
    stride_am,
    stride_ak,
    stride_bk,
    stride_bn,
    stride_cm,
    stride_cn,
    stride_As_m,
    stride_As_k,
    stride_Bs_k,
    stride_Bs_n,
    BLOCK_SIZE_M: tl.constexpr,
    BLOCK_SIZE_N: tl.constexpr,
    BLOCK_SIZE_K: tl.constexpr,
    GROUP_SIZE_M: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    num_pid_m = tl.cdiv(M, BLOCK_SIZE_M)
    num_pid_n = tl.cdiv(N, BLOCK_SIZE_N)
    num_pid_in_group = GROUP_SIZE_M * num_pid_n
    group_id = pid // num_pid_in_group
    first_pid_m = group_id * GROUP_SIZE_M
    group_size_m = min(num_pid_m - first_pid_m, GROUP_SIZE_M)
    pid_m = first_pid_m + (pid % group_size_m)
    pid_n = (pid % num_pid_in_group) // group_size_m

    # Modulo wrap keeps every gather in range on ragged M/N tiles, so the
    # operand loads only need the K mask (dead lanes read as zero).
    offs_am = (pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)) % M
    offs_bn = (pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)) % N
    offs_k = tl.arange(0, BLOCK_SIZE_K)
    a_ptrs = A + (offs_am[:, None] * stride_am + offs_k[None, :] * stride_ak)
    b_ptrs = B + (offs_k[:, None] * stride_bk + offs_bn[None, :] * stride_bn)

    As_ptrs = As + offs_am * stride_As_m
    offs_bsn = offs_bn // group_n
    Bs_ptrs = Bs + offs_bsn * stride_Bs_n

    accumulator = tl.zeros((BLOCK_SIZE_M, BLOCK_SIZE_N), dtype=tl.float32)
    for k in range(0, tl.cdiv(K, BLOCK_SIZE_K)):
        a = tl.load(a_ptrs, mask=offs_k[None, :] < K - k * BLOCK_SIZE_K, other=0.0)
        b = tl.load(b_ptrs, mask=offs_k[:, None] < K - k * BLOCK_SIZE_K, other=0.0)

        k_start = k * BLOCK_SIZE_K
        offs_ks = k_start // group_k
        a_s = tl.load(As_ptrs + offs_ks * stride_As_k)
        b_s = tl.load(Bs_ptrs + offs_ks * stride_Bs_k)

        blk = tl.dot(a, b).to(tl.float32)
        accumulator += blk * a_s[:, None] * b_s[None, :]

        a_ptrs += BLOCK_SIZE_K * stride_ak
        b_ptrs += BLOCK_SIZE_K * stride_bk

    if C.dtype.element_ty == tl.bfloat16:
        c = accumulator.to(tl.bfloat16)
    elif C.dtype.element_ty == tl.float16:
        c = accumulator.to(tl.float16)
    else:
        c = accumulator.to(tl.float32)

    offs_cm = pid_m * BLOCK_SIZE_M + tl.arange(0, BLOCK_SIZE_M)
    offs_cn = pid_n * BLOCK_SIZE_N + tl.arange(0, BLOCK_SIZE_N)
    c_ptrs = C + stride_cm * offs_cm[:, None] + stride_cn * offs_cn[None, :]
    c_mask = (offs_cm[:, None] < M) & (offs_cn[None, :] < N)
    tl.store(c_ptrs, c, mask=c_mask)


def _block_size_m(rows: int) -> int:
    if rows <= 16:
        return 16
    if rows <= 32:
        return 32
    return 64


def npu_triton_impl(inputs: dict) -> dict:
    A = inputs["A"]
    B = inputs["B"]
    As = inputs["As"]
    Bs = inputs["Bs"]
    block_size = inputs["block_size"]
    output_dtype = inputs["output_dtype"] if "output_dtype" in inputs else torch.float16

    block_n = block_size[0]
    block_k = block_size[1]

    N = B.shape[0]
    K = B.shape[1]
    M = A.numel() // A.shape[-1]

    if not A.is_contiguous():
        A = A.contiguous()
    if not B.is_contiguous():
        B = B.contiguous()
    if not As.is_contiguous():
        As = As.contiguous()
    if not Bs.is_contiguous():
        Bs = Bs.contiguous()

    out_shape = A.shape[:-1] + (N,)
    C = torch.empty(out_shape, dtype=output_dtype, device=A.device)

    # Static tiling, held independent of block_size: one k-step consumes
    # exactly one 32-wide scale group (the contracted block_k), and the 64-wide
    # N tile is an exact multiple of block_n, so every tile column maps to a
    # single Bs row. M follows the token count; 910B tiles stay cube-aligned.
    BLOCK_SIZE_M = _block_size_m(M)
    BLOCK_SIZE_N = 128 if N >= 2048 else 64
    BLOCK_SIZE_K = 32
    GROUP_SIZE_M = 32 if M >= 512 else 8

    num_pid_m = (M + BLOCK_SIZE_M - 1) // BLOCK_SIZE_M
    num_pid_n = (N + BLOCK_SIZE_N - 1) // BLOCK_SIZE_N
    grid = (num_pid_m * num_pid_n,)

    _w8a8_block_int8_matmul_npu[grid](
        A,
        B,
        C,
        As,
        Bs,
        M,
        N,
        K,
        block_n,
        block_k,
        A.stride(-2),
        A.stride(-1),
        B.stride(1),
        B.stride(0),
        C.stride(-2),
        C.stride(-1),
        As.stride(-2),
        As.stride(-1),
        Bs.stride(1),
        Bs.stride(0),
        BLOCK_SIZE_M=BLOCK_SIZE_M,
        BLOCK_SIZE_N=BLOCK_SIZE_N,
        BLOCK_SIZE_K=BLOCK_SIZE_K,
        GROUP_SIZE_M=GROUP_SIZE_M,
        num_warps=4,
        num_stages=3,
    )
    return {"C": C}
