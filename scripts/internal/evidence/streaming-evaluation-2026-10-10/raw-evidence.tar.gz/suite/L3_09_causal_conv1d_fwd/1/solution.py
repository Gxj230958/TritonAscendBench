"""L3_09_causal_conv1d_fwd -- Triton-Ascend implementation (round 2).

Depthwise causal 1-D convolution over a [D, L] channel-major bf16 fixture
(Mamba-style prefill projection). With W = weight.shape[1] taps and a left zero
pad of W-1:

    out[d, t] = fp32 sum_j bf16_round(x[d, t-(W-1)+j] * w[d, j])
                + bias[d]            # fp32, added after the tap sum
                -> SiLU when asked   # fp32, acc / (1 + exp(-acc))
                -> bf16 at the store

What this round changes, and nothing else.

Round 1 wrote the per-tap narrowing as an explicit fp32 -> bf16 -> fp32 cast
pair. That is exact on paper, but it is also a foldable no-op for a compiler
whose bf16 multiply is already "widen, multiply in fp32, keep fp32", and the
Ascend path drops it. The products then reached the accumulator at full fp32
precision, the reference's quantisation never happened, and all 40 shapes
landed 1-2 bf16 ULP away from the reference. The receipt's max_rel column is the
tell: ~1e9 is only reachable when the fp32 accumulator itself deviates by ~1e-2
and the reference output for that element is near zero -- i.e. a lost rounding,
not a lost element. Simulating the elision on CPU reproduces the receipt's
max_abs values essentially shape for shape (P1/P13/P15/P16/P28/P29/P30/P32
0.0312, P3/P4/P5/P8/P25/P26 0.0625, P27/H2 0.0156), while the fix below
reproduces the reference bit for bit.

So the rounding is now done with integer bit manipulation, which no float-level
optimisation can fold away:

    u = bitcast<int32>(p)                        p = fp32 product of two bf16s
    u = u + 32767 + ((u >> 16) & 1)              round-half-away-from-zero: the
    p = bitcast<f32>(u - (u & 65535))            rule c10 uses for fp32 -> bf16

The low 16 mantissa bits come off by subtracting them rather than by an
& 0xFFFF0000, because that mask does not fit int32. A bf16 x bf16 product needs
at most 16 mantissa bits, so it is exact in fp32, the value landing in the
helper is never a tie broken by chance, and the rounding is fully determined --
no dependence on the backend's float-cast rounding mode. The same four lines run
once more on the accumulator before the store, so the final narrowing is exact
too and does not lean on the store cast either.

Everything else is byte-for-byte round 1's structure: taps accumulate in fp32 in
ascending tap order via `tl.static_range` (the reference order), bias is added
last, SiLU is `acc / (1 + exp(-acc))` in fp32, negative window columns are the
zero pad handled by the load mask, and the tile geometry / grid / launch are
unchanged so the numeric fix is the only variable this round.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

# activation scalar -> SiLU flag; anything unmapped runs the linear path.
_ACT_MODE = {
    "silu": 1,
    "swish": 1,
    "SiLU": 1,
    "Swish": 1,
    "SILU": 1,
    "SWISH": 1,
    "none": 0,
    "None": 0,
    "": 0,
}


@triton.jit
def _causal_conv1d_fwd_ascend(
    x_ptr,
    w_ptr,
    b_ptr,
    o_ptr,
    D,
    L,
    stride_xc,
    stride_xt,
    stride_wc,
    stride_ww,
    stride_bc,
    stride_oc,
    stride_ot,
    BLOCK_C: tl.constexpr,
    BLOCK_T: tl.constexpr,
    KW: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    SILU: tl.constexpr,
):
    pid_c = tl.program_id(0)
    pid_t = tl.program_id(1)

    idx_c = pid_c * BLOCK_C + tl.arange(0, BLOCK_C)
    idx_t = pid_t * BLOCK_T + tl.arange(0, BLOCK_T)
    mask_c = idx_c < D

    acc = tl.zeros((BLOCK_C, BLOCK_T), dtype=tl.float32)

    x_rows = x_ptr + idx_c[:, None] * stride_xc
    w_row = w_ptr + idx_c * stride_wc

    # Tap j reads the window shifted by -(KW-1)+j. Adjacent taps touch the same
    # cache lines, so reloading beats a rolling register window: every lane
    # stays busy and the taps form independent FMA chains. Columns left of the
    # sequence are the reference's zero pad -- the masked load returns 0.0 and
    # the tap contributes nothing.
    for j in tl.static_range(KW):
        col = idx_t - (KW - 1) + j
        in_x = (col >= 0) & (col < L)
        mask_x = mask_c[:, None] & in_x[None, :]
        x_tile = tl.load(x_rows + col[None, :] * stride_xt, mask=mask_x, other=0.0)
        w_col = tl.load(w_row + j * stride_ww, mask=mask_c, other=0.0)
        # Widen deliberately: a bf16 x bf16 multiply is exact in fp32 (the
        # result needs 16 mantissa bits at most), so the only rounding on the
        # tap is the one below, and it does not depend on whether this backend
        # widens or narrows a bf16 x bf16 product.
        prod = x_tile.to(tl.float32) * w_col.to(tl.float32)[:, None]
        # Round the product onto the bf16 grid by bit surgery (see the module
        # docstring): integer-only, so no optimiser can fold it away as a
        # redundant widen/narrow cast pair.
        u = prod.to(tl.int32, bitcast=True)
        u = u + 32767 + ((u >> 16) & 1)
        acc += (u - (u & 65535)).to(tl.float32, bitcast=True)

    if HAS_BIAS:
        b_tile = tl.load(b_ptr + idx_c * stride_bc, mask=mask_c, other=0.0)
        acc += b_tile.to(tl.float32)[:, None]

    if SILU:
        acc = acc / (1.0 + tl.exp(-acc))

    # Land on the bf16 grid before the store cast, so the final narrowing is
    # exact and does not depend on the backend's float-cast rounding mode.
    u = acc.to(tl.int32, bitcast=True)
    u = u + 32767 + ((u >> 16) & 1)
    out_tile = (u - (u & 65535)).to(tl.float32, bitcast=True).to(o_ptr.dtype.element_ty)
    in_o = idx_t < L
    mask_o = mask_c[:, None] & in_o[None, :]
    tl.store(
        o_ptr + idx_c[:, None] * stride_oc + idx_t[None, :] * stride_ot,
        out_tile,
        mask=mask_o,
    )


def _act_mode(inputs, key):
    """Map the activation scalar to a flag without touching tensor values."""
    if key in inputs:
        try:
            return _ACT_MODE[inputs[key]]
        except KeyError:
            return 0
    return 0


def _bias_flag(inputs):
    """1 when inputs carries a real bias tensor, 0 when it is absent or None."""
    if "bias" not in inputs:
        return 0
    try:
        inputs["bias"].contiguous()
    except AttributeError:
        return 0
    return 1


def _bias_or_weight(inputs, weight):
    """Bias tensor when present, else the weight; the kernel never reads this
    pointer unless the HAS_BIAS branch is live."""
    if "bias" not in inputs:
        return weight.contiguous()
    try:
        return inputs["bias"].contiguous()
    except AttributeError:
        return weight.contiguous()


def _grid_size(D: int, L: int, block_c: int, block_t: int) -> int:
    return triton.cdiv(D, block_c) * triton.cdiv(L, block_t)


def _pick_blocks(D: int, L: int) -> tuple[int, int]:
    """Power-of-two tile: vector-width floor on both axes, bounded footprint.

    Lanes past the real extent are masked off, so padding the block up to the
    16-lane floor is cheaper than emitting a degenerate narrow tile.
    """
    np2_t = triton.next_power_of_2(max(L, 1))
    np2_c = triton.next_power_of_2(max(D, 1))
    block_t = min(max(np2_t, 16), 64)
    block_c = min(max(np2_c, 16), max(16, 2048 // block_t))

    # A tall, skinny fixture would otherwise issue only a handful of programs;
    # shrink the tile until there are enough blocks to spread over the cores.
    target = 128 if D * L >= (1 << 18) else 1
    while (block_c > 16 or block_t > 16) and _grid_size(D, L, block_c, block_t) < target:
        if block_c >= block_t:
            block_c = max(16, block_c // 2)
        else:
            block_t = max(16, block_t // 2)
    return block_c, block_t


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weight = inputs["weight"]
    silu_mode = _act_mode(inputs, "activation")

    x_c = x.contiguous()
    w_c = weight.contiguous()
    bias_flag = _bias_flag(inputs)
    b_c = _bias_or_weight(inputs, w_c)

    dim = int(x_c.shape[0])
    seqlen = int(x_c.shape[1])
    kw = int(w_c.shape[-1])

    out = torch.empty((dim, seqlen), dtype=x_c.dtype, device=x_c.device)
    if dim == 0 or seqlen == 0 or kw == 0:
        return {"output": out}

    block_c, block_t = _pick_blocks(dim, seqlen)
    grid = (triton.cdiv(dim, block_c), triton.cdiv(seqlen, block_t))

    # b_ptr is only read inside the HAS_BIAS branch, so a missing or None bias
    # still gets a real tensor and the constexpr drops the dead code.
    _causal_conv1d_fwd_ascend[grid](
        x_c,
        w_c,
        b_c,
        out,
        dim,
        seqlen,
        x_c.stride(0),
        x_c.stride(1),
        w_c.stride(0),
        w_c.stride(1),
        b_c.stride(0),
        out.stride(0),
        out.stride(1),
        BLOCK_C=block_c,
        BLOCK_T=block_t,
        KW=kw,
        HAS_BIAS=bias_flag,
        SILU=silu_mode,
    )

    return {"output": out}
