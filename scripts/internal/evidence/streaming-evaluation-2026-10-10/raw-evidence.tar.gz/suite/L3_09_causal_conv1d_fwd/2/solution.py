"""L3_09_causal_conv1d_fwd -- Triton-Ascend implementation (round 5).

Depthwise causal 1-D convolution over a [D, L] channel-major bf16 fixture
(Mamba-style prefill projection). With W = weight.shape[1] taps and a left zero
pad of W-1:

    out[d, t] = fp32 sum_j bf16_round(x[d, t-(W-1)+j] * w[d, j])
                + bias[d]            # fp32, added after the tap sum
                -> SiLU when asked   # fp32, acc / (1 + exp(-acc))
                -> bf16 at the store

WHAT THIS ROUND CHANGES: HOW A 2048-LANE PROGRAM SPENDS ITS LANES

One constant. `_MAX_BLOCK_T` goes 1024 -> 128 in the tile chooser, which lets the
channel axis take the part of the lane budget the token axis stops spending. The
lane budget, the grid, the kernel body, the mask logic, the contiguity hints, the
argument list, the plan memo and the wrapper are round 4's, byte for byte.

The value of every output element is invariant under this change by construction:
each lane computes its own (channel, token) pair from the same unrolled chain of
KW shifted loads, in ascending tap order, and BLOCK_C x BLOCK_T only decides which
program owns which lanes. Dead lanes are masked to 0.0 and never stored. So no
shape can move between pass and fail because of the split -- the pass set is
fixed at round 4's 30/40 and only the clock reacts. That is what makes this a
clean single-variable measurement.

Why 128 and not 1024: round 4's numbers price the two shapes, and the claim
survives round 3's independent run of the same plan table (rounds 3 and 4 differ
only in the launch argument list, so their geometry is comparable). Take the
marginal cost per program: total time minus the cheapest reading in the run (H2
at 144.9 us, 128 elements in one program, so it carries no measurable device
work), divided by the program count. Every program in every fixture holds the
same 2048 lanes, the same four masked tap loads per lane, and the same 4 bytes of
traffic per element, so this is a like-for-like rate:

    fixture        tile     progs   r3      r4     us/program
    P8   384x8192    2x1024   1536   1.013   1.068
    P7   384x6144    2x1024   1152   1.015   1.059
    H3   256x4096    2x1024    512   1.033   1.027
    P4  1024x2048    2x1024   1024   1.039   1.091
    -------------------------------------------------------
    P11   3072x384  16x128     576   0.358   0.452
    P40    384x640  16x128     120   0.393   0.547
    H1     384x384  16x128      72   0.332   0.325
    P5   2048x256   8x256      256   0.427   0.591
    P41    384x768   8x256     144   0.332   0.296

Restricted to fixtures with at least 72 programs and 23 us of increment -- below
that the floor subtraction dominates and the quotient is noise -- no 1024-token
tile ever gets under 1.01 us/program in either run, and no 128- or 256-token tile
ever gets above 0.60. H3 against P11 is the direct comparison: 1048576 against
1179648 elements, 512 against 576 programs, both on the FULL_C = FULL_T = 1 path
with no padded lane anywhere, both reading x and writing out exactly once. H3
spends its lanes as 2 rows x 1024 tokens and pays 2.3x what P11 pays for 16 rows
x 128 tokens, on 13% less data.

This is a measurement, not an argument, and I am holding it to the size-matched
large-program-count cases only. Round 3 moved this axis by 4x on P8, but it
collapsed the load predicate from 2-D to 1-D, swapped the grid axes and added the
contiguity hints in the same round, so none of that gain is attributable to run
length alone; and P3 at 4x512 reads 0.607 in round 3 against 1.145 in round 4, so
the mid-size readings carry +-25 us of run-to-run noise and prove nothing. The
mechanism I would expect is not memory traffic, which is identical, but the shape
of the address and predicate work per vector instruction: 128 lanes of bf16 is
exactly one 256-byte line, and the channel axis -- which advances by an immediate
L -- is what lets a program spend the rest of its lane budget without lengthening
the run the load unit walks.

What changes, concretely: the four fixtures above the 1 us/program line move from
2x1024 to 16x128 at an identical program count (P8 1536, P7 1152, P4 1024, H3
512), and together they hold 78% of this candidate's measured time above that
floor. Expected, at P11's measured 0.452 us/program: P8 1785 -> about 840 us,
P7 1364 -> about 660, P4 1263 -> about 610, H3 671 -> about 380, which is
+7.2% on the geometric mean over all 40 shapes (+5.7% at P40's 0.547). The other retuned
fixtures (P3, P5, P38, P41, the 512-token family) sit within a few us of the
launch floor and cannot move much either way; P13..P16 gain a few programs each
and are floor-bound too. A cap of 256 would capture most of the same win on
weaker evidence, since 8x256 sits in the same measured band; 128 is where the
closest size analogue to the four heavy fixtures actually measures.

One caveat I cannot rule out from this data, and it bounds the downside: P8 at
1536 programs is the highest occupancy in the corpus, and the only tile ever
measured there is 2x1024. If 1.05 us/program is a machine plateau at that program
count rather than a property of the tile, the retune buys nothing on P8 and P7 and
the gain shrinks to H3 and P3. That case is unlikely because H3 and P11 sit three
program-counts apart at 512 and 576 and differ by 2.3x, but it is the honest
failure mode, and it costs little: the lane budget, program counts, argument list
and value path are all untouched, so a plateau shows up as a near-zero delta
rather than a regression.

THE VALUE PATH IS CLOSED, AND THIS ROUND DOES NOT TOUCH IT

Rounds 2 and 3 established it. The reference narrows every tap product onto the
bf16 grid before the fp32 add; a float-level narrow-then-widen pair is a provably
lossless round-trip that this backend deletes, so the narrowing is done by
integer bit surgery that cannot be folded. Round 3 reproduced round 2's pass set
exactly, and both report the same ten failures at max_abs=0.00781 /
max_rel=0.00556 -- one bf16 ULP at |y| = 1.4, i.e. a one-bit disagreement at a
near-tie. Those ten (H1, H3, P4, P5, P7, P8, P11, P19, P20, P21) are precisely
the shapes this task's frozen equivalence record marks CEILING_ACCEPTED with the
same two numbers, so the shipped GPU kernel misses them against the same
reference at atol=rtol=1e-3 too. A CPU model of the pipeline shows the mechanism
is the transcendental rather than the arithmetic: neither a reciprocal multiply
in place of the division, nor a reversed or pairwise tap order, nor bias-first
accumulation changes a single element on any of the ten. This round keeps the
fp32 accumulator, the ascending tap order, bias last, `acc / (1.0 + tl.exp(-acc))`
and the pre-store rounding exactly as they were.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl

# activation scalar -> SiLU flag; anything unmapped runs the linear path.
_ACT_MODE = {
    "silu": 1,
    "swish": 1,
    "SiLU": 1,
    "Swish": 1,
    "SILU": 1,
    "SWISH": 1,
    "none": 0,
    "None": 0,
    "": 0,
}

# Lane budget per program: unchanged from rounds 3 and 4, so the program count
# of every fixture is what it was and no timing delta here can be attributed to
# how much work a program holds. What does change is how those lanes are split.
_BLOCK_LANES = 2048
_MIN_BLOCK_T = 16
# Ceiling on the token axis of a tile. Filling the contiguous axis first was
# right when it also collapsed the load predicate from 2-D to 1-D, but past a
# 256-byte run the extra length buys nothing while the rows it costs a program
# are what leaves the lane budget unspent: H3 (2 rows x 1024 tokens) measures
# 2.3x the per-program rate of P11 (16 rows x 128 tokens) on comparable sizes,
# in both of this candidate's runs. See the module docstring. 128 lanes of bf16
# is one 256-byte line, and channels take the rest of the budget.
_MAX_BLOCK_T = 128
_MIN_BLOCK_C = 2


@triton.jit
def _causal_conv1d_fwd_ascend(
    x_ptr,
    w_ptr,
    b_ptr,
    o_ptr,
    D,
    L,
    BLOCK_C: tl.constexpr,
    BLOCK_T: tl.constexpr,
    KW: tl.constexpr,
    HAS_BIAS: tl.constexpr,
    SILU: tl.constexpr,
    FULL_C: tl.constexpr,
    FULL_T: tl.constexpr,
):
    # Axis 0 is the token axis: neighbouring programs cover neighbouring token
    # blocks of the same channel block.
    pid_t = tl.program_id(0)
    pid_c = tl.program_id(1)

    idx_c = pid_c * BLOCK_C + tl.arange(0, BLOCK_C)
    idx_t = pid_t * BLOCK_T + tl.arange(0, BLOCK_T)
    mask_c = idx_c < D

    acc = tl.zeros((BLOCK_C, BLOCK_T), dtype=tl.float32)

    # The wrapper only ever passes `.contiguous()` tensors, so the row stride is
    # L and every element stride is 1: what round 3 carried as seven runtime
    # scalars is a function of the two it still receives. `x_rows` and `w_row`
    # are hoisted because they do not depend on the tap.
    x_rows = x_ptr + idx_c[:, None] * L
    w_row = w_ptr + idx_c * KW

    # Tap j reads the window shifted by -(KW-1)+j. Adjacent taps touch the same
    # cache lines, so reloading beats a rolling register window: every lane stays
    # busy and the taps form independent FMA chains. Columns left of the sequence
    # are the reference's zero pad -- a masked-off lane returns 0.0 and the tap
    # contributes nothing. The right-hand bound only matters when a tile
    # straddles the end of a row, which FULL_T rules out at launch time, and the
    # channel bound only matters on a partial channel block, which FULL_C does.
    # The token index is an arange shifted by a fixed constant, so the run is
    # contiguous by construction; say so explicitly, because this load is the
    # whole point of the tile shape and it should not have to be re-derived from
    # the address expression after the shift.
    idx_t = tl.max_contiguous(tl.multiple_of(idx_t, BLOCK_T), BLOCK_T)
    for j in tl.static_range(KW):
        col = idx_t - (KW - 1) + j
        if FULL_T:
            in_x = col >= 0
        else:
            in_x = (col >= 0) & (col < L)
        if FULL_C:
            mask_x = in_x[None, :]
        else:
            mask_x = mask_c[:, None] & in_x[None, :]
        x_tile = tl.load(x_rows + col[None, :], mask=mask_x, other=0.0)
        if FULL_C:
            w_col = tl.load(w_row + j)
        else:
            w_col = tl.load(w_row + j, mask=mask_c, other=0.0)
        # Widen deliberately: a bf16 x bf16 product is exact in fp32 (the result
        # needs 16 mantissa bits at most), so the only rounding on the tap is the
        # one below, independent of whether this backend widens or narrows a
        # bf16 x bf16 product.
        prod = x_tile.to(tl.float32) * w_col.to(tl.float32)[:, None]
        # Round the product onto the bf16 grid by bit surgery: integer-only, so
        # no optimiser can fold it away as a redundant widen/narrow cast pair.
        # Adding 0x7FFF plus the mantissa LSB before clearing the low 16 bits is
        # round-to-nearest-even, the same rule the reference's cast applies, and
        # the signed carry runs on the magnitude because the sign bit sits above
        # the field being rounded, so it cannot disturb the sign.
        u = prod.to(tl.int32, bitcast=True)
        u = u + 32767 + ((u >> 16) & 1)
        acc += (u - (u & 65535)).to(tl.float32, bitcast=True)

    if HAS_BIAS:
        if FULL_C:
            b_tile = tl.load(b_ptr + idx_c)
        else:
            b_tile = tl.load(b_ptr + idx_c, mask=mask_c, other=0.0)
        acc += b_tile.to(tl.float32)[:, None]

    if SILU:
        acc = acc / (1.0 + tl.exp(-acc))

    # Land on the bf16 grid before the store cast with the same nearest-even
    # rule, so the final narrowing is exact and does not depend on the backend's
    # float-cast rounding mode.
    u = acc.to(tl.int32, bitcast=True)
    u = u + 32767 + ((u >> 16) & 1)
    out_tile = (u - (u & 65535)).to(tl.float32, bitcast=True).to(o_ptr.dtype.element_ty)

    o_ptrs = o_ptr + idx_c[:, None] * L + idx_t[None, :]
    if FULL_C and FULL_T:
        tl.store(o_ptrs, out_tile)
    elif FULL_C:
        in_o = idx_t < L
        tl.store(o_ptrs, out_tile, mask=in_o[None, :])
    else:
        in_o = idx_t < L
        tl.store(o_ptrs, out_tile, mask=mask_c[:, None] & in_o[None, :])


# ---------------------------------------------------------------------------
# Host side.
# ---------------------------------------------------------------------------

# (D, L, KW, SILU, HAS_BIAS) -> plan tuple, see _plan. `_plan` is a pure
# function of the fixture geometry that returns only geometry, so a cached entry
# cannot carry a value from one fixture to another.
_PLANS = {}


def _act_mode(inputs, key):
    """Map the activation scalar to a flag without touching tensor values."""
    if key in inputs:
        try:
            return _ACT_MODE[inputs[key]]
        except KeyError:
            return 0
    return 0


def _bias_flag(inputs):
    """1 when inputs carries a real bias tensor, 0 when it is absent or None."""
    if "bias" not in inputs:
        return 0
    try:
        inputs["bias"].contiguous()
    except AttributeError:
        return 0
    return 1


def _bias_or_weight(inputs, weight):
    """Bias tensor when present, else the weight; the kernel never reads this
    pointer unless the HAS_BIAS branch is live."""
    if "bias" not in inputs:
        return weight.contiguous()
    try:
        return inputs["bias"].contiguous()
    except AttributeError:
        return weight.contiguous()


def _pick_blocks(D: int, L: int) -> tuple[int, int]:
    """Power-of-two tile of <= _BLOCK_LANES lanes, token axis filled first.

    The token block is the widest power of two at or below _MAX_BLOCK_T that
    divides L and still leaves the lane budget to a channel block of at least
    _MIN_BLOCK_C: a block that divides L wastes no lane on a padded tail, and
    the cap is what keeps the channel axis from being squeezed out of the
    budget. If nothing divides above the 16-lane floor the least-padded
    candidate wins instead, tie-broken toward the longer run. Channels then take
    the rest of the budget -- that axis adds rows at stride L and buys no
    contiguity, so it must not compete with the axis the pipe consumes.
    """
    np2_c = triton.next_power_of_2(max(D, 1))
    np2_t = triton.next_power_of_2(max(L, 1))
    cap_t = min(np2_t, _MAX_BLOCK_T)
    if cap_t < _MIN_BLOCK_T:
        # Degenerate row: keep the 16-lane vector floor and buy channels instead.
        return max(min(np2_c, _BLOCK_LANES // _MIN_BLOCK_T), _MIN_BLOCK_C), _MIN_BLOCK_T

    # Widest divisor of L that leaves the budget's remainder to channels.
    block_t = 0
    b = cap_t
    while b >= _MIN_BLOCK_T:
        if L % b == 0 and _BLOCK_LANES // b >= _MIN_BLOCK_C:
            block_t = b
            break
        b //= 2

    if block_t == 0:
        # No divisor above the floor: minimise the padded tail.
        best_span = 0
        b = _MIN_BLOCK_T
        while b <= cap_t:
            span = triton.cdiv(L, b) * b
            if block_t == 0 or span <= best_span:
                best_span = span
                block_t = b
            b *= 2

    block_c = max(min(np2_c, _BLOCK_LANES // block_t), _MIN_BLOCK_C)
    return block_c, block_t


def _plan(D: int, L: int, kw: int, silu_mode: int, bias_flag: int):
    """Tile, grid and full-tile flags for a fixture.

    Positional layout: 0 BLOCK_C, 1 BLOCK_T, 2 grid_t, 3 grid_c, 4 FULL_T,
    5 FULL_C, 6 KW.
    """
    shape_key = (D, L, kw, silu_mode, bias_flag)
    try:
        return _PLANS[shape_key]
    except KeyError:
        pass
    block_c, block_t = _pick_blocks(D, L)
    # Token axis first: neighbouring programs read neighbouring token blocks.
    grid_t = (L + block_t - 1) // block_t
    grid_c = (D + block_c - 1) // block_c
    entry = (
        block_c,
        block_t,
        grid_t,
        grid_c,
        1 if L % block_t == 0 else 0,
        1 if D % block_c == 0 else 0,
        kw,
    )
    _PLANS[shape_key] = entry
    return entry


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weight = inputs["weight"]
    silu_mode = _act_mode(inputs, "activation")

    x_c = x.contiguous()
    w_c = weight.contiguous()
    bias_flag = _bias_flag(inputs)
    b_c = _bias_or_weight(inputs, w_c)

    dim = int(x_c.shape[0])
    seqlen = int(x_c.shape[1])
    kw = int(w_c.shape[-1])

    out = torch.empty((dim, seqlen), dtype=x_c.dtype, device=x_c.device)
    if dim == 0 or seqlen == 0 or kw == 0:
        return {"output": out}

    plan = _plan(dim, seqlen, kw, silu_mode, bias_flag)

    # b_ptr is only read inside the HAS_BIAS branch, so a missing or None bias
    # still gets a real tensor and the constexpr drops the dead code.
    _causal_conv1d_fwd_ascend[(plan[2], plan[3])](
        x_c,
        w_c,
        b_c,
        out,
        dim,
        seqlen,
        BLOCK_C=plan[0],
        BLOCK_T=plan[1],
        KW=plan[6],
        HAS_BIAS=bias_flag,
        SILU=silu_mode,
        FULL_C=plan[5],
        FULL_T=plan[4],
    )

    return {"output": out}
