"""Triton-Ascend port of the frozen `_causal_conv1d_fwd_kernel` (L3_09).

Depthwise causal 1-D convolution over one sequence (Mamba prefill):

    out[d, t] = sum_{j=0..KW-1} x[d, t - (KW-1) + j] * w[d, j]  (+ bias[d])
    out       = out / (1 + exp(-out))      only when activation is silu/swish

with x: [dim, seqlen], weight: [dim, KW], bias: [dim], all bfloat16, and the
result returned as [dim, seqlen] bfloat16.

Shape of the computation
------------------------
Upstream walks the token axis with a scalar loop, one [BLOCK_N] channel vector
per token, and carries the length-KW sliding window in the col0..col3
registers. Short vectors and a serial loop as long as the sequence are a poor
fit for the Ascend vector cores, so here the same math runs on a
two-dimensional [BLOCK_D, BLOCK_L] tile: tap j reads the token tile at the
constant offset `t - (KW - 1) + j`, and the left zero pad becomes a mask on
that offset rather than carried state. Each tap load is contiguous along the
token axis, the KW overlapping tiles are served straight from cache, and no
serial token loop is left in the program.

The continuous-batching machinery around the frozen launcher (conv-state cache
lines, query_start_loc segmentation, batch/chunk scheduler pointers, APC
bookkeeping) is inert for these fixtures: a single sequence with no prior
state, so the window to the left of token 0 is zeros and every output token
depends on x alone. That plumbing is therefore not reproduced; the arithmetic
below is unchanged.

Numerics: why the per-tap rounding is done with integer bit work
----------------------------------------------------------------
The tolerance is atol = rtol = 1e-3 on a bfloat16 result, and one bfloat16 step
at magnitude 1 is 0.4 percent, so the comparison cannot absorb a single
least-significant-bit flip. Bit-exact agreement with the reference is the only
safe target, and the reference rounds *each tap product* to bfloat16 before it
enters the fp32 sum:

    prod = (win * wf).to(bfloat16).to(float32);  y = prod.sum(-1)

Round 1 of this port wrote that step as `(matrix_x * matrix_w).to(tl.bfloat16)
.to(tl.float32)`, and the on-device result came out as the *unrounded* fp32
product sum. Replaying that single deviation on CPU reproduces the round-1
report shape for shape: max_abs 0.0312 on P1/P13, 0.0625 on P2/P3/P4/P8,
0.0156 on P27/H2, a huge max_rel where the reference is near zero, and ~17
percent of elements differing. That pins the cause. A cast pair sitting between
a multiply and an add is not a safe way to ask for a rounding: the backend
widens bfloat16 arithmetic to fp32, contracts multiply-and-add into a fused
form, and folds a narrowing back to fp32 into nothing.

So each tap term is rounded by hand on the fp32 bit pattern. The fp32 product of
two bfloat16 operands is exact (8-bit significands give at most 16 bits, well
inside fp32's 24), and these five integer operations narrow to bfloat16 with
round-to-nearest-even while keeping the value in fp32:

    bits = bitcast_i32(v);  bits += 0x7FFF + ((bits >> 16) & 1);
    v = bitcast_f32((bits >> 16) << 16)

The added term is round-half-to-even: 0x7FFF plus the mantissa bit that survives
the truncation. `(bits >> 16) << 16` clears the low 16 bits, and an arithmetic
shift pair needs no unsigned masking for negative values. The ladder is pure
integer work, which no float contraction or cast folding can step across, so the
rounding reaches the hardware. It was checked on CPU against torch's own
fp32 -> bfloat16 -> fp32 round trip over 8M values spanning negatives, zero,
bfloat16 subnormals and magnitudes up to 100: no difference.

The same forced rounding is applied once more to the accumulator before the
store. There it is a guard rather than a semantic change: the value already
carries the fp32 -> bfloat16 conversion, so handing the store path a
bfloat16-representable fp32 makes the final narrowing exact whatever rounding
mode it happens to use.

Everything else keeps the round-1 order, which is the reference order: fp32
accumulator, taps summed in increasing j, bias widened to fp32 and added after
the tap sum, SiLU evaluated on the fp32 accumulator as `acc / (1 + exp(-acc))`,
and a single narrowing to bfloat16 at the store. The tile geometry, block
heuristic and launch are unchanged from round 1, so the rounding ladder is the
only difference in this file.
"""
from __future__ import annotations

import torch
import triton
import triton.language as tl


@triton.jit
def _rne_bf16_in_f32(v):
    """Round an fp32 tensor to bfloat16 precision, staying in fp32.

    Integer-only, so the rounding cannot be folded away by float-level
    contraction, nor by a cast the backend decides to widen back out.
    """
    bits = v.to(tl.int32, bitcast=True)
    bits = bits + 32767 + ((bits >> 16) & 1)
    return ((bits >> 16) << 16).to(tl.float32, bitcast=True)


@triton.jit
def _causal_conv1d_fwd_npu(
    x_ptr,
    w_ptr,
    bias_ptr,
    o_ptr,
    dim,
    seqlen,
    stride_x_dim,
    stride_x_token,
    stride_w_dim,
    stride_w_width,
    stride_o_dim,
    stride_o_token,
    HAS_BIAS: tl.constexpr,
    ROUND_TAPS: tl.constexpr,
    KERNEL_WIDTH: tl.constexpr,
    SILU_ACTIVATION: tl.constexpr,
    BLOCK_D: tl.constexpr,
    BLOCK_L: tl.constexpr,
):
    pid_d = tl.program_id(0)
    pid_l = tl.program_id(1)

    idx_d = pid_d * BLOCK_D + tl.arange(0, BLOCK_D)
    idx_t = pid_l * BLOCK_L + tl.arange(0, BLOCK_L)
    mask_d = idx_d < dim
    mask_d_row = mask_d[:, None]

    # Row base of the x tile; the tap loop only shifts the token offset.
    x_row = x_ptr + idx_d[:, None] * stride_x_dim
    w_row = w_ptr + idx_d * stride_w_dim

    acc = tl.zeros((BLOCK_D, BLOCK_L), dtype=tl.float32)
    for j in tl.static_range(0, KERNEL_WIDTH):
        # Tap j reads token t - (KERNEL_WIDTH - 1) + j. Offsets below 0 are
        # the causal left pad, which contributes an exact zero.
        cols = idx_t[None, :] - (KERNEL_WIDTH - 1) + j
        mask_x = mask_d_row & (cols >= 0) & (cols < seqlen)
        matrix_x = tl.load(x_row + cols * stride_x_token, mask=mask_x, other=0.0)
        matrix_w = tl.load(w_row + j * stride_w_width, mask=mask_d, other=0.0)
        # The fp32 product of two bfloat16 operands is exact; narrowing it by
        # hand is what puts a bfloat16-rounded term into the accumulator.
        tap = matrix_x.to(tl.float32) * matrix_w.to(tl.float32)[:, None]
        if ROUND_TAPS:
            tap = _rne_bf16_in_f32(tap)
        acc += tap

    if HAS_BIAS:
        channel_bias = tl.load(bias_ptr + idx_d, mask=mask_d, other=0.0)
        acc += channel_bias.to(tl.float32)[:, None]

    if SILU_ACTIVATION:
        acc = acc / (1.0 + tl.exp(-acc))

    if ROUND_TAPS:
        # Already bfloat16-exact, so the store conversion cannot round.
        acc = _rne_bf16_in_f32(acc)

    out = acc.to(o_ptr.dtype.element_ty)
    mask_o = mask_d_row & (idx_t < seqlen)[None, :]
    o_ptrs = o_ptr + idx_d[:, None] * stride_o_dim + idx_t[None, :] * stride_o_token
    tl.store(o_ptrs, out, mask=mask_o)


# Elements per program, chosen so the fp32 accumulator plus the bfloat16 tap
# tiles stay inside the on-core buffer while the token axis stays wide enough
# for full-width vector traffic.
_TILE_ELEMENTS = 4096


def _pick_blocks(dim: int, seqlen: int):
    block_l = min(512, max(32, triton.next_power_of_2(seqlen)))
    block_d = min(triton.next_power_of_2(dim), max(4, _TILE_ELEMENTS // block_l))
    return block_d, block_l


def _optional(inputs: dict, key: str):
    try:
        return inputs[key]
    except KeyError:
        return None


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weight = inputs["weight"]
    bias = _optional(inputs, "bias")
    activation = _optional(inputs, "activation")

    if not x.is_contiguous():
        x = x.contiguous()
    if not weight.is_contiguous():
        weight = weight.contiguous()

    # A null bias entry is possible even when the key is present, so gate on
    # the object rather than on key presence and keep a real tensor in the
    # unused pointer slot.
    has_bias = bias is not None
    bias_arg = bias.contiguous() if has_bias else weight

    dim, seqlen = x.shape
    kernel_width = weight.shape[-1]

    out = torch.empty_like(x)
    if dim == 0 or seqlen == 0:
        return {"output": out}

    block_d, block_l = _pick_blocks(dim, seqlen)
    grid = (triton.cdiv(dim, block_d), triton.cdiv(seqlen, block_l))

    _causal_conv1d_fwd_npu[grid](
        x,
        weight,
        bias_arg,
        out,
        dim,
        seqlen,
        x.stride(0),
        x.stride(1),
        weight.stride(0),
        weight.stride(1),
        out.stride(0),
        out.stride(1),
        HAS_BIAS=has_bias,
        # The hand rounding reproduces a bfloat16 narrowing, which is only
        # meaningful while operands and result share that format.
        ROUND_TAPS=(x.dtype == torch.bfloat16 and out.dtype == torch.bfloat16),
        KERNEL_WIDTH=kernel_width,
        SILU_ACTIVATION=activation in ("silu", "swish"),
        BLOCK_D=block_d,
        BLOCK_L=block_l,
    )

    return {"output": out}


run = npu_triton_impl
