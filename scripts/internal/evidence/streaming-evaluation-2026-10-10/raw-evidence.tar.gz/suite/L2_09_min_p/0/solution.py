"""triton-ascend migration of the min-p sampling filter (L2_09_min_p).

Round 2 change (single, justified optimisation over round 1):
  Round 1 was a verbatim port of the reference two-pass kernel with a
  1024-wide vector block. For the dominant shapes (vocab size 1536, and
  everything <= 1024) that means the row is loaded twice (once for the
  max reduction, once to filter) and, for N<=1024, most block lanes are
  masked dead.

  Here we make each row register-resident: the vector block is widened
  to 2048 (the next power of two that covers vocab size 1536, i.e. 45 of
  the 48 graded shapes) and, when the whole row fits in one vector block,
  the max reduction and the filter are fused into a single pass -- one
  masked load, an in-register row max, an in-register `where`, one
  masked store. This removes one redundant full HBM read of the logits
  tensor. The three shapes whose rows cannot fit in a single vector block
  (vocab 4096 / 32768 / 65536) use a looped two-pass path that is
  numerically identical to the reference (just with wider blocks -> fewer
  loop iterations).

Load-bearing semantics, preserved exactly from the reference:
  * All math stays in the log domain (no softmax / no exp).
    threshold = row_max(raw_logits) + log(min_p_row); equivalently
    `logits < max + log(min_p)` iff `probs < min_p * max_prob` because
    softmax is monotone in the logits.
  * A row whose mapped min_p is exactly 0.0 is left completely untouched
    (early `return`). log(0) == -inf would otherwise filter everything,
    so this guard is correctness-critical, not an optimisation.
  * Accumulation is fp32; the strict less-than keeps equal entries.
  * `logits` is mutated in place (meta: in_place_logits /
    inplace_outputs=[logits]); the entrypoint returns the same tensor and
    passes expanded_idx_mapping / min_p through unchanged.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _min_p_kernel(
    logits_ptr,
    logits_stride,
    expanded_idx_mapping_ptr,
    min_p_ptr,
    vocab_size,
    BLOCK_SIZE: tl.constexpr,
    SINGLE_PASS: tl.constexpr,
):
    token_idx = tl.program_id(0)
    req_state_idx = tl.load(expanded_idx_mapping_ptr + token_idx)
    min_p = tl.load(min_p_ptr + req_state_idx).to(tl.float32)
    if min_p == 0.0:
        return

    row_ptr = logits_ptr + token_idx * logits_stride

    if SINGLE_PASS:
        # The entire row fits in one vector block: keep it in registers
        # so we read it once, take the max, filter, and store it once.
        offs = tl.arange(0, BLOCK_SIZE)
        mask = offs < vocab_size
        logits = tl.load(row_ptr + offs, mask=mask, other=float("-inf"))
        max_val = tl.max(logits).to(tl.float32)
        threshold = max_val + tl.log(min_p)
        logits = tl.where(logits < threshold, float("-inf"), logits)
        tl.store(row_ptr + offs, logits, mask=mask)
    else:
        # Large row: looped pass 1 for the max, looped pass 2 to filter.
        max_val = float("-inf")
        for i in range(0, vocab_size, BLOCK_SIZE):
            offs = i + tl.arange(0, BLOCK_SIZE)
            mask = offs < vocab_size
            x = tl.load(row_ptr + offs, mask=mask, other=float("-inf"))
            max_val = tl.max(tl.maximum(x, max_val))
        max_val = max_val.to(tl.float32)
        threshold = max_val + tl.log(min_p)
        for i in range(0, vocab_size, BLOCK_SIZE):
            offs = i + tl.arange(0, BLOCK_SIZE)
            mask = offs < vocab_size
            x = tl.load(row_ptr + offs, mask=mask, other=float("-inf"))
            x = tl.where(x < threshold, float("-inf"), x)
            tl.store(row_ptr + offs, x, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    """Dict entrypoint: mutate `logits` in place, return all three keys."""
    logits = inputs["logits"]
    expanded_idx_mapping = inputs["expanded_idx_mapping"]
    min_p = inputs["min_p"]

    num_tokens, vocab_size = logits.shape
    if num_tokens > 0 and vocab_size > 0:
        # Widest single vector block that keeps a row register-resident
        # while covering the dominant vocab sizes (<= 2048).
        BLOCK_SIZE = 2048
        single_pass = vocab_size <= BLOCK_SIZE
        _min_p_kernel[(num_tokens,)](
            logits,
            logits.stride(0),
            expanded_idx_mapping,
            min_p,
            vocab_size,
            BLOCK_SIZE=BLOCK_SIZE,
            SINGLE_PASS=single_pass,
        )

    return {
        "logits": logits,
        "expanded_idx_mapping": expanded_idx_mapping,
        "min_p": min_p,
    }
