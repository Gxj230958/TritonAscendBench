"""triton-ascend migration of the upstream _min_p_kernel (L2_09_min_p).

Semantics (load-bearing, preserved exactly from the upstream kernel):
  * For every token row we compute the row-wise max of the raw logits
    (all math stays in the log domain; no softmax exponentials).
  * threshold = max_val + log(min_p_row)
  * Any entry with logits < threshold is set to -inf, in place.
  * Rows whose mapped min_p is exactly 0.0 are left untouched (the
    upstream kernel returns early; in that case threshold would be -inf
    and every entry would be filtered, which is not the upstream
    behavior).

The grid is one program per token row (program_id(0) == token index),
which matches the upstream launch so each row is independent.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _min_p_kernel(
    logits_ptr,
    logits_stride,
    expanded_idx_mapping_ptr,
    min_p_ptr,
    vocab_size,
    BLOCK_SIZE: tl.constexpr,
):
    token_idx = tl.program_id(0)
    req_state_idx = tl.load(expanded_idx_mapping_ptr + token_idx)
    min_p = tl.load(min_p_ptr + req_state_idx).to(tl.float32)
    if min_p == 0.0:
        return

    # Pass 1: row max of the raw logits, accumulated in fp32.
    max_val = float("-inf")
    for i in range(0, vocab_size, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        mask = block < vocab_size
        logits = tl.load(
            logits_ptr + token_idx * logits_stride + block,
            mask=mask,
            other=float("-inf"),
        )
        max_val = tl.max(tl.maximum(logits, max_val))
    max_val = max_val.to(tl.float32)

    # Log-space threshold: log(p) + log(min_p) == log(min_p * p).
    threshold = max_val + tl.log(min_p)

    # Pass 2: filter and store back in place (fp32 in, fp32 out).
    for i in range(0, vocab_size, BLOCK_SIZE):
        block = i + tl.arange(0, BLOCK_SIZE)
        mask = block < vocab_size
        logits = tl.load(
            logits_ptr + token_idx * logits_stride + block,
            mask=mask,
            other=float("-inf"),
        )
        logits = tl.where(logits < threshold, float("-inf"), logits)
        tl.store(logits_ptr + token_idx * logits_stride + block, logits, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    """Dict entrypoint: mutate `logits` in place, return all three keys."""
    logits = inputs["logits"]
    expanded_idx_mapping = inputs["expanded_idx_mapping"]
    min_p = inputs["min_p"]

    num_tokens, vocab_size = logits.shape
    if num_tokens > 0 and vocab_size > 0:
        BLOCK_SIZE = 1024
        _min_p_kernel[(num_tokens,)](
            logits,
            logits.stride(0),
            expanded_idx_mapping,
            min_p,
            vocab_size,
            BLOCK_SIZE=BLOCK_SIZE,
        )

    return {
        "logits": logits,
        "expanded_idx_mapping": expanded_idx_mapping,
        "min_p": min_p,
    }
