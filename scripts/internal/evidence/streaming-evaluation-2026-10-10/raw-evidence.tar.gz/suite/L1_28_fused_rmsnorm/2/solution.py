"""triton-ascend migration of the fused per-row RMSNorm operator
(L1_28_fused_rmsnorm, upstream vendored snapshot at commit 409d350,
function fused_rmsnorm_kernel).

Math (identical to upstream, load-bearing order preserved):
    a   = x.to(float32)                       # bf16 -> f32 upcast first
    rms = sqrt(sum(a*a, dim=-1) / D + eps)    # f32 reduction, eps added last
    out = a / rms * w.to(float32)             # divide, then scale
    store(out)                                # implicit cast back to bf16

One program per row. Rows wider than BLOCK_SIZE are processed in
fixed-size chunks with an f32 accumulator, so full-row correctness is
preserved even at D = 32768.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def fused_rmsnorm_kernel(
    output_ptr,
    activ_ptr,
    weight_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Fast path, mathematically identical to the frozen upstream kernel
    (BLOCK_SIZE >= hidden_dim): one load of the row, f32 reduction,
    store in the input dtype."""
    pid = tl.program_id(axis=0).to(tl.int64)
    base = pid * hidden_dim
    offs = tl.arange(0, BLOCK_SIZE)
    mask = offs < hidden_dim

    a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
    a = a_.to(tl.float32)
    rms = tl.sqrt(tl.sum(a * a, axis=0) / hidden_dim + eps)

    w1_ = tl.load(weight_ptr + offs, mask=mask, other=0.0)
    w1 = w1_.to(tl.float32)
    a_rms = a / rms * w1
    tl.store(output_ptr + base + offs, a_rms, mask=mask)


@triton.jit
def rmsnorm_chunked_kernel(
    output_ptr,
    activ_ptr,
    weight_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """General path: D > BLOCK_SIZE, row processed in f32-accumulated
    chunks (two passes over the row)."""
    pid = tl.program_id(axis=0).to(tl.int64)
    base = pid * hidden_dim

    sum_sq = 0.0
    for start in range(0, hidden_dim, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim
        a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
        a = a_.to(tl.float32)
        sum_sq += tl.sum(a * a, axis=0)

    rms = tl.sqrt(sum_sq / hidden_dim + eps)

    for start in range(0, hidden_dim, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim
        a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
        a = a_.to(tl.float32)
        w1_ = tl.load(weight_ptr + offs, mask=mask, other=0.0)
        w1 = w1_.to(tl.float32)
        a_rms = a / rms * w1
        tl.store(output_ptr + base + offs, a_rms, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weight = inputs["weight"]
    eps = inputs["eps"]  # Python scalar per shapes.yaml (kind: scalar)

    assert x.dim() == 2
    bs, hidden_dim = x.shape
    output = torch.empty_like(x)

    # Fast path: the whole row fits in one block -> single load/store.
    if hidden_dim <= 8192:
        BLOCK_SIZE = max(triton.next_power_of_2(hidden_dim), 16)
        kernel = fused_rmsnorm_kernel
    else:
        # Wide rows (D up to 32768): fixed-size chunks, f32 accumulator.
        BLOCK_SIZE = 8192
        kernel = rmsnorm_chunked_kernel

    kernel[(bs,)](
        output,
        x,
        weight,
        eps=eps,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=4,
    )
    return {"output": output}
