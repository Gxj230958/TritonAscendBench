"""Round 2 candidate.

Change vs round 1 (single, evidence-based):
    Round 1 failed on exactly one shape, P4 (B=8, D=4096), with a one
    bf16-ulp deviation (max_abs=0.00195, max_rel=0.00704).  Every other
    reduction geometry from round 1 passed cleanly:
      * fully-active single tiles at D in {2..2048, 8192},
      * masked single tiles at D in {3, 6, 96, ...3072, 6144}
        (inactive lanes are NOT the trigger),
      * the chunked BLOCK=8192 left-to-right f32 accumulation at
        D in {16384, 32768}.
    The only geometry that diverged is the single fully-active
    BLOCK=4096 reduction tile, i.e. D=4096 on the one-block fast path.
    Round 2 therefore reroutes D=4096 to the chunked kernel with
    BLOCK=1024: each per-chunk reduction uses the exact geometry that
    passed at D=1024, and the scalar f32 sum-of-chunks order is the same
    left-to-right pattern that matched the reference at D=32768.  All
    other dispatch decisions and both kernels are unchanged.

Math (identical to upstream, load-bearing order preserved):
    a   = x.to(float32)                       # bf16 -> f32 upcast first
    rms = sqrt(sum(a*a, dim=-1) / D + eps)    # f32 reduction, eps added last
    out = a / rms * w.to(float32)             # divide, then scale
    store(out)                                # implicit cast back to bf16

One program per row. Rows wider than BLOCK_SIZE are processed in
fixed-size chunks with an f32 accumulator, so full-row correctness is
preserved even at D = 32768.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def fused_rmsnorm_kernel(
    output_ptr,
    activ_ptr,
    weight_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """Fast path, mathematically identical to the frozen upstream kernel
    (BLOCK_SIZE >= hidden_dim): one load of the row, f32 reduction,
    store in the input dtype."""
    pid = tl.program_id(axis=0).to(tl.int64)
    base = pid * hidden_dim
    offs = tl.arange(0, BLOCK_SIZE)
    mask = offs < hidden_dim

    a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
    a = a_.to(tl.float32)
    rms = tl.sqrt(tl.sum(a * a, axis=0) / hidden_dim + eps)

    w1_ = tl.load(weight_ptr + offs, mask=mask, other=0.0)
    w1 = w1_.to(tl.float32)
    a_rms = a / rms * w1
    tl.store(output_ptr + base + offs, a_rms, mask=mask)


@triton.jit
def rmsnorm_chunked_kernel(
    output_ptr,
    activ_ptr,
    weight_ptr,
    eps: tl.constexpr,
    hidden_dim: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    """General path: D > BLOCK_SIZE, row processed in f32-accumulated
    chunks (two passes over the row)."""
    pid = tl.program_id(axis=0).to(tl.int64)
    base = pid * hidden_dim

    sum_sq = 0.0
    for start in range(0, hidden_dim, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim
        a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
        a = a_.to(tl.float32)
        sum_sq += tl.sum(a * a, axis=0)

    rms = tl.sqrt(sum_sq / hidden_dim + eps)

    for start in range(0, hidden_dim, BLOCK_SIZE):
        offs = start + tl.arange(0, BLOCK_SIZE)
        mask = offs < hidden_dim
        a_ = tl.load(activ_ptr + base + offs, mask=mask, other=0.0)
        a = a_.to(tl.float32)
        w1_ = tl.load(weight_ptr + offs, mask=mask, other=0.0)
        w1 = w1_.to(tl.float32)
        a_rms = a / rms * w1
        tl.store(output_ptr + base + offs, a_rms, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    x = inputs["x"]
    weight = inputs["weight"]
    eps = inputs["eps"]  # Python scalar per shapes.yaml (kind: scalar)

    assert x.dim() == 2
    bs, hidden_dim = x.shape
    output = torch.empty_like(x)

    # Fast path: the whole row fits in one block -> single load/store.
    if hidden_dim <= 8192:
        if hidden_dim == 4096:
            # Fully-active BLOCK=4096 single-tile reduction deviates by one
            # bf16 ulp vs the reference (round 1, P4).  4 x 1024 chunks with
            # f32 accumulator reproduce the verified-passing geometries.
            BLOCK_SIZE = 1024
            kernel = rmsnorm_chunked_kernel
        else:
            BLOCK_SIZE = max(triton.next_power_of_2(hidden_dim), 16)
            kernel = fused_rmsnorm_kernel
    else:
        # Wide rows (D up to 32768): fixed-size chunks, f32 accumulator.
        BLOCK_SIZE = 8192
        kernel = rmsnorm_chunked_kernel

    kernel[(bs,)](
        output,
        x,
        weight,
        eps=eps,
        hidden_dim=hidden_dim,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=4,
    )
    return {"output": output}
