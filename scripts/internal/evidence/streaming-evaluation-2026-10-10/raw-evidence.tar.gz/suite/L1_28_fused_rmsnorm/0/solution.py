"""Triton-Ascend implementation of fused RMSNorm (task L1_28_fused_rmsnorm).

Per-row RMSNorm with a learnable scale:

    rms = sqrt(mean(x * x over the row) + eps)
    out = (x / rms) * weight

Numerics follow the reference semantics exactly:
- x and weight are loaded as bfloat16 and upcast to float32 before any
  arithmetic;
- the sum of squares and the rms are computed in float32;
- the elementwise op order is divide first, then multiply by the weight;
- the float32 result is stored into a bfloat16 output tensor (implicit
  downcast on store).

Round 5 change vs round 4 (targeted P4 correctness fix).

Rounds 1-4 all failed only P4 (B=8, D=4096) with a bit-identical
signature: max_abs=0.00195 (exactly one bfloat16 ulp for a value of
magnitude ~0.277) and max_rel=0.00704. The failure did not move under
three different sum-of-squares layouts

  round 1: 1024-chunked partial vectors + final tree,
  round 2: one whole-row 4096-wide tree,
  round 3: two 2048-wide half-row trees + one sequential add,

and round 4's Newton sharpening of the row-scalar sqrt left the
signature untouched as well (that step reuses the same fast division
for m / rms, so it cannot move a fast-division-caused boundary flip).
That rules out both the sum-of-squares accumulation order and the
row-scalar sqrt: changing either moves the row rms by a data-dependent
amount and would shift or remove the borderline element. The only
remaining step that is applied per element, depends on that element's
own value, and was identical across all four kernel layouts is the
normalization division a / rms.

On this backend a plain fp32 `a / rms` lowers to the fast approximate
vector division, whose result can sit a few fp32 ulps away from the
correctly-rounded IEEE quotient used by the reference side. When the
exact quotient of some element lands within that error band next to a
bfloat16 rounding boundary, the approximate division pushes the stored
bfloat16 value to the adjacent representable number: exactly one
element, one bfloat16 ulp, always the same element for fixed inputs --
the observed signature. Magnitude check: an fp32 division error of
~2^-23 relative against a bfloat16 boundary window of ~2^-8 relative
gives a per-element flip probability of ~1e-4, so over the 32768
outputs of P4 about one flip is expected, and exactly one is observed.

The fix makes every fp32 division and the square root correctly
rounded in software, using only plain arithmetic (no special math
intrinsics):

1. `_precise_div(a, b)`: Dekker/Veltkamp correction of the hardware
   quotient. Veltkamp splitting with SPLIT = 1 + 2^12 = 4097 (exact in
   fp32: 24-bit mantissa) decomposes any product q*b exactly into a
   high part p_hi = fl(q*b) and an error-free low part p_lo, so the
   residual r = a - q*b is recovered exactly as (a - p_hi) - p_lo, and
   q + r/b is the correctly-rounded quotient whenever the hardware
   quotient is within a few fp32 ulps (validated on CPU for hardware
   errors up to 16 ulps with one correction step; the kernel applies
   two correction steps, which also tolerates much larger errors).
2. `_precise_sqrt(m)`: hardware sqrt followed by two Newton iterations
   r <- r + (m - r*r) / (2*r), where r*r uses the same exact Dekker
   product and the division uses `_precise_div`. One Newton step
   halves the relative error; after two steps it is below 2^-40, which
   always rounds to the correctly-rounded fp32 sqrt.

The precise division replaces the plain `/` in every spot: the row mean
ssq / D, the Newton correction (m - r*r) / (2*r), and the elementwise
normalization a / rms. The precise sqrt replaces `tl.sqrt` for the row
rms. Round 4's ad-hoc Newton step is subsumed by `_precise_sqrt` and
removed.

The other 39 shapes passed four consecutive rounds; correctly-rounded
ops only tighten the rounding there, so their proven numerics are
preserved. Everything else is kept bit-for-bit from round 4: D < 4096
uses the whole-row single-block kernel (BLOCK = next_power_of_2(max(D,
256)), one tl.sum), D >= 4096 uses the 1024-chunked two-pass kernel;
one program per row; masked lanes load 0.0 so they never affect the sum
of squares and are never stored.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _dekker_two_prod(q, b):
    # Exact product decomposition q * b = p_hi + p_lo in float32 via
    # Veltkamp splitting (SPLIT = 1 + 2^12 fits fp32's 24-bit mantissa).
    SPLIT = 4097.0
    t = q * SPLIT
    q_hi = t - (t - q)
    q_lo = q - q_hi
    u = b * SPLIT
    b_hi = u - (u - b)
    b_lo = b - b_hi
    p_hi = q * b
    p_lo = q_lo * b_lo - (((p_hi - q_hi * b_hi) - q_lo * b_hi) - q_hi * b_lo)
    return p_hi, p_lo


@triton.jit
def _precise_div(a, b):
    # Correctly-rounded a / b: hardware quotient + two Dekker residual
    # corrections (see module docstring). Works for scalars and tensors.
    q = a / b
    for _ in range(2):
        p_hi, p_lo = _dekker_two_prod(q, b)
        r = (a - p_hi) - p_lo
        q = q + r / b
    return q


@triton.jit
def _precise_sqrt(m):
    # Correctly-rounded sqrt: hardware estimate + two Newton steps with
    # exact Dekker products and precise division (see module docstring).
    r = tl.sqrt(m)
    for _ in range(2):
        p_hi, p_lo = _dekker_two_prod(r, r)
        res = (m - p_hi) - p_lo
        r = r + _precise_div(res, 2.0 * r)
    return r


@triton.jit
def _fused_rmsnorm_kernel_row(
    out_ptr,
    x_ptr,
    w_ptr,
    eps: tl.constexpr,
    D: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    row_start = (pid * D).to(tl.int64)
    offs = tl.arange(0, BLOCK)
    mask = offs < D

    a = tl.load(x_ptr + row_start + offs, mask=mask, other=0.0).to(tl.float32)
    ssq = tl.sum(a * a, axis=0)
    # Correctly-rounded row mean and square root (see module docstring).
    m = _precise_div(ssq, float(D)) + eps
    rms = _precise_sqrt(m)

    w = tl.load(w_ptr + offs, mask=mask, other=0.0).to(tl.float32)
    # Correctly-rounded elementwise division, then multiply by the weight,
    # matching the reference operation order; store downcasts to bfloat16.
    y = _precise_div(a, rms) * w
    tl.store(out_ptr + row_start + offs, y, mask=mask)


@triton.jit
def _fused_rmsnorm_kernel_chunked(
    out_ptr,
    x_ptr,
    w_ptr,
    eps: tl.constexpr,
    D: tl.constexpr,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    row_start = (pid * D).to(tl.int64)
    offs = tl.arange(0, BLOCK)

    # Pass 1: accumulate the row sum of squares in float32, chunk by chunk.
    acc = tl.zeros([BLOCK], dtype=tl.float32)
    for start in range(0, D, BLOCK):
        cols = start + offs
        mask = cols < D
        a = tl.load(x_ptr + row_start + cols, mask=mask, other=0.0).to(tl.float32)
        acc += a * a
    ssq = tl.sum(acc, axis=0)
    # Correctly-rounded row mean and square root (see module docstring).
    m = _precise_div(ssq, float(D)) + eps
    rms = _precise_sqrt(m)

    # Pass 2: normalize and scale with the correctly-rounded division
    # (divide by rms, then multiply by weight), matching the reference
    # operation order; store downcasts to bfloat16.
    for start in range(0, D, BLOCK):
        cols = start + offs
        mask = cols < D
        a = tl.load(x_ptr + row_start + cols, mask=mask, other=0.0).to(tl.float32)
        w = tl.load(w_ptr + cols, mask=mask, other=0.0).to(tl.float32)
        y = _precise_div(a, rms) * w
        tl.store(out_ptr + row_start + cols, y, mask=mask)


def _next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


def npu_triton_impl(inputs: dict) -> dict:
    """Entry point: inputs dict -> dict with the normalized output tensor."""
    x = inputs["x"].contiguous()
    weight = inputs["weight"].contiguous()
    eps = inputs["eps"]

    output = torch.empty_like(x)
    B, D = x.shape

    if D < 4096:
        # Whole row in one block, mirroring the upstream GPU layout. The
        # 256-lane floor keeps the block a clean multiple of 8 warps for
        # the tiny hidden rows (D as small as 2).
        block = _next_pow2(max(D, 256))
        _fused_rmsnorm_kernel_row[(B,)](
            output,
            x,
            weight,
            eps,
            D=D,
            BLOCK=block,
            num_warps=8,
        )
    else:
        # Every D >= 4096 uses the same 1024-chunked two-pass layout that
        # passed rounds 1-4 on all wider rows.
        _fused_rmsnorm_kernel_chunked[(B,)](
            output,
            x,
            weight,
            eps,
            D=D,
            BLOCK=1024,
            num_warps=8,
        )
    return {"output": output}
