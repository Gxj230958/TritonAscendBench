"""Triton-Ascend implementation of the penalties operator (L2_10).

Semantics (see contract.md): repetition / frequency / presence penalties applied
to one row of logits per draft token, where each row's per-token counts are the
request's base generated counts PLUS the draft-window scan

    pos = expanded_local_pos[t],  start = t - pos
    for j in range(pos): counts[token_ids[start + j + 1]] += 1

Order is load-bearing and is mirrored element for element:
  1. counts = base_counts[req] + draft increments   (float32, exact integers)
  2. seen   = (counts > 0) OR prompt presence
  3. scale  = rep_penalty where seen else 1.0
     logits = logits * (1/scale if logits > 0 else scale)   <- reciprocal then
     multiply, NOT a direct divide by the penalty value
  4. logits = logits - freq_penalty * counts
  5. logits = logits - pres_penalty * (counts > 0)

The prompt mask arrives as a dense per-vocab 0/1 tensor, so the kernel reads the
element it needs directly instead of unpacking a bit-packed word.

Tiling: one program owns a BLOCK_SIZE tile of the vocab for exactly one token
row, and rows are independent (no cross-program reduction), so the tile width
never changes the arithmetic result.

The kernel reads the caller's logits and writes a separate output buffer, so one
launch covers the whole [n_tokens, vocab] tile grid and nothing is copied first.
"""

from __future__ import annotations

import torch
import triton
import triton.language as tl

# Fixed trip count for the draft scan. Every shape of this task uses a window of
# 4 (dist window_pos:4), so slots at or past `pos` are inert; the extra headroom
# keeps the accumulation correct for a slightly wider window without needing a
# device->host read of the largest position to size the loop.
_WINDOW = 8


@triton.jit
def _penalties_npu_kernel(
    logits_in_ptr,
    logits_out_ptr,
    logits_stride,
    mapping_ptr,
    local_pos_ptr,
    token_ids_ptr,
    repetition_penalty_ptr,
    frequency_penalty_ptr,
    presence_penalty_ptr,
    prompt_bin_mask_ptr,
    prompt_bin_mask_stride,
    output_bin_counts_ptr,
    output_bin_counts_stride,
    vocab_size,
    BLOCK_SIZE: tl.constexpr,
    WINDOW: tl.constexpr,
):
    row = tl.program_id(0).to(tl.int64)      # 64-bit row keeps every offset exact
    block_idx = tl.program_id(1)

    req_idx = tl.load(mapping_ptr + row)

    rep_penalty = tl.load(repetition_penalty_ptr + req_idx)
    freq_penalty = tl.load(frequency_penalty_ptr + req_idx)
    pres_penalty = tl.load(presence_penalty_ptr + req_idx)

    block = block_idx * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = block < vocab_size

    logits = tl.load(logits_in_ptr + row * logits_stride + block, mask=mask, other=0.0)
    logits = logits.to(tl.float32)

    # Base generated-token counts of this row's request (integer valued, hence
    # exact in float32); the draft scan then folds the window tokens on top.
    counts = tl.load(
        output_bin_counts_ptr + req_idx * output_bin_counts_stride + block,
        mask=mask,
        other=0.0,
    )
    counts = counts.to(tl.float32)

    prompt_bits = tl.load(
        prompt_bin_mask_ptr + req_idx * prompt_bin_mask_stride + block,
        mask=mask,
        other=0,
    )

    pos = tl.load(local_pos_ptr + row)
    start_idx = row - pos

    for j in range(WINDOW):
        # Draft slot j contributes +1 on the lane holding that slot's token, and
        # nothing once the slot index runs past this row's local position. The
        # fixed trip count means inert slots still gather, so the index is pinned
        # inside the token buffer (inert slots read their own row, whose weight
        # is zero); the second clamp covers a degenerate pos ahead of the row.
        weight = (j < pos).to(tl.float32)
        src = tl.where(j < pos, start_idx + (j + 1), row)
        src = tl.where(src < 0, 0, src)
        prev_token = tl.load(token_ids_ptr + src)
        hit = (block == prev_token).to(tl.float32)
        counts = counts + weight * hit

    output_bin_mask = counts > 0.0
    seen = output_bin_mask | (prompt_bits != 0)

    scale = tl.where(seen, rep_penalty, 1.0)
    logits = logits * tl.where(logits > 0.0, 1.0 / scale, scale)
    logits = logits - freq_penalty * counts
    logits = logits - pres_penalty * output_bin_mask.to(tl.float32)

    tl.store(logits_out_ptr + row * logits_stride + block, logits, mask=mask)


_MAX_BLOCK = 1024
_MIN_BLOCK = 32


def _block_size(vocab_size: int, num_tokens: int) -> int:
    """Power-of-two vocab tile.

    Widest tile first (fewer programs, longer vector per lane); when the token
    dimension alone cannot fill the grid, the tile shrinks so the vocab split adds
    programs. Rows are independent, so the split never changes any element value.
    """
    block = _MIN_BLOCK
    while block < vocab_size and block < _MAX_BLOCK:
        block <<= 1
    while block > _MIN_BLOCK and num_tokens * ((vocab_size + block - 1) // block) < 128:
        block >>= 1
    return block


def npu_triton_impl(inputs: dict) -> dict:
    logits = inputs["logits"]
    # Work in float32 and write a fresh buffer: the input tensor is never touched.
    src = logits if logits.dtype == torch.float32 else logits.to(torch.float32)
    src = src if src.is_contiguous() else src.contiguous()
    out = torch.empty_like(src)

    mapping = inputs["expanded_idx_mapping"].contiguous()
    local_pos = inputs["expanded_local_pos"].contiguous()
    token_ids = inputs["token_ids"].contiguous()
    counts = inputs["output_token_counts"].contiguous()
    prompt_mask = inputs["prompt_bin_mask"].contiguous()
    rep = inputs["repetition_penalty"].to(torch.float32).contiguous()
    freq = inputs["frequency_penalty"].to(torch.float32).contiguous()
    pres = inputs["presence_penalty"].to(torch.float32).contiguous()

    num_tokens, vocab_size = out.shape
    block_size = _block_size(vocab_size, num_tokens)
    num_blocks = triton.cdiv(vocab_size, block_size)

    _penalties_npu_kernel[(num_tokens, num_blocks)](
        src,
        out,
        src.stride(0),
        mapping,
        local_pos,
        token_ids,
        rep,
        freq,
        pres,
        prompt_mask,
        prompt_mask.stride(0),
        counts,
        counts.stride(0),
        vocab_size,
        BLOCK_SIZE=block_size,
        WINDOW=_WINDOW,
    )

    if out.dtype != logits.dtype:
        out = out.to(logits.dtype)
    return {"logits": out}


run = npu_triton_impl
