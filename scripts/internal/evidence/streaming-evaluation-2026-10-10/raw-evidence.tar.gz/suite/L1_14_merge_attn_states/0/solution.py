"""Triton-Ascend implementation of split-KV attention state merging.

Task: L1_14_merge_attn_states, operator merge_attn_states_kernel.
Recombines two partial attention results (prefix / suffix) produced by a
split-KV / flash-decoding attention pass using the online-softmax log-sum-exp
identity (section 2.2 of https://www.arxiv.org/pdf/2501.01005).

Layout contract:
  prefix_output, suffix_output, output      : [T, H, D]  bfloat16
  prefix_lse,   suffix_lse,   output_lse    : [H, T]     float32

The LSE tensors are head-major / token-minor: the entry for (token, head) sits
at ``head * T + token``. The state tensors are token-major. Addressing therefore
mixes two linearisations, which is the load-bearing detail of this task, so the
strides of every tensor are passed explicitly rather than assuming a packed
layout.

Numerics, kept in the same order as the fp32 specification:
  * +inf on either LSE collapses to -inf (empty-split convention),
  * max-subtracted exponentials sharing one denominator,
  * the mixing scale is formed first and only then multiplied by the state
    vectors; multiplying raw states by exp() directly can overflow,
  * arithmetic runs in fp32 and there is exactly one cast, at the store.

Tiling: one program owns a [BLOCK_H, BLOCK_D] state tile for a single token, so
the row decomposition never needs an integer divide. The LSE scalars for that
tile are gathered with the head-major stride; the state tile keeps the head
dimension contiguous in memory.

Returned surface: the merge writes `output` and `output_lse` in place, and the
entry point hands back every buffer it was given, each under its own key. The
four input tensors are never written by the kernel, so what comes back under
their keys is the caller's own storage, unchanged and unaliased.
"""

from __future__ import annotations

import triton
import triton.language as tl


@triton.jit
def _merge_attn_states_kernel(
    output,                # [T, H, D]
    output_lse,            # [H, T]
    prefix_output,         # [T, H, D]
    prefix_lse,            # [H, T]
    suffix_output,         # [T, H, D]
    suffix_lse,            # [H, T]
    num_tokens,            # T
    num_heads,             # H
    stride_po_t, stride_po_h, stride_po_d,
    stride_so_t, stride_so_h, stride_so_d,
    stride_o_t, stride_o_h, stride_o_d,
    HEAD_SIZE: tl.constexpr,
    PADDED_HEAD_SIZE: tl.constexpr,
    BLOCK_H: tl.constexpr,
):
    token_idx = tl.program_id(0)
    head_blk = tl.program_id(1)
    dim_blk = tl.program_id(2)

    head_idx = head_blk * BLOCK_H + tl.arange(0, BLOCK_H)
    head_mask = head_idx < num_heads

    # Head-major / token-minor LSE addressing for this (token, head) strip.
    lse_off = head_idx * num_tokens + token_idx
    p_lse = tl.load(prefix_lse + lse_off, mask=head_mask, other=0.0)
    s_lse = tl.load(suffix_lse + lse_off, mask=head_mask, other=0.0)

    # An empty split can arrive as +inf or -inf depending on which attention
    # pass produced it; collapse +inf onto -inf so its weight is exactly zero.
    p_lse = tl.where(p_lse == float("inf"), float("-inf"), p_lse)
    s_lse = tl.where(s_lse == float("inf"), float("-inf"), s_lse)

    max_lse = tl.maximum(p_lse, s_lse)
    p_lse_c = p_lse - max_lse
    s_lse_c = s_lse - max_lse
    # The exponentials are reused for the mixing scales, so form them once.
    p_se = tl.exp(p_lse_c)
    s_se = tl.exp(s_lse_c)
    out_se = p_se + s_se

    out_lse = tl.log(out_se) + max_lse
    tl.store(output_lse + lse_off, out_lse, mask=head_mask)

    # Scale first, state vectors second.
    p_scale = p_se / out_se
    s_scale = s_se / out_se

    dim_off = dim_blk * PADDED_HEAD_SIZE + tl.arange(0, PADDED_HEAD_SIZE)
    tile_mask = head_mask[:, None] & (dim_off < HEAD_SIZE)[None, :]

    po_ptrs = (
        prefix_output
        + token_idx * stride_po_t
        + (head_idx * stride_po_h)[:, None]
        + (dim_off * stride_po_d)[None, :]
    )
    so_ptrs = (
        suffix_output
        + token_idx * stride_so_t
        + (head_idx * stride_so_h)[:, None]
        + (dim_off * stride_so_d)[None, :]
    )
    o_ptrs = (
        output
        + token_idx * stride_o_t
        + (head_idx * stride_o_h)[:, None]
        + (dim_off * stride_o_d)[None, :]
    )

    p_out = tl.load(po_ptrs, mask=tile_mask, other=0.0).to(tl.float32)
    s_out = tl.load(so_ptrs, mask=tile_mask, other=0.0).to(tl.float32)

    out = p_out * p_scale[:, None] + s_out * s_scale[:, None]

    tl.store(o_ptrs, out.to(output.dtype.element_ty), mask=tile_mask)


def _programs(tokens: int, heads: int, pad_d: int, block_h: int, block_d: int) -> int:
    return tokens * triton.cdiv(heads, block_h) * triton.cdiv(pad_d, block_d)


def _pick_tile(heads: int, pad_d: int, tokens: int) -> tuple[int, int, int]:
    """Choose (BLOCK_H, BLOCK_D, num_warps) for one [BLOCK_H, BLOCK_D] state tile.

    Width starts from a 1024-lane budget. The launch is then made wide enough to
    fill the device: the head block shrinks first because it keeps more
    contiguous state per program, and the head axis splits across dim blocks
    only once the head block is down to one, which is what a long head with few
    tokens needs.
    """
    block_d = min(pad_d, 1024)
    block_h = min(max(1024 // block_d, 1), triton.next_power_of_2(heads))
    while block_h > 1 and _programs(tokens, heads, pad_d, block_h // 2, block_d) < 96:
        block_h //= 2
    while block_d > 32 and block_h == 1 and _programs(tokens, heads, pad_d, 1, block_d) < 96:
        block_d //= 2
    lanes = block_h * block_d
    num_warps = 4 if lanes >= 1024 else (2 if lanes >= 256 else 1)
    return block_h, block_d, num_warps


def npu_triton_impl(inputs: dict) -> dict:
    prefix_output = inputs["prefix_output"]
    prefix_lse = inputs["prefix_lse"]
    suffix_output = inputs["suffix_output"]
    suffix_lse = inputs["suffix_lse"]
    output = inputs["output"]
    output_lse = inputs["output_lse"]

    num_tokens, num_heads, head_size = output.shape

    block_h, block_d, num_warps = _pick_tile(
        num_heads, triton.next_power_of_2(head_size), num_tokens
    )

    grid = (
        num_tokens,
        triton.cdiv(num_heads, block_h),
        triton.cdiv(head_size, block_d),
    )

    _merge_attn_states_kernel[grid](
        output,
        output_lse,
        prefix_output,
        prefix_lse,
        suffix_output,
        suffix_lse,
        num_tokens,
        num_heads,
        prefix_output.stride(0),
        prefix_output.stride(1),
        prefix_output.stride(2),
        suffix_output.stride(0),
        suffix_output.stride(1),
        suffix_output.stride(2),
        output.stride(0),
        output.stride(1),
        output.stride(2),
        HEAD_SIZE=head_size,
        PADDED_HEAD_SIZE=block_d,
        BLOCK_H=block_h,
        num_warps=num_warps,
    )

    # Every tensor the runner handed us comes back under its own key: the two
    # result buffers carry the merge (written in place), the four inputs are not
    # touched by the kernel and go back as the very same objects.
    return {
        "output": output,
        "output_lse": output_lse,
        "prefix_output": prefix_output,
        "prefix_lse": prefix_lse,
        "suffix_output": suffix_output,
        "suffix_lse": suffix_lse,
    }
