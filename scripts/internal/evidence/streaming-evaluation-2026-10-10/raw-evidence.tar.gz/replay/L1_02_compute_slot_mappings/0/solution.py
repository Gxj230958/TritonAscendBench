"""triton-ascend migration of the paged-KV slot-mapping kernel (L1_02).

Semantics (per contract): for token t, with request id r = idx_mapping[t]
and position p = positions[t]:
    slot_mapping[t] = block_table[r, p // block_size] * block_size + p % block_size

All arithmetic is done in int64 end-to-end (inputs are int64, the table
holds int64 block ids, and the reference multiplies/adds in long), so the
result is exact -- no rounding, no promotion surprises.  block_size is a
scalar input that may arrive as a tensor, so it is loaded on-device inside
the kernel and converted to int64 there; nothing is coerced host-side.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _slot_mapping_kernel(
    idx_mapping_ptr,      # [B] int64
    positions_ptr,        # [B] int64
    block_table_ptr,      # [E, N] int64 (accessed via row stride)
    block_table_row_stride,
    block_size_ptr,       # [1] scalar (any int dtype), loaded on-device
    out_ptr,              # [B] int64
    num_tokens,
    BLOCK: tl.constexpr,
):
    pid = tl.program_id(0)
    off = pid * BLOCK + tl.arange(0, BLOCK)
    mask = off < num_tokens

    block_size = tl.load(block_size_ptr).to(tl.int64)

    req = tl.load(idx_mapping_ptr + off, mask=mask, other=0)
    pos = tl.load(positions_ptr + off, mask=mask, other=0)

    # p // block_size is always < N here (positions are drawn in [0, N)),
    # so the table gather index is in range for the masked lanes; the
    # other=0 values used by masked-out lanes are in range as well.
    blk = tl.load(
        block_table_ptr + req * block_table_row_stride + (pos // block_size),
        mask=mask,
        other=0,
    )

    slot = blk * block_size + (pos % block_size)
    tl.store(out_ptr + off, slot, mask=mask)


def npu_triton_impl(inputs: dict) -> dict:
    idx_mapping = inputs["idx_mapping"]
    positions = inputs["positions"]
    block_table = inputs["block_table"]
    block_size = inputs["block_size"]

    num_tokens = idx_mapping.shape[0]
    device = idx_mapping.device

    # Accept block_size as a Python int or an int tensor; normalise to a
    # single-element device tensor without host-side coercion.
    block_size_dev = torch.as_tensor(block_size, dtype=torch.int64).reshape(1).to(device)

    out = torch.empty(num_tokens, dtype=torch.int64, device=device)

    BLOCK = 32
    grid = (triton.cdiv(num_tokens, BLOCK),)

    _slot_mapping_kernel[grid](
        idx_mapping,
        positions,
        block_table,
        block_table.stride(0),
        block_size_dev,
        out,
        num_tokens,
        BLOCK=BLOCK,
    )

    return {"slot_mapping": out}
