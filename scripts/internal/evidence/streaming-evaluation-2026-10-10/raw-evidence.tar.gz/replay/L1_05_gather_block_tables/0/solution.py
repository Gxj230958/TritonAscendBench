"""triton-ascend candidate for L1_05_gather_block_tables (round 5).

Semantics (from contract.md / reference math): gather rows of
``block_table`` per the request index mapping ``idx_mapping``;
output[b, :] = block_table[idx_mapping[b], :], dtype int64, shape [B, N].

Layout notes:
  * block_table: [E, N] int64, read through its native row stride.
  * idx_mapping: [B] int64, each value in [0, E).
  * The kernel is a pure per-row gather (single kv-cache group, complete
    row copy, no padding): every destination row is fully written, so a
    torch.empty output is safe (no zero-initialisation needed).

ROUND-5 DELTA (single, evidence-based geometry change):
  Each program now handles ROWS_PER_PROG = 2 consecutive destination
  rows instead of 1 (grid axis 0 becomes ceil(B / 2)). The per-row
  memory access pattern is byte-identical to the passing round-4
  candidate: same BLOCK_SIZE, same int64 tl.load/tl.store, same mask,
  same num_warps=8.

  Why: the round-4 per-shape evidence splits shapes into two regimes.
  1. 41/49 shapes sit on a ~140us fixed launch/queue floor whose cost
     scales with the number of resident programs (e.g. H7 with B=64
     runs 16% slower than P2 with B=32, despite 8x less data). More
     work per program => half as many programs => less per-program
     scheduling/tile issue overhead inside the harness-visible window.
  2. The large copies (P8 134MB @ 785us ~171GB/s, P6 75MB @ 495us,
     H8 33MB @ 439us with 4096 single-source-row programs) are far
     below 910B HBM peak; halving the program count while doubling the
     in-flight work per program should keep AI cores fed with the same
     total bandwidth budget.
  Correctness is preserved: rows are independent, the second row of a
  pair is masked off when B is odd, and idx_mapping lookups are per-row
  as before. Only the program-to-row mapping changes.
"""

import torch
import triton
import triton.language as tl

ROWS_PER_PROG = 2


@triton.jit
def _gather_block_tables_kernel(
    src_ptr,
    idx_ptr,
    dst_ptr,
    src_stride,  # elements per source row (block_table.stride(0))
    dst_stride,  # elements per destination row
    N,           # row width (runtime)
    B,           # number of destination rows (runtime)
    BLOCK_SIZE: tl.constexpr,
):
    row_group = tl.program_id(0)
    col = tl.program_id(1)

    base_row = row_group * 2
    off = col * BLOCK_SIZE + tl.arange(0, BLOCK_SIZE)
    mask = off < N

    # Row 1 of the pair.
    row = base_row
    if row < B:
        req_idx = tl.load(idx_ptr + row).to(tl.int64)
        src_row_ptr = src_ptr + req_idx * src_stride
        dst_row_ptr = dst_ptr + row * dst_stride
        vals = tl.load(src_row_ptr + off, mask=mask)
        tl.store(dst_row_ptr + off, vals, mask=mask)

    # Row 2 of the pair (masked off when B is odd).
    row = base_row + 1
    if row < B:
        req_idx = tl.load(idx_ptr + row).to(tl.int64)
        src_row_ptr = src_ptr + req_idx * src_stride
        dst_row_ptr = dst_ptr + row * dst_stride
        vals = tl.load(src_row_ptr + off, mask=mask)
        tl.store(dst_row_ptr + off, vals, mask=mask)


def _next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


def npu_triton_impl(inputs: dict) -> dict:
    block_table = inputs["block_table"]   # [E, N] int64
    idx_mapping = inputs["idx_mapping"]   # [B]   int64

    device = block_table.device
    E, N = int(block_table.shape[0]), int(block_table.shape[1])
    B = int(idx_mapping.shape[0])

    src = block_table  # read through native strides (no copy needed)
    src_stride = int(src.stride(0))

    dst = torch.empty((B, N), dtype=torch.int64, device=device)
    dst_stride = N  # contiguous

    # Column-block width: next power of two up to 1024 so small rows
    # stay efficient (identical to rounds 3/4).
    BLOCK_SIZE = min(_next_pow2(N), 1024)
    num_col_blocks = (N + BLOCK_SIZE - 1) // BLOCK_SIZE

    # ROUND 5: 2 destination rows per program.
    num_row_groups = (B + ROWS_PER_PROG - 1) // ROWS_PER_PROG

    _gather_block_tables_kernel[(num_row_groups, num_col_blocks)](
        src,
        idx_mapping,
        dst,
        src_stride,
        dst_stride,
        N,
        B,
        BLOCK_SIZE=BLOCK_SIZE,
        num_warps=8,
    )

    return {"output": dst}
