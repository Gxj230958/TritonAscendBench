"""NPU (Triton-Ascend) implementation of the request-index to global-index gather.

For row ``t`` of ``token_indices`` and column ``k``::

    req    = req_id[t]
    tok    = token_indices[t, k]
    block  = tok // BLOCK_SIZE
    offset = tok %  BLOCK_SIZE
    out    = block_table[req, block] * BLOCK_SIZE + offset

A lane is invalid, and stores ``-1``, when ``tok < 0`` or when the derived
block id leaves the ``block_table`` row.  The op is pure integer gather: no
reduction and no floating point path, so the int32 result is bit exact against
the contract formula.

Entry point: ``npu_triton_impl(inputs: dict) -> dict`` returning
``{"out": int32 [num_tokens, num_cols]}``.

Round 2 change: every shape and stride value becomes a ``tl.constexpr``
argument, and the dense row-major layout is settled on the host before the
launch.  The kernel then takes exactly four runtime arguments (the pointers),
and the address vector ``row * NUM_COLS + col`` is provably unit-stride, so the
vector unit can widen the token load and the out store instead of treating
them as opaque strided reads.  Both effects target what round 1 measured: 42 of
44 shapes reported a flat ~146 us floor, i.e. time that is not element work,
while the shapes above the floor scaled at roughly 1.1 ns per element.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _convert_req_index_to_global_index_kernel(
    # the only runtime arguments: four pointers
    req_id_ptr,             # int32 [num_tokens]
    block_table_ptr,        # int32 [num_requests, max_num_blocks_per_req]
    token_indices_ptr,      # int32 [num_tokens, num_cols]
    out_ptr,                # int32 [num_tokens, num_cols]
    # shapes -- constant-folded by the launcher, dense row-major layout
    num_cols: tl.constexpr,
    max_num_blocks_per_req: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
    BLOCK_N: tl.constexpr,    # upstream tile width along columns
    BLOCK: tl.constexpr,      # columns owned by one program (divisor of num_cols)
    EVEN_COLS: tl.constexpr,  # BLOCK divides num_cols, so masks drop out
):
    # program_id(0) -> token_id (row), program_id(1) -> tile along columns
    token_id = tl.program_id(0)
    tile_id = tl.program_id(1)

    # One scalar load per program: the request selects the block_table row.
    req = tl.load(req_id_ptr + token_id)

    indice_id = tile_id * BLOCK + tl.arange(0, BLOCK)
    col_mask = indice_id < num_cols

    # num_cols is a constant here, so this address vector is unit-stride and
    # the load/store can widen to the vector unit's natural granularity.
    ti_ptr = token_indices_ptr + token_id * num_cols + indice_id
    if EVEN_COLS:
        tok = tl.load(ti_ptr)
    else:
        tok = tl.load(ti_ptr, mask=col_mask, other=0)

    # Only token < 0 propagates as -1.  Clamping negatives to zero first keeps
    # the division on the non-negative path, so floor and truncating semantics
    # cannot diverge here, and no masked-off lane can form a bad address.
    tok_ok = tok >= 0
    tok_pos = tl.where(tok_ok, tok, 0)

    # BLOCK_SIZE is a power-of-two constant, so these become a shift and a
    # mask rather than a divider.
    block_id = tok_pos // BLOCK_SIZE
    inblock_off = tok_pos - block_id * BLOCK_SIZE

    # Guard the block_table access.  block_id is non-negative by construction
    # and bounded by the comparison below, so masked-off lanes can never read
    # past the end of the table; the contract fills those lanes with 0 first.
    valid_block = block_id < max_num_blocks_per_req
    bt_ptr = block_table_ptr + req * max_num_blocks_per_req + block_id
    base = tl.load(bt_ptr, mask=valid_block, other=0)

    out_val = base * BLOCK_SIZE + inblock_off
    out_val = tl.where(tok_ok & valid_block, out_val, -1)

    out_ptr_ij = out_ptr + token_id * num_cols + indice_id
    if EVEN_COLS:
        tl.store(out_ptr_ij, out_val)
    else:
        tl.store(out_ptr_ij, out_val, mask=col_mask)


def _pow2_divisor(value, cap):
    """Largest power of two no greater than ``cap`` that divides ``value``.

    Only ever applied to integers that come from tensor shapes, so no device
    value is read on the host.
    """
    result = 1
    while result * 2 <= cap and value % (result * 2) == 0:
        result *= 2
    return result


def _row_width(num_rows, num_cols):
    """Columns per program, and the resulting tile count per row.

    Upstream walks BLOCK_N (8) columns per program, which is far narrower than
    an Ascend vector unit likes.  Merging several of those tiles into one
    program gives a wide vector tile; the shrinking pass keeps the program
    count high enough for single-row and very narrow inputs.  The tile always
    divides num_cols, so the grid stays exact and no lane is wasted -- the same
    geometry round 1 used, kept deliberately so this round isolates the
    argument-binding and access-pattern changes alone.
    """
    block = _pow2_divisor(num_cols, min(1024, num_cols))
    while block > 16 and num_rows * (num_cols // block) < 64:
        block //= 2
    return block, num_cols // block


# Launch geometry depends on shape metadata only, never on tensor values, so it
# is worked out once per distinct shape and reused by every later call.
_LAUNCH_CONF = {}


def _launch_conf(num_rows, num_cols, max_num_blocks_per_req):
    key = (num_rows, num_cols, max_num_blocks_per_req)
    try:
        return _LAUNCH_CONF[key]
    except KeyError:
        pass
    block, tiles_per_row = _row_width(num_rows, num_cols)
    conf = ((num_rows, tiles_per_row), block, num_cols == block * tiles_per_row)
    # The key space is bounded by the number of distinct input shapes, so the
    # entry count stays small; the guard just keeps a pathological caller from
    # growing it without limit.
    if len(_LAUNCH_CONF) < 4096:
        _LAUNCH_CONF[key] = conf
    return conf


def npu_triton_impl(inputs: dict) -> dict:
    req_id = inputs["req_id"]
    block_table = inputs["block_table"]
    token_indices = inputs["token_indices"]
    # Contract names the two scalar knobs BLOCK_SIZE / BLOCK_N; the lowercase
    # spelling from the I/O section is accepted as well.
    try:
        block_size = inputs["BLOCK_SIZE"]
    except KeyError:
        block_size = inputs["block_size"]
    if "BLOCK_N" in inputs:
        block_n = inputs["BLOCK_N"]
    else:
        block_n = 8

    # The kernel indexes a dense row-major layout, so the strides it would
    # otherwise need are just the shapes.  contiguous() hands back the same
    # storage for the dense inputs the runner builds, and a real copy for
    # anything else, which keeps strided inputs correct too.
    req_c = req_id.contiguous()
    bt_c = block_table.contiguous()
    ti_c = token_indices.contiguous()
    out = torch.empty_like(ti_c)

    num_rows = ti_c.shape[0]
    num_cols = ti_c.shape[1]
    max_num_blocks_per_req = bt_c.shape[1]

    grid, block, even_cols = _launch_conf(
        num_rows, num_cols, max_num_blocks_per_req
    )

    _convert_req_index_to_global_index_kernel[grid](
        req_c,
        bt_c,
        ti_c,
        out,
        # shapes / constants -- no runtime scalars reach the launcher
        num_cols,
        max_num_blocks_per_req,
        block_size,
        block_n,
        block,
        even_cols,
    )

    return {"out": out}
