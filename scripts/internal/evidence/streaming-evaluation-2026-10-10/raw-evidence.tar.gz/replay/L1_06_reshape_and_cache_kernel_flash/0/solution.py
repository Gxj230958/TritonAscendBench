"""NPU triton-ascend migration of the paged KV-cache reshape-and-scatter op.

Scatters new per-token K/V into a paged (rank-4) flash KV cache following
``slot_mapping``:

    key/value : [n_tokens, n_kvh, head_size]          (bfloat16)
    *_cache   : [n_blocks, block_size, n_kvh, head_size] (bfloat16)
    slot      = block_idx * block_size + block_offset

Design (round 3): three cooperating Triton-Ascend kernel launches, all
serialized on the same stream:

1. ``_copy_flat`` on the key cache: contiguous flat 1D copy from the input
   cache into a freshly allocated output.
2. ``_copy_flat`` on the value cache: same.
3. ``_scatter_kv``: gathers each token's row from key/value and stores it
   into the output row selected by ``slot_mapping``.

Why the copy changed from round 2: round 2's copy kernel was a
(n_rows, n_tiles) grid where every program moved two 64-byte half-rows
(one for key, one for value).  The receipt shows that hurt exactly the
shapes where the full-cache traffic dominates: on the two ~134 MB-per-
tensor caches (P4, H3) and the ~28 MB caches (P6, P10) round 2 measured
1.5-2.7x SLOWER than the reference's two native torch copy kernels, i.e.
its triton copy achieved only ~190 GB/s while the native copy sustains
~500 GB/s on 910B HBM.  Tiny programs with a single 128-byte access per
vector are a poor fit for the AI CPU/AI Core scheduling; the copy kernel
also did two logical tensors in one program, coupling their vector
pipelines.

Round 3's ``_copy_flat`` is a plain linear copy: one 1-D grid of
8192-element (16 KiB bf16) spans per program, per tensor, int32 offsets
(cache is < 2^31 elements so no int64 index math in the inner path),
num_warps=8 -> one contiguous 2 KiB bf16 vector per lane.  Each launch
streams a whole contiguous memory region, which is what the native copy
does well.  Two contiguous 1-D copies plus one scatter replace round 2's
coupled row-major pass; the extra launch is cheap compared to the
recoverd streaming bandwidth on the large-cache shapes.

Scatter (unchanged from round 2, correctness-verified 46/46): the
contract makes ``slot_mapping`` monotonically non-decreasing, so tokens
sharing a slot form one contiguous group and the reference's
advanced-indexing assignment resolves duplicates with last-write-wins;
only the final token of each group stores (nxt != s), which also removes
any same-address write hazard between programs of one launch.

bfloat16 end to end; pure move, no arithmetic, so outputs are
bit-identical to the reference values.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _copy_flat(
    src, dst,
    N: tl.constexpr, SPAN: tl.constexpr,
):
    pid = tl.program_id(axis=0)
    off = pid * SPAN + tl.arange(0, SPAN)
    m = off < N
    x = tl.load(src + off, mask=m)
    tl.store(dst + off, x, mask=m)


@triton.jit
def _scatter_kv(
    key, value, kc_out, vc_out, slot_mapping,
    n_tokens: tl.int32,
    N_HD: tl.constexpr, TILE: tl.constexpr,
):
    tok = tl.program_id(axis=0)
    tile = tl.program_id(axis=1)
    s = tl.load(slot_mapping + tok)
    # Monotonic slot_mapping: token tok loses the duplicate-slot race iff
    # the next token maps to the same slot.  (out-of-range load masked to -1)
    nxt = tl.load(slot_mapping + tok + 1, mask=(tok + 1 < n_tokens), other=-1)
    if nxt != s:
        pos = tile * TILE + tl.arange(0, TILE)
        m = pos < N_HD
        src = tok.to(tl.int64) * N_HD + pos
        k = tl.load(key + src, mask=m)
        v = tl.load(value + src, mask=m)
        dst = s * N_HD + pos
        tl.store(kc_out + dst, k, mask=m)
        tl.store(vc_out + dst, v, mask=m)


def npu_triton_impl(inputs: dict) -> dict:
    key = inputs["key"].contiguous()
    value = inputs["value"].contiguous()
    kc_in = inputs["key_cache"].contiguous()
    vc_in = inputs["value_cache"].contiguous()
    slot = inputs["slot_mapping"]

    # Fresh outputs; the copy launches write every element, the scatter
    # launch overwrites the scattered rows.
    kc_out = torch.empty_like(kc_in)
    vc_out = torch.empty_like(vc_in)

    n_cache = kc_in.shape[0] * kc_in.shape[1] * kc_in.shape[2] * kc_in.shape[3]
    n_hd = key.shape[1] * key.shape[2]
    n_tokens = slot.shape[0]

    # Contiguous flat copies (one launch per tensor), int32 offsets are
    # safe: largest cache is 67108864 elements < 2^31.
    span = 8192
    _copy_flat[(triton.cdiv(n_cache, span),)](
        kc_in, kc_out, N=n_cache, SPAN=span,
        num_warps=8, num_stages=1,
    )
    _copy_flat[(triton.cdiv(n_cache, span),)](
        vc_in, vc_out, N=n_cache, SPAN=span,
        num_warps=8, num_stages=1,
    )

    tile = min(2048, triton.next_power_of_2(n_hd))
    n_tiles = triton.cdiv(n_hd, tile)
    # Scatter the new K/V rows on top (stream-ordered after the copies).
    _scatter_kv[(n_tokens, n_tiles)](
        key, value, kc_out, vc_out, slot, n_tokens,
        N_HD=n_hd, TILE=tile,
        num_warps=8, num_stages=1,
    )

    return {"key_cache": kc_out, "value_cache": vc_out}
