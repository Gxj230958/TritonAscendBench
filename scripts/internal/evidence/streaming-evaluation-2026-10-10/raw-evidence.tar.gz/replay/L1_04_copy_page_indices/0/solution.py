"""triton-ascend migration of the page-index flattening operator.

For every request r, emit ceil(seq_lens[r]/page_size) page ids from
block_table[r, ...] into a flat int32 kv_indices vector (FlashInfer
layout). All numeric work is done by triton-ascend kernels:

  * _total_pages_kernel   : one program sums ceil(seq_lens/page_size)
                            over all requests into a 1-element int32
                            buffer (total_t) so the output can be
                            allocated at exactly the right length.
  * _copy_page_indices_kernel: launched with grid (E,); each program r
                            recomputes the per-request page counts from
                            seq_lens, derives its output offset as a
                            masked tl.sum (exclusive prefix) and copies
                            the used block_table row entries into the
                            flat int32 output. Loaded int64 block ids
                            are explicitly cast to int32 before the
                            store (round 1 fix), mirroring the upstream
                            reference which truncates int64 block ids
                            when writing the int32 buffer.

Round 1 fix (dtype): the output buffer must be int32. Round 1 allocated
it as seq_lens.new_empty(total_t), which preserves seq_lens' int64
dtype and produced an int64 result. It is now allocated as
total_t.new_empty(total_t): total_t is the int32 buffer written by the
first kernel, so new_empty both sizes the tensor from the device-side
total (no host read) and yields the required int32 dtype.

The host only performs allocations and grid/constexpr sizing from
static shape metadata.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _total_pages_kernel(seq_lens, page_size, total, E, TOTAL_REQS: tl.constexpr):
    reqs = tl.arange(0, TOTAL_REQS)
    mask = reqs < E
    s = tl.load(seq_lens + reqs, mask=mask, other=0).to(tl.int64)
    # ceil(seq_lens / page_size), matching the upstream build() formula.
    n = ((s + (page_size - 1)) // page_size).to(tl.int32)
    tl.store(total, tl.sum(n))


@triton.jit
def _copy_page_indices_kernel(
    page_indices,
    block_table,
    block_table_stride,
    seq_lens,
    page_size,
    E,
    TOTAL_REQS: tl.constexpr,
    BLOCK_SIZE: tl.constexpr,
):
    req_idx = tl.program_id(0)
    reqs = tl.arange(0, TOTAL_REQS)
    mask = reqs < E
    s_all = tl.load(seq_lens + reqs, mask=mask, other=0).to(tl.int64)
    # per-request page counts (int32), matching upstream dtype handling.
    n_all = ((s_all + (page_size - 1)) // page_size).to(tl.int32)
    # exclusive prefix for request r and its own count.
    start_idx = tl.sum(tl.where(reqs < req_idx, n_all, 0))
    num_blocks = tl.sum(tl.where(reqs == req_idx, n_all, 0))
    row_ptr = block_table + req_idx * block_table_stride
    offset = tl.arange(0, BLOCK_SIZE)
    for i in range(0, num_blocks, BLOCK_SIZE):
        m = i + offset < num_blocks
        # explicit int64 -> int32 cast (round 1 fix): the upstream
        # reference truncates block ids when writing the int32 buffer.
        block_ids = tl.load(row_ptr + i + offset, mask=m).to(tl.int32)
        tl.store(
            page_indices + start_idx + i + offset,
            block_ids,
            mask=m,
        )


def npu_triton_impl(inputs: dict) -> dict:
    block_table = inputs["block_table"]
    seq_lens = inputs["seq_lens"]
    page_size = inputs["page_size"]

    num_reqs = seq_lens.shape[0]
    total_reqs = triton.next_power_of_2(num_reqs)
    device = block_table.device

    # Data-dependent total page count (int32, one element).
    total_t = torch.empty(1, dtype=torch.int32, device=device)
    _total_pages_kernel[(1,)](seq_lens, page_size, total_t, num_reqs,
                              TOTAL_REQS=total_reqs)

    # Flat int32 output sized by the kernel-computed total. Allocating
    # from total_t (the int32 buffer) gives the correct int32 dtype
    # while the 1-element tensor supplies the length device-side.
    page_indices = total_t.new_empty(total_t)

    _copy_page_indices_kernel[(num_reqs,)](
        page_indices,
        block_table,
        block_table.stride(0),
        seq_lens,
        page_size,
        num_reqs,
        TOTAL_REQS=total_reqs,
        BLOCK_SIZE=1024,
    )
    return {"kv_indices": page_indices}
