"""L1_01_bias — triton-ascend migration of the per-token sampler logit-bias
kernel (see kernel.py in the task directory for the upstream GPU reference).

Per token row ``t`` with request index ``r = expanded_idx_mapping[t]`` the
kernel applies, strictly in this order (order is load-bearing):

  Stage 1 (allowed-token allowlist):
      if num_allowed_token_ids[r] > 0:
          save logits[t, allowed]          (fp32, no cast)
          fill logits[t, :] with -inf      (block loop over vocab)
          restore logits[t, allowed]
  Stage 2 (additive logit bias):
      if num_logit_bias[r] > 0:
          logits[t, ids] += logit_bias     (fp32 add; -inf + bias == -inf)
  Stage 3 (min-length stop suppression):
      if num_stop_token_ids[r] > 0 and pos[t] < min_lens[r]:
          logits[t, sids] = -inf

``logits`` is mutated in place. Accumulation stays fp32 end to end (no dtype
widening, no early casts) so the additive results are exact in fp32 and the
-infinities are preserved exactly (elementwise_exact_or_inf_safe class).

Semantics notes preserved from upstream:
  * index tables are int64; pointer arithmetic uses the row strides read from
    the 2-D tables (allowed/bias/stop id tables have a per-row stride);
  * masked lanes of the id gathers default to 0 but are never read/written
    because the same mask is reused on the corresponding scatter;
  * ``BLOCK_SIZE`` is the next power of two over the widest id table column
    (8 in all shapes) and ``LOGITS_BLOCK_SIZE`` is the full-row fill tile
    (8192), both passed as tl.constexpr.
"""

import torch
import triton
import triton.language as tl


@triton.jit
def _bias_kernel(
    logits_ptr,
    logits_stride,
    vocab_size,
    expanded_idx_mapping_ptr,
    num_allowed_token_ids_ptr,
    allowed_token_ids_ptr,
    allowed_token_ids_stride,
    num_logit_bias_ptr,
    bias_token_ids_ptr,
    bias_token_ids_stride,
    bias_ptr,
    bias_stride,
    pos_ptr,
    min_lens_ptr,
    num_stop_token_ids_ptr,
    stop_token_ids_ptr,
    stop_token_ids_stride,
    BLOCK_SIZE: tl.constexpr,
    LOGITS_BLOCK_SIZE: tl.constexpr,
):
    token_idx = tl.program_id(0)
    req_state_idx = tl.load(expanded_idx_mapping_ptr + token_idx)

    block = tl.arange(0, BLOCK_SIZE)

    # ---- Stage 1: allowed-token allowlist (save / fill -inf / restore) ----
    num_allowed_token_ids = tl.load(num_allowed_token_ids_ptr + req_state_idx)
    if num_allowed_token_ids > 0:
        block = tl.arange(0, BLOCK_SIZE)
        mask = block < num_allowed_token_ids
        allowed_token_ids = tl.load(
            allowed_token_ids_ptr + req_state_idx * allowed_token_ids_stride + block,
            mask=mask,
        )
        logits = tl.load(
            logits_ptr + token_idx * logits_stride + allowed_token_ids, mask=mask
        )
        for i in range(0, vocab_size, LOGITS_BLOCK_SIZE):
            offset = i + tl.arange(0, LOGITS_BLOCK_SIZE)
            tl.store(
                logits_ptr + token_idx * logits_stride + offset,
                -float("inf"),
                mask=offset < vocab_size,
            )
        tl.store(
            logits_ptr + token_idx * logits_stride + allowed_token_ids,
            logits,
            mask=mask,
        )

    # ---- Stage 2: additive logit bias (fp32 read-modify-write) ----
    num_logit_bias = tl.load(num_logit_bias_ptr + req_state_idx)
    if num_logit_bias > 0:
        mask = block < num_logit_bias
        token_ids = tl.load(
            bias_token_ids_ptr + req_state_idx * bias_token_ids_stride + block,
            mask=mask,
        )
        bias = tl.load(bias_ptr + req_state_idx * bias_stride + block, mask=mask)
        logits = tl.load(logits_ptr + token_idx * logits_stride + token_ids, mask=mask)
        logits += bias
        tl.store(logits_ptr + token_idx * logits_stride + token_ids, logits, mask=mask)

    # ---- Stage 3: min-length stop-token suppression ----
    num_stop_token_ids = tl.load(num_stop_token_ids_ptr + req_state_idx)
    pos = tl.load(pos_ptr + token_idx)
    min_len = tl.load(min_lens_ptr + req_state_idx)
    if num_stop_token_ids > 0 and pos < min_len:
        mask = block < num_stop_token_ids
        stop_token_ids = tl.load(
            stop_token_ids_ptr + req_state_idx * stop_token_ids_stride + block,
            mask=mask,
        )
        tl.store(
            logits_ptr + token_idx * logits_stride + stop_token_ids,
            -float("inf"),
            mask=mask,
        )


def apply_logit_bias(
    logits: torch.Tensor,
    expanded_idx_mapping: torch.Tensor,
    pos: torch.Tensor,
    num_allowed_token_ids: torch.Tensor,
    allowed_token_ids: torch.Tensor,
    num_logit_bias: torch.Tensor,
    logit_bias_token_ids: torch.Tensor,
    logit_bias: torch.Tensor,
    min_lens: torch.Tensor,
    num_stop_token_ids: torch.Tensor,
    stop_token_ids: torch.Tensor,
) -> None:
    """In-place transform on ``logits``. Same host-side launch recipe as
    upstream: one program per token row, ``BLOCK_SIZE`` = next power of two
    over the widest per-request id table, full-row fill tile 8192."""
    num_tokens, vocab_size = logits.shape
    BLOCK_SIZE = triton.next_power_of_2(
        max(
            allowed_token_ids.shape[-1],
            logit_bias_token_ids.shape[-1],
            stop_token_ids.shape[-1],
        )
    )
    LOGITS_BLOCK_SIZE = 8192
    _bias_kernel[(num_tokens,)](
        logits,
        logits.stride(0),
        vocab_size,
        expanded_idx_mapping,
        num_allowed_token_ids,
        allowed_token_ids,
        allowed_token_ids.stride(0),
        num_logit_bias,
        logit_bias_token_ids,
        logit_bias_token_ids.stride(0),
        logit_bias,
        logit_bias.stride(0),
        pos,
        min_lens,
        num_stop_token_ids,
        stop_token_ids,
        stop_token_ids.stride(0),
        BLOCK_SIZE=BLOCK_SIZE,
        LOGITS_BLOCK_SIZE=LOGITS_BLOCK_SIZE,
    )


def npu_triton_impl(inputs: dict) -> dict:
    """TAB entrypoint.

    Runs the in-place three-stage transform on ``inputs["logits"]`` and
    mirrors the reference output structure: the transformed ``logits`` plus
    the ten untouched read-only tables echoed back (same keys/arity).
    """
    apply_logit_bias(
        inputs["logits"],
        inputs["expanded_idx_mapping"],
        inputs["pos"],
        inputs["num_allowed_token_ids"],
        inputs["allowed_token_ids"],
        inputs["num_logit_bias"],
        inputs["logit_bias_token_ids"],
        inputs["logit_bias"],
        inputs["min_lens"],
        inputs["num_stop_token_ids"],
        inputs["stop_token_ids"],
    )
    return {
        "logits": inputs["logits"],
        "expanded_idx_mapping": inputs["expanded_idx_mapping"],
        "pos": inputs["pos"],
        "num_allowed_token_ids": inputs["num_allowed_token_ids"],
        "allowed_token_ids": inputs["allowed_token_ids"],
        "num_logit_bias": inputs["num_logit_bias"],
        "logit_bias_token_ids": inputs["logit_bias_token_ids"],
        "logit_bias": inputs["logit_bias"],
        "min_lens": inputs["min_lens"],
        "num_stop_token_ids": inputs["num_stop_token_ids"],
        "stop_token_ids": inputs["stop_token_ids"],
    }
